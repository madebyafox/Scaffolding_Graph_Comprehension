var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05214393f7f79c589517cf9500d0d8eedb7f21d7"] = {
  "startTime": "2018-05-21T16:15:43.8243113Z",
  "websitePageUrl": "/16",
  "visitTime": 134282,
  "engagementTime": 90835,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "ce949a7b240215792d57dd83aa4d1805",
    "created": "2018-05-21T16:15:43.8243113+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=9D6O3",
      "CONDITION=3"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4bd2c0ec4c5ea2f797ce7e00045e2ac3",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/ce949a7b240215792d57dd83aa4d1805/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 172,
      "e": 172,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 172,
      "e": 172,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 531,
      "y": 764
    },
    {
      "t": 869,
      "e": 869,
      "ty": 6,
      "x": 452,
      "y": 666,
      "ta": "#strategyButton"
    },
    {
      "t": 886,
      "e": 886,
      "ty": 7,
      "x": 443,
      "y": 653,
      "ta": "#strategyButton"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 443,
      "y": 653
    },
    {
      "t": 953,
      "e": 953,
      "ty": 6,
      "x": 412,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 401,
      "y": 582
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 34162,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 395,
      "y": 571
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 394,
      "y": 570
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 33375,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 398,
      "y": 578
    },
    {
      "t": 2324,
      "e": 2324,
      "ty": 7,
      "x": 474,
      "y": 626,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 810,
      "y": 739
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 1075,
      "y": 803
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 20366,
      "y": 47629,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 1106,
      "y": 812
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 1143,
      "y": 879
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 27272,
      "y": 55149,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 1206,
      "y": 926
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 1249,
      "y": 941
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 1257,
      "y": 948
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 33191,
      "y": 58014,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3099,
      "e": 3099,
      "ty": 2,
      "x": 1249,
      "y": 972
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 1209,
      "y": 985
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 28188,
      "y": 61022,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 1177,
      "y": 990
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 1169,
      "y": 986
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 1150,
      "y": 963
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 21586,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 1149,
      "y": 963
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 25580,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 1145,
      "y": 953
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 1129,
      "y": 885
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 1116,
      "y": 808
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 23255,
      "y": 47987,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 1115,
      "y": 732
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 1115,
      "y": 710
    },
    {
      "t": 4250,
      "e": 4250,
      "ty": 41,
      "x": 23255,
      "y": 40753,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1120,
      "y": 703
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 1128,
      "y": 691
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 826,
      "y": 548
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 2819,
      "y": 29365,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 538,
      "y": 479
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 512,
      "y": 505
    },
    {
      "t": 4723,
      "e": 4723,
      "ty": 6,
      "x": 504,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 45740,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 500,
      "y": 542
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 498,
      "y": 547
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 41,
      "x": 45065,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5012,
      "e": 5012,
      "ty": 3,
      "x": 498,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5012,
      "e": 5012,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5172,
      "e": 5172,
      "ty": 4,
      "x": 45065,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5172,
      "e": 5172,
      "ty": 5,
      "x": 498,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8278,
      "e": 8278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 8518,
      "e": 8518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 8518,
      "e": 8518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8542,
      "e": 8542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 8734,
      "e": 8734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 8797,
      "e": 8797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 8934,
      "e": 8934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 9198,
      "e": 9198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9198,
      "e": 9198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9342,
      "e": 9342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B "
    },
    {
      "t": 9774,
      "e": 9774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9774,
      "e": 9774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9927,
      "e": 9927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B a"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10014,
      "e": 10014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10014,
      "e": 10014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10150,
      "e": 10150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B an"
    },
    {
      "t": 10358,
      "e": 10358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 10359,
      "e": 10359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10534,
      "e": 10534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 10591,
      "e": 10591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10592,
      "e": 10592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10742,
      "e": 10742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10862,
      "e": 10862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 11102,
      "e": 11102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11557,
      "e": 11557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 11558,
      "e": 11558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11678,
      "e": 11678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 11726,
      "e": 11726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 11886,
      "e": 11886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12429,
      "e": 12429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12430,
      "e": 12430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12525,
      "e": 12525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14782,
      "e": 14782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14886,
      "e": 14886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F"
    },
    {
      "t": 15062,
      "e": 15062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15185,
      "e": 15185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and "
    },
    {
      "t": 15313,
      "e": 15313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15386,
      "e": 15386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and"
    },
    {
      "t": 15514,
      "e": 15514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15602,
      "e": 15602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B an"
    },
    {
      "t": 15826,
      "e": 15826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15922,
      "e": 15922,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B a"
    },
    {
      "t": 16370,
      "e": 16370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16482,
      "e": 16482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B "
    },
    {
      "t": 16610,
      "e": 16610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16610,
      "e": 16610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16771,
      "e": 16771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B e"
    },
    {
      "t": 16891,
      "e": 16891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16892,
      "e": 16892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17006,
      "e": 17006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B en"
    },
    {
      "t": 17018,
      "e": 17018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B en"
    },
    {
      "t": 17066,
      "e": 17066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17066,
      "e": 17066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17186,
      "e": 17186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17188,
      "e": 17188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17274,
      "e": 17274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 17419,
      "e": 17419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17515,
      "e": 17515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17516,
      "e": 17516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17626,
      "e": 17626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18257,
      "e": 18257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18258,
      "e": 18258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18386,
      "e": 18386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18387,
      "e": 18387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18474,
      "e": 18474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 18506,
      "e": 18506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18538,
      "e": 18538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18538,
      "e": 18538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18706,
      "e": 18706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18778,
      "e": 18778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18778,
      "e": 18778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18898,
      "e": 18898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19106,
      "e": 19106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19106,
      "e": 19106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19258,
      "e": 19258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19258,
      "e": 19258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19330,
      "e": 19330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 19370,
      "e": 19370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19546,
      "e": 19546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19546,
      "e": 19546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19658,
      "e": 19658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20005,
      "e": 20005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20338,
      "e": 20338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 20338,
      "e": 20338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20498,
      "e": 20498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20499,
      "e": 20499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20514,
      "e": 20514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ft"
    },
    {
      "t": 20586,
      "e": 20586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20866,
      "e": 20866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20866,
      "e": 20866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20953,
      "e": 20953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21026,
      "e": 21026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21027,
      "e": 21027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21194,
      "e": 21194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 21219,
      "e": 21219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 21219,
      "e": 21219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21370,
      "e": 21370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 21523,
      "e": 21523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21523,
      "e": 21523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21666,
      "e": 21666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 21762,
      "e": 21762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21763,
      "e": 21763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21898,
      "e": 21898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22562,
      "e": 22562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22618,
      "e": 22618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B ends the shift abd"
    },
    {
      "t": 22730,
      "e": 22730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22810,
      "e": 22810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B ends the shift ab"
    },
    {
      "t": 22978,
      "e": 22978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23050,
      "e": 23050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B ends the shift a"
    },
    {
      "t": 23547,
      "e": 23547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23547,
      "e": 23547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23682,
      "e": 23682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23867,
      "e": 23867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23868,
      "e": 23868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24008,
      "e": 24008,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B ends the shift and"
    },
    {
      "t": 24059,
      "e": 24059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 24066,
      "e": 24066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24067,
      "e": 24067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24178,
      "e": 24178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30004,
      "e": 29178,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30723,
      "e": 29178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31223,
      "e": 29678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31255,
      "e": 29710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31288,
      "e": 29743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31321,
      "e": 29776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31354,
      "e": 29809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31387,
      "e": 29842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31420,
      "e": 29875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31453,
      "e": 29908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31486,
      "e": 29941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31519,
      "e": 29974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31552,
      "e": 30007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31585,
      "e": 30040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31618,
      "e": 30073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31651,
      "e": 30106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31684,
      "e": 30139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31717,
      "e": 30172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31730,
      "e": 30185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B en"
    },
    {
      "t": 32034,
      "e": 30489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32146,
      "e": 30601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B e"
    },
    {
      "t": 32426,
      "e": 30881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32514,
      "e": 30969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B "
    },
    {
      "t": 32761,
      "e": 31216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32762,
      "e": 31217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32938,
      "e": 31393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B a"
    },
    {
      "t": 33002,
      "e": 31457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33002,
      "e": 31457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33146,
      "e": 31601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B an"
    },
    {
      "t": 33177,
      "e": 31632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33178,
      "e": 31633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33386,
      "e": 31841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 33402,
      "e": 31857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33403,
      "e": 31858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33506,
      "e": 31961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34146,
      "e": 32601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 34274,
      "e": 32729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34554,
      "e": 33009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34554,
      "e": 33009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34722,
      "e": 33177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 34970,
      "e": 33425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 35154,
      "e": 33609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35578,
      "e": 34033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35578,
      "e": 34033,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35706,
      "e": 34161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38098,
      "e": 36553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38098,
      "e": 36553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38206,
      "e": 36661,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F s"
    },
    {
      "t": 38250,
      "e": 36705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 38250,
      "e": 36705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38274,
      "e": 36729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 38370,
      "e": 36825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38498,
      "e": 36953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38498,
      "e": 36953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38606,
      "e": 37061,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shi"
    },
    {
      "t": 38609,
      "e": 37064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 38874,
      "e": 37329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 38874,
      "e": 37329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39006,
      "e": 37461,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shif"
    },
    {
      "t": 39058,
      "e": 37513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 39105,
      "e": 37560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39106,
      "e": 37561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39186,
      "e": 37641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39273,
      "e": 37728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39273,
      "e": 37728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39406,
      "e": 37861,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts"
    },
    {
      "t": 39410,
      "e": 37865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39458,
      "e": 37913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39458,
      "e": 37913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39561,
      "e": 38016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39827,
      "e": 38282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39827,
      "e": 38282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39962,
      "e": 38417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39977,
      "e": 38432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39978,
      "e": 38433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40004,
      "e": 38459,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40049,
      "e": 38504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40194,
      "e": 38649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40194,
      "e": 38649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40354,
      "e": 38809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40362,
      "e": 38817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40362,
      "e": 38817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40522,
      "e": 38977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40570,
      "e": 39025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40570,
      "e": 39025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40642,
      "e": 39097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40866,
      "e": 39321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40866,
      "e": 39321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40985,
      "e": 39440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41082,
      "e": 39537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41082,
      "e": 39537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41206,
      "e": 39661,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start a"
    },
    {
      "t": 41218,
      "e": 39673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 41257,
      "e": 39712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 41259,
      "e": 39714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41379,
      "e": 39834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 41475,
      "e": 39930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 41476,
      "e": 39931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41578,
      "e": 40033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 41634,
      "e": 40089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41634,
      "e": 40089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41806,
      "e": 40261,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start abd "
    },
    {
      "t": 41818,
      "e": 40273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42249,
      "e": 40704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 42250,
      "e": 40705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42370,
      "e": 40825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||="
    },
    {
      "t": 42465,
      "e": 40920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 42466,
      "e": 40921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42546,
      "e": 41001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||="
    },
    {
      "t": 42739,
      "e": 41194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42841,
      "e": 41296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start abd ="
    },
    {
      "t": 42938,
      "e": 41393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43058,
      "e": 41513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start abd "
    },
    {
      "t": 43130,
      "e": 41585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43250,
      "e": 41705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start abd"
    },
    {
      "t": 43282,
      "e": 41737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43407,
      "e": 41862,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start ab"
    },
    {
      "t": 43419,
      "e": 41874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start ab"
    },
    {
      "t": 43498,
      "e": 41953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43594,
      "e": 42049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start a"
    },
    {
      "t": 43714,
      "e": 42169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43817,
      "e": 42272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts start "
    },
    {
      "t": 45105,
      "e": 43560,
      "ty": 2,
      "x": 492,
      "y": 577
    },
    {
      "t": 45127,
      "e": 43582,
      "ty": 7,
      "x": 484,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45204,
      "e": 43659,
      "ty": 2,
      "x": 475,
      "y": 639
    },
    {
      "t": 45256,
      "e": 43711,
      "ty": 41,
      "x": 42480,
      "y": 34955,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 45305,
      "e": 43760,
      "ty": 2,
      "x": 471,
      "y": 638
    },
    {
      "t": 45328,
      "e": 43783,
      "ty": 6,
      "x": 414,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45344,
      "e": 43799,
      "ty": 7,
      "x": 351,
      "y": 503,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45405,
      "e": 43860,
      "ty": 2,
      "x": 291,
      "y": 472
    },
    {
      "t": 45505,
      "e": 43960,
      "ty": 2,
      "x": 289,
      "y": 470
    },
    {
      "t": 45506,
      "e": 43961,
      "ty": 41,
      "x": 21572,
      "y": 25593,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 45605,
      "e": 44060,
      "ty": 2,
      "x": 262,
      "y": 511
    },
    {
      "t": 45645,
      "e": 44100,
      "ty": 6,
      "x": 254,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45705,
      "e": 44160,
      "ty": 2,
      "x": 240,
      "y": 534
    },
    {
      "t": 45755,
      "e": 44210,
      "ty": 41,
      "x": 13366,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45804,
      "e": 44259,
      "ty": 2,
      "x": 210,
      "y": 524
    },
    {
      "t": 45904,
      "e": 44359,
      "ty": 2,
      "x": 209,
      "y": 524
    },
    {
      "t": 46005,
      "e": 44460,
      "ty": 2,
      "x": 198,
      "y": 555
    },
    {
      "t": 46005,
      "e": 44460,
      "ty": 41,
      "x": 11342,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46105,
      "e": 44560,
      "ty": 2,
      "x": 201,
      "y": 554
    },
    {
      "t": 46205,
      "e": 44660,
      "ty": 2,
      "x": 215,
      "y": 549
    },
    {
      "t": 46255,
      "e": 44710,
      "ty": 41,
      "x": 13591,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46305,
      "e": 44760,
      "ty": 2,
      "x": 218,
      "y": 547
    },
    {
      "t": 46405,
      "e": 44860,
      "ty": 2,
      "x": 225,
      "y": 540
    },
    {
      "t": 46505,
      "e": 44960,
      "ty": 2,
      "x": 227,
      "y": 536
    },
    {
      "t": 46505,
      "e": 44960,
      "ty": 41,
      "x": 14602,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46528,
      "e": 44983,
      "ty": 3,
      "x": 227,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46649,
      "e": 45104,
      "ty": 4,
      "x": 14602,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46649,
      "e": 45104,
      "ty": 5,
      "x": 227,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46744,
      "e": 45199,
      "ty": 3,
      "x": 227,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46848,
      "e": 45303,
      "ty": 4,
      "x": 14602,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46848,
      "e": 45303,
      "ty": 5,
      "x": 227,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47491,
      "e": 45946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47491,
      "e": 45946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47606,
      "e": 46061,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts e"
    },
    {
      "t": 47642,
      "e": 46097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts e"
    },
    {
      "t": 47803,
      "e": 46258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 47803,
      "e": 46258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47961,
      "e": 46416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 48098,
      "e": 46553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 48099,
      "e": 46554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48206,
      "e": 46661,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts end"
    },
    {
      "t": 48233,
      "e": 46688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 49081,
      "e": 47536,
      "ty": 7,
      "x": 264,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49104,
      "e": 47559,
      "ty": 2,
      "x": 269,
      "y": 615
    },
    {
      "t": 49204,
      "e": 47659,
      "ty": 2,
      "x": 320,
      "y": 662
    },
    {
      "t": 49248,
      "e": 47703,
      "ty": 6,
      "x": 350,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 49255,
      "e": 47710,
      "ty": 41,
      "x": 6229,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 49304,
      "e": 47759,
      "ty": 2,
      "x": 357,
      "y": 681
    },
    {
      "t": 49404,
      "e": 47859,
      "ty": 2,
      "x": 376,
      "y": 670
    },
    {
      "t": 49504,
      "e": 47959,
      "ty": 41,
      "x": 20428,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 49513,
      "e": 47968,
      "ty": 3,
      "x": 376,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 49515,
      "e": 47970,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B and F shifts end"
    },
    {
      "t": 49516,
      "e": 47971,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49517,
      "e": 47972,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 49615,
      "e": 48070,
      "ty": 4,
      "x": 20428,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 49624,
      "e": 48079,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 49626,
      "e": 48079,
      "ty": 5,
      "x": 376,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 49635,
      "e": 48088,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 49704,
      "e": 48157,
      "ty": 2,
      "x": 377,
      "y": 669
    },
    {
      "t": 49755,
      "e": 48208,
      "ty": 41,
      "x": 12707,
      "y": 36617,
      "ta": "html > body"
    },
    {
      "t": 50630,
      "e": 49083,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 51004,
      "e": 49457,
      "ty": 2,
      "x": 376,
      "y": 669
    },
    {
      "t": 51004,
      "e": 49457,
      "ty": 41,
      "x": 12673,
      "y": 36617,
      "ta": "html > body"
    },
    {
      "t": 51255,
      "e": 49708,
      "ty": 41,
      "x": 14498,
      "y": 35398,
      "ta": "html > body"
    },
    {
      "t": 51304,
      "e": 49757,
      "ty": 2,
      "x": 654,
      "y": 632
    },
    {
      "t": 51404,
      "e": 49857,
      "ty": 2,
      "x": 797,
      "y": 616
    },
    {
      "t": 51504,
      "e": 49957,
      "ty": 2,
      "x": 822,
      "y": 604
    },
    {
      "t": 51504,
      "e": 49957,
      "ty": 41,
      "x": 3028,
      "y": 7021,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 51583,
      "e": 50036,
      "ty": 6,
      "x": 850,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51604,
      "e": 50057,
      "ty": 2,
      "x": 853,
      "y": 569
    },
    {
      "t": 51704,
      "e": 50157,
      "ty": 2,
      "x": 855,
      "y": 564
    },
    {
      "t": 51755,
      "e": 50208,
      "ty": 41,
      "x": 10165,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51904,
      "e": 50357,
      "ty": 3,
      "x": 855,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51905,
      "e": 50358,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52016,
      "e": 50469,
      "ty": 4,
      "x": 10165,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52016,
      "e": 50469,
      "ty": 5,
      "x": 855,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54674,
      "e": 53127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 54674,
      "e": 53127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54770,
      "e": 53223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 54954,
      "e": 53407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 54955,
      "e": 53408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55057,
      "e": 53510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 55704,
      "e": 54157,
      "ty": 2,
      "x": 844,
      "y": 573
    },
    {
      "t": 55720,
      "e": 54173,
      "ty": 7,
      "x": 853,
      "y": 595,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55754,
      "e": 54207,
      "ty": 41,
      "x": 13626,
      "y": 51491,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 55787,
      "e": 54240,
      "ty": 6,
      "x": 882,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55804,
      "e": 54257,
      "ty": 2,
      "x": 886,
      "y": 666
    },
    {
      "t": 55820,
      "e": 54273,
      "ty": 7,
      "x": 891,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55837,
      "e": 54290,
      "ty": 6,
      "x": 896,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55904,
      "e": 54357,
      "ty": 2,
      "x": 902,
      "y": 706
    },
    {
      "t": 55921,
      "e": 54374,
      "ty": 7,
      "x": 906,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56004,
      "e": 54457,
      "ty": 2,
      "x": 907,
      "y": 712
    },
    {
      "t": 56004,
      "e": 54457,
      "ty": 41,
      "x": 30959,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 56037,
      "e": 54490,
      "ty": 6,
      "x": 908,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56103,
      "e": 54556,
      "ty": 7,
      "x": 907,
      "y": 675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56104,
      "e": 54557,
      "ty": 2,
      "x": 907,
      "y": 675
    },
    {
      "t": 56204,
      "e": 54657,
      "ty": 2,
      "x": 907,
      "y": 673
    },
    {
      "t": 56255,
      "e": 54708,
      "ty": 41,
      "x": 21412,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 56304,
      "e": 54757,
      "ty": 2,
      "x": 906,
      "y": 668
    },
    {
      "t": 56353,
      "e": 54806,
      "ty": 6,
      "x": 904,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56404,
      "e": 54857,
      "ty": 2,
      "x": 902,
      "y": 665
    },
    {
      "t": 56504,
      "e": 54957,
      "ty": 2,
      "x": 900,
      "y": 661
    },
    {
      "t": 56505,
      "e": 54958,
      "ty": 41,
      "x": 19898,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56605,
      "e": 55058,
      "ty": 2,
      "x": 898,
      "y": 659
    },
    {
      "t": 56632,
      "e": 55085,
      "ty": 3,
      "x": 898,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56634,
      "e": 55087,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 56634,
      "e": 55087,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56635,
      "e": 55088,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56754,
      "e": 55207,
      "ty": 41,
      "x": 19465,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56768,
      "e": 55221,
      "ty": 4,
      "x": 19465,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56768,
      "e": 55221,
      "ty": 5,
      "x": 898,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58002,
      "e": 56455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "188"
    },
    {
      "t": 58002,
      "e": 56455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58042,
      "e": 56495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ","
    },
    {
      "t": 58578,
      "e": 57031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 58690,
      "e": 57143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 59178,
      "e": 57631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 59179,
      "e": 57632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59339,
      "e": 57792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "m"
    },
    {
      "t": 59435,
      "e": 57888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 59435,
      "e": 57888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59571,
      "e": 58024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "me"
    },
    {
      "t": 59962,
      "e": 58415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "88"
    },
    {
      "t": 59963,
      "e": 58416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60005,
      "e": 58458,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60161,
      "e": 58614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "mex"
    },
    {
      "t": 60185,
      "e": 58638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 60186,
      "e": 58639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60298,
      "e": 58751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "mexi"
    },
    {
      "t": 60362,
      "e": 58815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 60363,
      "e": 58816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60497,
      "e": 58950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 60497,
      "e": 58950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60521,
      "e": 58974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||co"
    },
    {
      "t": 60601,
      "e": 59054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 61457,
      "e": 59910,
      "ty": 7,
      "x": 907,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61491,
      "e": 59944,
      "ty": 6,
      "x": 917,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61504,
      "e": 59957,
      "ty": 2,
      "x": 917,
      "y": 680
    },
    {
      "t": 61504,
      "e": 59957,
      "ty": 41,
      "x": 10863,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61604,
      "e": 60057,
      "ty": 2,
      "x": 942,
      "y": 696
    },
    {
      "t": 61705,
      "e": 60158,
      "ty": 2,
      "x": 945,
      "y": 699
    },
    {
      "t": 61711,
      "e": 60164,
      "ty": 3,
      "x": 945,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61711,
      "e": 60164,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "mexico"
    },
    {
      "t": 61712,
      "e": 60165,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61712,
      "e": 60165,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61754,
      "e": 60207,
      "ty": 41,
      "x": 25294,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61783,
      "e": 60236,
      "ty": 4,
      "x": 25294,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61784,
      "e": 60237,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61785,
      "e": 60238,
      "ty": 5,
      "x": 945,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61785,
      "e": 60238,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 62796,
      "e": 61249,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 63404,
      "e": 61857,
      "ty": 2,
      "x": 914,
      "y": 678
    },
    {
      "t": 63505,
      "e": 61958,
      "ty": 2,
      "x": 773,
      "y": 582
    },
    {
      "t": 63505,
      "e": 61958,
      "ty": 41,
      "x": 26344,
      "y": 31798,
      "ta": "html > body"
    },
    {
      "t": 63605,
      "e": 62058,
      "ty": 2,
      "x": 709,
      "y": 209
    },
    {
      "t": 63705,
      "e": 62158,
      "ty": 2,
      "x": 722,
      "y": 188
    },
    {
      "t": 63755,
      "e": 62208,
      "ty": 41,
      "x": 26792,
      "y": 9971,
      "ta": "html > body"
    },
    {
      "t": 63805,
      "e": 62258,
      "ty": 2,
      "x": 937,
      "y": 188
    },
    {
      "t": 63905,
      "e": 62358,
      "ty": 2,
      "x": 963,
      "y": 192
    },
    {
      "t": 64005,
      "e": 62458,
      "ty": 2,
      "x": 849,
      "y": 172
    },
    {
      "t": 64005,
      "e": 62458,
      "ty": 41,
      "x": 6544,
      "y": 821,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64105,
      "e": 62558,
      "ty": 2,
      "x": 819,
      "y": 209
    },
    {
      "t": 64162,
      "e": 62615,
      "ty": 6,
      "x": 836,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 64178,
      "e": 62631,
      "ty": 7,
      "x": 841,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 64205,
      "e": 62658,
      "ty": 2,
      "x": 844,
      "y": 242
    },
    {
      "t": 64254,
      "e": 62707,
      "ty": 41,
      "x": 20126,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 64304,
      "e": 62757,
      "ty": 2,
      "x": 846,
      "y": 242
    },
    {
      "t": 64705,
      "e": 63158,
      "ty": 2,
      "x": 845,
      "y": 252
    },
    {
      "t": 64756,
      "e": 63209,
      "ty": 41,
      "x": 5595,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 64804,
      "e": 63257,
      "ty": 2,
      "x": 845,
      "y": 259
    },
    {
      "t": 64904,
      "e": 63357,
      "ty": 2,
      "x": 845,
      "y": 261
    },
    {
      "t": 64929,
      "e": 63382,
      "ty": 3,
      "x": 845,
      "y": 261,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 65005,
      "e": 63458,
      "ty": 41,
      "x": 17957,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 65032,
      "e": 63485,
      "ty": 4,
      "x": 17957,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 65033,
      "e": 63486,
      "ty": 5,
      "x": 845,
      "y": 261,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 65033,
      "e": 63486,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 65035,
      "e": 63488,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 65255,
      "e": 63708,
      "ty": 41,
      "x": 24050,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 65305,
      "e": 63758,
      "ty": 2,
      "x": 868,
      "y": 285
    },
    {
      "t": 65405,
      "e": 63858,
      "ty": 2,
      "x": 932,
      "y": 347
    },
    {
      "t": 65505,
      "e": 63958,
      "ty": 2,
      "x": 956,
      "y": 416
    },
    {
      "t": 65505,
      "e": 63958,
      "ty": 41,
      "x": 31938,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 65604,
      "e": 64057,
      "ty": 2,
      "x": 956,
      "y": 417
    },
    {
      "t": 65755,
      "e": 64208,
      "ty": 41,
      "x": 30514,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 65805,
      "e": 64258,
      "ty": 2,
      "x": 930,
      "y": 422
    },
    {
      "t": 65905,
      "e": 64358,
      "ty": 2,
      "x": 908,
      "y": 427
    },
    {
      "t": 66005,
      "e": 64458,
      "ty": 2,
      "x": 894,
      "y": 440
    },
    {
      "t": 66005,
      "e": 64458,
      "ty": 41,
      "x": 57971,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 66105,
      "e": 64558,
      "ty": 2,
      "x": 874,
      "y": 486
    },
    {
      "t": 66205,
      "e": 64658,
      "ty": 2,
      "x": 863,
      "y": 515
    },
    {
      "t": 66255,
      "e": 64658,
      "ty": 41,
      "x": 9867,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 66305,
      "e": 64708,
      "ty": 2,
      "x": 860,
      "y": 493
    },
    {
      "t": 66404,
      "e": 64807,
      "ty": 2,
      "x": 858,
      "y": 447
    },
    {
      "t": 66505,
      "e": 64908,
      "ty": 2,
      "x": 858,
      "y": 438
    },
    {
      "t": 66505,
      "e": 64908,
      "ty": 41,
      "x": 29216,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 66604,
      "e": 65007,
      "ty": 2,
      "x": 865,
      "y": 496
    },
    {
      "t": 66755,
      "e": 65158,
      "ty": 41,
      "x": 39113,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 66805,
      "e": 65208,
      "ty": 2,
      "x": 867,
      "y": 483
    },
    {
      "t": 66905,
      "e": 65308,
      "ty": 2,
      "x": 870,
      "y": 476
    },
    {
      "t": 67005,
      "e": 65408,
      "ty": 41,
      "x": 51347,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 67205,
      "e": 65608,
      "ty": 2,
      "x": 869,
      "y": 472
    },
    {
      "t": 67239,
      "e": 65642,
      "ty": 3,
      "x": 869,
      "y": 472,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 67240,
      "e": 65643,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 67255,
      "e": 65658,
      "ty": 41,
      "x": 50290,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 67336,
      "e": 65739,
      "ty": 4,
      "x": 50290,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 67336,
      "e": 65739,
      "ty": 5,
      "x": 869,
      "y": 472,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 67336,
      "e": 65739,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 67337,
      "e": 65740,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 67605,
      "e": 66008,
      "ty": 2,
      "x": 873,
      "y": 492
    },
    {
      "t": 67704,
      "e": 66107,
      "ty": 2,
      "x": 893,
      "y": 556
    },
    {
      "t": 67755,
      "e": 66158,
      "ty": 41,
      "x": 48839,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 67805,
      "e": 66208,
      "ty": 2,
      "x": 893,
      "y": 562
    },
    {
      "t": 68605,
      "e": 67008,
      "ty": 2,
      "x": 894,
      "y": 564
    },
    {
      "t": 68704,
      "e": 67107,
      "ty": 2,
      "x": 890,
      "y": 565
    },
    {
      "t": 68755,
      "e": 67158,
      "ty": 41,
      "x": 58151,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 68805,
      "e": 67208,
      "ty": 2,
      "x": 870,
      "y": 618
    },
    {
      "t": 68904,
      "e": 67307,
      "ty": 2,
      "x": 855,
      "y": 698
    },
    {
      "t": 69004,
      "e": 67407,
      "ty": 2,
      "x": 856,
      "y": 728
    },
    {
      "t": 69005,
      "e": 67408,
      "ty": 41,
      "x": 8678,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 69505,
      "e": 67908,
      "ty": 2,
      "x": 871,
      "y": 734
    },
    {
      "t": 69505,
      "e": 67908,
      "ty": 41,
      "x": 12443,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 69604,
      "e": 68007,
      "ty": 2,
      "x": 897,
      "y": 788
    },
    {
      "t": 69705,
      "e": 68108,
      "ty": 2,
      "x": 907,
      "y": 825
    },
    {
      "t": 69755,
      "e": 68158,
      "ty": 41,
      "x": 20309,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 69905,
      "e": 68308,
      "ty": 2,
      "x": 907,
      "y": 827
    },
    {
      "t": 70004,
      "e": 68407,
      "ty": 41,
      "x": 20309,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 70104,
      "e": 68507,
      "ty": 2,
      "x": 907,
      "y": 807
    },
    {
      "t": 70205,
      "e": 68608,
      "ty": 2,
      "x": 907,
      "y": 809
    },
    {
      "t": 70255,
      "e": 68658,
      "ty": 41,
      "x": 50511,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 70304,
      "e": 68707,
      "ty": 2,
      "x": 907,
      "y": 815
    },
    {
      "t": 70505,
      "e": 68908,
      "ty": 41,
      "x": 50511,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 70705,
      "e": 69108,
      "ty": 2,
      "x": 909,
      "y": 809
    },
    {
      "t": 70756,
      "e": 69109,
      "ty": 41,
      "x": 38628,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 70805,
      "e": 69158,
      "ty": 2,
      "x": 920,
      "y": 727
    },
    {
      "t": 70905,
      "e": 69258,
      "ty": 2,
      "x": 920,
      "y": 716
    },
    {
      "t": 71005,
      "e": 69358,
      "ty": 41,
      "x": 23395,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 71105,
      "e": 69458,
      "ty": 2,
      "x": 927,
      "y": 720
    },
    {
      "t": 71205,
      "e": 69558,
      "ty": 2,
      "x": 932,
      "y": 732
    },
    {
      "t": 71255,
      "e": 69608,
      "ty": 41,
      "x": 28506,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 71305,
      "e": 69658,
      "ty": 2,
      "x": 935,
      "y": 737
    },
    {
      "t": 71505,
      "e": 69858,
      "ty": 2,
      "x": 940,
      "y": 718
    },
    {
      "t": 71505,
      "e": 69858,
      "ty": 41,
      "x": 28141,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 71605,
      "e": 69958,
      "ty": 2,
      "x": 940,
      "y": 713
    },
    {
      "t": 71756,
      "e": 70109,
      "ty": 41,
      "x": 28141,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 72005,
      "e": 70358,
      "ty": 2,
      "x": 940,
      "y": 712
    },
    {
      "t": 72005,
      "e": 70358,
      "ty": 41,
      "x": 29879,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 72079,
      "e": 70432,
      "ty": 3,
      "x": 940,
      "y": 712,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 72079,
      "e": 70432,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 72183,
      "e": 70536,
      "ty": 4,
      "x": 29879,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 72183,
      "e": 70536,
      "ty": 5,
      "x": 940,
      "y": 712,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 72184,
      "e": 70537,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 72184,
      "e": 70537,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 72705,
      "e": 71058,
      "ty": 2,
      "x": 948,
      "y": 755
    },
    {
      "t": 72755,
      "e": 71108,
      "ty": 41,
      "x": 54484,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 72805,
      "e": 71158,
      "ty": 2,
      "x": 952,
      "y": 769
    },
    {
      "t": 73005,
      "e": 71358,
      "ty": 41,
      "x": 30989,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 73505,
      "e": 71858,
      "ty": 2,
      "x": 952,
      "y": 784
    },
    {
      "t": 73505,
      "e": 71858,
      "ty": 41,
      "x": 30989,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 73605,
      "e": 71958,
      "ty": 2,
      "x": 931,
      "y": 850
    },
    {
      "t": 73705,
      "e": 72058,
      "ty": 2,
      "x": 886,
      "y": 927
    },
    {
      "t": 73756,
      "e": 72109,
      "ty": 41,
      "x": 36868,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 73805,
      "e": 72158,
      "ty": 2,
      "x": 867,
      "y": 962
    },
    {
      "t": 73905,
      "e": 72258,
      "ty": 2,
      "x": 867,
      "y": 964
    },
    {
      "t": 74006,
      "e": 72359,
      "ty": 41,
      "x": 36868,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 74080,
      "e": 72433,
      "ty": 3,
      "x": 867,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 74082,
      "e": 72435,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74167,
      "e": 72520,
      "ty": 4,
      "x": 36868,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 74167,
      "e": 72520,
      "ty": 5,
      "x": 867,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 74168,
      "e": 72521,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 74168,
      "e": 72521,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 74305,
      "e": 72658,
      "ty": 2,
      "x": 868,
      "y": 984
    },
    {
      "t": 74336,
      "e": 72689,
      "ty": 6,
      "x": 881,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74404,
      "e": 72757,
      "ty": 2,
      "x": 892,
      "y": 1032
    },
    {
      "t": 74504,
      "e": 72857,
      "ty": 41,
      "x": 32252,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74604,
      "e": 72957,
      "ty": 2,
      "x": 894,
      "y": 1032
    },
    {
      "t": 74704,
      "e": 73057,
      "ty": 2,
      "x": 896,
      "y": 1032
    },
    {
      "t": 74729,
      "e": 73082,
      "ty": 3,
      "x": 896,
      "y": 1032,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74730,
      "e": 73083,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 74731,
      "e": 73084,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74754,
      "e": 73107,
      "ty": 41,
      "x": 34313,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74832,
      "e": 73185,
      "ty": 4,
      "x": 34313,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74832,
      "e": 73185,
      "ty": 5,
      "x": 896,
      "y": 1032,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74834,
      "e": 73187,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74836,
      "e": 73189,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 74837,
      "e": 73190,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 75207,
      "e": 73560,
      "ty": 2,
      "x": 897,
      "y": 1031
    },
    {
      "t": 75258,
      "e": 73611,
      "ty": 41,
      "x": 30718,
      "y": 56560,
      "ta": "html > body"
    },
    {
      "t": 75307,
      "e": 73660,
      "ty": 2,
      "x": 905,
      "y": 1022
    },
    {
      "t": 75408,
      "e": 73761,
      "ty": 2,
      "x": 905,
      "y": 1021
    },
    {
      "t": 75507,
      "e": 73860,
      "ty": 2,
      "x": 907,
      "y": 1021
    },
    {
      "t": 75508,
      "e": 73861,
      "ty": 41,
      "x": 30959,
      "y": 56117,
      "ta": "html > body"
    },
    {
      "t": 75608,
      "e": 73961,
      "ty": 2,
      "x": 907,
      "y": 1020
    },
    {
      "t": 75708,
      "e": 74061,
      "ty": 2,
      "x": 911,
      "y": 1013
    },
    {
      "t": 75758,
      "e": 74111,
      "ty": 41,
      "x": 31097,
      "y": 55618,
      "ta": "html > body"
    },
    {
      "t": 75808,
      "e": 74161,
      "ty": 2,
      "x": 911,
      "y": 1012
    },
    {
      "t": 76158,
      "e": 74511,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 77007,
      "e": 75360,
      "ty": 2,
      "x": 912,
      "y": 1012
    },
    {
      "t": 77007,
      "e": 75360,
      "ty": 41,
      "x": 30430,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77108,
      "e": 75461,
      "ty": 2,
      "x": 922,
      "y": 1013
    },
    {
      "t": 77207,
      "e": 75560,
      "ty": 2,
      "x": 926,
      "y": 1013
    },
    {
      "t": 77257,
      "e": 75610,
      "ty": 41,
      "x": 31266,
      "y": 61124,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77308,
      "e": 75661,
      "ty": 2,
      "x": 935,
      "y": 918
    },
    {
      "t": 77407,
      "e": 75760,
      "ty": 2,
      "x": 805,
      "y": 436
    },
    {
      "t": 77508,
      "e": 75861,
      "ty": 41,
      "x": 20345,
      "y": 9951,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77508,
      "e": 75861,
      "ty": 2,
      "x": 707,
      "y": 270
    },
    {
      "t": 77607,
      "e": 75960,
      "ty": 2,
      "x": 697,
      "y": 280
    },
    {
      "t": 77708,
      "e": 76061,
      "ty": 2,
      "x": 694,
      "y": 367
    },
    {
      "t": 77758,
      "e": 76111,
      "ty": 41,
      "x": 20197,
      "y": 5083,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 77807,
      "e": 76160,
      "ty": 2,
      "x": 715,
      "y": 405
    },
    {
      "t": 77907,
      "e": 76260,
      "ty": 2,
      "x": 732,
      "y": 412
    },
    {
      "t": 78007,
      "e": 76360,
      "ty": 2,
      "x": 747,
      "y": 412
    },
    {
      "t": 78007,
      "e": 76360,
      "ty": 41,
      "x": 22313,
      "y": 24587,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 78107,
      "e": 76460,
      "ty": 2,
      "x": 751,
      "y": 414
    },
    {
      "t": 78207,
      "e": 76560,
      "ty": 2,
      "x": 762,
      "y": 410
    },
    {
      "t": 78258,
      "e": 76611,
      "ty": 41,
      "x": 23543,
      "y": 21467,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 78308,
      "e": 76661,
      "ty": 2,
      "x": 784,
      "y": 407
    },
    {
      "t": 78408,
      "e": 76761,
      "ty": 2,
      "x": 796,
      "y": 407
    },
    {
      "t": 78507,
      "e": 76860,
      "ty": 2,
      "x": 800,
      "y": 407
    },
    {
      "t": 78508,
      "e": 76861,
      "ty": 41,
      "x": 24920,
      "y": 20686,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 78708,
      "e": 77061,
      "ty": 2,
      "x": 803,
      "y": 407
    },
    {
      "t": 78758,
      "e": 77111,
      "ty": 41,
      "x": 25658,
      "y": 27708,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 78808,
      "e": 77161,
      "ty": 2,
      "x": 861,
      "y": 444
    },
    {
      "t": 78908,
      "e": 77261,
      "ty": 2,
      "x": 907,
      "y": 454
    },
    {
      "t": 79008,
      "e": 77361,
      "ty": 2,
      "x": 917,
      "y": 452
    },
    {
      "t": 79008,
      "e": 77361,
      "ty": 41,
      "x": 30676,
      "y": 55794,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 79108,
      "e": 77461,
      "ty": 2,
      "x": 927,
      "y": 447
    },
    {
      "t": 79208,
      "e": 77561,
      "ty": 2,
      "x": 932,
      "y": 445
    },
    {
      "t": 79258,
      "e": 77611,
      "ty": 41,
      "x": 31660,
      "y": 49553,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 79308,
      "e": 77661,
      "ty": 2,
      "x": 941,
      "y": 441
    },
    {
      "t": 79408,
      "e": 77761,
      "ty": 2,
      "x": 948,
      "y": 439
    },
    {
      "t": 79508,
      "e": 77861,
      "ty": 41,
      "x": 32201,
      "y": 45652,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 80007,
      "e": 78360,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 126308,
      "e": 82861,
      "ty": 2,
      "x": 940,
      "y": 447
    },
    {
      "t": 126408,
      "e": 82961,
      "ty": 2,
      "x": 922,
      "y": 517
    },
    {
      "t": 126509,
      "e": 83062,
      "ty": 2,
      "x": 923,
      "y": 623
    },
    {
      "t": 126509,
      "e": 83062,
      "ty": 41,
      "x": 30971,
      "y": 54813,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 126608,
      "e": 83161,
      "ty": 2,
      "x": 905,
      "y": 626
    },
    {
      "t": 126758,
      "e": 83311,
      "ty": 41,
      "x": 30086,
      "y": 55983,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 127107,
      "e": 83660,
      "ty": 2,
      "x": 903,
      "y": 683
    },
    {
      "t": 127207,
      "e": 83760,
      "ty": 2,
      "x": 927,
      "y": 808
    },
    {
      "t": 127258,
      "e": 83811,
      "ty": 41,
      "x": 32103,
      "y": 5887,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 127308,
      "e": 83861,
      "ty": 2,
      "x": 976,
      "y": 938
    },
    {
      "t": 127407,
      "e": 83960,
      "ty": 2,
      "x": 1049,
      "y": 1041
    },
    {
      "t": 127508,
      "e": 84061,
      "ty": 2,
      "x": 1064,
      "y": 1055
    },
    {
      "t": 127508,
      "e": 84061,
      "ty": 41,
      "x": 37908,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127608,
      "e": 84161,
      "ty": 2,
      "x": 1067,
      "y": 1057
    },
    {
      "t": 127709,
      "e": 84262,
      "ty": 2,
      "x": 1068,
      "y": 1073
    },
    {
      "t": 127759,
      "e": 84312,
      "ty": 41,
      "x": 36435,
      "y": 59219,
      "ta": "> div.masterdiv"
    },
    {
      "t": 127808,
      "e": 84361,
      "ty": 2,
      "x": 1061,
      "y": 1082
    },
    {
      "t": 127908,
      "e": 84461,
      "ty": 2,
      "x": 1054,
      "y": 1083
    },
    {
      "t": 127998,
      "e": 84551,
      "ty": 6,
      "x": 1029,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 128008,
      "e": 84561,
      "ty": 2,
      "x": 1029,
      "y": 1078
    },
    {
      "t": 128008,
      "e": 84561,
      "ty": 41,
      "x": 65261,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 128108,
      "e": 84661,
      "ty": 2,
      "x": 1026,
      "y": 1076
    },
    {
      "t": 128208,
      "e": 84761,
      "ty": 2,
      "x": 1022,
      "y": 1075
    },
    {
      "t": 128257,
      "e": 84810,
      "ty": 41,
      "x": 60346,
      "y": 602,
      "ta": "#start"
    },
    {
      "t": 128308,
      "e": 84861,
      "ty": 2,
      "x": 1011,
      "y": 1073
    },
    {
      "t": 128408,
      "e": 84961,
      "ty": 2,
      "x": 995,
      "y": 1076
    },
    {
      "t": 128508,
      "e": 85061,
      "ty": 2,
      "x": 990,
      "y": 1079
    },
    {
      "t": 128508,
      "e": 85061,
      "ty": 41,
      "x": 43963,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 128608,
      "e": 85161,
      "ty": 2,
      "x": 988,
      "y": 1080
    },
    {
      "t": 128758,
      "e": 85311,
      "ty": 41,
      "x": 42870,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 128808,
      "e": 85361,
      "ty": 2,
      "x": 987,
      "y": 1080
    },
    {
      "t": 128907,
      "e": 85460,
      "ty": 2,
      "x": 985,
      "y": 1082
    },
    {
      "t": 129008,
      "e": 85561,
      "ty": 2,
      "x": 982,
      "y": 1084
    },
    {
      "t": 129008,
      "e": 85561,
      "ty": 41,
      "x": 39594,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 130258,
      "e": 86811,
      "ty": 41,
      "x": 39594,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 130308,
      "e": 86861,
      "ty": 2,
      "x": 982,
      "y": 1080
    },
    {
      "t": 130408,
      "e": 86961,
      "ty": 2,
      "x": 982,
      "y": 1078
    },
    {
      "t": 130508,
      "e": 87061,
      "ty": 41,
      "x": 39594,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 130707,
      "e": 87260,
      "ty": 2,
      "x": 977,
      "y": 1079
    },
    {
      "t": 130758,
      "e": 87311,
      "ty": 41,
      "x": 36863,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 131146,
      "e": 87699,
      "ty": 3,
      "x": 977,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 131147,
      "e": 87700,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 131305,
      "e": 87858,
      "ty": 4,
      "x": 36863,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 131306,
      "e": 87859,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 131307,
      "e": 87860,
      "ty": 5,
      "x": 977,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 131307,
      "e": 87860,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 132336,
      "e": 88889,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 134258,
      "e": 90811,
      "ty": 41,
      "x": 33387,
      "y": 32845,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 134282,
      "e": 90835,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"nodeType\":3,\"id\":2489,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2486},{\"id\":2487},{\"nodeType\":3,\"id\":2490,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2488}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2491,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2491},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2492},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2493},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2492}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2495},\"parentNode\":{\"id\":2492}},{\"nodeType\":3,\"id\":2497,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2495}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2493}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2498},\"parentNode\":{\"id\":2493}},{\"nodeType\":3,\"id\":2500,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2498}},{\"nodeType\":3,\"id\":2501,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2494}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2491},{\"id\":2492},{\"id\":2495},{\"id\":2497},{\"id\":2496},{\"id\":2493},{\"id\":2498},{\"id\":2500},{\"id\":2499},{\"id\":2494},{\"id\":2501}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2502,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2502}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2502}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2502}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2502}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2502}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2502}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2504}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2504}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2504}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2504}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2504}},{\"nodeType\":3,\"id\":2514,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2509}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2509}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2510}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2516}},{\"nodeType\":3,\"id\":2518,\"textContent\":\"English\",\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2516}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2511}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2519}},{\"nodeType\":3,\"id\":2521,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2519}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2512}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2522}},{\"nodeType\":3,\"id\":2524,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2522}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2513}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":3,\"id\":2527,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2525}},{\"nodeType\":3,\"id\":2528,\"textContent\":\"*\",\"parentNode\":{\"id\":2515}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2505}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2505}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2505}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2505}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2505}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2505}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2505}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2505}},{\"nodeType\":3,\"id\":2537,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":3,\"id\":2541,\"textContent\":\"First\",\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":3,\"id\":2544,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2547,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2545}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2548}},{\"nodeType\":3,\"id\":2550,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2549},\"parentNode\":{\"id\":2548}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2553,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2551}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2554}},{\"nodeType\":3,\"id\":2556,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2555},\"parentNode\":{\"id\":2554}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2559,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2560,\"textContent\":\"*\",\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2506}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2561},\"parentNode\":{\"id\":2506}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2506}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2563},\"parentNode\":{\"id\":2506}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2506}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2565},\"parentNode\":{\"id\":2506}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2506}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2567},\"parentNode\":{\"id\":2506}},{\"nodeType\":3,\"id\":2569,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2561}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2569},\"parentNode\":{\"id\":2561}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2562}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2573,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2571}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2563}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2574}},{\"nodeType\":3,\"id\":2576,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2575},\"parentNode\":{\"id\":2574}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2564}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2577}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2578},\"parentNode\":{\"id\":2577}},{\"nodeType\":1,\"id\":2580,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2565}},{\"nodeType\":1,\"id\":2581,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2580}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2581},\"parentNode\":{\"id\":2580}},{\"nodeType\":1,\"id\":2583,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2566}},{\"nodeType\":1,\"id\":2584,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2583}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2584},\"parentNode\":{\"id\":2583}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2567}},{\"nodeType\":1,\"id\":2587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2586}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2587},\"parentNode\":{\"id\":2586}},{\"nodeType\":1,\"id\":2589,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2568}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2589}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2590},\"parentNode\":{\"id\":2589}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"*\",\"parentNode\":{\"id\":2570}},{\"nodeType\":1,\"id\":2593,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2507}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2593},\"parentNode\":{\"id\":2507}},{\"nodeType\":1,\"id\":2595,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2594},\"parentNode\":{\"id\":2507}},{\"nodeType\":1,\"id\":2596,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2595},\"parentNode\":{\"id\":2507}},{\"nodeType\":3,\"id\":2597,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2593}},{\"nodeType\":1,\"id\":2598,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2597},\"parentNode\":{\"id\":2593}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2594}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2601,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2595}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2602}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2603},\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2596}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"*\",\"parentNode\":{\"id\":2598}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2509},{\"id\":2514},{\"id\":2515},{\"id\":2528},{\"id\":2510},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2511},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2512},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2513},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2505},{\"id\":2529},{\"id\":2537},{\"id\":2538},{\"id\":2560},{\"id\":2530},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2531},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2532},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2533},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2534},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2535},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2536},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2506},{\"id\":2561},{\"id\":2569},{\"id\":2570},{\"id\":2592},{\"id\":2562},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2563},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2564},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2565},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2566},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2567},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2568},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2507},{\"id\":2593},{\"id\":2597},{\"id\":2598},{\"id\":2608},{\"id\":2594},{\"id\":2599},{\"id\":2600},{\"id\":2601},{\"id\":2595},{\"id\":2602},{\"id\":2603},{\"id\":2604},{\"id\":2596},{\"id\":2605},{\"id\":2606},{\"id\":2607},{\"id\":2508}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2610,\"textContent\":\" \",\"previousSibling\":{\"id\":2609},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2611,\"textContent\":\" \",\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":3,\"id\":2613,\"textContent\":\" \",\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":3,\"id\":2615,\"textContent\":\" \",\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2615},\"parentNode\":{\"id\":2609}},{\"nodeType\":3,\"id\":2617,\"textContent\":\" \",\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2609}},{\"nodeType\":3,\"id\":2618,\"textContent\":\" \",\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2620,\"textContent\":\" \",\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2621,\"textContent\":\" \",\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2623,\"textContent\":\" \",\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2624,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2625,\"textContent\":\" \",\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2627,\"textContent\":\" \",\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2628,\"textContent\":\" \",\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2628},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2631,\"textContent\":\" \",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2631},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2633,\"textContent\":\" \",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2635,\"textContent\":\" \",\"previousSibling\":{\"id\":2634},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2637,\"textContent\":\" \",\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2639,\"textContent\":\" \",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2640,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2641,\"textContent\":\" \",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2630}},{\"nodeType\":3,\"id\":2643,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2630}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2642}},{\"nodeType\":3,\"id\":2645,\"textContent\":\" \",\"parentNode\":{\"id\":2632}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2647,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2650,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2636}},{\"nodeType\":3,\"id\":2653,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2638}},{\"nodeType\":3,\"id\":2654,\"textContent\":\" \",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2654},\"parentNode\":{\"id\":2616}},{\"nodeType\":3,\"id\":2656,\"textContent\":\" \",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2616}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2655}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2611},{\"id\":2612},{\"id\":2618},{\"id\":2619},{\"id\":2621},{\"id\":2622},{\"id\":2624},{\"id\":2623},{\"id\":2620},{\"id\":2613},{\"id\":2614},{\"id\":2625},{\"id\":2626},{\"id\":2628},{\"id\":2629},{\"id\":2640},{\"id\":2630},{\"id\":2641},{\"id\":2642},{\"id\":2644},{\"id\":2643},{\"id\":2631},{\"id\":2632},{\"id\":2645},{\"id\":2646},{\"id\":2648},{\"id\":2647},{\"id\":2633},{\"id\":2634},{\"id\":2649},{\"id\":2651},{\"id\":2650},{\"id\":2635},{\"id\":2636},{\"id\":2652},{\"id\":2637},{\"id\":2638},{\"id\":2653},{\"id\":2639},{\"id\":2627},{\"id\":2615},{\"id\":2616},{\"id\":2654},{\"id\":2655},{\"id\":2657},{\"id\":2656},{\"id\":2617},{\"id\":2610}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2658,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"[ { \\\"rt\\\": 20318, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 20321, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\" }, { \\\"rt\\\": 5436, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 26839, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\" }, { \\\"rt\\\": 12861, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"alpha\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"3\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 40703, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\" }, { \\\"rt\\\": 24013, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 65799, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\" }, { \\\"rt\\\": 8446, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 75246, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\" }, { \\\"rt\\\": 32595, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 109050, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-08 AM-09 AM-08 AM-08 AM-09 AM-10 AM-11 AM-12 PM-01 PM-02 PM-03 PM-04 PM-05 PM-06 PM-07 PM-07 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:972,y:950,t:1526918837432};\\\", \\\"{x:971,y:940,t:1526918837439};\\\", \\\"{x:965,y:930,t:1526918837453};\\\", \\\"{x:955,y:911,t:1526918837470};\\\", \\\"{x:939,y:889,t:1526918837487};\\\", \\\"{x:893,y:839,t:1526918837503};\\\", \\\"{x:847,y:795,t:1526918837519};\\\", \\\"{x:805,y:763,t:1526918837536};\\\", \\\"{x:765,y:734,t:1526918837553};\\\", \\\"{x:728,y:709,t:1526918837569};\\\", \\\"{x:681,y:679,t:1526918837587};\\\", \\\"{x:645,y:655,t:1526918837603};\\\", \\\"{x:623,y:640,t:1526918837619};\\\", \\\"{x:608,y:633,t:1526918837635};\\\", \\\"{x:603,y:631,t:1526918837652};\\\", \\\"{x:601,y:631,t:1526918837668};\\\", \\\"{x:600,y:631,t:1526918837686};\\\", \\\"{x:599,y:631,t:1526918837702};\\\", \\\"{x:598,y:631,t:1526918837719};\\\", \\\"{x:596,y:631,t:1526918837735};\\\", \\\"{x:593,y:631,t:1526918837752};\\\", \\\"{x:587,y:630,t:1526918837769};\\\", \\\"{x:574,y:628,t:1526918837785};\\\", \\\"{x:552,y:628,t:1526918837802};\\\", \\\"{x:504,y:625,t:1526918837819};\\\", \\\"{x:448,y:617,t:1526918837836};\\\", \\\"{x:382,y:608,t:1526918837853};\\\", \\\"{x:301,y:597,t:1526918837869};\\\", \\\"{x:239,y:587,t:1526918837886};\\\", \\\"{x:195,y:583,t:1526918837902};\\\", \\\"{x:154,y:583,t:1526918837920};\\\", \\\"{x:98,y:581,t:1526918837936};\\\", \\\"{x:37,y:575,t:1526918837953};\\\", \\\"{x:0,y:558,t:1526918837970};\\\", \\\"{x:0,y:552,t:1526918837985};\\\", \\\"{x:0,y:545,t:1526918838003};\\\", \\\"{x:0,y:544,t:1526918838020};\\\", \\\"{x:0,y:543,t:1526918838035};\\\", \\\"{x:0,y:541,t:1526918838166};\\\", \\\"{x:5,y:539,t:1526918838174};\\\", \\\"{x:11,y:535,t:1526918838186};\\\", \\\"{x:23,y:529,t:1526918838203};\\\", \\\"{x:35,y:522,t:1526918838219};\\\", \\\"{x:49,y:511,t:1526918838236};\\\", \\\"{x:68,y:496,t:1526918838252};\\\", \\\"{x:79,y:487,t:1526918838270};\\\", \\\"{x:87,y:480,t:1526918838286};\\\", \\\"{x:89,y:476,t:1526918838303};\\\", \\\"{x:90,y:476,t:1526918838320};\\\", \\\"{x:91,y:474,t:1526918838360};\\\", \\\"{x:93,y:474,t:1526918838383};\\\", \\\"{x:94,y:473,t:1526918838391};\\\", \\\"{x:96,y:472,t:1526918838406};\\\", \\\"{x:97,y:472,t:1526918838423};\\\", \\\"{x:99,y:471,t:1526918838435};\\\", \\\"{x:100,y:471,t:1526918838455};\\\", \\\"{x:101,y:470,t:1526918838470};\\\", \\\"{x:102,y:470,t:1526918839103};\\\", \\\"{x:103,y:471,t:1526918839119};\\\", \\\"{x:104,y:472,t:1526918839159};\\\", \\\"{x:104,y:473,t:1526918839214};\\\", \\\"{x:104,y:474,t:1526918839230};\\\", \\\"{x:105,y:475,t:1526918839270};\\\", \\\"{x:106,y:477,t:1526918839318};\\\", \\\"{x:107,y:477,t:1526918839519};\\\", \\\"{x:109,y:478,t:1526918839630};\\\", \\\"{x:109,y:479,t:1526918839687};\\\", \\\"{x:110,y:479,t:1526918839710};\\\", \\\"{x:110,y:480,t:1526918839726};\\\", \\\"{x:111,y:480,t:1526918839774};\\\", \\\"{x:112,y:480,t:1526918839786};\\\", \\\"{x:112,y:481,t:1526918839862};\\\", \\\"{x:113,y:481,t:1526918839895};\\\", \\\"{x:114,y:481,t:1526918839918};\\\", \\\"{x:115,y:482,t:1526918840679};\\\", \\\"{x:115,y:483,t:1526918841926};\\\", \\\"{x:116,y:483,t:1526918841950};\\\", \\\"{x:116,y:484,t:1526918841974};\\\", \\\"{x:118,y:485,t:1526918841986};\\\", \\\"{x:118,y:486,t:1526918842002};\\\", \\\"{x:121,y:490,t:1526918842019};\\\", \\\"{x:125,y:495,t:1526918842037};\\\", \\\"{x:136,y:510,t:1526918842053};\\\", \\\"{x:156,y:537,t:1526918842070};\\\", \\\"{x:191,y:584,t:1526918842086};\\\", \\\"{x:224,y:612,t:1526918842103};\\\", \\\"{x:254,y:637,t:1526918842124};\\\", \\\"{x:288,y:661,t:1526918842141};\\\", \\\"{x:325,y:688,t:1526918842157};\\\", \\\"{x:354,y:709,t:1526918842173};\\\", \\\"{x:384,y:731,t:1526918842189};\\\", \\\"{x:418,y:749,t:1526918842206};\\\", \\\"{x:464,y:769,t:1526918842223};\\\", \\\"{x:497,y:783,t:1526918842239};\\\", \\\"{x:537,y:797,t:1526918842257};\\\", \\\"{x:574,y:808,t:1526918842273};\\\", \\\"{x:616,y:815,t:1526918842290};\\\", \\\"{x:651,y:821,t:1526918842307};\\\", \\\"{x:683,y:825,t:1526918842323};\\\", \\\"{x:717,y:830,t:1526918842340};\\\", \\\"{x:760,y:837,t:1526918842357};\\\", \\\"{x:833,y:848,t:1526918842373};\\\", \\\"{x:973,y:881,t:1526918842390};\\\", \\\"{x:1073,y:911,t:1526918842407};\\\", \\\"{x:1150,y:933,t:1526918842424};\\\", \\\"{x:1185,y:953,t:1526918842440};\\\", \\\"{x:1206,y:965,t:1526918842457};\\\", \\\"{x:1210,y:970,t:1526918842474};\\\", \\\"{x:1211,y:973,t:1526918842490};\\\", \\\"{x:1211,y:978,t:1526918842507};\\\", \\\"{x:1211,y:981,t:1526918842525};\\\", \\\"{x:1211,y:983,t:1526918842541};\\\", \\\"{x:1212,y:984,t:1526918842557};\\\", \\\"{x:1212,y:986,t:1526918842574};\\\", \\\"{x:1212,y:988,t:1526918842591};\\\", \\\"{x:1211,y:989,t:1526918842607};\\\", \\\"{x:1210,y:989,t:1526918842623};\\\", \\\"{x:1202,y:992,t:1526918842641};\\\", \\\"{x:1192,y:992,t:1526918842657};\\\", \\\"{x:1180,y:992,t:1526918842674};\\\", \\\"{x:1169,y:992,t:1526918842691};\\\", \\\"{x:1153,y:991,t:1526918842707};\\\", \\\"{x:1141,y:990,t:1526918842724};\\\", \\\"{x:1131,y:987,t:1526918842740};\\\", \\\"{x:1127,y:986,t:1526918842758};\\\", \\\"{x:1126,y:985,t:1526918842775};\\\", \\\"{x:1125,y:984,t:1526918842791};\\\", \\\"{x:1124,y:984,t:1526918842942};\\\", \\\"{x:1121,y:983,t:1526918842958};\\\", \\\"{x:1119,y:980,t:1526918842975};\\\", \\\"{x:1116,y:980,t:1526918842992};\\\", \\\"{x:1112,y:978,t:1526918843009};\\\", \\\"{x:1111,y:977,t:1526918843025};\\\", \\\"{x:1109,y:976,t:1526918843042};\\\", \\\"{x:1108,y:976,t:1526918843059};\\\", \\\"{x:1106,y:976,t:1526918843279};\\\", \\\"{x:1105,y:976,t:1526918843335};\\\", \\\"{x:1104,y:976,t:1526918843358};\\\", \\\"{x:1103,y:976,t:1526918843375};\\\", \\\"{x:1102,y:976,t:1526918843382};\\\", \\\"{x:1101,y:976,t:1526918843414};\\\", \\\"{x:1100,y:976,t:1526918843431};\\\", \\\"{x:1098,y:976,t:1526918843446};\\\", \\\"{x:1099,y:976,t:1526918843678};\\\", \\\"{x:1100,y:976,t:1526918843694};\\\", \\\"{x:1101,y:976,t:1526918843710};\\\", \\\"{x:1102,y:976,t:1526918843767};\\\", \\\"{x:1103,y:976,t:1526918843790};\\\", \\\"{x:1104,y:976,t:1526918843799};\\\", \\\"{x:1105,y:976,t:1526918843838};\\\", \\\"{x:1107,y:976,t:1526918843862};\\\", \\\"{x:1109,y:974,t:1526918843934};\\\", \\\"{x:1110,y:974,t:1526918843967};\\\", \\\"{x:1111,y:973,t:1526918843998};\\\", \\\"{x:1112,y:973,t:1526918844011};\\\", \\\"{x:1113,y:973,t:1526918844028};\\\", \\\"{x:1114,y:973,t:1526918844045};\\\", \\\"{x:1117,y:973,t:1526918844062};\\\", \\\"{x:1119,y:973,t:1526918844078};\\\", \\\"{x:1122,y:973,t:1526918844095};\\\", \\\"{x:1123,y:973,t:1526918844118};\\\", \\\"{x:1124,y:973,t:1526918844190};\\\", \\\"{x:1126,y:973,t:1526918844214};\\\", \\\"{x:1127,y:973,t:1526918844262};\\\", \\\"{x:1130,y:973,t:1526918844279};\\\", \\\"{x:1137,y:973,t:1526918844296};\\\", \\\"{x:1141,y:973,t:1526918844312};\\\", \\\"{x:1143,y:973,t:1526918844332};\\\", \\\"{x:1145,y:973,t:1526918844346};\\\", \\\"{x:1146,y:973,t:1526918844366};\\\", \\\"{x:1147,y:973,t:1526918844423};\\\", \\\"{x:1148,y:973,t:1526918844438};\\\", \\\"{x:1150,y:973,t:1526918844454};\\\", \\\"{x:1151,y:973,t:1526918844494};\\\", \\\"{x:1152,y:973,t:1526918844510};\\\", \\\"{x:1154,y:973,t:1526918844526};\\\", \\\"{x:1155,y:973,t:1526918844542};\\\", \\\"{x:1157,y:973,t:1526918844550};\\\", \\\"{x:1159,y:973,t:1526918844563};\\\", \\\"{x:1160,y:973,t:1526918844598};\\\", \\\"{x:1161,y:973,t:1526918844895};\\\", \\\"{x:1161,y:972,t:1526918844935};\\\", \\\"{x:1161,y:971,t:1526918845150};\\\", \\\"{x:1160,y:971,t:1526918845222};\\\", \\\"{x:1160,y:970,t:1526918845254};\\\", \\\"{x:1159,y:970,t:1526918845542};\\\", \\\"{x:1156,y:970,t:1526918845550};\\\", \\\"{x:1153,y:971,t:1526918845566};\\\", \\\"{x:1152,y:972,t:1526918845583};\\\", \\\"{x:1150,y:972,t:1526918845599};\\\", \\\"{x:1149,y:972,t:1526918845622};\\\", \\\"{x:1148,y:973,t:1526918845633};\\\", \\\"{x:1144,y:974,t:1526918845649};\\\", \\\"{x:1138,y:975,t:1526918845666};\\\", \\\"{x:1132,y:975,t:1526918845683};\\\", \\\"{x:1123,y:976,t:1526918845700};\\\", \\\"{x:1114,y:976,t:1526918845716};\\\", \\\"{x:1110,y:976,t:1526918845733};\\\", \\\"{x:1108,y:976,t:1526918845750};\\\", \\\"{x:1107,y:977,t:1526918845871};\\\", \\\"{x:1107,y:978,t:1526918845910};\\\", \\\"{x:1106,y:978,t:1526918845918};\\\", \\\"{x:1104,y:979,t:1526918845934};\\\", \\\"{x:1103,y:980,t:1526918845950};\\\", \\\"{x:1101,y:981,t:1526918845967};\\\", \\\"{x:1100,y:981,t:1526918846007};\\\", \\\"{x:1100,y:982,t:1526918846039};\\\", \\\"{x:1100,y:983,t:1526918846055};\\\", \\\"{x:1100,y:984,t:1526918846067};\\\", \\\"{x:1101,y:984,t:1526918846084};\\\", \\\"{x:1101,y:985,t:1526918846101};\\\", \\\"{x:1100,y:985,t:1526918846302};\\\", \\\"{x:1100,y:984,t:1526918846318};\\\", \\\"{x:1099,y:982,t:1526918846334};\\\", \\\"{x:1098,y:981,t:1526918846358};\\\", \\\"{x:1098,y:980,t:1526918846439};\\\", \\\"{x:1099,y:980,t:1526918846454};\\\", \\\"{x:1101,y:980,t:1526918846468};\\\", \\\"{x:1103,y:981,t:1526918846485};\\\", \\\"{x:1104,y:981,t:1526918846502};\\\", \\\"{x:1105,y:981,t:1526918846519};\\\", \\\"{x:1106,y:981,t:1526918846534};\\\", \\\"{x:1107,y:981,t:1526918846566};\\\", \\\"{x:1109,y:981,t:1526918846574};\\\", \\\"{x:1110,y:981,t:1526918846585};\\\", \\\"{x:1113,y:979,t:1526918846602};\\\", \\\"{x:1115,y:977,t:1526918846619};\\\", \\\"{x:1116,y:977,t:1526918846636};\\\", \\\"{x:1116,y:975,t:1526918846879};\\\", \\\"{x:1117,y:975,t:1526918846902};\\\", \\\"{x:1117,y:974,t:1526918846927};\\\", \\\"{x:1118,y:973,t:1526918846950};\\\", \\\"{x:1118,y:972,t:1526918846967};\\\", \\\"{x:1119,y:971,t:1526918846975};\\\", \\\"{x:1120,y:971,t:1526918847015};\\\", \\\"{x:1122,y:971,t:1526918847031};\\\", \\\"{x:1123,y:971,t:1526918847055};\\\", \\\"{x:1125,y:971,t:1526918847071};\\\", \\\"{x:1126,y:971,t:1526918847095};\\\", \\\"{x:1128,y:971,t:1526918847119};\\\", \\\"{x:1130,y:969,t:1526918847150};\\\", \\\"{x:1132,y:969,t:1526918847166};\\\", \\\"{x:1133,y:968,t:1526918847174};\\\", \\\"{x:1135,y:968,t:1526918847190};\\\", \\\"{x:1136,y:968,t:1526918847223};\\\", \\\"{x:1138,y:968,t:1526918847350};\\\", \\\"{x:1139,y:968,t:1526918847390};\\\", \\\"{x:1140,y:967,t:1526918847414};\\\", \\\"{x:1141,y:967,t:1526918847430};\\\", \\\"{x:1142,y:967,t:1526918847470};\\\", \\\"{x:1144,y:967,t:1526918847495};\\\", \\\"{x:1145,y:967,t:1526918847510};\\\", \\\"{x:1148,y:967,t:1526918847522};\\\", \\\"{x:1151,y:966,t:1526918847538};\\\", \\\"{x:1153,y:965,t:1526918847555};\\\", \\\"{x:1155,y:965,t:1526918847572};\\\", \\\"{x:1157,y:965,t:1526918847598};\\\", \\\"{x:1158,y:965,t:1526918847606};\\\", \\\"{x:1161,y:965,t:1526918847622};\\\", \\\"{x:1167,y:965,t:1526918847638};\\\", \\\"{x:1169,y:965,t:1526918847655};\\\", \\\"{x:1171,y:965,t:1526918847672};\\\", \\\"{x:1172,y:965,t:1526918847775};\\\", \\\"{x:1173,y:965,t:1526918847814};\\\", \\\"{x:1174,y:965,t:1526918847822};\\\", \\\"{x:1175,y:965,t:1526918847839};\\\", \\\"{x:1176,y:965,t:1526918847886};\\\", \\\"{x:1177,y:965,t:1526918847974};\\\", \\\"{x:1178,y:965,t:1526918847999};\\\", \\\"{x:1179,y:965,t:1526918848407};\\\", \\\"{x:1180,y:965,t:1526918848414};\\\", \\\"{x:1182,y:965,t:1526918848424};\\\", \\\"{x:1186,y:966,t:1526918848441};\\\", \\\"{x:1189,y:966,t:1526918848457};\\\", \\\"{x:1191,y:966,t:1526918848474};\\\", \\\"{x:1192,y:966,t:1526918848491};\\\", \\\"{x:1193,y:966,t:1526918848508};\\\", \\\"{x:1195,y:966,t:1526918848524};\\\", \\\"{x:1196,y:966,t:1526918848542};\\\", \\\"{x:1198,y:967,t:1526918848558};\\\", \\\"{x:1199,y:967,t:1526918848614};\\\", \\\"{x:1200,y:967,t:1526918848638};\\\", \\\"{x:1201,y:967,t:1526918848654};\\\", \\\"{x:1202,y:967,t:1526918848710};\\\", \\\"{x:1203,y:968,t:1526918848725};\\\", \\\"{x:1204,y:968,t:1526918848743};\\\", \\\"{x:1206,y:969,t:1526918848758};\\\", \\\"{x:1208,y:969,t:1526918848998};\\\", \\\"{x:1210,y:969,t:1526918849009};\\\", \\\"{x:1216,y:969,t:1526918849026};\\\", \\\"{x:1222,y:969,t:1526918849043};\\\", \\\"{x:1225,y:969,t:1526918849059};\\\", \\\"{x:1228,y:970,t:1526918849076};\\\", \\\"{x:1229,y:970,t:1526918849093};\\\", \\\"{x:1230,y:971,t:1526918849134};\\\", \\\"{x:1231,y:971,t:1526918849143};\\\", \\\"{x:1232,y:971,t:1526918849174};\\\", \\\"{x:1234,y:971,t:1526918849223};\\\", \\\"{x:1235,y:971,t:1526918849254};\\\", \\\"{x:1237,y:971,t:1526918849270};\\\", \\\"{x:1238,y:971,t:1526918849278};\\\", \\\"{x:1240,y:971,t:1526918849294};\\\", \\\"{x:1242,y:972,t:1526918849310};\\\", \\\"{x:1244,y:972,t:1526918849327};\\\", \\\"{x:1247,y:972,t:1526918849343};\\\", \\\"{x:1249,y:972,t:1526918849360};\\\", \\\"{x:1250,y:972,t:1526918849377};\\\", \\\"{x:1252,y:972,t:1526918849694};\\\", \\\"{x:1254,y:972,t:1526918849711};\\\", \\\"{x:1256,y:972,t:1526918849742};\\\", \\\"{x:1257,y:972,t:1526918849767};\\\", \\\"{x:1259,y:972,t:1526918849790};\\\", \\\"{x:1260,y:972,t:1526918849814};\\\", \\\"{x:1260,y:971,t:1526918849828};\\\", \\\"{x:1262,y:971,t:1526918849870};\\\", \\\"{x:1264,y:971,t:1526918849910};\\\", \\\"{x:1265,y:971,t:1526918849974};\\\", \\\"{x:1266,y:970,t:1526918849982};\\\", \\\"{x:1267,y:969,t:1526918849995};\\\", \\\"{x:1268,y:969,t:1526918850013};\\\", \\\"{x:1269,y:969,t:1526918850029};\\\", \\\"{x:1270,y:969,t:1526918850046};\\\", \\\"{x:1271,y:969,t:1526918850063};\\\", \\\"{x:1272,y:969,t:1526918850079};\\\", \\\"{x:1273,y:969,t:1526918850096};\\\", \\\"{x:1274,y:968,t:1526918850294};\\\", \\\"{x:1275,y:968,t:1526918850334};\\\", \\\"{x:1276,y:968,t:1526918850358};\\\", \\\"{x:1277,y:968,t:1526918850471};\\\", \\\"{x:1279,y:968,t:1526918850480};\\\", \\\"{x:1282,y:968,t:1526918850498};\\\", \\\"{x:1285,y:968,t:1526918850513};\\\", \\\"{x:1288,y:968,t:1526918850531};\\\", \\\"{x:1289,y:968,t:1526918850548};\\\", \\\"{x:1290,y:968,t:1526918850563};\\\", \\\"{x:1292,y:968,t:1526918850583};\\\", \\\"{x:1294,y:968,t:1526918850622};\\\", \\\"{x:1295,y:968,t:1526918850655};\\\", \\\"{x:1296,y:968,t:1526918850670};\\\", \\\"{x:1297,y:968,t:1526918850682};\\\", \\\"{x:1300,y:967,t:1526918850697};\\\", \\\"{x:1303,y:967,t:1526918850714};\\\", \\\"{x:1306,y:966,t:1526918850731};\\\", \\\"{x:1307,y:966,t:1526918850747};\\\", \\\"{x:1308,y:966,t:1526918850975};\\\", \\\"{x:1310,y:966,t:1526918850990};\\\", \\\"{x:1311,y:966,t:1526918851022};\\\", \\\"{x:1312,y:966,t:1526918851127};\\\", \\\"{x:1313,y:966,t:1526918851191};\\\", \\\"{x:1314,y:966,t:1526918851327};\\\", \\\"{x:1316,y:966,t:1526918851342};\\\", \\\"{x:1317,y:966,t:1526918851350};\\\", \\\"{x:1320,y:966,t:1526918851366};\\\", \\\"{x:1323,y:966,t:1526918851383};\\\", \\\"{x:1326,y:966,t:1526918851399};\\\", \\\"{x:1330,y:967,t:1526918851416};\\\", \\\"{x:1331,y:967,t:1526918851434};\\\", \\\"{x:1333,y:967,t:1526918851478};\\\", \\\"{x:1334,y:967,t:1526918851486};\\\", \\\"{x:1335,y:967,t:1526918851499};\\\", \\\"{x:1338,y:967,t:1526918851516};\\\", \\\"{x:1341,y:967,t:1526918851533};\\\", \\\"{x:1343,y:967,t:1526918851550};\\\", \\\"{x:1344,y:967,t:1526918851590};\\\", \\\"{x:1346,y:967,t:1526918851606};\\\", \\\"{x:1347,y:967,t:1526918851616};\\\", \\\"{x:1348,y:967,t:1526918851655};\\\", \\\"{x:1349,y:967,t:1526918851678};\\\", \\\"{x:1350,y:967,t:1526918851694};\\\", \\\"{x:1351,y:967,t:1526918851776};\\\", \\\"{x:1354,y:967,t:1526918851785};\\\", \\\"{x:1357,y:968,t:1526918851800};\\\", \\\"{x:1363,y:970,t:1526918851817};\\\", \\\"{x:1364,y:970,t:1526918851834};\\\", \\\"{x:1365,y:970,t:1526918851851};\\\", \\\"{x:1365,y:971,t:1526918852438};\\\", \\\"{x:1368,y:972,t:1526918852454};\\\", \\\"{x:1370,y:972,t:1526918852470};\\\", \\\"{x:1374,y:972,t:1526918852486};\\\", \\\"{x:1375,y:972,t:1526918852510};\\\", \\\"{x:1376,y:972,t:1526918852526};\\\", \\\"{x:1377,y:972,t:1526918852615};\\\", \\\"{x:1378,y:973,t:1526918852822};\\\", \\\"{x:1380,y:973,t:1526918852837};\\\", \\\"{x:1384,y:973,t:1526918852853};\\\", \\\"{x:1389,y:973,t:1526918852870};\\\", \\\"{x:1391,y:973,t:1526918852888};\\\", \\\"{x:1392,y:973,t:1526918852903};\\\", \\\"{x:1393,y:973,t:1526918852926};\\\", \\\"{x:1394,y:973,t:1526918852942};\\\", \\\"{x:1395,y:973,t:1526918852958};\\\", \\\"{x:1397,y:973,t:1526918852974};\\\", \\\"{x:1398,y:973,t:1526918852987};\\\", \\\"{x:1404,y:973,t:1526918853004};\\\", \\\"{x:1405,y:973,t:1526918853022};\\\", \\\"{x:1407,y:973,t:1526918853046};\\\", \\\"{x:1408,y:973,t:1526918853078};\\\", \\\"{x:1409,y:973,t:1526918853095};\\\", \\\"{x:1410,y:972,t:1526918853104};\\\", \\\"{x:1411,y:972,t:1526918853121};\\\", \\\"{x:1413,y:972,t:1526918853139};\\\", \\\"{x:1414,y:972,t:1526918853183};\\\", \\\"{x:1416,y:972,t:1526918853206};\\\", \\\"{x:1417,y:971,t:1526918853438};\\\", \\\"{x:1418,y:971,t:1526918853510};\\\", \\\"{x:1419,y:971,t:1526918853558};\\\", \\\"{x:1420,y:971,t:1526918853590};\\\", \\\"{x:1422,y:971,t:1526918853606};\\\", \\\"{x:1425,y:971,t:1526918853622};\\\", \\\"{x:1426,y:971,t:1526918853639};\\\", \\\"{x:1430,y:972,t:1526918853657};\\\", \\\"{x:1431,y:972,t:1526918853686};\\\", \\\"{x:1432,y:972,t:1526918853702};\\\", \\\"{x:1433,y:972,t:1526918853710};\\\", \\\"{x:1434,y:972,t:1526918853723};\\\", \\\"{x:1436,y:972,t:1526918853739};\\\", \\\"{x:1438,y:973,t:1526918853756};\\\", \\\"{x:1439,y:973,t:1526918853774};\\\", \\\"{x:1440,y:973,t:1526918853790};\\\", \\\"{x:1441,y:973,t:1526918853806};\\\", \\\"{x:1442,y:973,t:1526918853824};\\\", \\\"{x:1443,y:973,t:1526918853846};\\\", \\\"{x:1444,y:973,t:1526918853861};\\\", \\\"{x:1445,y:973,t:1526918853910};\\\", \\\"{x:1446,y:973,t:1526918853923};\\\", \\\"{x:1452,y:973,t:1526918853940};\\\", \\\"{x:1456,y:973,t:1526918853957};\\\", \\\"{x:1458,y:973,t:1526918853973};\\\", \\\"{x:1460,y:973,t:1526918853991};\\\", \\\"{x:1462,y:973,t:1526918854134};\\\", \\\"{x:1463,y:973,t:1526918854142};\\\", \\\"{x:1464,y:973,t:1526918854158};\\\", \\\"{x:1465,y:973,t:1526918854182};\\\", \\\"{x:1466,y:973,t:1526918854198};\\\", \\\"{x:1467,y:973,t:1526918854222};\\\", \\\"{x:1468,y:973,t:1526918854230};\\\", \\\"{x:1469,y:973,t:1526918854242};\\\", \\\"{x:1472,y:973,t:1526918854257};\\\", \\\"{x:1474,y:973,t:1526918854276};\\\", \\\"{x:1475,y:973,t:1526918854383};\\\", \\\"{x:1476,y:974,t:1526918854399};\\\", \\\"{x:1477,y:975,t:1526918854422};\\\", \\\"{x:1478,y:975,t:1526918854446};\\\", \\\"{x:1481,y:975,t:1526918854459};\\\", \\\"{x:1484,y:975,t:1526918854475};\\\", \\\"{x:1487,y:975,t:1526918854491};\\\", \\\"{x:1489,y:976,t:1526918854870};\\\", \\\"{x:1490,y:976,t:1526918854878};\\\", \\\"{x:1491,y:977,t:1526918854893};\\\", \\\"{x:1492,y:978,t:1526918854909};\\\", \\\"{x:1493,y:978,t:1526918854926};\\\", \\\"{x:1494,y:978,t:1526918854950};\\\", \\\"{x:1494,y:979,t:1526918854966};\\\", \\\"{x:1495,y:979,t:1526918854976};\\\", \\\"{x:1497,y:979,t:1526918854994};\\\", \\\"{x:1500,y:980,t:1526918855010};\\\", \\\"{x:1501,y:980,t:1526918855038};\\\", \\\"{x:1502,y:980,t:1526918855054};\\\", \\\"{x:1503,y:980,t:1526918855062};\\\", \\\"{x:1504,y:981,t:1526918855102};\\\", \\\"{x:1506,y:981,t:1526918855126};\\\", \\\"{x:1507,y:981,t:1526918855134};\\\", \\\"{x:1508,y:981,t:1526918855150};\\\", \\\"{x:1509,y:981,t:1526918855161};\\\", \\\"{x:1512,y:981,t:1526918855178};\\\", \\\"{x:1513,y:981,t:1526918855206};\\\", \\\"{x:1515,y:981,t:1526918855222};\\\", \\\"{x:1516,y:981,t:1526918855230};\\\", \\\"{x:1518,y:981,t:1526918855246};\\\", \\\"{x:1520,y:981,t:1526918855261};\\\", \\\"{x:1521,y:981,t:1526918855286};\\\", \\\"{x:1522,y:981,t:1526918855302};\\\", \\\"{x:1523,y:981,t:1526918855342};\\\", \\\"{x:1524,y:981,t:1526918855374};\\\", \\\"{x:1525,y:981,t:1526918855390};\\\", \\\"{x:1526,y:981,t:1526918855406};\\\", \\\"{x:1527,y:981,t:1526918855422};\\\", \\\"{x:1528,y:981,t:1526918855439};\\\", \\\"{x:1530,y:980,t:1526918855454};\\\", \\\"{x:1532,y:980,t:1526918855470};\\\", \\\"{x:1533,y:980,t:1526918855518};\\\", \\\"{x:1536,y:980,t:1526918855529};\\\", \\\"{x:1538,y:980,t:1526918855544};\\\", \\\"{x:1539,y:980,t:1526918855562};\\\", \\\"{x:1542,y:980,t:1526918855578};\\\", \\\"{x:1543,y:980,t:1526918855606};\\\", \\\"{x:1544,y:980,t:1526918855630};\\\", \\\"{x:1545,y:980,t:1526918855645};\\\", \\\"{x:1546,y:980,t:1526918855662};\\\", \\\"{x:1547,y:980,t:1526918855679};\\\", \\\"{x:1548,y:980,t:1526918855719};\\\", \\\"{x:1550,y:980,t:1526918855728};\\\", \\\"{x:1551,y:980,t:1526918856143};\\\", \\\"{x:1553,y:980,t:1526918856150};\\\", \\\"{x:1554,y:980,t:1526918856164};\\\", \\\"{x:1559,y:980,t:1526918856181};\\\", \\\"{x:1561,y:980,t:1526918856196};\\\", \\\"{x:1562,y:980,t:1526918856213};\\\", \\\"{x:1563,y:980,t:1526918856334};\\\", \\\"{x:1564,y:980,t:1526918856350};\\\", \\\"{x:1565,y:980,t:1526918856365};\\\", \\\"{x:1567,y:980,t:1526918856380};\\\", \\\"{x:1569,y:980,t:1526918856397};\\\", \\\"{x:1571,y:980,t:1526918856414};\\\", \\\"{x:1572,y:980,t:1526918856431};\\\", \\\"{x:1573,y:980,t:1526918856447};\\\", \\\"{x:1574,y:980,t:1526918856486};\\\", \\\"{x:1575,y:980,t:1526918856497};\\\", \\\"{x:1576,y:980,t:1526918856515};\\\", \\\"{x:1577,y:980,t:1526918856558};\\\", \\\"{x:1579,y:980,t:1526918856606};\\\", \\\"{x:1580,y:980,t:1526918856614};\\\", \\\"{x:1584,y:980,t:1526918856631};\\\", \\\"{x:1589,y:980,t:1526918856648};\\\", \\\"{x:1590,y:980,t:1526918856665};\\\", \\\"{x:1591,y:980,t:1526918856681};\\\", \\\"{x:1592,y:980,t:1526918856710};\\\", \\\"{x:1593,y:980,t:1526918856734};\\\", \\\"{x:1594,y:980,t:1526918856749};\\\", \\\"{x:1596,y:980,t:1526918856765};\\\", \\\"{x:1601,y:980,t:1526918856781};\\\", \\\"{x:1603,y:980,t:1526918856798};\\\", \\\"{x:1605,y:979,t:1526918857046};\\\", \\\"{x:1606,y:979,t:1526918857054};\\\", \\\"{x:1607,y:979,t:1526918857065};\\\", \\\"{x:1608,y:978,t:1526918857082};\\\", \\\"{x:1610,y:977,t:1526918857099};\\\", \\\"{x:1611,y:977,t:1526918857116};\\\", \\\"{x:1614,y:977,t:1526918857133};\\\", \\\"{x:1616,y:975,t:1526918857149};\\\", \\\"{x:1617,y:975,t:1526918857166};\\\", \\\"{x:1619,y:975,t:1526918857183};\\\", \\\"{x:1622,y:974,t:1526918857200};\\\", \\\"{x:1624,y:974,t:1526918857216};\\\", \\\"{x:1627,y:973,t:1526918857234};\\\", \\\"{x:1630,y:973,t:1526918857249};\\\", \\\"{x:1630,y:972,t:1526918857266};\\\", \\\"{x:1631,y:972,t:1526918857285};\\\", \\\"{x:1632,y:972,t:1526918857300};\\\", \\\"{x:1635,y:972,t:1526918857316};\\\", \\\"{x:1640,y:972,t:1526918857334};\\\", \\\"{x:1641,y:971,t:1526918857702};\\\", \\\"{x:1643,y:971,t:1526918857718};\\\", \\\"{x:1645,y:971,t:1526918857854};\\\", \\\"{x:1646,y:971,t:1526918857869};\\\", \\\"{x:1649,y:971,t:1526918857885};\\\", \\\"{x:1651,y:971,t:1526918857901};\\\", \\\"{x:1653,y:972,t:1526918857918};\\\", \\\"{x:1654,y:972,t:1526918857936};\\\", \\\"{x:1656,y:973,t:1526918857951};\\\", \\\"{x:1658,y:973,t:1526918857969};\\\", \\\"{x:1659,y:973,t:1526918857985};\\\", \\\"{x:1662,y:974,t:1526918858001};\\\", \\\"{x:1662,y:975,t:1526918858018};\\\", \\\"{x:1665,y:975,t:1526918858035};\\\", \\\"{x:1668,y:976,t:1526918858052};\\\", \\\"{x:1670,y:976,t:1526918858069};\\\", \\\"{x:1671,y:976,t:1526918858415};\\\", \\\"{x:1672,y:976,t:1526918858423};\\\", \\\"{x:1673,y:976,t:1526918858436};\\\", \\\"{x:1674,y:976,t:1526918858454};\\\", \\\"{x:1675,y:976,t:1526918858469};\\\", \\\"{x:1676,y:976,t:1526918858487};\\\", \\\"{x:1677,y:976,t:1526918858503};\\\", \\\"{x:1678,y:976,t:1526918858534};\\\", \\\"{x:1679,y:976,t:1526918858550};\\\", \\\"{x:1680,y:976,t:1526918858558};\\\", \\\"{x:1681,y:976,t:1526918858570};\\\", \\\"{x:1686,y:976,t:1526918858586};\\\", \\\"{x:1688,y:976,t:1526918858604};\\\", \\\"{x:1690,y:976,t:1526918858621};\\\", \\\"{x:1692,y:976,t:1526918858637};\\\", \\\"{x:1693,y:976,t:1526918858662};\\\", \\\"{x:1695,y:976,t:1526918858670};\\\", \\\"{x:1697,y:976,t:1526918858688};\\\", \\\"{x:1700,y:976,t:1526918858704};\\\", \\\"{x:1702,y:976,t:1526918858721};\\\", \\\"{x:1704,y:976,t:1526918858737};\\\", \\\"{x:1705,y:976,t:1526918858766};\\\", \\\"{x:1707,y:976,t:1526918858814};\\\", \\\"{x:1708,y:976,t:1526918858838};\\\", \\\"{x:1709,y:976,t:1526918858862};\\\", \\\"{x:1710,y:976,t:1526918858878};\\\", \\\"{x:1711,y:976,t:1526918858887};\\\", \\\"{x:1713,y:976,t:1526918858910};\\\", \\\"{x:1714,y:976,t:1526918858922};\\\", \\\"{x:1716,y:976,t:1526918858938};\\\", \\\"{x:1717,y:976,t:1526918858954};\\\", \\\"{x:1719,y:976,t:1526918858971};\\\", \\\"{x:1721,y:976,t:1526918859046};\\\", \\\"{x:1722,y:976,t:1526918859070};\\\", \\\"{x:1723,y:976,t:1526918859238};\\\", \\\"{x:1724,y:976,t:1526918859310};\\\", \\\"{x:1725,y:976,t:1526918859350};\\\", \\\"{x:1726,y:976,t:1526918859366};\\\", \\\"{x:1727,y:976,t:1526918859390};\\\", \\\"{x:1728,y:976,t:1526918859406};\\\", \\\"{x:1734,y:976,t:1526918859422};\\\", \\\"{x:1736,y:976,t:1526918859440};\\\", \\\"{x:1739,y:976,t:1526918859457};\\\", \\\"{x:1740,y:976,t:1526918859478};\\\", \\\"{x:1742,y:976,t:1526918859502};\\\", \\\"{x:1743,y:976,t:1526918859534};\\\", \\\"{x:1745,y:976,t:1526918859550};\\\", \\\"{x:1746,y:976,t:1526918859574};\\\", \\\"{x:1746,y:977,t:1526918859646};\\\", \\\"{x:1747,y:978,t:1526918859662};\\\", \\\"{x:1748,y:978,t:1526918859673};\\\", \\\"{x:1749,y:978,t:1526918859689};\\\", \\\"{x:1751,y:978,t:1526918859706};\\\", \\\"{x:1753,y:978,t:1526918860134};\\\", \\\"{x:1755,y:978,t:1526918860142};\\\", \\\"{x:1756,y:978,t:1526918860157};\\\", \\\"{x:1762,y:978,t:1526918860174};\\\", \\\"{x:1763,y:978,t:1526918860214};\\\", \\\"{x:1764,y:978,t:1526918860262};\\\", \\\"{x:1765,y:978,t:1526918860275};\\\", \\\"{x:1766,y:978,t:1526918860302};\\\", \\\"{x:1768,y:979,t:1526918860310};\\\", \\\"{x:1771,y:980,t:1526918860334};\\\", \\\"{x:1772,y:980,t:1526918860342};\\\", \\\"{x:1773,y:980,t:1526918860358};\\\", \\\"{x:1774,y:980,t:1526918860377};\\\", \\\"{x:1775,y:980,t:1526918860758};\\\", \\\"{x:1778,y:980,t:1526918860766};\\\", \\\"{x:1782,y:981,t:1526918860777};\\\", \\\"{x:1785,y:981,t:1526918860794};\\\", \\\"{x:1788,y:982,t:1526918860809};\\\", \\\"{x:1789,y:982,t:1526918860826};\\\", \\\"{x:1790,y:982,t:1526918860846};\\\", \\\"{x:1791,y:982,t:1526918860877};\\\", \\\"{x:1792,y:982,t:1526918860910};\\\", \\\"{x:1794,y:982,t:1526918860934};\\\", \\\"{x:1795,y:981,t:1526918860958};\\\", \\\"{x:1796,y:981,t:1526918860982};\\\", \\\"{x:1798,y:981,t:1526918860993};\\\", \\\"{x:1799,y:981,t:1526918861010};\\\", \\\"{x:1801,y:981,t:1526918861028};\\\", \\\"{x:1802,y:980,t:1526918861043};\\\", \\\"{x:1804,y:980,t:1526918861062};\\\", \\\"{x:1805,y:980,t:1526918861086};\\\", \\\"{x:1806,y:979,t:1526918861406};\\\", \\\"{x:1807,y:979,t:1526918861414};\\\", \\\"{x:1808,y:979,t:1526918861428};\\\", \\\"{x:1810,y:979,t:1526918861462};\\\", \\\"{x:1811,y:979,t:1526918861485};\\\", \\\"{x:1813,y:979,t:1526918861501};\\\", \\\"{x:1815,y:979,t:1526918861526};\\\", \\\"{x:1817,y:979,t:1526918861542};\\\", \\\"{x:1819,y:979,t:1526918861550};\\\", \\\"{x:1820,y:979,t:1526918861563};\\\", \\\"{x:1821,y:979,t:1526918861578};\\\", \\\"{x:1822,y:979,t:1526918861622};\\\", \\\"{x:1823,y:979,t:1526918861638};\\\", \\\"{x:1824,y:978,t:1526918861654};\\\", \\\"{x:1826,y:978,t:1526918861693};\\\", \\\"{x:1827,y:978,t:1526918861775};\\\", \\\"{x:1828,y:978,t:1526918861862};\\\", \\\"{x:1831,y:977,t:1526918861880};\\\", \\\"{x:1842,y:977,t:1526918861897};\\\", \\\"{x:1846,y:977,t:1526918861914};\\\", \\\"{x:1847,y:977,t:1526918861930};\\\", \\\"{x:1846,y:977,t:1526918862261};\\\", \\\"{x:1838,y:976,t:1526918862269};\\\", \\\"{x:1833,y:975,t:1526918862281};\\\", \\\"{x:1805,y:972,t:1526918862297};\\\", \\\"{x:1746,y:962,t:1526918862315};\\\", \\\"{x:1637,y:940,t:1526918862331};\\\", \\\"{x:1498,y:917,t:1526918862348};\\\", \\\"{x:1359,y:895,t:1526918862364};\\\", \\\"{x:1215,y:872,t:1526918862382};\\\", \\\"{x:1070,y:843,t:1526918862397};\\\", \\\"{x:878,y:801,t:1526918862414};\\\", \\\"{x:750,y:780,t:1526918862431};\\\", \\\"{x:625,y:759,t:1526918862447};\\\", \\\"{x:502,y:739,t:1526918862465};\\\", \\\"{x:412,y:718,t:1526918862482};\\\", \\\"{x:325,y:689,t:1526918862499};\\\", \\\"{x:231,y:663,t:1526918862523};\\\", \\\"{x:188,y:656,t:1526918862540};\\\", \\\"{x:169,y:653,t:1526918862557};\\\", \\\"{x:165,y:651,t:1526918862573};\\\", \\\"{x:164,y:651,t:1526918862606};\\\", \\\"{x:164,y:650,t:1526918862623};\\\", \\\"{x:164,y:648,t:1526918862639};\\\", \\\"{x:164,y:645,t:1526918862656};\\\", \\\"{x:164,y:641,t:1526918862673};\\\", \\\"{x:171,y:634,t:1526918862690};\\\", \\\"{x:183,y:626,t:1526918862706};\\\", \\\"{x:192,y:621,t:1526918862723};\\\", \\\"{x:206,y:615,t:1526918862740};\\\", \\\"{x:226,y:611,t:1526918862757};\\\", \\\"{x:256,y:605,t:1526918862774};\\\", \\\"{x:283,y:605,t:1526918862790};\\\", \\\"{x:305,y:605,t:1526918862806};\\\", \\\"{x:326,y:605,t:1526918862823};\\\", \\\"{x:348,y:607,t:1526918862839};\\\", \\\"{x:366,y:614,t:1526918862857};\\\", \\\"{x:381,y:618,t:1526918862873};\\\", \\\"{x:390,y:622,t:1526918862891};\\\", \\\"{x:395,y:625,t:1526918862907};\\\", \\\"{x:400,y:627,t:1526918862923};\\\", \\\"{x:405,y:630,t:1526918862940};\\\", \\\"{x:414,y:635,t:1526918862956};\\\", \\\"{x:442,y:649,t:1526918862974};\\\", \\\"{x:456,y:656,t:1526918862990};\\\", \\\"{x:457,y:656,t:1526918863006};\\\", \\\"{x:458,y:657,t:1526918863542};\\\", \\\"{x:458,y:656,t:1526918863566};\\\", \\\"{x:458,y:655,t:1526918863574};\\\", \\\"{x:457,y:654,t:1526918863598};\\\", \\\"{x:457,y:653,t:1526918863608};\\\", \\\"{x:457,y:652,t:1526918863623};\\\", \\\"{x:454,y:648,t:1526918863641};\\\", \\\"{x:452,y:646,t:1526918863658};\\\", \\\"{x:450,y:643,t:1526918863673};\\\", \\\"{x:449,y:641,t:1526918863691};\\\", \\\"{x:448,y:640,t:1526918863708};\\\", \\\"{x:448,y:639,t:1526918863724};\\\", \\\"{x:448,y:638,t:1526918863750};\\\", \\\"{x:448,y:637,t:1526918863758};\\\", \\\"{x:447,y:635,t:1526918863774};\\\", \\\"{x:446,y:633,t:1526918863790};\\\", \\\"{x:446,y:631,t:1526918863808};\\\", \\\"{x:444,y:629,t:1526918863823};\\\", \\\"{x:442,y:626,t:1526918863840};\\\", \\\"{x:440,y:625,t:1526918863858};\\\", \\\"{x:435,y:622,t:1526918863873};\\\", \\\"{x:433,y:622,t:1526918863890};\\\", \\\"{x:433,y:620,t:1526918863907};\\\", \\\"{x:431,y:619,t:1526918863924};\\\", \\\"{x:429,y:619,t:1526918863998};\\\", \\\"{x:428,y:619,t:1526918864007};\\\", \\\"{x:427,y:619,t:1526918864024};\\\", \\\"{x:425,y:619,t:1526918864040};\\\", \\\"{x:424,y:619,t:1526918864058};\\\", \\\"{x:423,y:619,t:1526918864077};\\\", \\\"{x:421,y:619,t:1526918864090};\\\", \\\"{x:418,y:619,t:1526918864107};\\\", \\\"{x:415,y:620,t:1526918864125};\\\", \\\"{x:411,y:621,t:1526918864140};\\\", \\\"{x:407,y:621,t:1526918864157};\\\", \\\"{x:404,y:621,t:1526918864173};\\\", \\\"{x:401,y:622,t:1526918864191};\\\", \\\"{x:396,y:622,t:1526918864208};\\\", \\\"{x:389,y:623,t:1526918864224};\\\", \\\"{x:380,y:624,t:1526918864241};\\\", \\\"{x:369,y:625,t:1526918864257};\\\", \\\"{x:356,y:625,t:1526918864274};\\\", \\\"{x:345,y:625,t:1526918864290};\\\", \\\"{x:333,y:625,t:1526918864307};\\\", \\\"{x:319,y:625,t:1526918864325};\\\", \\\"{x:300,y:625,t:1526918864341};\\\", \\\"{x:268,y:625,t:1526918864359};\\\", \\\"{x:245,y:625,t:1526918864375};\\\", \\\"{x:221,y:625,t:1526918864392};\\\", \\\"{x:210,y:625,t:1526918864408};\\\", \\\"{x:203,y:625,t:1526918864425};\\\", \\\"{x:202,y:625,t:1526918864542};\\\", \\\"{x:200,y:625,t:1526918864557};\\\", \\\"{x:198,y:623,t:1526918864574};\\\", \\\"{x:198,y:620,t:1526918864591};\\\", \\\"{x:198,y:619,t:1526918864607};\\\", \\\"{x:198,y:617,t:1526918864630};\\\", \\\"{x:200,y:616,t:1526918864642};\\\", \\\"{x:211,y:616,t:1526918864658};\\\", \\\"{x:238,y:623,t:1526918864675};\\\", \\\"{x:277,y:629,t:1526918864692};\\\", \\\"{x:353,y:644,t:1526918864709};\\\", \\\"{x:428,y:653,t:1526918864727};\\\", \\\"{x:505,y:664,t:1526918864743};\\\", \\\"{x:527,y:664,t:1526918864759};\\\", \\\"{x:531,y:664,t:1526918864775};\\\", \\\"{x:535,y:660,t:1526918864792};\\\", \\\"{x:535,y:651,t:1526918864809};\\\", \\\"{x:535,y:643,t:1526918864825};\\\", \\\"{x:540,y:637,t:1526918864841};\\\", \\\"{x:551,y:631,t:1526918864859};\\\", \\\"{x:563,y:628,t:1526918864875};\\\", \\\"{x:572,y:624,t:1526918864892};\\\", \\\"{x:585,y:619,t:1526918864909};\\\", \\\"{x:605,y:614,t:1526918864925};\\\", \\\"{x:648,y:612,t:1526918864942};\\\", \\\"{x:685,y:612,t:1526918864958};\\\", \\\"{x:720,y:612,t:1526918864975};\\\", \\\"{x:740,y:612,t:1526918864992};\\\", \\\"{x:746,y:612,t:1526918865008};\\\", \\\"{x:746,y:613,t:1526918865070};\\\", \\\"{x:744,y:616,t:1526918865079};\\\", \\\"{x:741,y:621,t:1526918865092};\\\", \\\"{x:736,y:631,t:1526918865107};\\\", \\\"{x:729,y:639,t:1526918865125};\\\", \\\"{x:721,y:648,t:1526918865142};\\\", \\\"{x:714,y:652,t:1526918865159};\\\", \\\"{x:706,y:659,t:1526918865175};\\\", \\\"{x:699,y:662,t:1526918865192};\\\", \\\"{x:685,y:666,t:1526918865209};\\\", \\\"{x:670,y:668,t:1526918865225};\\\", \\\"{x:650,y:669,t:1526918865242};\\\", \\\"{x:628,y:670,t:1526918865259};\\\", \\\"{x:605,y:670,t:1526918865275};\\\", \\\"{x:584,y:669,t:1526918865292};\\\", \\\"{x:575,y:667,t:1526918865308};\\\", \\\"{x:571,y:667,t:1526918865325};\\\", \\\"{x:570,y:666,t:1526918865358};\\\", \\\"{x:570,y:665,t:1526918865382};\\\", \\\"{x:570,y:664,t:1526918865398};\\\", \\\"{x:570,y:663,t:1526918865409};\\\", \\\"{x:570,y:662,t:1526918865426};\\\", \\\"{x:574,y:658,t:1526918865442};\\\", \\\"{x:576,y:657,t:1526918865458};\\\", \\\"{x:577,y:657,t:1526918865476};\\\", \\\"{x:579,y:655,t:1526918865493};\\\", \\\"{x:580,y:655,t:1526918865509};\\\", \\\"{x:582,y:655,t:1526918865526};\\\", \\\"{x:584,y:655,t:1526918865542};\\\", \\\"{x:586,y:655,t:1526918865559};\\\", \\\"{x:587,y:654,t:1526918865578};\\\", \\\"{x:590,y:652,t:1526918865592};\\\", \\\"{x:591,y:652,t:1526918865609};\\\", \\\"{x:593,y:652,t:1526918865626};\\\", \\\"{x:596,y:652,t:1526918865643};\\\", \\\"{x:600,y:652,t:1526918865659};\\\", \\\"{x:601,y:652,t:1526918865676};\\\", \\\"{x:604,y:652,t:1526918865693};\\\", \\\"{x:605,y:652,t:1526918865735};\\\", \\\"{x:606,y:652,t:1526918865776};\\\", \\\"{x:607,y:652,t:1526918865793};\\\", \\\"{x:609,y:652,t:1526918865809};\\\", \\\"{x:610,y:648,t:1526918865826};\\\", \\\"{x:611,y:646,t:1526918865842};\\\", \\\"{x:611,y:644,t:1526918865859};\\\", \\\"{x:611,y:642,t:1526918865876};\\\", \\\"{x:611,y:641,t:1526918865893};\\\", \\\"{x:611,y:640,t:1526918865917};\\\", \\\"{x:611,y:639,t:1526918865990};\\\", \\\"{x:611,y:638,t:1526918866006};\\\", \\\"{x:611,y:637,t:1526918866014};\\\", \\\"{x:611,y:636,t:1526918866029};\\\", \\\"{x:611,y:635,t:1526918866042};\\\", \\\"{x:611,y:634,t:1526918866060};\\\", \\\"{x:613,y:633,t:1526918866076};\\\", \\\"{x:613,y:630,t:1526918866093};\\\", \\\"{x:614,y:628,t:1526918866110};\\\", \\\"{x:619,y:623,t:1526918866127};\\\", \\\"{x:626,y:620,t:1526918866144};\\\", \\\"{x:635,y:616,t:1526918866160};\\\", \\\"{x:648,y:613,t:1526918866176};\\\", \\\"{x:659,y:612,t:1526918866193};\\\", \\\"{x:681,y:610,t:1526918866210};\\\", \\\"{x:703,y:610,t:1526918866225};\\\", \\\"{x:725,y:610,t:1526918866243};\\\", \\\"{x:745,y:610,t:1526918866259};\\\", \\\"{x:768,y:610,t:1526918866276};\\\", \\\"{x:792,y:612,t:1526918866293};\\\", \\\"{x:821,y:616,t:1526918866310};\\\", \\\"{x:828,y:616,t:1526918866326};\\\", \\\"{x:830,y:617,t:1526918866343};\\\", \\\"{x:831,y:617,t:1526918866445};\\\", \\\"{x:831,y:615,t:1526918866469};\\\", \\\"{x:825,y:615,t:1526918866478};\\\", \\\"{x:815,y:614,t:1526918866493};\\\", \\\"{x:750,y:608,t:1526918866510};\\\", \\\"{x:652,y:604,t:1526918866527};\\\", \\\"{x:528,y:604,t:1526918866542};\\\", \\\"{x:425,y:602,t:1526918866560};\\\", \\\"{x:369,y:602,t:1526918866576};\\\", \\\"{x:346,y:602,t:1526918866593};\\\", \\\"{x:341,y:602,t:1526918866610};\\\", \\\"{x:340,y:602,t:1526918866626};\\\", \\\"{x:340,y:606,t:1526918866643};\\\", \\\"{x:341,y:611,t:1526918866660};\\\", \\\"{x:341,y:615,t:1526918866677};\\\", \\\"{x:341,y:622,t:1526918866693};\\\", \\\"{x:341,y:630,t:1526918866709};\\\", \\\"{x:341,y:633,t:1526918866727};\\\", \\\"{x:341,y:638,t:1526918866743};\\\", \\\"{x:343,y:641,t:1526918866760};\\\", \\\"{x:345,y:644,t:1526918866777};\\\", \\\"{x:348,y:648,t:1526918866793};\\\", \\\"{x:351,y:650,t:1526918866810};\\\", \\\"{x:356,y:653,t:1526918866827};\\\", \\\"{x:361,y:654,t:1526918866844};\\\", \\\"{x:364,y:656,t:1526918866860};\\\", \\\"{x:366,y:656,t:1526918866876};\\\", \\\"{x:370,y:658,t:1526918866894};\\\", \\\"{x:370,y:659,t:1526918866910};\\\", \\\"{x:372,y:660,t:1526918866927};\\\", \\\"{x:375,y:662,t:1526918866944};\\\", \\\"{x:375,y:663,t:1526918866959};\\\", \\\"{x:376,y:663,t:1526918866981};\\\", \\\"{x:377,y:664,t:1526918866993};\\\", \\\"{x:377,y:665,t:1526918867462};\\\", \\\"{x:379,y:666,t:1526918867477};\\\", \\\"{x:383,y:671,t:1526918867493};\\\", \\\"{x:387,y:675,t:1526918867511};\\\", \\\"{x:391,y:678,t:1526918867527};\\\", \\\"{x:393,y:678,t:1526918867544};\\\", \\\"{x:394,y:679,t:1526918867630};\\\", \\\"{x:394,y:680,t:1526918867646};\\\", \\\"{x:394,y:681,t:1526918867661};\\\", \\\"{x:402,y:690,t:1526918867678};\\\", \\\"{x:412,y:700,t:1526918867693};\\\", \\\"{x:419,y:708,t:1526918867711};\\\", \\\"{x:430,y:715,t:1526918867727};\\\", \\\"{x:435,y:717,t:1526918867743};\\\", \\\"{x:436,y:717,t:1526918867761};\\\", \\\"{x:437,y:718,t:1526918867797};\\\", \\\"{x:438,y:719,t:1526918867814};\\\", \\\"{x:439,y:720,t:1526918867827};\\\", \\\"{x:441,y:721,t:1526918867843};\\\", \\\"{x:442,y:722,t:1526918867869};\\\", \\\"{x:443,y:723,t:1526918867909};\\\", \\\"{x:445,y:724,t:1526918867918};\\\", \\\"{x:445,y:725,t:1526918867928};\\\", \\\"{x:448,y:728,t:1526918867943};\\\", \\\"{x:450,y:730,t:1526918867961};\\\", \\\"{x:451,y:732,t:1526918867978};\\\", \\\"{x:451,y:733,t:1526918867998};\\\", \\\"{x:452,y:733,t:1526918868022};\\\", \\\"{x:452,y:734,t:1526918868030};\\\", \\\"{x:452,y:735,t:1526918868044};\\\", \\\"{x:453,y:739,t:1526918868062};\\\", \\\"{x:454,y:740,t:1526918868078};\\\", \\\"{x:456,y:742,t:1526918868158};\\\", \\\"{x:456,y:743,t:1526918868173};\\\", \\\"{x:456,y:744,t:1526918868198};\\\", \\\"{x:456,y:745,t:1526918868246};\\\", \\\"{x:458,y:746,t:1526918868261};\\\", \\\"{x:459,y:747,t:1526918868278};\\\" ] }, { \\\"rt\\\": 38825, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 149152, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-08 AM-09 AM-10 AM-09 AM-08 AM-09 AM-09 AM-10 AM-10 AM-11 AM-12 PM-01 PM-02 PM-03 PM-04 PM-05 PM-06 PM-07 PM-08 PM-07 PM-06 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:459,y:745,t:1526918870542};\\\", \\\"{x:457,y:742,t:1526918870550};\\\", \\\"{x:453,y:736,t:1526918870562};\\\", \\\"{x:446,y:724,t:1526918870578};\\\", \\\"{x:442,y:712,t:1526918870596};\\\", \\\"{x:439,y:701,t:1526918870613};\\\", \\\"{x:432,y:677,t:1526918870631};\\\", \\\"{x:428,y:662,t:1526918870647};\\\", \\\"{x:426,y:646,t:1526918870663};\\\", \\\"{x:425,y:631,t:1526918870680};\\\", \\\"{x:425,y:623,t:1526918870697};\\\", \\\"{x:427,y:613,t:1526918870713};\\\", \\\"{x:427,y:610,t:1526918870730};\\\", \\\"{x:431,y:605,t:1526918870747};\\\", \\\"{x:434,y:600,t:1526918870763};\\\", \\\"{x:434,y:598,t:1526918871399};\\\", \\\"{x:433,y:594,t:1526918871414};\\\", \\\"{x:433,y:590,t:1526918871430};\\\", \\\"{x:432,y:587,t:1526918871447};\\\", \\\"{x:432,y:584,t:1526918871464};\\\", \\\"{x:432,y:583,t:1526918871480};\\\", \\\"{x:433,y:581,t:1526918871497};\\\", \\\"{x:434,y:579,t:1526918871515};\\\", \\\"{x:436,y:578,t:1526918871530};\\\", \\\"{x:438,y:576,t:1526918871547};\\\", \\\"{x:440,y:573,t:1526918871564};\\\", \\\"{x:443,y:570,t:1526918871581};\\\", \\\"{x:445,y:567,t:1526918871598};\\\", \\\"{x:447,y:565,t:1526918871614};\\\", \\\"{x:449,y:563,t:1526918871631};\\\", \\\"{x:451,y:562,t:1526918871647};\\\", \\\"{x:455,y:559,t:1526918871664};\\\", \\\"{x:458,y:558,t:1526918871681};\\\", \\\"{x:461,y:555,t:1526918871696};\\\", \\\"{x:465,y:552,t:1526918871714};\\\", \\\"{x:468,y:549,t:1526918871731};\\\", \\\"{x:470,y:547,t:1526918871747};\\\", \\\"{x:472,y:545,t:1526918871764};\\\", \\\"{x:474,y:543,t:1526918871780};\\\", \\\"{x:476,y:541,t:1526918871797};\\\", \\\"{x:480,y:537,t:1526918871814};\\\", \\\"{x:480,y:535,t:1526918871830};\\\", \\\"{x:481,y:535,t:1526918871847};\\\", \\\"{x:481,y:533,t:1526918871894};\\\", \\\"{x:482,y:532,t:1526918871902};\\\", \\\"{x:482,y:531,t:1526918871918};\\\", \\\"{x:484,y:529,t:1526918871931};\\\", \\\"{x:484,y:528,t:1526918871947};\\\", \\\"{x:486,y:527,t:1526918871964};\\\", \\\"{x:488,y:526,t:1526918871981};\\\", \\\"{x:490,y:524,t:1526918871997};\\\", \\\"{x:492,y:522,t:1526918872014};\\\", \\\"{x:494,y:521,t:1526918872031};\\\", \\\"{x:496,y:520,t:1526918872047};\\\", \\\"{x:497,y:520,t:1526918872064};\\\", \\\"{x:497,y:519,t:1526918872081};\\\", \\\"{x:498,y:519,t:1526918872102};\\\", \\\"{x:499,y:519,t:1526918872118};\\\", \\\"{x:500,y:518,t:1526918872131};\\\", \\\"{x:502,y:518,t:1526918872147};\\\", \\\"{x:510,y:518,t:1526918872164};\\\", \\\"{x:532,y:518,t:1526918872182};\\\", \\\"{x:560,y:520,t:1526918872197};\\\", \\\"{x:638,y:541,t:1526918872214};\\\", \\\"{x:713,y:565,t:1526918872232};\\\", \\\"{x:791,y:587,t:1526918872248};\\\", \\\"{x:877,y:614,t:1526918872264};\\\", \\\"{x:958,y:638,t:1526918872281};\\\", \\\"{x:1044,y:661,t:1526918872298};\\\", \\\"{x:1132,y:698,t:1526918872315};\\\", \\\"{x:1212,y:731,t:1526918872331};\\\", \\\"{x:1294,y:767,t:1526918872348};\\\", \\\"{x:1370,y:803,t:1526918872365};\\\", \\\"{x:1433,y:829,t:1526918872381};\\\", \\\"{x:1515,y:868,t:1526918872398};\\\", \\\"{x:1541,y:885,t:1526918872415};\\\", \\\"{x:1553,y:893,t:1526918872431};\\\", \\\"{x:1557,y:898,t:1526918872448};\\\", \\\"{x:1557,y:899,t:1526918872469};\\\", \\\"{x:1557,y:900,t:1526918872526};\\\", \\\"{x:1557,y:901,t:1526918872533};\\\", \\\"{x:1556,y:903,t:1526918872550};\\\", \\\"{x:1555,y:904,t:1526918872566};\\\", \\\"{x:1551,y:907,t:1526918872581};\\\", \\\"{x:1544,y:913,t:1526918872598};\\\", \\\"{x:1535,y:917,t:1526918872615};\\\", \\\"{x:1525,y:923,t:1526918872631};\\\", \\\"{x:1518,y:926,t:1526918872649};\\\", \\\"{x:1515,y:926,t:1526918872665};\\\", \\\"{x:1514,y:926,t:1526918872682};\\\", \\\"{x:1512,y:926,t:1526918872726};\\\", \\\"{x:1511,y:926,t:1526918872733};\\\", \\\"{x:1504,y:925,t:1526918872748};\\\", \\\"{x:1493,y:924,t:1526918872765};\\\", \\\"{x:1469,y:920,t:1526918872782};\\\", \\\"{x:1456,y:919,t:1526918872797};\\\", \\\"{x:1443,y:917,t:1526918872815};\\\", \\\"{x:1428,y:915,t:1526918872832};\\\", \\\"{x:1419,y:913,t:1526918872847};\\\", \\\"{x:1404,y:909,t:1526918872865};\\\", \\\"{x:1396,y:907,t:1526918872882};\\\", \\\"{x:1385,y:905,t:1526918872898};\\\", \\\"{x:1377,y:905,t:1526918872914};\\\", \\\"{x:1366,y:904,t:1526918872932};\\\", \\\"{x:1357,y:901,t:1526918872948};\\\", \\\"{x:1350,y:899,t:1526918872965};\\\", \\\"{x:1344,y:897,t:1526918872982};\\\", \\\"{x:1338,y:896,t:1526918872999};\\\", \\\"{x:1334,y:895,t:1526918873015};\\\", \\\"{x:1326,y:893,t:1526918873032};\\\", \\\"{x:1319,y:891,t:1526918873049};\\\", \\\"{x:1310,y:890,t:1526918873065};\\\", \\\"{x:1299,y:887,t:1526918873082};\\\", \\\"{x:1293,y:884,t:1526918873099};\\\", \\\"{x:1280,y:882,t:1526918873115};\\\", \\\"{x:1272,y:881,t:1526918873132};\\\", \\\"{x:1268,y:878,t:1526918873149};\\\", \\\"{x:1256,y:878,t:1526918873164};\\\", \\\"{x:1247,y:878,t:1526918873182};\\\", \\\"{x:1246,y:878,t:1526918873199};\\\", \\\"{x:1244,y:878,t:1526918873215};\\\", \\\"{x:1243,y:878,t:1526918873232};\\\", \\\"{x:1241,y:878,t:1526918873249};\\\", \\\"{x:1240,y:878,t:1526918873265};\\\", \\\"{x:1238,y:878,t:1526918873282};\\\", \\\"{x:1237,y:876,t:1526918873299};\\\", \\\"{x:1236,y:876,t:1526918873314};\\\", \\\"{x:1236,y:875,t:1526918873332};\\\", \\\"{x:1234,y:874,t:1526918873349};\\\", \\\"{x:1233,y:874,t:1526918873453};\\\", \\\"{x:1232,y:874,t:1526918873466};\\\", \\\"{x:1229,y:876,t:1526918873482};\\\", \\\"{x:1224,y:878,t:1526918873499};\\\", \\\"{x:1218,y:883,t:1526918873515};\\\", \\\"{x:1210,y:889,t:1526918873531};\\\", \\\"{x:1204,y:893,t:1526918873549};\\\", \\\"{x:1197,y:897,t:1526918873565};\\\", \\\"{x:1192,y:902,t:1526918873582};\\\", \\\"{x:1186,y:906,t:1526918873599};\\\", \\\"{x:1182,y:911,t:1526918873616};\\\", \\\"{x:1179,y:913,t:1526918873632};\\\", \\\"{x:1176,y:916,t:1526918873649};\\\", \\\"{x:1173,y:919,t:1526918873666};\\\", \\\"{x:1169,y:925,t:1526918873682};\\\", \\\"{x:1168,y:929,t:1526918873699};\\\", \\\"{x:1165,y:932,t:1526918873716};\\\", \\\"{x:1161,y:938,t:1526918873733};\\\", \\\"{x:1158,y:942,t:1526918873749};\\\", \\\"{x:1154,y:947,t:1526918873765};\\\", \\\"{x:1152,y:951,t:1526918873782};\\\", \\\"{x:1148,y:956,t:1526918873799};\\\", \\\"{x:1146,y:958,t:1526918873816};\\\", \\\"{x:1140,y:964,t:1526918873833};\\\", \\\"{x:1135,y:969,t:1526918873849};\\\", \\\"{x:1131,y:973,t:1526918873865};\\\", \\\"{x:1129,y:976,t:1526918873883};\\\", \\\"{x:1128,y:977,t:1526918873899};\\\", \\\"{x:1127,y:978,t:1526918873916};\\\", \\\"{x:1127,y:979,t:1526918873941};\\\", \\\"{x:1126,y:979,t:1526918873958};\\\", \\\"{x:1125,y:980,t:1526918873965};\\\", \\\"{x:1124,y:980,t:1526918873983};\\\", \\\"{x:1123,y:980,t:1526918874262};\\\", \\\"{x:1121,y:980,t:1526918874309};\\\", \\\"{x:1119,y:980,t:1526918874317};\\\", \\\"{x:1116,y:980,t:1526918874333};\\\", \\\"{x:1113,y:980,t:1526918874349};\\\", \\\"{x:1112,y:980,t:1526918874366};\\\", \\\"{x:1111,y:980,t:1526918874397};\\\", \\\"{x:1110,y:980,t:1526918874405};\\\", \\\"{x:1109,y:980,t:1526918874416};\\\", \\\"{x:1108,y:980,t:1526918874433};\\\", \\\"{x:1106,y:980,t:1526918874450};\\\", \\\"{x:1105,y:978,t:1526918874467};\\\", \\\"{x:1103,y:978,t:1526918874483};\\\", \\\"{x:1100,y:978,t:1526918874500};\\\", \\\"{x:1099,y:978,t:1526918874517};\\\", \\\"{x:1098,y:978,t:1526918874533};\\\", \\\"{x:1100,y:978,t:1526918874734};\\\", \\\"{x:1106,y:977,t:1526918874750};\\\", \\\"{x:1111,y:976,t:1526918874766};\\\", \\\"{x:1115,y:975,t:1526918874782};\\\", \\\"{x:1119,y:974,t:1526918874799};\\\", \\\"{x:1119,y:973,t:1526918874817};\\\", \\\"{x:1121,y:973,t:1526918874833};\\\", \\\"{x:1122,y:973,t:1526918874850};\\\", \\\"{x:1124,y:973,t:1526918874866};\\\", \\\"{x:1126,y:973,t:1526918874884};\\\", \\\"{x:1125,y:973,t:1526918875070};\\\", \\\"{x:1125,y:972,t:1526918875101};\\\", \\\"{x:1124,y:972,t:1526918875117};\\\", \\\"{x:1122,y:971,t:1526918875133};\\\", \\\"{x:1121,y:970,t:1526918875150};\\\", \\\"{x:1119,y:970,t:1526918875167};\\\", \\\"{x:1118,y:970,t:1526918875254};\\\", \\\"{x:1119,y:970,t:1526918875350};\\\", \\\"{x:1121,y:970,t:1526918875367};\\\", \\\"{x:1123,y:970,t:1526918875383};\\\", \\\"{x:1129,y:970,t:1526918875401};\\\", \\\"{x:1133,y:970,t:1526918875417};\\\", \\\"{x:1140,y:970,t:1526918875434};\\\", \\\"{x:1143,y:970,t:1526918875451};\\\", \\\"{x:1145,y:970,t:1526918875467};\\\", \\\"{x:1148,y:971,t:1526918875484};\\\", \\\"{x:1150,y:971,t:1526918875589};\\\", \\\"{x:1152,y:971,t:1526918875774};\\\", \\\"{x:1156,y:971,t:1526918875784};\\\", \\\"{x:1164,y:971,t:1526918875801};\\\", \\\"{x:1171,y:971,t:1526918875819};\\\", \\\"{x:1173,y:971,t:1526918875834};\\\", \\\"{x:1174,y:971,t:1526918875878};\\\", \\\"{x:1176,y:971,t:1526918875902};\\\", \\\"{x:1181,y:971,t:1526918875918};\\\", \\\"{x:1183,y:971,t:1526918875934};\\\", \\\"{x:1187,y:971,t:1526918875951};\\\", \\\"{x:1189,y:972,t:1526918875968};\\\", \\\"{x:1192,y:972,t:1526918875984};\\\", \\\"{x:1195,y:972,t:1526918876001};\\\", \\\"{x:1201,y:972,t:1526918876018};\\\", \\\"{x:1204,y:972,t:1526918876035};\\\", \\\"{x:1206,y:972,t:1526918876051};\\\", \\\"{x:1207,y:972,t:1526918876068};\\\", \\\"{x:1208,y:972,t:1526918876086};\\\", \\\"{x:1209,y:972,t:1526918876101};\\\", \\\"{x:1211,y:972,t:1526918876390};\\\", \\\"{x:1208,y:972,t:1526918876566};\\\", \\\"{x:1202,y:972,t:1526918876573};\\\", \\\"{x:1194,y:972,t:1526918876585};\\\", \\\"{x:1178,y:972,t:1526918876602};\\\", \\\"{x:1164,y:972,t:1526918876618};\\\", \\\"{x:1147,y:972,t:1526918876635};\\\", \\\"{x:1139,y:972,t:1526918876652};\\\", \\\"{x:1129,y:970,t:1526918876668};\\\", \\\"{x:1121,y:970,t:1526918876685};\\\", \\\"{x:1114,y:970,t:1526918876702};\\\", \\\"{x:1108,y:970,t:1526918876718};\\\", \\\"{x:1099,y:970,t:1526918876736};\\\", \\\"{x:1095,y:970,t:1526918876752};\\\", \\\"{x:1092,y:970,t:1526918876768};\\\", \\\"{x:1091,y:970,t:1526918876821};\\\", \\\"{x:1092,y:970,t:1526918877014};\\\", \\\"{x:1094,y:970,t:1526918877022};\\\", \\\"{x:1098,y:970,t:1526918877036};\\\", \\\"{x:1105,y:974,t:1526918877053};\\\", \\\"{x:1116,y:976,t:1526918877070};\\\", \\\"{x:1120,y:977,t:1526918877086};\\\", \\\"{x:1123,y:978,t:1526918877103};\\\", \\\"{x:1125,y:978,t:1526918877119};\\\", \\\"{x:1126,y:978,t:1526918877135};\\\", \\\"{x:1128,y:978,t:1526918877175};\\\", \\\"{x:1129,y:978,t:1526918877186};\\\", \\\"{x:1130,y:977,t:1526918877222};\\\", \\\"{x:1130,y:976,t:1526918877245};\\\", \\\"{x:1130,y:975,t:1526918877277};\\\", \\\"{x:1130,y:973,t:1526918877317};\\\", \\\"{x:1130,y:972,t:1526918877358};\\\", \\\"{x:1130,y:971,t:1526918877381};\\\", \\\"{x:1131,y:971,t:1526918877631};\\\", \\\"{x:1132,y:971,t:1526918877638};\\\", \\\"{x:1133,y:971,t:1526918877654};\\\", \\\"{x:1134,y:971,t:1526918877670};\\\", \\\"{x:1136,y:971,t:1526918877687};\\\", \\\"{x:1138,y:971,t:1526918877703};\\\", \\\"{x:1140,y:971,t:1526918877720};\\\", \\\"{x:1142,y:971,t:1526918877736};\\\", \\\"{x:1143,y:971,t:1526918877754};\\\", \\\"{x:1144,y:971,t:1526918877769};\\\", \\\"{x:1145,y:971,t:1526918877786};\\\", \\\"{x:1148,y:971,t:1526918877804};\\\", \\\"{x:1150,y:971,t:1526918877819};\\\", \\\"{x:1151,y:971,t:1526918877837};\\\", \\\"{x:1153,y:970,t:1526918877959};\\\", \\\"{x:1154,y:970,t:1526918877971};\\\", \\\"{x:1158,y:969,t:1526918877987};\\\", \\\"{x:1162,y:969,t:1526918878004};\\\", \\\"{x:1167,y:969,t:1526918878020};\\\", \\\"{x:1172,y:969,t:1526918878036};\\\", \\\"{x:1175,y:969,t:1526918878053};\\\", \\\"{x:1177,y:969,t:1526918878070};\\\", \\\"{x:1179,y:969,t:1526918878125};\\\", \\\"{x:1180,y:969,t:1526918878142};\\\", \\\"{x:1181,y:969,t:1526918878166};\\\", \\\"{x:1180,y:968,t:1526918878607};\\\", \\\"{x:1178,y:967,t:1526918878638};\\\", \\\"{x:1176,y:965,t:1526918878654};\\\", \\\"{x:1173,y:964,t:1526918878671};\\\", \\\"{x:1171,y:962,t:1526918878688};\\\", \\\"{x:1167,y:961,t:1526918878704};\\\", \\\"{x:1163,y:958,t:1526918878720};\\\", \\\"{x:1158,y:952,t:1526918878737};\\\", \\\"{x:1152,y:942,t:1526918878764};\\\", \\\"{x:1147,y:930,t:1526918878780};\\\", \\\"{x:1140,y:913,t:1526918878797};\\\", \\\"{x:1130,y:894,t:1526918878814};\\\", \\\"{x:1114,y:864,t:1526918878829};\\\", \\\"{x:1091,y:821,t:1526918878846};\\\", \\\"{x:1072,y:785,t:1526918878863};\\\", \\\"{x:1054,y:756,t:1526918878879};\\\", \\\"{x:1043,y:736,t:1526918878896};\\\", \\\"{x:1035,y:721,t:1526918878913};\\\", \\\"{x:1025,y:708,t:1526918878930};\\\", \\\"{x:1018,y:698,t:1526918878946};\\\", \\\"{x:1012,y:693,t:1526918878963};\\\", \\\"{x:1004,y:687,t:1526918878980};\\\", \\\"{x:992,y:682,t:1526918878996};\\\", \\\"{x:979,y:679,t:1526918879013};\\\", \\\"{x:961,y:676,t:1526918879029};\\\", \\\"{x:943,y:672,t:1526918879047};\\\", \\\"{x:917,y:662,t:1526918879063};\\\", \\\"{x:889,y:655,t:1526918879080};\\\", \\\"{x:861,y:648,t:1526918879097};\\\", \\\"{x:848,y:645,t:1526918879114};\\\", \\\"{x:839,y:642,t:1526918879130};\\\", \\\"{x:834,y:640,t:1526918879146};\\\", \\\"{x:828,y:636,t:1526918879162};\\\", \\\"{x:818,y:634,t:1526918879179};\\\", \\\"{x:812,y:630,t:1526918879196};\\\", \\\"{x:805,y:629,t:1526918879213};\\\", \\\"{x:804,y:629,t:1526918879230};\\\", \\\"{x:803,y:629,t:1526918879255};\\\", \\\"{x:808,y:635,t:1526918879590};\\\", \\\"{x:816,y:642,t:1526918879599};\\\", \\\"{x:826,y:649,t:1526918879614};\\\", \\\"{x:851,y:667,t:1526918879629};\\\", \\\"{x:890,y:691,t:1526918879647};\\\", \\\"{x:945,y:733,t:1526918879663};\\\", \\\"{x:983,y:757,t:1526918879680};\\\", \\\"{x:1017,y:778,t:1526918879696};\\\", \\\"{x:1037,y:793,t:1526918879713};\\\", \\\"{x:1054,y:808,t:1526918879729};\\\", \\\"{x:1064,y:824,t:1526918879746};\\\", \\\"{x:1073,y:843,t:1526918879763};\\\", \\\"{x:1086,y:862,t:1526918879780};\\\", \\\"{x:1098,y:881,t:1526918879796};\\\", \\\"{x:1107,y:894,t:1526918879813};\\\", \\\"{x:1113,y:903,t:1526918879829};\\\", \\\"{x:1116,y:914,t:1526918879847};\\\", \\\"{x:1116,y:922,t:1526918879863};\\\", \\\"{x:1117,y:931,t:1526918879880};\\\", \\\"{x:1119,y:939,t:1526918879896};\\\", \\\"{x:1119,y:943,t:1526918879914};\\\", \\\"{x:1119,y:946,t:1526918879930};\\\", \\\"{x:1119,y:948,t:1526918879946};\\\", \\\"{x:1119,y:951,t:1526918879964};\\\", \\\"{x:1119,y:956,t:1526918879980};\\\", \\\"{x:1120,y:961,t:1526918879996};\\\", \\\"{x:1120,y:966,t:1526918880014};\\\", \\\"{x:1120,y:970,t:1526918880031};\\\", \\\"{x:1119,y:972,t:1526918880047};\\\", \\\"{x:1119,y:973,t:1526918880070};\\\", \\\"{x:1117,y:973,t:1526918880232};\\\", \\\"{x:1116,y:973,t:1526918880271};\\\", \\\"{x:1114,y:973,t:1526918880286};\\\", \\\"{x:1113,y:973,t:1526918880297};\\\", \\\"{x:1109,y:971,t:1526918880313};\\\", \\\"{x:1108,y:969,t:1526918880331};\\\", \\\"{x:1107,y:969,t:1526918880348};\\\", \\\"{x:1107,y:970,t:1526918880711};\\\", \\\"{x:1110,y:972,t:1526918880719};\\\", \\\"{x:1111,y:973,t:1526918880735};\\\", \\\"{x:1112,y:973,t:1526918880747};\\\", \\\"{x:1113,y:973,t:1526918881088};\\\", \\\"{x:1117,y:974,t:1526918881098};\\\", \\\"{x:1121,y:974,t:1526918881115};\\\", \\\"{x:1124,y:974,t:1526918881130};\\\", \\\"{x:1127,y:974,t:1526918881147};\\\", \\\"{x:1128,y:974,t:1526918881167};\\\", \\\"{x:1130,y:974,t:1526918881199};\\\", \\\"{x:1131,y:974,t:1526918881215};\\\", \\\"{x:1134,y:974,t:1526918881231};\\\", \\\"{x:1138,y:974,t:1526918881247};\\\", \\\"{x:1140,y:974,t:1526918881265};\\\", \\\"{x:1141,y:974,t:1526918881286};\\\", \\\"{x:1143,y:974,t:1526918881375};\\\", \\\"{x:1144,y:974,t:1526918881688};\\\", \\\"{x:1146,y:974,t:1526918881703};\\\", \\\"{x:1148,y:974,t:1526918881715};\\\", \\\"{x:1150,y:974,t:1526918881731};\\\", \\\"{x:1152,y:974,t:1526918881749};\\\", \\\"{x:1153,y:974,t:1526918881764};\\\", \\\"{x:1155,y:974,t:1526918881790};\\\", \\\"{x:1156,y:974,t:1526918881806};\\\", \\\"{x:1158,y:974,t:1526918881831};\\\", \\\"{x:1159,y:974,t:1526918881838};\\\", \\\"{x:1160,y:974,t:1526918881848};\\\", \\\"{x:1163,y:974,t:1526918881864};\\\", \\\"{x:1165,y:974,t:1526918881882};\\\", \\\"{x:1166,y:974,t:1526918881911};\\\", \\\"{x:1167,y:974,t:1526918881918};\\\", \\\"{x:1168,y:974,t:1526918881943};\\\", \\\"{x:1169,y:974,t:1526918881967};\\\", \\\"{x:1170,y:974,t:1526918881981};\\\", \\\"{x:1171,y:974,t:1526918881998};\\\", \\\"{x:1172,y:974,t:1526918882014};\\\", \\\"{x:1173,y:974,t:1526918882032};\\\", \\\"{x:1174,y:973,t:1526918882054};\\\", \\\"{x:1175,y:973,t:1526918882087};\\\", \\\"{x:1177,y:973,t:1526918882102};\\\", \\\"{x:1178,y:973,t:1526918882119};\\\", \\\"{x:1179,y:973,t:1526918882559};\\\", \\\"{x:1180,y:972,t:1526918882575};\\\", \\\"{x:1181,y:972,t:1526918882598};\\\", \\\"{x:1182,y:972,t:1526918882630};\\\", \\\"{x:1184,y:972,t:1526918882686};\\\", \\\"{x:1185,y:972,t:1526918882718};\\\", \\\"{x:1186,y:972,t:1526918882734};\\\", \\\"{x:1187,y:972,t:1526918882749};\\\", \\\"{x:1188,y:972,t:1526918882766};\\\", \\\"{x:1190,y:972,t:1526918882783};\\\", \\\"{x:1191,y:972,t:1526918882798};\\\", \\\"{x:1192,y:972,t:1526918882823};\\\", \\\"{x:1193,y:972,t:1526918882839};\\\", \\\"{x:1194,y:972,t:1526918882967};\\\", \\\"{x:1195,y:971,t:1526918882982};\\\", \\\"{x:1196,y:971,t:1526918883159};\\\", \\\"{x:1197,y:971,t:1526918883190};\\\", \\\"{x:1196,y:971,t:1526918883479};\\\", \\\"{x:1195,y:971,t:1526918883487};\\\", \\\"{x:1193,y:970,t:1526918883500};\\\", \\\"{x:1189,y:970,t:1526918883517};\\\", \\\"{x:1188,y:970,t:1526918883551};\\\", \\\"{x:1187,y:970,t:1526918883583};\\\", \\\"{x:1186,y:970,t:1526918883654};\\\", \\\"{x:1185,y:969,t:1526918883791};\\\", \\\"{x:1184,y:969,t:1526918883807};\\\", \\\"{x:1183,y:968,t:1526918883871};\\\", \\\"{x:1184,y:968,t:1526918887144};\\\", \\\"{x:1185,y:968,t:1526918887153};\\\", \\\"{x:1186,y:968,t:1526918887170};\\\", \\\"{x:1187,y:968,t:1526918887208};\\\", \\\"{x:1188,y:968,t:1526918887219};\\\", \\\"{x:1190,y:968,t:1526918887235};\\\", \\\"{x:1192,y:968,t:1526918887252};\\\", \\\"{x:1193,y:968,t:1526918887270};\\\", \\\"{x:1194,y:968,t:1526918887287};\\\", \\\"{x:1196,y:968,t:1526918887302};\\\", \\\"{x:1198,y:968,t:1526918887319};\\\", \\\"{x:1199,y:968,t:1526918887335};\\\", \\\"{x:1200,y:968,t:1526918887375};\\\", \\\"{x:1202,y:968,t:1526918887390};\\\", \\\"{x:1204,y:968,t:1526918887403};\\\", \\\"{x:1207,y:968,t:1526918887420};\\\", \\\"{x:1209,y:968,t:1526918887436};\\\", \\\"{x:1211,y:969,t:1526918887453};\\\", \\\"{x:1212,y:969,t:1526918887519};\\\", \\\"{x:1214,y:969,t:1526918887543};\\\", \\\"{x:1215,y:969,t:1526918887670};\\\", \\\"{x:1216,y:969,t:1526918887807};\\\", \\\"{x:1218,y:969,t:1526918887820};\\\", \\\"{x:1224,y:969,t:1526918887837};\\\", \\\"{x:1231,y:969,t:1526918887853};\\\", \\\"{x:1236,y:970,t:1526918887870};\\\", \\\"{x:1238,y:970,t:1526918887887};\\\", \\\"{x:1239,y:970,t:1526918887902};\\\", \\\"{x:1240,y:970,t:1526918887926};\\\", \\\"{x:1241,y:970,t:1526918887943};\\\", \\\"{x:1242,y:970,t:1526918887966};\\\", \\\"{x:1244,y:970,t:1526918887975};\\\", \\\"{x:1245,y:970,t:1526918887991};\\\", \\\"{x:1248,y:970,t:1526918888002};\\\", \\\"{x:1249,y:970,t:1526918888020};\\\", \\\"{x:1250,y:970,t:1526918888094};\\\", \\\"{x:1251,y:970,t:1526918888127};\\\", \\\"{x:1252,y:970,t:1526918888142};\\\", \\\"{x:1255,y:970,t:1526918888423};\\\", \\\"{x:1256,y:970,t:1526918888437};\\\", \\\"{x:1260,y:970,t:1526918888454};\\\", \\\"{x:1262,y:970,t:1526918888470};\\\", \\\"{x:1265,y:970,t:1526918888486};\\\", \\\"{x:1266,y:970,t:1526918888527};\\\", \\\"{x:1267,y:970,t:1526918888583};\\\", \\\"{x:1268,y:970,t:1526918888590};\\\", \\\"{x:1269,y:970,t:1526918888604};\\\", \\\"{x:1270,y:970,t:1526918888880};\\\", \\\"{x:1271,y:970,t:1526918888911};\\\", \\\"{x:1272,y:970,t:1526918888921};\\\", \\\"{x:1274,y:970,t:1526918888937};\\\", \\\"{x:1278,y:970,t:1526918888954};\\\", \\\"{x:1280,y:970,t:1526918888971};\\\", \\\"{x:1283,y:970,t:1526918888987};\\\", \\\"{x:1285,y:970,t:1526918889004};\\\", \\\"{x:1288,y:970,t:1526918889021};\\\", \\\"{x:1292,y:970,t:1526918889037};\\\", \\\"{x:1293,y:970,t:1526918889054};\\\", \\\"{x:1298,y:970,t:1526918889071};\\\", \\\"{x:1299,y:970,t:1526918889088};\\\", \\\"{x:1301,y:970,t:1526918889104};\\\", \\\"{x:1303,y:970,t:1526918889120};\\\", \\\"{x:1304,y:970,t:1526918889138};\\\", \\\"{x:1306,y:970,t:1526918889153};\\\", \\\"{x:1308,y:970,t:1526918889171};\\\", \\\"{x:1309,y:970,t:1526918889188};\\\", \\\"{x:1310,y:970,t:1526918889239};\\\", \\\"{x:1311,y:970,t:1526918889254};\\\", \\\"{x:1312,y:970,t:1526918889270};\\\", \\\"{x:1315,y:970,t:1526918889288};\\\", \\\"{x:1317,y:970,t:1526918889304};\\\", \\\"{x:1319,y:970,t:1526918889631};\\\", \\\"{x:1320,y:970,t:1526918889646};\\\", \\\"{x:1321,y:970,t:1526918889655};\\\", \\\"{x:1322,y:970,t:1526918889671};\\\", \\\"{x:1323,y:971,t:1526918889687};\\\", \\\"{x:1325,y:971,t:1526918889705};\\\", \\\"{x:1330,y:972,t:1526918889721};\\\", \\\"{x:1332,y:973,t:1526918889737};\\\", \\\"{x:1334,y:973,t:1526918889755};\\\", \\\"{x:1335,y:973,t:1526918889771};\\\", \\\"{x:1336,y:973,t:1526918889787};\\\", \\\"{x:1337,y:973,t:1526918889805};\\\", \\\"{x:1339,y:974,t:1526918889820};\\\", \\\"{x:1340,y:974,t:1526918889837};\\\", \\\"{x:1342,y:975,t:1526918890159};\\\", \\\"{x:1343,y:976,t:1526918890172};\\\", \\\"{x:1349,y:976,t:1526918890188};\\\", \\\"{x:1354,y:978,t:1526918890204};\\\", \\\"{x:1358,y:979,t:1526918890221};\\\", \\\"{x:1360,y:979,t:1526918890238};\\\", \\\"{x:1361,y:980,t:1526918890255};\\\", \\\"{x:1362,y:980,t:1526918890390};\\\", \\\"{x:1363,y:980,t:1526918890405};\\\", \\\"{x:1364,y:980,t:1526918890422};\\\", \\\"{x:1366,y:980,t:1526918890438};\\\", \\\"{x:1367,y:980,t:1526918890486};\\\", \\\"{x:1369,y:980,t:1526918890511};\\\", \\\"{x:1370,y:980,t:1526918890543};\\\", \\\"{x:1372,y:980,t:1526918890555};\\\", \\\"{x:1373,y:980,t:1526918890583};\\\", \\\"{x:1374,y:980,t:1526918890598};\\\", \\\"{x:1376,y:980,t:1526918890606};\\\", \\\"{x:1378,y:980,t:1526918890622};\\\", \\\"{x:1382,y:978,t:1526918890639};\\\", \\\"{x:1383,y:977,t:1526918890655};\\\", \\\"{x:1385,y:977,t:1526918890838};\\\", \\\"{x:1388,y:977,t:1526918890856};\\\", \\\"{x:1392,y:977,t:1526918890872};\\\", \\\"{x:1393,y:977,t:1526918890889};\\\", \\\"{x:1397,y:977,t:1526918890906};\\\", \\\"{x:1400,y:978,t:1526918890922};\\\", \\\"{x:1403,y:979,t:1526918890939};\\\", \\\"{x:1405,y:980,t:1526918890956};\\\", \\\"{x:1406,y:980,t:1526918890991};\\\", \\\"{x:1407,y:980,t:1526918891015};\\\", \\\"{x:1408,y:980,t:1526918891023};\\\", \\\"{x:1409,y:980,t:1526918891063};\\\", \\\"{x:1410,y:980,t:1526918891199};\\\", \\\"{x:1412,y:980,t:1526918891455};\\\", \\\"{x:1415,y:980,t:1526918891463};\\\", \\\"{x:1417,y:980,t:1526918891472};\\\", \\\"{x:1420,y:980,t:1526918891489};\\\", \\\"{x:1423,y:980,t:1526918891506};\\\", \\\"{x:1424,y:980,t:1526918891523};\\\", \\\"{x:1425,y:980,t:1526918891575};\\\", \\\"{x:1426,y:979,t:1526918891606};\\\", \\\"{x:1428,y:979,t:1526918891623};\\\", \\\"{x:1429,y:979,t:1526918891655};\\\", \\\"{x:1430,y:978,t:1526918891662};\\\", \\\"{x:1431,y:978,t:1526918891678};\\\", \\\"{x:1432,y:977,t:1526918891694};\\\", \\\"{x:1433,y:977,t:1526918891742};\\\", \\\"{x:1435,y:976,t:1526918891756};\\\", \\\"{x:1436,y:976,t:1526918891775};\\\", \\\"{x:1437,y:976,t:1526918891789};\\\", \\\"{x:1438,y:976,t:1526918891806};\\\", \\\"{x:1439,y:976,t:1526918891823};\\\", \\\"{x:1440,y:976,t:1526918891840};\\\", \\\"{x:1442,y:975,t:1526918891856};\\\", \\\"{x:1443,y:974,t:1526918891873};\\\", \\\"{x:1445,y:974,t:1526918891889};\\\", \\\"{x:1446,y:974,t:1526918891943};\\\", \\\"{x:1447,y:974,t:1526918891956};\\\", \\\"{x:1450,y:973,t:1526918891973};\\\", \\\"{x:1451,y:973,t:1526918891990};\\\", \\\"{x:1453,y:973,t:1526918892006};\\\", \\\"{x:1454,y:973,t:1526918892175};\\\", \\\"{x:1455,y:973,t:1526918892191};\\\", \\\"{x:1457,y:973,t:1526918892207};\\\", \\\"{x:1460,y:973,t:1526918892223};\\\", \\\"{x:1463,y:973,t:1526918892240};\\\", \\\"{x:1466,y:973,t:1526918892257};\\\", \\\"{x:1470,y:973,t:1526918892273};\\\", \\\"{x:1471,y:973,t:1526918892290};\\\", \\\"{x:1473,y:974,t:1526918892307};\\\", \\\"{x:1474,y:974,t:1526918892358};\\\", \\\"{x:1475,y:974,t:1526918892727};\\\", \\\"{x:1480,y:976,t:1526918892740};\\\", \\\"{x:1490,y:978,t:1526918892757};\\\", \\\"{x:1495,y:980,t:1526918892774};\\\", \\\"{x:1499,y:981,t:1526918892790};\\\", \\\"{x:1500,y:981,t:1526918892806};\\\", \\\"{x:1501,y:981,t:1526918892855};\\\", \\\"{x:1502,y:982,t:1526918892871};\\\", \\\"{x:1503,y:982,t:1526918892886};\\\", \\\"{x:1504,y:982,t:1526918892894};\\\", \\\"{x:1505,y:982,t:1526918892910};\\\", \\\"{x:1506,y:982,t:1526918892934};\\\", \\\"{x:1507,y:982,t:1526918892951};\\\", \\\"{x:1508,y:982,t:1526918892967};\\\", \\\"{x:1509,y:982,t:1526918892998};\\\", \\\"{x:1511,y:982,t:1526918893014};\\\", \\\"{x:1512,y:982,t:1526918893046};\\\", \\\"{x:1513,y:982,t:1526918893057};\\\", \\\"{x:1514,y:982,t:1526918893074};\\\", \\\"{x:1517,y:982,t:1526918893143};\\\", \\\"{x:1517,y:981,t:1526918893167};\\\", \\\"{x:1517,y:980,t:1526918893174};\\\", \\\"{x:1518,y:979,t:1526918893191};\\\", \\\"{x:1520,y:977,t:1526918893255};\\\", \\\"{x:1522,y:975,t:1526918893319};\\\", \\\"{x:1523,y:975,t:1526918893382};\\\", \\\"{x:1524,y:975,t:1526918893398};\\\", \\\"{x:1525,y:975,t:1526918893407};\\\", \\\"{x:1529,y:975,t:1526918893424};\\\", \\\"{x:1530,y:975,t:1526918893441};\\\", \\\"{x:1532,y:975,t:1526918893457};\\\", \\\"{x:1533,y:975,t:1526918893479};\\\", \\\"{x:1535,y:975,t:1526918893494};\\\", \\\"{x:1536,y:975,t:1526918893518};\\\", \\\"{x:1537,y:975,t:1526918893526};\\\", \\\"{x:1538,y:975,t:1526918893542};\\\", \\\"{x:1539,y:975,t:1526918893558};\\\", \\\"{x:1540,y:975,t:1526918893574};\\\", \\\"{x:1542,y:976,t:1526918893591};\\\", \\\"{x:1543,y:976,t:1526918893958};\\\", \\\"{x:1548,y:977,t:1526918893974};\\\", \\\"{x:1554,y:979,t:1526918893991};\\\", \\\"{x:1561,y:980,t:1526918894008};\\\", \\\"{x:1564,y:980,t:1526918894025};\\\", \\\"{x:1565,y:980,t:1526918894303};\\\", \\\"{x:1567,y:980,t:1526918894343};\\\", \\\"{x:1568,y:979,t:1526918894358};\\\", \\\"{x:1570,y:979,t:1526918894375};\\\", \\\"{x:1571,y:979,t:1526918894456};\\\", \\\"{x:1571,y:978,t:1526918894479};\\\", \\\"{x:1573,y:978,t:1526918894519};\\\", \\\"{x:1574,y:978,t:1526918894543};\\\", \\\"{x:1575,y:977,t:1526918894559};\\\", \\\"{x:1577,y:977,t:1526918894575};\\\", \\\"{x:1578,y:976,t:1526918894607};\\\", \\\"{x:1579,y:976,t:1526918894622};\\\", \\\"{x:1580,y:976,t:1526918894638};\\\", \\\"{x:1581,y:976,t:1526918894646};\\\", \\\"{x:1582,y:976,t:1526918894658};\\\", \\\"{x:1583,y:975,t:1526918894675};\\\", \\\"{x:1584,y:975,t:1526918894791};\\\", \\\"{x:1585,y:975,t:1526918894799};\\\", \\\"{x:1586,y:975,t:1526918894814};\\\", \\\"{x:1588,y:975,t:1526918894831};\\\", \\\"{x:1589,y:975,t:1526918894842};\\\", \\\"{x:1592,y:975,t:1526918894859};\\\", \\\"{x:1595,y:975,t:1526918894875};\\\", \\\"{x:1597,y:975,t:1526918894892};\\\", \\\"{x:1600,y:975,t:1526918894909};\\\", \\\"{x:1603,y:975,t:1526918894925};\\\", \\\"{x:1605,y:975,t:1526918894942};\\\", \\\"{x:1609,y:975,t:1526918894958};\\\", \\\"{x:1610,y:975,t:1526918894998};\\\", \\\"{x:1611,y:975,t:1526918895014};\\\", \\\"{x:1612,y:975,t:1526918895031};\\\", \\\"{x:1613,y:975,t:1526918895054};\\\", \\\"{x:1614,y:975,t:1526918895086};\\\", \\\"{x:1615,y:975,t:1526918895335};\\\", \\\"{x:1616,y:975,t:1526918895398};\\\", \\\"{x:1617,y:975,t:1526918895409};\\\", \\\"{x:1619,y:974,t:1526918895426};\\\", \\\"{x:1620,y:974,t:1526918895442};\\\", \\\"{x:1622,y:974,t:1526918895459};\\\", \\\"{x:1625,y:974,t:1526918895476};\\\", \\\"{x:1627,y:974,t:1526918895492};\\\", \\\"{x:1628,y:974,t:1526918895509};\\\", \\\"{x:1630,y:974,t:1526918895526};\\\", \\\"{x:1631,y:974,t:1526918895574};\\\", \\\"{x:1632,y:974,t:1526918895583};\\\", \\\"{x:1633,y:974,t:1526918895655};\\\", \\\"{x:1634,y:974,t:1526918895678};\\\", \\\"{x:1635,y:974,t:1526918895692};\\\", \\\"{x:1637,y:974,t:1526918895709};\\\", \\\"{x:1638,y:974,t:1526918895735};\\\", \\\"{x:1639,y:973,t:1526918895743};\\\", \\\"{x:1640,y:973,t:1526918895759};\\\", \\\"{x:1641,y:972,t:1526918895776};\\\", \\\"{x:1643,y:972,t:1526918895793};\\\", \\\"{x:1644,y:972,t:1526918895809};\\\", \\\"{x:1646,y:972,t:1526918896072};\\\", \\\"{x:1647,y:972,t:1526918896079};\\\", \\\"{x:1649,y:972,t:1526918896094};\\\", \\\"{x:1653,y:972,t:1526918896110};\\\", \\\"{x:1657,y:972,t:1526918896127};\\\", \\\"{x:1659,y:972,t:1526918896143};\\\", \\\"{x:1660,y:972,t:1526918896167};\\\", \\\"{x:1661,y:972,t:1526918896214};\\\", \\\"{x:1662,y:972,t:1526918896226};\\\", \\\"{x:1663,y:972,t:1526918896478};\\\", \\\"{x:1664,y:972,t:1526918896493};\\\", \\\"{x:1665,y:972,t:1526918896510};\\\", \\\"{x:1666,y:972,t:1526918896558};\\\", \\\"{x:1667,y:972,t:1526918896950};\\\", \\\"{x:1668,y:973,t:1526918896960};\\\", \\\"{x:1669,y:973,t:1526918897095};\\\", \\\"{x:1672,y:973,t:1526918897111};\\\", \\\"{x:1676,y:973,t:1526918897127};\\\", \\\"{x:1679,y:973,t:1526918897144};\\\", \\\"{x:1680,y:973,t:1526918897160};\\\", \\\"{x:1682,y:973,t:1526918897178};\\\", \\\"{x:1683,y:973,t:1526918897214};\\\", \\\"{x:1684,y:973,t:1526918897246};\\\", \\\"{x:1685,y:973,t:1526918897263};\\\", \\\"{x:1687,y:973,t:1526918897278};\\\", \\\"{x:1689,y:973,t:1526918897295};\\\", \\\"{x:1690,y:973,t:1526918897310};\\\", \\\"{x:1693,y:973,t:1526918897327};\\\", \\\"{x:1694,y:973,t:1526918897366};\\\", \\\"{x:1695,y:973,t:1526918897377};\\\", \\\"{x:1697,y:973,t:1526918897394};\\\", \\\"{x:1699,y:973,t:1526918897411};\\\", \\\"{x:1701,y:973,t:1526918897427};\\\", \\\"{x:1703,y:973,t:1526918897445};\\\", \\\"{x:1704,y:973,t:1526918897463};\\\", \\\"{x:1705,y:973,t:1526918897495};\\\", \\\"{x:1706,y:973,t:1526918897510};\\\", \\\"{x:1707,y:973,t:1526918897527};\\\", \\\"{x:1709,y:973,t:1526918897544};\\\", \\\"{x:1711,y:973,t:1526918897561};\\\", \\\"{x:1712,y:973,t:1526918897577};\\\", \\\"{x:1713,y:973,t:1526918897798};\\\", \\\"{x:1715,y:972,t:1526918897814};\\\", \\\"{x:1717,y:972,t:1526918897831};\\\", \\\"{x:1718,y:972,t:1526918897844};\\\", \\\"{x:1721,y:972,t:1526918897861};\\\", \\\"{x:1728,y:972,t:1526918897878};\\\", \\\"{x:1729,y:972,t:1526918897894};\\\", \\\"{x:1735,y:971,t:1526918897912};\\\", \\\"{x:1738,y:971,t:1526918897928};\\\", \\\"{x:1739,y:971,t:1526918897944};\\\", \\\"{x:1742,y:970,t:1526918897961};\\\", \\\"{x:1744,y:970,t:1526918898119};\\\", \\\"{x:1745,y:970,t:1526918898150};\\\", \\\"{x:1747,y:970,t:1526918898182};\\\", \\\"{x:1748,y:970,t:1526918898246};\\\", \\\"{x:1749,y:970,t:1526918898294};\\\", \\\"{x:1751,y:970,t:1526918898415};\\\", \\\"{x:1752,y:970,t:1526918898428};\\\", \\\"{x:1755,y:970,t:1526918898445};\\\", \\\"{x:1758,y:970,t:1526918898461};\\\", \\\"{x:1761,y:970,t:1526918898479};\\\", \\\"{x:1764,y:970,t:1526918898495};\\\", \\\"{x:1766,y:970,t:1526918898511};\\\", \\\"{x:1768,y:970,t:1526918898528};\\\", \\\"{x:1769,y:970,t:1526918898545};\\\", \\\"{x:1770,y:970,t:1526918898562};\\\", \\\"{x:1771,y:969,t:1526918898578};\\\", \\\"{x:1773,y:969,t:1526918898614};\\\", \\\"{x:1774,y:969,t:1526918898671};\\\", \\\"{x:1776,y:969,t:1526918898774};\\\", \\\"{x:1777,y:969,t:1526918899183};\\\", \\\"{x:1779,y:969,t:1526918899195};\\\", \\\"{x:1781,y:969,t:1526918899213};\\\", \\\"{x:1782,y:969,t:1526918899231};\\\", \\\"{x:1784,y:970,t:1526918899247};\\\", \\\"{x:1787,y:970,t:1526918899263};\\\", \\\"{x:1792,y:970,t:1526918899279};\\\", \\\"{x:1796,y:970,t:1526918899296};\\\", \\\"{x:1797,y:970,t:1526918899312};\\\", \\\"{x:1798,y:970,t:1526918899342};\\\", \\\"{x:1799,y:970,t:1526918899431};\\\", \\\"{x:1800,y:970,t:1526918899495};\\\", \\\"{x:1801,y:971,t:1526918899584};\\\", \\\"{x:1802,y:971,t:1526918899631};\\\", \\\"{x:1804,y:972,t:1526918899775};\\\", \\\"{x:1806,y:972,t:1526918899799};\\\", \\\"{x:1808,y:973,t:1526918899813};\\\", \\\"{x:1810,y:973,t:1526918899829};\\\", \\\"{x:1813,y:973,t:1526918899847};\\\", \\\"{x:1814,y:973,t:1526918899862};\\\", \\\"{x:1815,y:973,t:1526918899880};\\\", \\\"{x:1817,y:973,t:1526918899897};\\\", \\\"{x:1818,y:973,t:1526918899912};\\\", \\\"{x:1819,y:973,t:1526918899929};\\\", \\\"{x:1821,y:973,t:1526918899946};\\\", \\\"{x:1823,y:973,t:1526918899962};\\\", \\\"{x:1827,y:973,t:1526918899979};\\\", \\\"{x:1830,y:973,t:1526918899996};\\\", \\\"{x:1832,y:973,t:1526918900012};\\\", \\\"{x:1833,y:973,t:1526918900175};\\\", \\\"{x:1833,y:972,t:1526918900182};\\\", \\\"{x:1835,y:971,t:1526918900206};\\\", \\\"{x:1836,y:970,t:1526918900246};\\\", \\\"{x:1839,y:969,t:1526918900351};\\\", \\\"{x:1840,y:969,t:1526918900694};\\\", \\\"{x:1842,y:969,t:1526918900702};\\\", \\\"{x:1844,y:969,t:1526918900713};\\\", \\\"{x:1849,y:969,t:1526918900730};\\\", \\\"{x:1855,y:969,t:1526918900747};\\\", \\\"{x:1856,y:969,t:1526918900766};\\\", \\\"{x:1858,y:969,t:1526918900799};\\\", \\\"{x:1860,y:969,t:1526918900813};\\\", \\\"{x:1867,y:967,t:1526918900831};\\\", \\\"{x:1869,y:966,t:1526918900846};\\\", \\\"{x:1871,y:966,t:1526918900863};\\\", \\\"{x:1872,y:966,t:1526918901631};\\\", \\\"{x:1872,y:967,t:1526918901671};\\\", \\\"{x:1873,y:967,t:1526918901720};\\\", \\\"{x:1873,y:968,t:1526918901734};\\\", \\\"{x:1874,y:969,t:1526918901823};\\\", \\\"{x:1875,y:970,t:1526918901839};\\\", \\\"{x:1876,y:970,t:1526918901863};\\\", \\\"{x:1877,y:970,t:1526918901879};\\\", \\\"{x:1878,y:971,t:1526918901894};\\\", \\\"{x:1878,y:972,t:1526918901911};\\\", \\\"{x:1879,y:974,t:1526918901934};\\\", \\\"{x:1881,y:976,t:1526918901948};\\\", \\\"{x:1881,y:978,t:1526918901964};\\\", \\\"{x:1882,y:978,t:1526918901981};\\\", \\\"{x:1882,y:979,t:1526918901998};\\\", \\\"{x:1884,y:981,t:1526918902015};\\\", \\\"{x:1887,y:984,t:1526918902031};\\\", \\\"{x:1889,y:986,t:1526918902048};\\\", \\\"{x:1891,y:988,t:1526918902065};\\\", \\\"{x:1892,y:989,t:1526918902082};\\\", \\\"{x:1892,y:990,t:1526918902119};\\\", \\\"{x:1894,y:991,t:1526918902143};\\\", \\\"{x:1895,y:992,t:1526918902168};\\\", \\\"{x:1898,y:994,t:1526918902183};\\\", \\\"{x:1898,y:995,t:1526918902199};\\\", \\\"{x:1899,y:996,t:1526918902215};\\\", \\\"{x:1901,y:998,t:1526918902232};\\\", \\\"{x:1902,y:998,t:1526918902263};\\\", \\\"{x:1900,y:998,t:1526918902703};\\\", \\\"{x:1897,y:998,t:1526918902715};\\\", \\\"{x:1880,y:996,t:1526918902732};\\\", \\\"{x:1857,y:991,t:1526918902748};\\\", \\\"{x:1823,y:986,t:1526918902766};\\\", \\\"{x:1796,y:981,t:1526918902782};\\\", \\\"{x:1728,y:973,t:1526918902799};\\\", \\\"{x:1653,y:964,t:1526918902816};\\\", \\\"{x:1567,y:951,t:1526918902832};\\\", \\\"{x:1471,y:945,t:1526918902849};\\\", \\\"{x:1369,y:933,t:1526918902866};\\\", \\\"{x:1286,y:924,t:1526918902882};\\\", \\\"{x:1215,y:919,t:1526918902899};\\\", \\\"{x:1151,y:901,t:1526918902916};\\\", \\\"{x:1100,y:882,t:1526918902931};\\\", \\\"{x:1046,y:874,t:1526918902949};\\\", \\\"{x:999,y:862,t:1526918902966};\\\", \\\"{x:976,y:856,t:1526918902982};\\\", \\\"{x:942,y:850,t:1526918902998};\\\", \\\"{x:915,y:845,t:1526918903016};\\\", \\\"{x:897,y:843,t:1526918903032};\\\", \\\"{x:876,y:840,t:1526918903049};\\\", \\\"{x:861,y:838,t:1526918903066};\\\", \\\"{x:852,y:837,t:1526918903082};\\\", \\\"{x:848,y:837,t:1526918903099};\\\", \\\"{x:847,y:836,t:1526918903115};\\\", \\\"{x:846,y:836,t:1526918903151};\\\", \\\"{x:845,y:836,t:1526918903167};\\\", \\\"{x:844,y:836,t:1526918903183};\\\", \\\"{x:843,y:836,t:1526918903198};\\\", \\\"{x:837,y:836,t:1526918903503};\\\", \\\"{x:828,y:833,t:1526918903516};\\\", \\\"{x:802,y:829,t:1526918903533};\\\", \\\"{x:772,y:826,t:1526918903549};\\\", \\\"{x:747,y:817,t:1526918903566};\\\", \\\"{x:710,y:800,t:1526918903583};\\\", \\\"{x:687,y:787,t:1526918903600};\\\", \\\"{x:668,y:773,t:1526918903616};\\\", \\\"{x:654,y:765,t:1526918903633};\\\", \\\"{x:645,y:759,t:1526918903650};\\\", \\\"{x:638,y:754,t:1526918903666};\\\", \\\"{x:635,y:752,t:1526918903682};\\\", \\\"{x:633,y:751,t:1526918903700};\\\", \\\"{x:632,y:750,t:1526918903719};\\\", \\\"{x:631,y:749,t:1526918903751};\\\", \\\"{x:631,y:748,t:1526918903816};\\\", \\\"{x:631,y:747,t:1526918904438};\\\", \\\"{x:635,y:745,t:1526918904450};\\\", \\\"{x:646,y:736,t:1526918904466};\\\", \\\"{x:664,y:724,t:1526918904483};\\\", \\\"{x:679,y:713,t:1526918904500};\\\", \\\"{x:689,y:706,t:1526918904516};\\\", \\\"{x:697,y:700,t:1526918904533};\\\", \\\"{x:702,y:696,t:1526918904549};\\\", \\\"{x:715,y:687,t:1526918904566};\\\", \\\"{x:729,y:678,t:1526918904583};\\\", \\\"{x:743,y:670,t:1526918904599};\\\", \\\"{x:753,y:663,t:1526918904616};\\\", \\\"{x:755,y:662,t:1526918904634};\\\", \\\"{x:756,y:662,t:1526918904695};\\\", \\\"{x:758,y:660,t:1526918904710};\\\", \\\"{x:761,y:659,t:1526918904718};\\\", \\\"{x:762,y:659,t:1526918904734};\\\", \\\"{x:771,y:658,t:1526918904749};\\\", \\\"{x:788,y:655,t:1526918904766};\\\", \\\"{x:794,y:655,t:1526918904783};\\\", \\\"{x:797,y:655,t:1526918904799};\\\", \\\"{x:799,y:655,t:1526918904817};\\\", \\\"{x:802,y:655,t:1526918904834};\\\", \\\"{x:809,y:655,t:1526918904850};\\\", \\\"{x:819,y:657,t:1526918904866};\\\", \\\"{x:829,y:660,t:1526918904883};\\\", \\\"{x:837,y:660,t:1526918904900};\\\", \\\"{x:839,y:661,t:1526918904916};\\\", \\\"{x:841,y:661,t:1526918904934};\\\", \\\"{x:843,y:661,t:1526918904951};\\\", \\\"{x:845,y:661,t:1526918904966};\\\", \\\"{x:847,y:661,t:1526918904983};\\\", \\\"{x:849,y:661,t:1526918905022};\\\", \\\"{x:850,y:661,t:1526918905038};\\\", \\\"{x:851,y:660,t:1526918905050};\\\", \\\"{x:852,y:659,t:1526918905067};\\\", \\\"{x:854,y:659,t:1526918905084};\\\", \\\"{x:856,y:658,t:1526918905118};\\\", \\\"{x:856,y:657,t:1526918905133};\\\", \\\"{x:857,y:657,t:1526918905151};\\\", \\\"{x:858,y:656,t:1526918905166};\\\", \\\"{x:858,y:654,t:1526918905462};\\\", \\\"{x:858,y:653,t:1526918905479};\\\", \\\"{x:858,y:650,t:1526918905486};\\\", \\\"{x:858,y:649,t:1526918905501};\\\", \\\"{x:858,y:648,t:1526918905517};\\\", \\\"{x:858,y:646,t:1526918905534};\\\", \\\"{x:858,y:644,t:1526918906222};\\\", \\\"{x:857,y:644,t:1526918906235};\\\", \\\"{x:856,y:643,t:1526918906252};\\\", \\\"{x:854,y:643,t:1526918906268};\\\", \\\"{x:853,y:643,t:1526918906286};\\\", \\\"{x:852,y:643,t:1526918906366};\\\", \\\"{x:851,y:643,t:1526918906374};\\\", \\\"{x:850,y:643,t:1526918906478};\\\", \\\"{x:848,y:643,t:1526918906878};\\\", \\\"{x:846,y:643,t:1526918906886};\\\", \\\"{x:833,y:648,t:1526918906902};\\\", \\\"{x:825,y:651,t:1526918906919};\\\", \\\"{x:817,y:656,t:1526918906935};\\\", \\\"{x:811,y:660,t:1526918906953};\\\", \\\"{x:808,y:660,t:1526918906969};\\\", \\\"{x:807,y:661,t:1526918906985};\\\", \\\"{x:806,y:662,t:1526918907079};\\\", \\\"{x:805,y:663,t:1526918907094};\\\", \\\"{x:805,y:661,t:1526918907271};\\\", \\\"{x:805,y:658,t:1526918907286};\\\", \\\"{x:807,y:654,t:1526918907303};\\\", \\\"{x:811,y:653,t:1526918907319};\\\", \\\"{x:813,y:651,t:1526918907336};\\\", \\\"{x:814,y:651,t:1526918907358};\\\", \\\"{x:815,y:651,t:1526918907382};\\\", \\\"{x:817,y:650,t:1526918907399};\\\", \\\"{x:818,y:650,t:1526918907406};\\\", \\\"{x:819,y:649,t:1526918907419};\\\", \\\"{x:820,y:649,t:1526918907437};\\\", \\\"{x:823,y:648,t:1526918907452};\\\", \\\"{x:824,y:648,t:1526918907469};\\\", \\\"{x:825,y:648,t:1526918907486};\\\", \\\"{x:828,y:647,t:1526918907503};\\\", \\\"{x:829,y:646,t:1526918907520};\\\", \\\"{x:830,y:646,t:1526918907590};\\\", \\\"{x:830,y:645,t:1526918907602};\\\", \\\"{x:831,y:644,t:1526918907620};\\\", \\\"{x:831,y:643,t:1526918907902};\\\", \\\"{x:828,y:643,t:1526918907919};\\\", \\\"{x:825,y:646,t:1526918907937};\\\", \\\"{x:824,y:646,t:1526918907952};\\\", \\\"{x:820,y:649,t:1526918907970};\\\", \\\"{x:811,y:655,t:1526918907986};\\\", \\\"{x:795,y:666,t:1526918908003};\\\", \\\"{x:778,y:679,t:1526918908021};\\\", \\\"{x:760,y:691,t:1526918908036};\\\", \\\"{x:744,y:701,t:1526918908053};\\\", \\\"{x:716,y:719,t:1526918908070};\\\", \\\"{x:701,y:731,t:1526918908086};\\\", \\\"{x:688,y:740,t:1526918908104};\\\", \\\"{x:671,y:751,t:1526918908121};\\\", \\\"{x:653,y:763,t:1526918908137};\\\", \\\"{x:632,y:773,t:1526918908153};\\\", \\\"{x:612,y:781,t:1526918908171};\\\", \\\"{x:592,y:786,t:1526918908186};\\\", \\\"{x:575,y:794,t:1526918908204};\\\", \\\"{x:561,y:796,t:1526918908221};\\\", \\\"{x:556,y:797,t:1526918908237};\\\", \\\"{x:554,y:797,t:1526918908253};\\\", \\\"{x:550,y:797,t:1526918908270};\\\", \\\"{x:543,y:793,t:1526918908287};\\\", \\\"{x:534,y:782,t:1526918908303};\\\", \\\"{x:525,y:770,t:1526918908321};\\\", \\\"{x:517,y:762,t:1526918908338};\\\", \\\"{x:515,y:756,t:1526918908353};\\\", \\\"{x:513,y:753,t:1526918908370};\\\", \\\"{x:512,y:752,t:1526918909151};\\\", \\\"{x:512,y:753,t:1526918909239};\\\", \\\"{x:512,y:754,t:1526918909262};\\\" ] }, { \\\"rt\\\": 10037, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 160480, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-09 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:754,t:1526918910543};\\\", \\\"{x:507,y:752,t:1526918910555};\\\", \\\"{x:478,y:733,t:1526918910572};\\\", \\\"{x:446,y:714,t:1526918910588};\\\", \\\"{x:415,y:699,t:1526918910606};\\\", \\\"{x:393,y:688,t:1526918910622};\\\", \\\"{x:371,y:672,t:1526918910639};\\\", \\\"{x:362,y:665,t:1526918910656};\\\", \\\"{x:356,y:659,t:1526918910671};\\\", \\\"{x:352,y:656,t:1526918910689};\\\", \\\"{x:349,y:654,t:1526918910706};\\\", \\\"{x:348,y:654,t:1526918910722};\\\", \\\"{x:348,y:653,t:1526918910886};\\\", \\\"{x:350,y:651,t:1526918910902};\\\", \\\"{x:357,y:647,t:1526918910910};\\\", \\\"{x:363,y:645,t:1526918910923};\\\", \\\"{x:374,y:640,t:1526918910939};\\\", \\\"{x:382,y:637,t:1526918910956};\\\", \\\"{x:386,y:634,t:1526918910973};\\\", \\\"{x:389,y:632,t:1526918910988};\\\", \\\"{x:391,y:631,t:1526918911006};\\\", \\\"{x:393,y:630,t:1526918911039};\\\", \\\"{x:394,y:630,t:1526918911071};\\\", \\\"{x:395,y:630,t:1526918911087};\\\", \\\"{x:399,y:630,t:1526918911470};\\\", \\\"{x:403,y:636,t:1526918911478};\\\", \\\"{x:408,y:639,t:1526918911490};\\\", \\\"{x:424,y:654,t:1526918911507};\\\", \\\"{x:446,y:669,t:1526918911523};\\\", \\\"{x:468,y:685,t:1526918911539};\\\", \\\"{x:493,y:701,t:1526918911557};\\\", \\\"{x:516,y:717,t:1526918911572};\\\", \\\"{x:543,y:734,t:1526918911589};\\\", \\\"{x:571,y:750,t:1526918911605};\\\", \\\"{x:605,y:772,t:1526918911623};\\\", \\\"{x:626,y:787,t:1526918911640};\\\", \\\"{x:643,y:798,t:1526918911655};\\\", \\\"{x:656,y:808,t:1526918911673};\\\", \\\"{x:670,y:818,t:1526918911689};\\\", \\\"{x:676,y:824,t:1526918911705};\\\", \\\"{x:681,y:829,t:1526918911723};\\\", \\\"{x:687,y:832,t:1526918911739};\\\", \\\"{x:691,y:836,t:1526918911755};\\\", \\\"{x:702,y:843,t:1526918911773};\\\", \\\"{x:711,y:851,t:1526918911790};\\\", \\\"{x:717,y:856,t:1526918911806};\\\", \\\"{x:722,y:860,t:1526918911822};\\\", \\\"{x:726,y:864,t:1526918911839};\\\", \\\"{x:727,y:866,t:1526918911855};\\\", \\\"{x:729,y:871,t:1526918911873};\\\", \\\"{x:734,y:874,t:1526918911888};\\\", \\\"{x:741,y:877,t:1526918911905};\\\", \\\"{x:745,y:879,t:1526918911923};\\\", \\\"{x:752,y:884,t:1526918911939};\\\", \\\"{x:758,y:887,t:1526918911956};\\\", \\\"{x:763,y:891,t:1526918911972};\\\", \\\"{x:770,y:894,t:1526918911989};\\\", \\\"{x:780,y:901,t:1526918912006};\\\", \\\"{x:799,y:922,t:1526918912022};\\\", \\\"{x:817,y:937,t:1526918912039};\\\", \\\"{x:836,y:951,t:1526918912055};\\\", \\\"{x:851,y:961,t:1526918912073};\\\", \\\"{x:868,y:971,t:1526918912088};\\\", \\\"{x:875,y:972,t:1526918912106};\\\", \\\"{x:879,y:972,t:1526918912121};\\\", \\\"{x:882,y:972,t:1526918912138};\\\", \\\"{x:883,y:972,t:1526918912156};\\\", \\\"{x:885,y:972,t:1526918912171};\\\", \\\"{x:886,y:972,t:1526918912189};\\\", \\\"{x:888,y:972,t:1526918912206};\\\", \\\"{x:894,y:972,t:1526918912221};\\\", \\\"{x:908,y:972,t:1526918912239};\\\", \\\"{x:921,y:975,t:1526918912256};\\\", \\\"{x:925,y:978,t:1526918912272};\\\", \\\"{x:925,y:979,t:1526918912839};\\\", \\\"{x:934,y:979,t:1526918912854};\\\", \\\"{x:947,y:981,t:1526918912871};\\\", \\\"{x:957,y:985,t:1526918912888};\\\", \\\"{x:969,y:989,t:1526918912905};\\\", \\\"{x:980,y:989,t:1526918912921};\\\", \\\"{x:993,y:990,t:1526918912938};\\\", \\\"{x:1004,y:990,t:1526918912955};\\\", \\\"{x:1010,y:990,t:1526918912971};\\\", \\\"{x:1021,y:990,t:1526918912988};\\\", \\\"{x:1035,y:990,t:1526918913005};\\\", \\\"{x:1048,y:990,t:1526918913022};\\\", \\\"{x:1057,y:990,t:1526918913039};\\\", \\\"{x:1058,y:990,t:1526918913055};\\\", \\\"{x:1059,y:990,t:1526918913087};\\\", \\\"{x:1061,y:990,t:1526918913104};\\\", \\\"{x:1065,y:988,t:1526918913121};\\\", \\\"{x:1067,y:988,t:1526918913139};\\\", \\\"{x:1070,y:986,t:1526918913154};\\\", \\\"{x:1071,y:985,t:1526918913171};\\\", \\\"{x:1072,y:983,t:1526918913188};\\\", \\\"{x:1075,y:981,t:1526918913205};\\\", \\\"{x:1076,y:978,t:1526918913221};\\\", \\\"{x:1078,y:976,t:1526918913239};\\\", \\\"{x:1080,y:975,t:1526918913255};\\\", \\\"{x:1085,y:972,t:1526918913271};\\\", \\\"{x:1087,y:971,t:1526918913288};\\\", \\\"{x:1088,y:971,t:1526918913304};\\\", \\\"{x:1091,y:971,t:1526918913322};\\\", \\\"{x:1093,y:969,t:1526918913337};\\\", \\\"{x:1094,y:969,t:1526918913354};\\\", \\\"{x:1095,y:967,t:1526918913373};\\\", \\\"{x:1096,y:967,t:1526918913387};\\\", \\\"{x:1099,y:967,t:1526918913405};\\\", \\\"{x:1104,y:967,t:1526918913421};\\\", \\\"{x:1115,y:967,t:1526918913437};\\\", \\\"{x:1133,y:967,t:1526918913456};\\\", \\\"{x:1141,y:967,t:1526918913471};\\\", \\\"{x:1144,y:967,t:1526918913487};\\\", \\\"{x:1145,y:967,t:1526918913680};\\\", \\\"{x:1145,y:966,t:1526918913687};\\\", \\\"{x:1144,y:966,t:1526918913711};\\\", \\\"{x:1143,y:966,t:1526918913720};\\\", \\\"{x:1142,y:966,t:1526918913737};\\\", \\\"{x:1141,y:966,t:1526918913754};\\\", \\\"{x:1140,y:966,t:1526918913770};\\\", \\\"{x:1139,y:966,t:1526918913787};\\\", \\\"{x:1136,y:966,t:1526918913804};\\\", \\\"{x:1135,y:966,t:1526918913821};\\\", \\\"{x:1135,y:967,t:1526918913888};\\\", \\\"{x:1135,y:968,t:1526918913911};\\\", \\\"{x:1137,y:969,t:1526918913920};\\\", \\\"{x:1139,y:970,t:1526918913937};\\\", \\\"{x:1143,y:971,t:1526918913953};\\\", \\\"{x:1146,y:971,t:1526918913969};\\\", \\\"{x:1150,y:973,t:1526918913987};\\\", \\\"{x:1153,y:973,t:1526918914003};\\\", \\\"{x:1155,y:974,t:1526918914020};\\\", \\\"{x:1156,y:975,t:1526918914036};\\\", \\\"{x:1157,y:975,t:1526918914415};\\\", \\\"{x:1158,y:975,t:1526918914422};\\\", \\\"{x:1160,y:975,t:1526918914436};\\\", \\\"{x:1166,y:975,t:1526918914453};\\\", \\\"{x:1169,y:975,t:1526918914469};\\\", \\\"{x:1172,y:975,t:1526918914485};\\\", \\\"{x:1176,y:975,t:1526918914502};\\\", \\\"{x:1179,y:975,t:1526918914519};\\\", \\\"{x:1180,y:975,t:1526918914536};\\\", \\\"{x:1182,y:975,t:1526918914553};\\\", \\\"{x:1182,y:974,t:1526918914695};\\\", \\\"{x:1182,y:973,t:1526918914703};\\\", \\\"{x:1179,y:970,t:1526918914718};\\\", \\\"{x:1174,y:966,t:1526918914736};\\\", \\\"{x:1165,y:958,t:1526918914752};\\\", \\\"{x:1148,y:946,t:1526918914769};\\\", \\\"{x:1124,y:936,t:1526918914786};\\\", \\\"{x:1091,y:921,t:1526918914802};\\\", \\\"{x:1055,y:904,t:1526918914819};\\\", \\\"{x:1013,y:885,t:1526918914835};\\\", \\\"{x:987,y:873,t:1526918914852};\\\", \\\"{x:969,y:863,t:1526918914869};\\\", \\\"{x:956,y:854,t:1526918914884};\\\", \\\"{x:946,y:846,t:1526918914902};\\\", \\\"{x:936,y:836,t:1526918914918};\\\", \\\"{x:931,y:829,t:1526918914934};\\\", \\\"{x:922,y:820,t:1526918914952};\\\", \\\"{x:916,y:815,t:1526918914969};\\\", \\\"{x:908,y:810,t:1526918914985};\\\", \\\"{x:905,y:808,t:1526918915002};\\\", \\\"{x:902,y:805,t:1526918915019};\\\", \\\"{x:893,y:801,t:1526918915035};\\\", \\\"{x:881,y:795,t:1526918915052};\\\", \\\"{x:865,y:790,t:1526918915067};\\\", \\\"{x:849,y:786,t:1526918915085};\\\", \\\"{x:838,y:782,t:1526918915101};\\\", \\\"{x:829,y:781,t:1526918915117};\\\", \\\"{x:828,y:781,t:1526918915135};\\\", \\\"{x:828,y:780,t:1526918915152};\\\", \\\"{x:828,y:781,t:1526918915295};\\\", \\\"{x:829,y:784,t:1526918915302};\\\", \\\"{x:835,y:788,t:1526918915318};\\\", \\\"{x:860,y:801,t:1526918915335};\\\", \\\"{x:890,y:814,t:1526918915351};\\\", \\\"{x:930,y:826,t:1526918915368};\\\", \\\"{x:972,y:838,t:1526918915385};\\\", \\\"{x:998,y:846,t:1526918915401};\\\", \\\"{x:1014,y:849,t:1526918915418};\\\", \\\"{x:1014,y:850,t:1526918915435};\\\", \\\"{x:1009,y:850,t:1526918915511};\\\", \\\"{x:1000,y:845,t:1526918915518};\\\", \\\"{x:968,y:831,t:1526918915534};\\\", \\\"{x:911,y:809,t:1526918915550};\\\", \\\"{x:825,y:786,t:1526918915568};\\\", \\\"{x:747,y:762,t:1526918915584};\\\", \\\"{x:700,y:752,t:1526918915601};\\\", \\\"{x:672,y:741,t:1526918915618};\\\", \\\"{x:646,y:730,t:1526918915634};\\\", \\\"{x:626,y:721,t:1526918915651};\\\", \\\"{x:610,y:709,t:1526918915668};\\\", \\\"{x:588,y:699,t:1526918915684};\\\", \\\"{x:553,y:683,t:1526918915702};\\\", \\\"{x:522,y:678,t:1526918915717};\\\", \\\"{x:516,y:676,t:1526918915734};\\\", \\\"{x:515,y:675,t:1526918915742};\\\", \\\"{x:514,y:675,t:1526918915798};\\\", \\\"{x:511,y:675,t:1526918915810};\\\", \\\"{x:502,y:675,t:1526918915827};\\\", \\\"{x:486,y:675,t:1526918915843};\\\", \\\"{x:469,y:673,t:1526918915860};\\\", \\\"{x:450,y:671,t:1526918915877};\\\", \\\"{x:437,y:668,t:1526918915892};\\\", \\\"{x:414,y:667,t:1526918915911};\\\", \\\"{x:402,y:666,t:1526918915926};\\\", \\\"{x:390,y:665,t:1526918915942};\\\", \\\"{x:377,y:663,t:1526918915960};\\\", \\\"{x:365,y:662,t:1526918915976};\\\", \\\"{x:349,y:661,t:1526918915993};\\\", \\\"{x:332,y:661,t:1526918916009};\\\", \\\"{x:317,y:661,t:1526918916026};\\\", \\\"{x:300,y:661,t:1526918916044};\\\", \\\"{x:284,y:661,t:1526918916060};\\\", \\\"{x:269,y:661,t:1526918916077};\\\", \\\"{x:260,y:661,t:1526918916093};\\\", \\\"{x:258,y:661,t:1526918916110};\\\", \\\"{x:263,y:661,t:1526918916174};\\\", \\\"{x:274,y:661,t:1526918916182};\\\", \\\"{x:292,y:661,t:1526918916193};\\\", \\\"{x:356,y:661,t:1526918916210};\\\", \\\"{x:467,y:661,t:1526918916227};\\\", \\\"{x:581,y:661,t:1526918916245};\\\", \\\"{x:689,y:661,t:1526918916260};\\\", \\\"{x:767,y:661,t:1526918916277};\\\", \\\"{x:814,y:661,t:1526918916294};\\\", \\\"{x:818,y:661,t:1526918916309};\\\", \\\"{x:828,y:661,t:1526918916327};\\\", \\\"{x:830,y:661,t:1526918916406};\\\", \\\"{x:833,y:659,t:1526918916415};\\\", \\\"{x:835,y:659,t:1526918916427};\\\", \\\"{x:835,y:658,t:1526918916444};\\\", \\\"{x:837,y:658,t:1526918916503};\\\", \\\"{x:838,y:656,t:1526918916510};\\\", \\\"{x:839,y:655,t:1526918916527};\\\", \\\"{x:841,y:652,t:1526918916544};\\\", \\\"{x:845,y:649,t:1526918916560};\\\", \\\"{x:850,y:646,t:1526918916578};\\\", \\\"{x:852,y:644,t:1526918916594};\\\", \\\"{x:853,y:643,t:1526918916927};\\\", \\\"{x:852,y:643,t:1526918917383};\\\", \\\"{x:848,y:643,t:1526918917395};\\\", \\\"{x:842,y:643,t:1526918917412};\\\", \\\"{x:839,y:645,t:1526918917427};\\\", \\\"{x:837,y:646,t:1526918917444};\\\", \\\"{x:836,y:646,t:1526918917461};\\\", \\\"{x:836,y:647,t:1526918917510};\\\", \\\"{x:835,y:648,t:1526918917518};\\\", \\\"{x:834,y:649,t:1526918917529};\\\", \\\"{x:833,y:649,t:1526918917545};\\\", \\\"{x:833,y:651,t:1526918917561};\\\", \\\"{x:831,y:652,t:1526918917577};\\\", \\\"{x:830,y:653,t:1526918917595};\\\", \\\"{x:829,y:653,t:1526918917612};\\\", \\\"{x:829,y:654,t:1526918917628};\\\", \\\"{x:828,y:654,t:1526918917662};\\\", \\\"{x:827,y:655,t:1526918917686};\\\", \\\"{x:827,y:656,t:1526918917727};\\\", \\\"{x:826,y:656,t:1526918917838};\\\", \\\"{x:826,y:657,t:1526918917846};\\\", \\\"{x:826,y:658,t:1526918917935};\\\", \\\"{x:826,y:659,t:1526918917946};\\\", \\\"{x:826,y:660,t:1526918917963};\\\", \\\"{x:826,y:661,t:1526918917982};\\\", \\\"{x:826,y:662,t:1526918918006};\\\", \\\"{x:826,y:663,t:1526918918022};\\\", \\\"{x:825,y:665,t:1526918918046};\\\", \\\"{x:821,y:668,t:1526918918063};\\\", \\\"{x:817,y:668,t:1526918918080};\\\", \\\"{x:815,y:669,t:1526918918097};\\\", \\\"{x:815,y:670,t:1526918918113};\\\", \\\"{x:814,y:670,t:1526918918166};\\\", \\\"{x:814,y:669,t:1526918918180};\\\", \\\"{x:814,y:667,t:1526918918197};\\\", \\\"{x:818,y:660,t:1526918918214};\\\", \\\"{x:823,y:656,t:1526918918230};\\\", \\\"{x:825,y:655,t:1526918918247};\\\", \\\"{x:829,y:654,t:1526918918264};\\\", \\\"{x:832,y:653,t:1526918918281};\\\", \\\"{x:838,y:650,t:1526918918297};\\\", \\\"{x:842,y:647,t:1526918918314};\\\", \\\"{x:846,y:643,t:1526918918331};\\\", \\\"{x:848,y:642,t:1526918918345};\\\", \\\"{x:849,y:642,t:1526918918362};\\\", \\\"{x:850,y:641,t:1526918918378};\\\", \\\"{x:851,y:640,t:1526918918395};\\\", \\\"{x:853,y:639,t:1526918918412};\\\", \\\"{x:854,y:639,t:1526918918429};\\\", \\\"{x:855,y:638,t:1526918918445};\\\", \\\"{x:854,y:638,t:1526918918582};\\\", \\\"{x:851,y:638,t:1526918918595};\\\", \\\"{x:844,y:638,t:1526918918612};\\\", \\\"{x:841,y:638,t:1526918918629};\\\", \\\"{x:839,y:638,t:1526918918645};\\\", \\\"{x:837,y:638,t:1526918918662};\\\", \\\"{x:836,y:638,t:1526918918966};\\\", \\\"{x:824,y:642,t:1526918918979};\\\", \\\"{x:780,y:658,t:1526918918997};\\\", \\\"{x:731,y:669,t:1526918919012};\\\", \\\"{x:697,y:680,t:1526918919029};\\\", \\\"{x:679,y:687,t:1526918919046};\\\", \\\"{x:675,y:690,t:1526918919062};\\\", \\\"{x:670,y:694,t:1526918919078};\\\", \\\"{x:665,y:698,t:1526918919096};\\\", \\\"{x:660,y:704,t:1526918919113};\\\", \\\"{x:653,y:710,t:1526918919129};\\\", \\\"{x:643,y:717,t:1526918919146};\\\", \\\"{x:636,y:724,t:1526918919162};\\\", \\\"{x:629,y:733,t:1526918919179};\\\", \\\"{x:624,y:737,t:1526918919196};\\\", \\\"{x:622,y:739,t:1526918919213};\\\", \\\"{x:617,y:743,t:1526918919229};\\\", \\\"{x:610,y:749,t:1526918919246};\\\", \\\"{x:601,y:755,t:1526918919262};\\\", \\\"{x:592,y:761,t:1526918919279};\\\", \\\"{x:586,y:765,t:1526918919296};\\\", \\\"{x:578,y:770,t:1526918919312};\\\", \\\"{x:573,y:772,t:1526918919329};\\\", \\\"{x:565,y:774,t:1526918919346};\\\", \\\"{x:557,y:775,t:1526918919363};\\\", \\\"{x:548,y:777,t:1526918919380};\\\", \\\"{x:537,y:781,t:1526918919395};\\\", \\\"{x:527,y:785,t:1526918919412};\\\", \\\"{x:511,y:790,t:1526918919430};\\\", \\\"{x:509,y:790,t:1526918919445};\\\", \\\"{x:508,y:790,t:1526918919463};\\\", \\\"{x:505,y:790,t:1526918919598};\\\", \\\"{x:503,y:790,t:1526918919613};\\\", \\\"{x:493,y:771,t:1526918919631};\\\", \\\"{x:489,y:765,t:1526918919646};\\\", \\\"{x:489,y:763,t:1526918919663};\\\", \\\"{x:489,y:762,t:1526918919686};\\\", \\\"{x:493,y:763,t:1526918920246};\\\", \\\"{x:499,y:767,t:1526918920263};\\\", \\\"{x:505,y:769,t:1526918920280};\\\", \\\"{x:508,y:771,t:1526918920297};\\\", \\\"{x:510,y:771,t:1526918920313};\\\" ] }, { \\\"rt\\\": 49918, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 211628, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-09 AM-09 AM-09 AM-10 AM-11 AM-12 PM-01 PM-02 PM-02 PM-12 PM-08 AM-09 AM-09 AM-10 AM-11 AM-12 PM-01 PM-02 PM-03 PM-04 PM-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:712,t:1526918921688};\\\", \\\"{x:497,y:702,t:1526918921698};\\\", \\\"{x:489,y:680,t:1526918921716};\\\", \\\"{x:484,y:668,t:1526918921731};\\\", \\\"{x:480,y:662,t:1526918921748};\\\", \\\"{x:477,y:652,t:1526918921765};\\\", \\\"{x:473,y:638,t:1526918921782};\\\", \\\"{x:470,y:625,t:1526918921798};\\\", \\\"{x:470,y:616,t:1526918921815};\\\", \\\"{x:470,y:610,t:1526918921833};\\\", \\\"{x:470,y:605,t:1526918921848};\\\", \\\"{x:471,y:599,t:1526918921865};\\\", \\\"{x:473,y:594,t:1526918921881};\\\", \\\"{x:473,y:589,t:1526918921898};\\\", \\\"{x:477,y:581,t:1526918921915};\\\", \\\"{x:481,y:572,t:1526918921932};\\\", \\\"{x:484,y:566,t:1526918921948};\\\", \\\"{x:484,y:561,t:1526918921965};\\\", \\\"{x:485,y:556,t:1526918921981};\\\", \\\"{x:488,y:550,t:1526918921997};\\\", \\\"{x:489,y:544,t:1526918922015};\\\", \\\"{x:490,y:541,t:1526918922032};\\\", \\\"{x:491,y:540,t:1526918922048};\\\", \\\"{x:491,y:539,t:1526918922065};\\\", \\\"{x:492,y:538,t:1526918922082};\\\", \\\"{x:494,y:534,t:1526918922097};\\\", \\\"{x:497,y:530,t:1526918922115};\\\", \\\"{x:499,y:529,t:1526918922132};\\\", \\\"{x:500,y:529,t:1526918922166};\\\", \\\"{x:501,y:528,t:1526918922263};\\\", \\\"{x:504,y:528,t:1526918922270};\\\", \\\"{x:508,y:530,t:1526918922282};\\\", \\\"{x:517,y:537,t:1526918922298};\\\", \\\"{x:533,y:549,t:1526918922315};\\\", \\\"{x:551,y:561,t:1526918922332};\\\", \\\"{x:577,y:579,t:1526918922348};\\\", \\\"{x:619,y:605,t:1526918922366};\\\", \\\"{x:694,y:660,t:1526918922382};\\\", \\\"{x:758,y:716,t:1526918922398};\\\", \\\"{x:835,y:783,t:1526918922415};\\\", \\\"{x:919,y:847,t:1526918922432};\\\", \\\"{x:1001,y:913,t:1526918922449};\\\", \\\"{x:1074,y:964,t:1526918922465};\\\", \\\"{x:1136,y:1012,t:1526918922482};\\\", \\\"{x:1186,y:1043,t:1526918922498};\\\", \\\"{x:1215,y:1059,t:1526918922515};\\\", \\\"{x:1230,y:1064,t:1526918922532};\\\", \\\"{x:1234,y:1065,t:1526918922549};\\\", \\\"{x:1236,y:1062,t:1526918922606};\\\", \\\"{x:1239,y:1055,t:1526918922615};\\\", \\\"{x:1239,y:1046,t:1526918922633};\\\", \\\"{x:1239,y:1041,t:1526918922650};\\\", \\\"{x:1235,y:1029,t:1526918922665};\\\", \\\"{x:1224,y:1018,t:1526918922682};\\\", \\\"{x:1210,y:1007,t:1526918922699};\\\", \\\"{x:1200,y:1001,t:1526918922716};\\\", \\\"{x:1190,y:997,t:1526918922732};\\\", \\\"{x:1175,y:989,t:1526918922749};\\\", \\\"{x:1164,y:986,t:1526918922765};\\\", \\\"{x:1148,y:981,t:1526918922783};\\\", \\\"{x:1142,y:979,t:1526918922800};\\\", \\\"{x:1135,y:977,t:1526918922815};\\\", \\\"{x:1128,y:976,t:1526918922833};\\\", \\\"{x:1123,y:975,t:1526918922850};\\\", \\\"{x:1120,y:975,t:1526918922865};\\\", \\\"{x:1119,y:975,t:1526918922942};\\\", \\\"{x:1118,y:975,t:1526918922958};\\\", \\\"{x:1118,y:976,t:1526918922991};\\\", \\\"{x:1118,y:977,t:1526918922999};\\\", \\\"{x:1118,y:979,t:1526918923016};\\\", \\\"{x:1118,y:980,t:1526918923032};\\\", \\\"{x:1118,y:981,t:1526918923049};\\\", \\\"{x:1119,y:981,t:1526918923246};\\\", \\\"{x:1120,y:981,t:1526918923278};\\\", \\\"{x:1122,y:981,t:1526918923286};\\\", \\\"{x:1123,y:981,t:1526918923299};\\\", \\\"{x:1126,y:980,t:1526918923316};\\\", \\\"{x:1130,y:979,t:1526918923332};\\\", \\\"{x:1131,y:979,t:1526918923349};\\\", \\\"{x:1132,y:979,t:1526918923366};\\\", \\\"{x:1133,y:979,t:1526918923382};\\\", \\\"{x:1135,y:979,t:1526918923399};\\\", \\\"{x:1136,y:979,t:1526918923416};\\\", \\\"{x:1138,y:978,t:1526918923433};\\\", \\\"{x:1139,y:978,t:1526918923534};\\\", \\\"{x:1141,y:978,t:1526918923566};\\\", \\\"{x:1143,y:978,t:1526918923583};\\\", \\\"{x:1144,y:978,t:1526918923599};\\\", \\\"{x:1146,y:978,t:1526918923616};\\\", \\\"{x:1148,y:978,t:1526918923633};\\\", \\\"{x:1149,y:978,t:1526918923649};\\\", \\\"{x:1150,y:978,t:1526918923666};\\\", \\\"{x:1153,y:977,t:1526918923683};\\\", \\\"{x:1155,y:977,t:1526918923699};\\\", \\\"{x:1158,y:977,t:1526918923716};\\\", \\\"{x:1162,y:977,t:1526918923733};\\\", \\\"{x:1166,y:976,t:1526918923749};\\\", \\\"{x:1169,y:975,t:1526918923766};\\\", \\\"{x:1170,y:974,t:1526918923783};\\\", \\\"{x:1171,y:974,t:1526918923799};\\\", \\\"{x:1172,y:974,t:1526918923816};\\\", \\\"{x:1174,y:973,t:1526918923838};\\\", \\\"{x:1175,y:972,t:1526918923862};\\\", \\\"{x:1176,y:972,t:1526918923886};\\\", \\\"{x:1177,y:971,t:1526918923927};\\\", \\\"{x:1178,y:971,t:1526918924254};\\\", \\\"{x:1179,y:971,t:1526918924270};\\\", \\\"{x:1180,y:971,t:1526918924302};\\\", \\\"{x:1180,y:972,t:1526918924326};\\\", \\\"{x:1180,y:973,t:1526918924390};\\\", \\\"{x:1180,y:974,t:1526918924406};\\\", \\\"{x:1180,y:975,t:1526918924430};\\\", \\\"{x:1180,y:976,t:1526918924446};\\\", \\\"{x:1180,y:977,t:1526918924462};\\\", \\\"{x:1180,y:978,t:1526918924517};\\\", \\\"{x:1177,y:980,t:1526918924534};\\\", \\\"{x:1168,y:981,t:1526918924550};\\\", \\\"{x:1164,y:981,t:1526918924567};\\\", \\\"{x:1159,y:981,t:1526918924584};\\\", \\\"{x:1154,y:981,t:1526918924600};\\\", \\\"{x:1148,y:981,t:1526918924617};\\\", \\\"{x:1141,y:981,t:1526918924633};\\\", \\\"{x:1134,y:980,t:1526918924650};\\\", \\\"{x:1129,y:979,t:1526918924668};\\\", \\\"{x:1127,y:979,t:1526918924683};\\\", \\\"{x:1125,y:979,t:1526918924701};\\\", \\\"{x:1123,y:979,t:1526918924717};\\\", \\\"{x:1122,y:979,t:1526918924734};\\\", \\\"{x:1121,y:979,t:1526918924870};\\\", \\\"{x:1120,y:979,t:1526918924884};\\\", \\\"{x:1120,y:980,t:1526918924918};\\\", \\\"{x:1121,y:980,t:1526918924941};\\\", \\\"{x:1122,y:981,t:1526918925006};\\\", \\\"{x:1123,y:981,t:1526918925022};\\\", \\\"{x:1123,y:982,t:1526918925035};\\\", \\\"{x:1123,y:983,t:1526918925050};\\\", \\\"{x:1123,y:984,t:1526918925176};\\\", \\\"{x:1122,y:984,t:1526918925185};\\\", \\\"{x:1117,y:984,t:1526918925201};\\\", \\\"{x:1114,y:984,t:1526918925217};\\\", \\\"{x:1113,y:984,t:1526918925235};\\\", \\\"{x:1111,y:984,t:1526918925251};\\\", \\\"{x:1110,y:984,t:1526918925287};\\\", \\\"{x:1108,y:984,t:1526918925311};\\\", \\\"{x:1106,y:986,t:1526918925327};\\\", \\\"{x:1104,y:986,t:1526918925343};\\\", \\\"{x:1103,y:986,t:1526918925359};\\\", \\\"{x:1102,y:986,t:1526918925375};\\\", \\\"{x:1101,y:986,t:1526918925384};\\\", \\\"{x:1100,y:987,t:1526918925401};\\\", \\\"{x:1098,y:987,t:1526918925417};\\\", \\\"{x:1098,y:988,t:1526918925434};\\\", \\\"{x:1097,y:989,t:1526918925452};\\\", \\\"{x:1096,y:989,t:1526918925471};\\\", \\\"{x:1095,y:990,t:1526918925484};\\\", \\\"{x:1095,y:991,t:1526918925543};\\\", \\\"{x:1094,y:992,t:1526918925845};\\\", \\\"{x:1093,y:991,t:1526918925861};\\\", \\\"{x:1092,y:991,t:1526918925878};\\\", \\\"{x:1092,y:990,t:1526918925886};\\\", \\\"{x:1091,y:989,t:1526918925901};\\\", \\\"{x:1092,y:989,t:1526918926014};\\\", \\\"{x:1096,y:989,t:1526918926023};\\\", \\\"{x:1100,y:990,t:1526918926034};\\\", \\\"{x:1106,y:994,t:1526918926051};\\\", \\\"{x:1109,y:994,t:1526918926068};\\\", \\\"{x:1112,y:995,t:1526918926084};\\\", \\\"{x:1113,y:995,t:1526918926142};\\\", \\\"{x:1114,y:995,t:1526918926152};\\\", \\\"{x:1116,y:995,t:1526918926168};\\\", \\\"{x:1119,y:995,t:1526918926184};\\\", \\\"{x:1125,y:995,t:1526918926201};\\\", \\\"{x:1127,y:994,t:1526918926218};\\\", \\\"{x:1129,y:993,t:1526918926234};\\\", \\\"{x:1132,y:993,t:1526918926252};\\\", \\\"{x:1135,y:992,t:1526918926268};\\\", \\\"{x:1137,y:990,t:1526918926285};\\\", \\\"{x:1139,y:989,t:1526918926301};\\\", \\\"{x:1142,y:987,t:1526918926318};\\\", \\\"{x:1144,y:986,t:1526918926335};\\\", \\\"{x:1147,y:985,t:1526918926351};\\\", \\\"{x:1149,y:984,t:1526918926369};\\\", \\\"{x:1151,y:983,t:1526918926385};\\\", \\\"{x:1152,y:983,t:1526918926774};\\\", \\\"{x:1154,y:984,t:1526918926790};\\\", \\\"{x:1156,y:984,t:1526918926803};\\\", \\\"{x:1158,y:985,t:1526918926818};\\\", \\\"{x:1160,y:987,t:1526918926835};\\\", \\\"{x:1161,y:987,t:1526918926894};\\\", \\\"{x:1162,y:987,t:1526918926910};\\\", \\\"{x:1162,y:988,t:1526918926919};\\\", \\\"{x:1163,y:988,t:1526918926942};\\\", \\\"{x:1164,y:988,t:1526918926958};\\\", \\\"{x:1165,y:988,t:1526918926968};\\\", \\\"{x:1167,y:988,t:1526918927294};\\\", \\\"{x:1168,y:988,t:1526918927414};\\\", \\\"{x:1169,y:988,t:1526918927550};\\\", \\\"{x:1171,y:988,t:1526918927566};\\\", \\\"{x:1172,y:988,t:1526918927582};\\\", \\\"{x:1173,y:987,t:1526918927590};\\\", \\\"{x:1174,y:987,t:1526918927606};\\\", \\\"{x:1175,y:986,t:1526918927654};\\\", \\\"{x:1176,y:985,t:1526918927774};\\\", \\\"{x:1176,y:984,t:1526918927798};\\\", \\\"{x:1177,y:983,t:1526918928054};\\\", \\\"{x:1179,y:981,t:1526918928086};\\\", \\\"{x:1179,y:980,t:1526918928127};\\\", \\\"{x:1180,y:979,t:1526918928136};\\\", \\\"{x:1181,y:978,t:1526918928153};\\\", \\\"{x:1182,y:978,t:1526918928271};\\\", \\\"{x:1183,y:978,t:1526918928286};\\\", \\\"{x:1184,y:979,t:1526918928304};\\\", \\\"{x:1185,y:980,t:1526918928320};\\\", \\\"{x:1186,y:981,t:1526918928337};\\\", \\\"{x:1187,y:981,t:1526918928353};\\\", \\\"{x:1189,y:981,t:1526918928430};\\\", \\\"{x:1190,y:981,t:1526918928437};\\\", \\\"{x:1192,y:982,t:1526918928453};\\\", \\\"{x:1193,y:982,t:1526918928469};\\\", \\\"{x:1197,y:982,t:1526918928487};\\\", \\\"{x:1198,y:982,t:1526918928534};\\\", \\\"{x:1199,y:982,t:1526918928541};\\\", \\\"{x:1200,y:982,t:1526918928553};\\\", \\\"{x:1201,y:982,t:1526918928569};\\\", \\\"{x:1203,y:982,t:1526918928586};\\\", \\\"{x:1204,y:982,t:1526918928603};\\\", \\\"{x:1206,y:982,t:1526918928619};\\\", \\\"{x:1208,y:982,t:1526918928646};\\\", \\\"{x:1209,y:981,t:1526918928678};\\\", \\\"{x:1210,y:981,t:1526918928774};\\\", \\\"{x:1211,y:981,t:1526918928787};\\\", \\\"{x:1212,y:981,t:1526918928806};\\\", \\\"{x:1213,y:981,t:1526918928820};\\\", \\\"{x:1214,y:981,t:1526918928837};\\\", \\\"{x:1215,y:981,t:1526918928854};\\\", \\\"{x:1218,y:981,t:1526918928870};\\\", \\\"{x:1219,y:981,t:1526918928886};\\\", \\\"{x:1221,y:981,t:1526918928903};\\\", \\\"{x:1222,y:981,t:1526918928921};\\\", \\\"{x:1223,y:981,t:1526918928936};\\\", \\\"{x:1225,y:981,t:1526918928953};\\\", \\\"{x:1228,y:981,t:1526918928971};\\\", \\\"{x:1234,y:981,t:1526918928987};\\\", \\\"{x:1237,y:981,t:1526918929004};\\\", \\\"{x:1239,y:981,t:1526918929020};\\\", \\\"{x:1240,y:981,t:1526918929036};\\\", \\\"{x:1241,y:981,t:1526918929053};\\\", \\\"{x:1244,y:981,t:1526918929110};\\\", \\\"{x:1245,y:981,t:1526918929126};\\\", \\\"{x:1247,y:981,t:1526918929137};\\\", \\\"{x:1249,y:981,t:1526918929153};\\\", \\\"{x:1250,y:981,t:1526918929170};\\\", \\\"{x:1251,y:981,t:1526918929334};\\\", \\\"{x:1252,y:981,t:1526918929374};\\\", \\\"{x:1253,y:981,t:1526918929422};\\\", \\\"{x:1254,y:981,t:1526918929446};\\\", \\\"{x:1256,y:981,t:1526918929527};\\\", \\\"{x:1257,y:981,t:1526918929537};\\\", \\\"{x:1260,y:981,t:1526918929555};\\\", \\\"{x:1261,y:981,t:1526918929574};\\\", \\\"{x:1262,y:981,t:1526918929598};\\\", \\\"{x:1263,y:981,t:1526918929622};\\\", \\\"{x:1266,y:981,t:1526918929638};\\\", \\\"{x:1270,y:981,t:1526918929654};\\\", \\\"{x:1274,y:981,t:1526918929671};\\\", \\\"{x:1276,y:981,t:1526918929687};\\\", \\\"{x:1277,y:981,t:1526918929870};\\\", \\\"{x:1278,y:981,t:1526918929934};\\\", \\\"{x:1279,y:981,t:1526918929942};\\\", \\\"{x:1280,y:981,t:1526918929955};\\\", \\\"{x:1281,y:981,t:1526918929970};\\\", \\\"{x:1282,y:981,t:1526918929987};\\\", \\\"{x:1283,y:981,t:1526918930029};\\\", \\\"{x:1284,y:981,t:1526918930046};\\\", \\\"{x:1286,y:981,t:1526918930054};\\\", \\\"{x:1287,y:981,t:1526918930072};\\\", \\\"{x:1293,y:981,t:1526918930088};\\\", \\\"{x:1299,y:981,t:1526918930104};\\\", \\\"{x:1302,y:981,t:1526918930121};\\\", \\\"{x:1304,y:981,t:1526918930302};\\\", \\\"{x:1305,y:981,t:1526918930310};\\\", \\\"{x:1310,y:980,t:1526918930321};\\\", \\\"{x:1316,y:980,t:1526918930337};\\\", \\\"{x:1319,y:980,t:1526918930354};\\\", \\\"{x:1320,y:980,t:1526918930371};\\\", \\\"{x:1321,y:980,t:1526918930387};\\\", \\\"{x:1322,y:980,t:1526918930582};\\\", \\\"{x:1325,y:980,t:1526918930590};\\\", \\\"{x:1329,y:980,t:1526918930604};\\\", \\\"{x:1339,y:980,t:1526918930622};\\\", \\\"{x:1340,y:980,t:1526918930638};\\\", \\\"{x:1342,y:980,t:1526918930918};\\\", \\\"{x:1343,y:980,t:1526918931022};\\\", \\\"{x:1345,y:980,t:1526918931054};\\\", \\\"{x:1346,y:980,t:1526918931070};\\\", \\\"{x:1347,y:980,t:1526918931077};\\\", \\\"{x:1349,y:980,t:1526918931088};\\\", \\\"{x:1350,y:980,t:1526918931106};\\\", \\\"{x:1351,y:980,t:1526918931122};\\\", \\\"{x:1352,y:980,t:1526918931174};\\\", \\\"{x:1354,y:980,t:1526918931189};\\\", \\\"{x:1358,y:980,t:1526918931205};\\\", \\\"{x:1359,y:980,t:1526918931221};\\\", \\\"{x:1365,y:980,t:1526918931238};\\\", \\\"{x:1366,y:980,t:1526918931255};\\\", \\\"{x:1368,y:980,t:1526918931326};\\\", \\\"{x:1370,y:980,t:1526918931350};\\\", \\\"{x:1371,y:980,t:1526918931357};\\\", \\\"{x:1372,y:980,t:1526918931371};\\\", \\\"{x:1380,y:980,t:1526918931388};\\\", \\\"{x:1388,y:982,t:1526918931405};\\\", \\\"{x:1389,y:982,t:1526918931422};\\\", \\\"{x:1390,y:982,t:1526918931438};\\\", \\\"{x:1391,y:982,t:1526918931638};\\\", \\\"{x:1393,y:982,t:1526918931669};\\\", \\\"{x:1394,y:982,t:1526918931686};\\\", \\\"{x:1395,y:982,t:1526918931694};\\\", \\\"{x:1397,y:982,t:1526918931706};\\\", \\\"{x:1400,y:982,t:1526918931722};\\\", \\\"{x:1403,y:982,t:1526918931738};\\\", \\\"{x:1404,y:982,t:1526918932054};\\\", \\\"{x:1406,y:982,t:1526918932062};\\\", \\\"{x:1407,y:982,t:1526918932077};\\\", \\\"{x:1408,y:982,t:1526918932090};\\\", \\\"{x:1409,y:982,t:1526918932105};\\\", \\\"{x:1411,y:982,t:1526918932122};\\\", \\\"{x:1413,y:982,t:1526918932139};\\\", \\\"{x:1415,y:982,t:1526918932155};\\\", \\\"{x:1416,y:982,t:1526918932172};\\\", \\\"{x:1417,y:982,t:1526918932189};\\\", \\\"{x:1419,y:982,t:1526918932206};\\\", \\\"{x:1420,y:982,t:1526918932222};\\\", \\\"{x:1423,y:982,t:1526918932239};\\\", \\\"{x:1425,y:982,t:1526918932255};\\\", \\\"{x:1429,y:982,t:1526918932273};\\\", \\\"{x:1430,y:982,t:1526918932290};\\\", \\\"{x:1432,y:984,t:1526918932305};\\\", \\\"{x:1435,y:984,t:1526918932334};\\\", \\\"{x:1436,y:984,t:1526918932358};\\\", \\\"{x:1438,y:984,t:1526918932374};\\\", \\\"{x:1439,y:984,t:1526918932390};\\\", \\\"{x:1443,y:984,t:1526918932406};\\\", \\\"{x:1446,y:984,t:1526918932423};\\\", \\\"{x:1454,y:984,t:1526918932440};\\\", \\\"{x:1460,y:984,t:1526918932456};\\\", \\\"{x:1470,y:984,t:1526918932472};\\\", \\\"{x:1474,y:984,t:1526918932489};\\\", \\\"{x:1482,y:984,t:1526918932506};\\\", \\\"{x:1485,y:984,t:1526918932522};\\\", \\\"{x:1484,y:984,t:1526918932758};\\\", \\\"{x:1483,y:984,t:1526918932774};\\\", \\\"{x:1484,y:984,t:1526918933150};\\\", \\\"{x:1487,y:984,t:1526918933158};\\\", \\\"{x:1493,y:985,t:1526918933174};\\\", \\\"{x:1498,y:985,t:1526918933189};\\\", \\\"{x:1514,y:986,t:1526918933207};\\\", \\\"{x:1520,y:986,t:1526918933224};\\\", \\\"{x:1522,y:986,t:1526918933239};\\\", \\\"{x:1524,y:986,t:1526918933454};\\\", \\\"{x:1527,y:986,t:1526918933470};\\\", \\\"{x:1528,y:986,t:1526918933478};\\\", \\\"{x:1530,y:986,t:1526918933491};\\\", \\\"{x:1534,y:986,t:1526918933506};\\\", \\\"{x:1537,y:986,t:1526918933523};\\\", \\\"{x:1538,y:986,t:1526918933541};\\\", \\\"{x:1540,y:986,t:1526918933934};\\\", \\\"{x:1541,y:986,t:1526918933998};\\\", \\\"{x:1543,y:986,t:1526918934029};\\\", \\\"{x:1544,y:986,t:1526918934046};\\\", \\\"{x:1546,y:986,t:1526918934062};\\\", \\\"{x:1547,y:986,t:1526918934085};\\\", \\\"{x:1549,y:986,t:1526918934230};\\\", \\\"{x:1551,y:988,t:1526918934240};\\\", \\\"{x:1555,y:988,t:1526918934258};\\\", \\\"{x:1558,y:988,t:1526918934273};\\\", \\\"{x:1561,y:989,t:1526918934291};\\\", \\\"{x:1563,y:989,t:1526918934317};\\\", \\\"{x:1564,y:989,t:1526918934334};\\\", \\\"{x:1566,y:989,t:1526918934350};\\\", \\\"{x:1567,y:989,t:1526918934358};\\\", \\\"{x:1570,y:989,t:1526918934373};\\\", \\\"{x:1573,y:989,t:1526918934390};\\\", \\\"{x:1576,y:989,t:1526918934407};\\\", \\\"{x:1577,y:989,t:1526918934424};\\\", \\\"{x:1579,y:989,t:1526918934502};\\\", \\\"{x:1581,y:989,t:1526918934510};\\\", \\\"{x:1583,y:989,t:1526918934524};\\\", \\\"{x:1589,y:988,t:1526918934540};\\\", \\\"{x:1591,y:988,t:1526918934558};\\\", \\\"{x:1592,y:987,t:1526918934581};\\\", \\\"{x:1594,y:987,t:1526918934742};\\\", \\\"{x:1598,y:987,t:1526918934758};\\\", \\\"{x:1602,y:986,t:1526918934774};\\\", \\\"{x:1603,y:985,t:1526918934790};\\\", \\\"{x:1593,y:985,t:1526918934998};\\\", \\\"{x:1569,y:985,t:1526918935007};\\\", \\\"{x:1471,y:981,t:1526918935025};\\\", \\\"{x:1347,y:969,t:1526918935042};\\\", \\\"{x:1195,y:952,t:1526918935058};\\\", \\\"{x:1046,y:930,t:1526918935074};\\\", \\\"{x:921,y:911,t:1526918935091};\\\", \\\"{x:848,y:901,t:1526918935108};\\\", \\\"{x:814,y:896,t:1526918935124};\\\", \\\"{x:786,y:892,t:1526918935142};\\\", \\\"{x:759,y:888,t:1526918935157};\\\", \\\"{x:727,y:881,t:1526918935175};\\\", \\\"{x:679,y:867,t:1526918935192};\\\", \\\"{x:640,y:861,t:1526918935208};\\\", \\\"{x:618,y:856,t:1526918935225};\\\", \\\"{x:601,y:854,t:1526918935242};\\\", \\\"{x:594,y:854,t:1526918935257};\\\", \\\"{x:591,y:852,t:1526918935275};\\\", \\\"{x:588,y:848,t:1526918935302};\\\", \\\"{x:584,y:842,t:1526918935310};\\\", \\\"{x:577,y:833,t:1526918935325};\\\", \\\"{x:535,y:791,t:1526918935341};\\\", \\\"{x:486,y:740,t:1526918935358};\\\", \\\"{x:425,y:687,t:1526918935375};\\\", \\\"{x:353,y:637,t:1526918935392};\\\", \\\"{x:298,y:603,t:1526918935409};\\\", \\\"{x:281,y:590,t:1526918935424};\\\", \\\"{x:275,y:583,t:1526918935442};\\\", \\\"{x:273,y:581,t:1526918935459};\\\", \\\"{x:272,y:580,t:1526918935477};\\\", \\\"{x:273,y:580,t:1526918935534};\\\", \\\"{x:278,y:580,t:1526918935542};\\\", \\\"{x:310,y:585,t:1526918935560};\\\", \\\"{x:366,y:593,t:1526918935577};\\\", \\\"{x:446,y:602,t:1526918935593};\\\", \\\"{x:542,y:612,t:1526918935610};\\\", \\\"{x:625,y:621,t:1526918935627};\\\", \\\"{x:692,y:630,t:1526918935642};\\\", \\\"{x:733,y:634,t:1526918935659};\\\", \\\"{x:755,y:641,t:1526918935676};\\\", \\\"{x:766,y:642,t:1526918935692};\\\", \\\"{x:766,y:644,t:1526918935758};\\\", \\\"{x:766,y:645,t:1526918935782};\\\", \\\"{x:766,y:647,t:1526918935793};\\\", \\\"{x:764,y:649,t:1526918935810};\\\", \\\"{x:756,y:653,t:1526918935825};\\\", \\\"{x:744,y:656,t:1526918935842};\\\", \\\"{x:725,y:660,t:1526918935859};\\\", \\\"{x:695,y:662,t:1526918935876};\\\", \\\"{x:609,y:668,t:1526918935894};\\\", \\\"{x:537,y:668,t:1526918935909};\\\", \\\"{x:453,y:670,t:1526918935928};\\\", \\\"{x:375,y:670,t:1526918935943};\\\", \\\"{x:306,y:670,t:1526918935959};\\\", \\\"{x:266,y:669,t:1526918935976};\\\", \\\"{x:248,y:667,t:1526918935992};\\\", \\\"{x:239,y:664,t:1526918936009};\\\", \\\"{x:230,y:663,t:1526918936027};\\\", \\\"{x:223,y:662,t:1526918936043};\\\", \\\"{x:217,y:662,t:1526918936059};\\\", \\\"{x:212,y:662,t:1526918936076};\\\", \\\"{x:207,y:664,t:1526918936093};\\\", \\\"{x:207,y:665,t:1526918936189};\\\", \\\"{x:206,y:665,t:1526918936198};\\\", \\\"{x:205,y:665,t:1526918936210};\\\", \\\"{x:200,y:662,t:1526918936228};\\\", \\\"{x:192,y:655,t:1526918936244};\\\", \\\"{x:185,y:650,t:1526918936260};\\\", \\\"{x:180,y:644,t:1526918936277};\\\", \\\"{x:174,y:635,t:1526918936294};\\\", \\\"{x:172,y:632,t:1526918936310};\\\", \\\"{x:171,y:629,t:1526918936326};\\\", \\\"{x:169,y:627,t:1526918936343};\\\", \\\"{x:167,y:626,t:1526918936360};\\\", \\\"{x:167,y:625,t:1526918936446};\\\", \\\"{x:168,y:625,t:1526918936460};\\\", \\\"{x:182,y:626,t:1526918936477};\\\", \\\"{x:219,y:638,t:1526918936493};\\\", \\\"{x:275,y:646,t:1526918936510};\\\", \\\"{x:323,y:656,t:1526918936527};\\\", \\\"{x:400,y:663,t:1526918936543};\\\", \\\"{x:439,y:667,t:1526918936561};\\\", \\\"{x:464,y:667,t:1526918936577};\\\", \\\"{x:482,y:667,t:1526918936594};\\\", \\\"{x:489,y:667,t:1526918936611};\\\", \\\"{x:490,y:667,t:1526918936628};\\\", \\\"{x:489,y:667,t:1526918936854};\\\", \\\"{x:488,y:667,t:1526918936862};\\\", \\\"{x:488,y:668,t:1526918936958};\\\", \\\"{x:490,y:670,t:1526918936966};\\\", \\\"{x:493,y:670,t:1526918936978};\\\", \\\"{x:510,y:672,t:1526918936995};\\\", \\\"{x:542,y:672,t:1526918937011};\\\", \\\"{x:575,y:672,t:1526918937026};\\\", \\\"{x:623,y:673,t:1526918937043};\\\", \\\"{x:665,y:673,t:1526918937059};\\\", \\\"{x:700,y:673,t:1526918937078};\\\", \\\"{x:706,y:673,t:1526918937093};\\\", \\\"{x:708,y:673,t:1526918937111};\\\", \\\"{x:709,y:673,t:1526918937133};\\\", \\\"{x:711,y:673,t:1526918937165};\\\", \\\"{x:712,y:673,t:1526918937177};\\\", \\\"{x:714,y:673,t:1526918937195};\\\", \\\"{x:716,y:673,t:1526918937210};\\\", \\\"{x:720,y:670,t:1526918937227};\\\", \\\"{x:724,y:666,t:1526918937244};\\\", \\\"{x:728,y:663,t:1526918937261};\\\", \\\"{x:732,y:657,t:1526918937278};\\\", \\\"{x:734,y:654,t:1526918937293};\\\", \\\"{x:735,y:652,t:1526918937309};\\\", \\\"{x:738,y:648,t:1526918937327};\\\", \\\"{x:743,y:643,t:1526918937343};\\\", \\\"{x:746,y:639,t:1526918937361};\\\", \\\"{x:752,y:633,t:1526918937377};\\\", \\\"{x:759,y:626,t:1526918937394};\\\", \\\"{x:763,y:623,t:1526918937410};\\\", \\\"{x:767,y:620,t:1526918937428};\\\", \\\"{x:768,y:618,t:1526918937444};\\\", \\\"{x:769,y:616,t:1526918937461};\\\", \\\"{x:769,y:615,t:1526918937566};\\\", \\\"{x:769,y:614,t:1526918937582};\\\", \\\"{x:769,y:613,t:1526918937621};\\\", \\\"{x:768,y:611,t:1526918937654};\\\", \\\"{x:767,y:611,t:1526918937678};\\\", \\\"{x:762,y:610,t:1526918937695};\\\", \\\"{x:757,y:609,t:1526918937712};\\\", \\\"{x:748,y:608,t:1526918937728};\\\", \\\"{x:728,y:605,t:1526918937744};\\\", \\\"{x:699,y:601,t:1526918937763};\\\", \\\"{x:661,y:595,t:1526918937777};\\\", \\\"{x:637,y:589,t:1526918937795};\\\", \\\"{x:615,y:583,t:1526918937812};\\\", \\\"{x:601,y:579,t:1526918937828};\\\", \\\"{x:595,y:579,t:1526918937844};\\\", \\\"{x:589,y:579,t:1526918937861};\\\", \\\"{x:578,y:577,t:1526918937878};\\\", \\\"{x:564,y:576,t:1526918937894};\\\", \\\"{x:546,y:576,t:1526918937912};\\\", \\\"{x:528,y:577,t:1526918937927};\\\", \\\"{x:509,y:577,t:1526918937945};\\\", \\\"{x:502,y:577,t:1526918937962};\\\", \\\"{x:488,y:579,t:1526918937978};\\\", \\\"{x:479,y:580,t:1526918937995};\\\", \\\"{x:467,y:581,t:1526918938011};\\\", \\\"{x:458,y:582,t:1526918938027};\\\", \\\"{x:447,y:583,t:1526918938045};\\\", \\\"{x:427,y:587,t:1526918938061};\\\", \\\"{x:413,y:590,t:1526918938079};\\\", \\\"{x:404,y:591,t:1526918938095};\\\", \\\"{x:392,y:592,t:1526918938111};\\\", \\\"{x:387,y:593,t:1526918938129};\\\", \\\"{x:380,y:595,t:1526918938144};\\\", \\\"{x:377,y:596,t:1526918938161};\\\", \\\"{x:372,y:598,t:1526918938178};\\\", \\\"{x:371,y:599,t:1526918938195};\\\", \\\"{x:369,y:599,t:1526918938212};\\\", \\\"{x:368,y:599,t:1526918938228};\\\", \\\"{x:367,y:600,t:1526918938244};\\\", \\\"{x:366,y:600,t:1526918938285};\\\", \\\"{x:365,y:600,t:1526918938296};\\\", \\\"{x:365,y:602,t:1526918938463};\\\", \\\"{x:374,y:616,t:1526918938481};\\\", \\\"{x:393,y:635,t:1526918938496};\\\", \\\"{x:422,y:655,t:1526918938512};\\\", \\\"{x:463,y:677,t:1526918938529};\\\", \\\"{x:503,y:700,t:1526918938546};\\\", \\\"{x:563,y:731,t:1526918938562};\\\", \\\"{x:612,y:761,t:1526918938578};\\\", \\\"{x:664,y:791,t:1526918938595};\\\", \\\"{x:697,y:819,t:1526918938612};\\\", \\\"{x:735,y:843,t:1526918938629};\\\", \\\"{x:773,y:866,t:1526918938646};\\\", \\\"{x:787,y:874,t:1526918938662};\\\", \\\"{x:796,y:883,t:1526918938678};\\\", \\\"{x:803,y:889,t:1526918938695};\\\", \\\"{x:808,y:892,t:1526918938711};\\\", \\\"{x:811,y:894,t:1526918938729};\\\", \\\"{x:811,y:895,t:1526918938746};\\\", \\\"{x:812,y:895,t:1526918939760};\\\", \\\"{x:813,y:897,t:1526918939773};\\\", \\\"{x:817,y:898,t:1526918939789};\\\", \\\"{x:824,y:902,t:1526918939806};\\\", \\\"{x:828,y:903,t:1526918939822};\\\", \\\"{x:835,y:906,t:1526918939839};\\\", \\\"{x:840,y:908,t:1526918939855};\\\", \\\"{x:843,y:910,t:1526918939872};\\\", \\\"{x:849,y:912,t:1526918939890};\\\", \\\"{x:858,y:917,t:1526918939905};\\\", \\\"{x:866,y:919,t:1526918939923};\\\", \\\"{x:877,y:923,t:1526918939940};\\\", \\\"{x:891,y:929,t:1526918939955};\\\", \\\"{x:910,y:936,t:1526918939973};\\\", \\\"{x:927,y:943,t:1526918939990};\\\", \\\"{x:946,y:952,t:1526918940006};\\\", \\\"{x:960,y:960,t:1526918940023};\\\", \\\"{x:989,y:973,t:1526918940041};\\\", \\\"{x:1006,y:980,t:1526918940056};\\\", \\\"{x:1022,y:984,t:1526918940073};\\\", \\\"{x:1035,y:988,t:1526918940091};\\\", \\\"{x:1051,y:992,t:1526918940106};\\\", \\\"{x:1069,y:995,t:1526918940123};\\\", \\\"{x:1089,y:998,t:1526918940140};\\\", \\\"{x:1112,y:1003,t:1526918940156};\\\", \\\"{x:1132,y:1005,t:1526918940173};\\\", \\\"{x:1151,y:1008,t:1526918940190};\\\", \\\"{x:1164,y:1009,t:1526918940206};\\\", \\\"{x:1171,y:1009,t:1526918940224};\\\", \\\"{x:1174,y:1009,t:1526918940425};\\\", \\\"{x:1177,y:1009,t:1526918940441};\\\", \\\"{x:1181,y:1009,t:1526918940456};\\\", \\\"{x:1186,y:1007,t:1526918940474};\\\", \\\"{x:1189,y:1007,t:1526918940491};\\\", \\\"{x:1190,y:1007,t:1526918940506};\\\", \\\"{x:1193,y:1005,t:1526918940523};\\\", \\\"{x:1196,y:1005,t:1526918940540};\\\", \\\"{x:1199,y:1004,t:1526918940556};\\\", \\\"{x:1202,y:1004,t:1526918940574};\\\", \\\"{x:1206,y:1003,t:1526918940591};\\\", \\\"{x:1209,y:1003,t:1526918940607};\\\", \\\"{x:1210,y:1003,t:1526918940624};\\\", \\\"{x:1213,y:1002,t:1526918940641};\\\", \\\"{x:1214,y:1002,t:1526918940656};\\\", \\\"{x:1218,y:1001,t:1526918940673};\\\", \\\"{x:1221,y:1001,t:1526918940690};\\\", \\\"{x:1226,y:1000,t:1526918940707};\\\", \\\"{x:1231,y:1000,t:1526918940722};\\\", \\\"{x:1233,y:1000,t:1526918940740};\\\", \\\"{x:1235,y:998,t:1526918940757};\\\", \\\"{x:1237,y:998,t:1526918940792};\\\", \\\"{x:1239,y:998,t:1526918940807};\\\", \\\"{x:1241,y:998,t:1526918940823};\\\", \\\"{x:1247,y:998,t:1526918940840};\\\", \\\"{x:1250,y:998,t:1526918940857};\\\", \\\"{x:1251,y:998,t:1526918940873};\\\", \\\"{x:1252,y:998,t:1526918940890};\\\", \\\"{x:1253,y:998,t:1526918941168};\\\", \\\"{x:1255,y:998,t:1526918941175};\\\", \\\"{x:1256,y:998,t:1526918941192};\\\", \\\"{x:1258,y:998,t:1526918941207};\\\", \\\"{x:1259,y:998,t:1526918941223};\\\", \\\"{x:1263,y:998,t:1526918941239};\\\", \\\"{x:1264,y:998,t:1526918941257};\\\", \\\"{x:1267,y:998,t:1526918941273};\\\", \\\"{x:1270,y:998,t:1526918941290};\\\", \\\"{x:1271,y:998,t:1526918941312};\\\", \\\"{x:1270,y:996,t:1526918942296};\\\", \\\"{x:1263,y:989,t:1526918942307};\\\", \\\"{x:1239,y:971,t:1526918942324};\\\", \\\"{x:1191,y:940,t:1526918942340};\\\", \\\"{x:1125,y:900,t:1526918942356};\\\", \\\"{x:1062,y:862,t:1526918942374};\\\", \\\"{x:990,y:827,t:1526918942391};\\\", \\\"{x:936,y:796,t:1526918942407};\\\", \\\"{x:893,y:767,t:1526918942423};\\\", \\\"{x:871,y:749,t:1526918942441};\\\", \\\"{x:853,y:735,t:1526918942457};\\\", \\\"{x:838,y:725,t:1526918942474};\\\", \\\"{x:822,y:716,t:1526918942491};\\\", \\\"{x:809,y:711,t:1526918942507};\\\", \\\"{x:796,y:707,t:1526918942524};\\\", \\\"{x:783,y:703,t:1526918942541};\\\", \\\"{x:775,y:702,t:1526918942556};\\\", \\\"{x:771,y:702,t:1526918942574};\\\", \\\"{x:769,y:700,t:1526918942591};\\\", \\\"{x:767,y:700,t:1526918942606};\\\", \\\"{x:766,y:700,t:1526918942624};\\\", \\\"{x:764,y:700,t:1526918942640};\\\", \\\"{x:760,y:705,t:1526918942657};\\\", \\\"{x:749,y:713,t:1526918942674};\\\", \\\"{x:733,y:725,t:1526918942691};\\\", \\\"{x:705,y:732,t:1526918942707};\\\", \\\"{x:697,y:738,t:1526918942724};\\\", \\\"{x:696,y:738,t:1526918944543};\\\", \\\"{x:695,y:737,t:1526918944559};\\\", \\\"{x:693,y:735,t:1526918944575};\\\", \\\"{x:692,y:730,t:1526918944592};\\\", \\\"{x:690,y:726,t:1526918944608};\\\", \\\"{x:686,y:721,t:1526918944625};\\\", \\\"{x:680,y:715,t:1526918944641};\\\", \\\"{x:674,y:711,t:1526918944658};\\\", \\\"{x:666,y:705,t:1526918944675};\\\", \\\"{x:659,y:698,t:1526918944692};\\\", \\\"{x:645,y:689,t:1526918944708};\\\", \\\"{x:634,y:681,t:1526918944725};\\\", \\\"{x:615,y:671,t:1526918944742};\\\", \\\"{x:601,y:665,t:1526918944758};\\\", \\\"{x:562,y:653,t:1526918944777};\\\", \\\"{x:536,y:644,t:1526918944793};\\\", \\\"{x:503,y:636,t:1526918944811};\\\", \\\"{x:477,y:628,t:1526918944827};\\\", \\\"{x:456,y:620,t:1526918944843};\\\", \\\"{x:438,y:618,t:1526918944861};\\\", \\\"{x:429,y:616,t:1526918944877};\\\", \\\"{x:419,y:615,t:1526918944894};\\\", \\\"{x:410,y:613,t:1526918944910};\\\", \\\"{x:406,y:612,t:1526918944926};\\\", \\\"{x:397,y:612,t:1526918944944};\\\", \\\"{x:395,y:613,t:1526918944961};\\\", \\\"{x:391,y:616,t:1526918944976};\\\", \\\"{x:387,y:623,t:1526918944994};\\\", \\\"{x:385,y:627,t:1526918945011};\\\", \\\"{x:380,y:632,t:1526918945027};\\\", \\\"{x:373,y:636,t:1526918945044};\\\", \\\"{x:367,y:640,t:1526918945061};\\\", \\\"{x:363,y:644,t:1526918945077};\\\", \\\"{x:360,y:644,t:1526918945094};\\\", \\\"{x:353,y:646,t:1526918945111};\\\", \\\"{x:341,y:648,t:1526918945127};\\\", \\\"{x:316,y:650,t:1526918945144};\\\", \\\"{x:299,y:650,t:1526918945160};\\\", \\\"{x:291,y:650,t:1526918945177};\\\", \\\"{x:283,y:650,t:1526918945194};\\\", \\\"{x:274,y:650,t:1526918945211};\\\", \\\"{x:269,y:652,t:1526918945226};\\\", \\\"{x:271,y:652,t:1526918945255};\\\", \\\"{x:277,y:653,t:1526918945263};\\\", \\\"{x:288,y:654,t:1526918945277};\\\", \\\"{x:317,y:656,t:1526918945294};\\\", \\\"{x:358,y:658,t:1526918945310};\\\", \\\"{x:433,y:658,t:1526918945327};\\\", \\\"{x:495,y:660,t:1526918945344};\\\", \\\"{x:521,y:661,t:1526918945361};\\\", \\\"{x:534,y:662,t:1526918945378};\\\", \\\"{x:537,y:662,t:1526918945393};\\\", \\\"{x:538,y:662,t:1526918945411};\\\", \\\"{x:540,y:662,t:1526918945431};\\\", \\\"{x:545,y:661,t:1526918945444};\\\", \\\"{x:556,y:660,t:1526918945461};\\\", \\\"{x:579,y:660,t:1526918945478};\\\", \\\"{x:604,y:660,t:1526918945494};\\\", \\\"{x:627,y:660,t:1526918945511};\\\", \\\"{x:665,y:659,t:1526918945527};\\\", \\\"{x:695,y:659,t:1526918945545};\\\", \\\"{x:722,y:658,t:1526918945561};\\\", \\\"{x:746,y:654,t:1526918945578};\\\", \\\"{x:758,y:649,t:1526918945593};\\\", \\\"{x:770,y:648,t:1526918945611};\\\", \\\"{x:780,y:647,t:1526918945628};\\\", \\\"{x:787,y:644,t:1526918945644};\\\", \\\"{x:789,y:643,t:1526918945660};\\\", \\\"{x:792,y:641,t:1526918945677};\\\", \\\"{x:794,y:640,t:1526918945694};\\\", \\\"{x:796,y:640,t:1526918945710};\\\", \\\"{x:798,y:639,t:1526918945728};\\\", \\\"{x:796,y:639,t:1526918945816};\\\", \\\"{x:793,y:640,t:1526918945828};\\\", \\\"{x:781,y:642,t:1526918945845};\\\", \\\"{x:756,y:646,t:1526918945861};\\\", \\\"{x:731,y:648,t:1526918945878};\\\", \\\"{x:705,y:654,t:1526918945895};\\\", \\\"{x:687,y:657,t:1526918945911};\\\", \\\"{x:673,y:659,t:1526918945927};\\\", \\\"{x:672,y:659,t:1526918945944};\\\", \\\"{x:670,y:661,t:1526918945961};\\\", \\\"{x:668,y:662,t:1526918945978};\\\", \\\"{x:667,y:662,t:1526918946000};\\\", \\\"{x:665,y:663,t:1526918946011};\\\", \\\"{x:659,y:665,t:1526918946028};\\\", \\\"{x:647,y:665,t:1526918946044};\\\", \\\"{x:640,y:665,t:1526918946061};\\\", \\\"{x:635,y:664,t:1526918946077};\\\", \\\"{x:631,y:663,t:1526918946094};\\\", \\\"{x:628,y:663,t:1526918946111};\\\", \\\"{x:625,y:660,t:1526918946127};\\\", \\\"{x:622,y:657,t:1526918946145};\\\", \\\"{x:614,y:653,t:1526918946162};\\\", \\\"{x:603,y:648,t:1526918946179};\\\", \\\"{x:591,y:643,t:1526918946194};\\\", \\\"{x:575,y:635,t:1526918946212};\\\", \\\"{x:562,y:630,t:1526918946228};\\\", \\\"{x:547,y:623,t:1526918946244};\\\", \\\"{x:533,y:619,t:1526918946262};\\\", \\\"{x:516,y:614,t:1526918946279};\\\", \\\"{x:501,y:610,t:1526918946295};\\\", \\\"{x:475,y:606,t:1526918946312};\\\", \\\"{x:459,y:604,t:1526918946328};\\\", \\\"{x:448,y:604,t:1526918946345};\\\", \\\"{x:440,y:602,t:1526918946362};\\\", \\\"{x:433,y:602,t:1526918946378};\\\", \\\"{x:427,y:602,t:1526918946395};\\\", \\\"{x:423,y:602,t:1526918946412};\\\", \\\"{x:419,y:602,t:1526918946428};\\\", \\\"{x:413,y:602,t:1526918946445};\\\", \\\"{x:409,y:602,t:1526918946462};\\\", \\\"{x:404,y:602,t:1526918946478};\\\", \\\"{x:396,y:602,t:1526918946495};\\\", \\\"{x:386,y:601,t:1526918946512};\\\", \\\"{x:380,y:600,t:1526918946529};\\\", \\\"{x:371,y:597,t:1526918946546};\\\", \\\"{x:362,y:596,t:1526918946561};\\\", \\\"{x:355,y:596,t:1526918946579};\\\", \\\"{x:347,y:596,t:1526918946595};\\\", \\\"{x:343,y:596,t:1526918946612};\\\", \\\"{x:341,y:596,t:1526918946629};\\\", \\\"{x:343,y:596,t:1526918946752};\\\", \\\"{x:348,y:596,t:1526918946762};\\\", \\\"{x:370,y:596,t:1526918946779};\\\", \\\"{x:405,y:597,t:1526918946796};\\\", \\\"{x:447,y:597,t:1526918946812};\\\", \\\"{x:506,y:597,t:1526918946829};\\\", \\\"{x:584,y:597,t:1526918946845};\\\", \\\"{x:642,y:597,t:1526918946863};\\\", \\\"{x:703,y:597,t:1526918946879};\\\", \\\"{x:770,y:597,t:1526918946895};\\\", \\\"{x:835,y:597,t:1526918946912};\\\", \\\"{x:888,y:591,t:1526918946929};\\\", \\\"{x:924,y:587,t:1526918946946};\\\", \\\"{x:942,y:587,t:1526918946962};\\\", \\\"{x:955,y:584,t:1526918946980};\\\", \\\"{x:957,y:584,t:1526918946996};\\\", \\\"{x:955,y:584,t:1526918947143};\\\", \\\"{x:951,y:584,t:1526918947151};\\\", \\\"{x:946,y:584,t:1526918947163};\\\", \\\"{x:929,y:584,t:1526918947180};\\\", \\\"{x:911,y:584,t:1526918947196};\\\", \\\"{x:892,y:584,t:1526918947212};\\\", \\\"{x:873,y:584,t:1526918947229};\\\", \\\"{x:855,y:584,t:1526918947247};\\\", \\\"{x:836,y:583,t:1526918947262};\\\", \\\"{x:818,y:579,t:1526918947279};\\\", \\\"{x:785,y:577,t:1526918947295};\\\", \\\"{x:764,y:574,t:1526918947312};\\\", \\\"{x:744,y:574,t:1526918947329};\\\", \\\"{x:728,y:574,t:1526918947346};\\\", \\\"{x:712,y:574,t:1526918947362};\\\", \\\"{x:699,y:574,t:1526918947379};\\\", \\\"{x:688,y:574,t:1526918947396};\\\", \\\"{x:674,y:574,t:1526918947413};\\\", \\\"{x:661,y:574,t:1526918947429};\\\", \\\"{x:657,y:574,t:1526918947446};\\\", \\\"{x:656,y:574,t:1526918947462};\\\", \\\"{x:659,y:578,t:1526918947495};\\\", \\\"{x:677,y:585,t:1526918947514};\\\", \\\"{x:698,y:598,t:1526918947529};\\\", \\\"{x:725,y:611,t:1526918947546};\\\", \\\"{x:766,y:629,t:1526918947563};\\\", \\\"{x:815,y:654,t:1526918947579};\\\", \\\"{x:859,y:685,t:1526918947596};\\\", \\\"{x:902,y:715,t:1526918947613};\\\", \\\"{x:934,y:749,t:1526918947629};\\\", \\\"{x:950,y:770,t:1526918947646};\\\", \\\"{x:956,y:785,t:1526918947663};\\\", \\\"{x:958,y:789,t:1526918947680};\\\", \\\"{x:958,y:791,t:1526918947696};\\\", \\\"{x:958,y:792,t:1526918947713};\\\", \\\"{x:958,y:796,t:1526918947729};\\\", \\\"{x:956,y:803,t:1526918947746};\\\", \\\"{x:951,y:814,t:1526918947763};\\\", \\\"{x:946,y:828,t:1526918947779};\\\", \\\"{x:940,y:844,t:1526918947796};\\\", \\\"{x:936,y:859,t:1526918947813};\\\", \\\"{x:934,y:867,t:1526918947830};\\\", \\\"{x:933,y:873,t:1526918947846};\\\", \\\"{x:932,y:874,t:1526918947863};\\\", \\\"{x:932,y:881,t:1526918947880};\\\", \\\"{x:932,y:887,t:1526918947896};\\\", \\\"{x:930,y:896,t:1526918947913};\\\", \\\"{x:930,y:907,t:1526918947930};\\\", \\\"{x:934,y:916,t:1526918947946};\\\", \\\"{x:942,y:927,t:1526918947963};\\\", \\\"{x:954,y:935,t:1526918947980};\\\", \\\"{x:960,y:943,t:1526918947996};\\\", \\\"{x:966,y:948,t:1526918948013};\\\", \\\"{x:972,y:953,t:1526918948030};\\\", \\\"{x:979,y:959,t:1526918948046};\\\", \\\"{x:987,y:965,t:1526918948063};\\\", \\\"{x:995,y:971,t:1526918948080};\\\", \\\"{x:998,y:974,t:1526918948096};\\\", \\\"{x:1003,y:978,t:1526918948113};\\\", \\\"{x:1007,y:982,t:1526918948130};\\\", \\\"{x:1009,y:984,t:1526918948146};\\\", \\\"{x:1012,y:987,t:1526918948163};\\\", \\\"{x:1014,y:990,t:1526918948180};\\\", \\\"{x:1017,y:992,t:1526918948197};\\\", \\\"{x:1021,y:995,t:1526918948213};\\\", \\\"{x:1024,y:997,t:1526918948230};\\\", \\\"{x:1029,y:998,t:1526918948247};\\\", \\\"{x:1035,y:1004,t:1526918948263};\\\", \\\"{x:1035,y:1007,t:1526918948280};\\\", \\\"{x:1037,y:1007,t:1526918948679};\\\", \\\"{x:1042,y:1005,t:1526918948697};\\\", \\\"{x:1047,y:1002,t:1526918948714};\\\", \\\"{x:1050,y:999,t:1526918948730};\\\", \\\"{x:1052,y:993,t:1526918948747};\\\", \\\"{x:1055,y:987,t:1526918948764};\\\", \\\"{x:1059,y:984,t:1526918948780};\\\", \\\"{x:1063,y:979,t:1526918948797};\\\", \\\"{x:1067,y:976,t:1526918948814};\\\", \\\"{x:1070,y:973,t:1526918948830};\\\", \\\"{x:1074,y:972,t:1526918948847};\\\", \\\"{x:1077,y:971,t:1526918948864};\\\", \\\"{x:1079,y:971,t:1526918948881};\\\", \\\"{x:1080,y:971,t:1526918948919};\\\", \\\"{x:1082,y:971,t:1526918948931};\\\", \\\"{x:1086,y:973,t:1526918948947};\\\", \\\"{x:1097,y:974,t:1526918948964};\\\", \\\"{x:1108,y:977,t:1526918948981};\\\", \\\"{x:1116,y:978,t:1526918948997};\\\", \\\"{x:1123,y:979,t:1526918949014};\\\", \\\"{x:1124,y:980,t:1526918949031};\\\", \\\"{x:1126,y:980,t:1526918949047};\\\", \\\"{x:1129,y:981,t:1526918949064};\\\", \\\"{x:1130,y:981,t:1526918949081};\\\", \\\"{x:1132,y:981,t:1526918949097};\\\", \\\"{x:1132,y:980,t:1526918949135};\\\", \\\"{x:1132,y:979,t:1526918949147};\\\", \\\"{x:1132,y:978,t:1526918949164};\\\", \\\"{x:1132,y:977,t:1526918949181};\\\", \\\"{x:1133,y:976,t:1526918949198};\\\", \\\"{x:1133,y:975,t:1526918949214};\\\", \\\"{x:1133,y:974,t:1526918949232};\\\", \\\"{x:1133,y:971,t:1526918949248};\\\", \\\"{x:1132,y:970,t:1526918949279};\\\", \\\"{x:1132,y:969,t:1526918949368};\\\", \\\"{x:1133,y:968,t:1526918949381};\\\", \\\"{x:1135,y:968,t:1526918949398};\\\", \\\"{x:1136,y:968,t:1526918949415};\\\", \\\"{x:1140,y:968,t:1526918949431};\\\", \\\"{x:1146,y:969,t:1526918949447};\\\", \\\"{x:1150,y:969,t:1526918949464};\\\", \\\"{x:1155,y:970,t:1526918949481};\\\", \\\"{x:1159,y:970,t:1526918949498};\\\", \\\"{x:1161,y:970,t:1526918949514};\\\", \\\"{x:1162,y:971,t:1526918950159};\\\", \\\"{x:1162,y:972,t:1526918950199};\\\", \\\"{x:1162,y:973,t:1526918950240};\\\", \\\"{x:1162,y:974,t:1526918950336};\\\", \\\"{x:1162,y:975,t:1526918950448};\\\", \\\"{x:1163,y:975,t:1526918950681};\\\", \\\"{x:1164,y:975,t:1526918950688};\\\", \\\"{x:1167,y:975,t:1526918950712};\\\", \\\"{x:1168,y:975,t:1526918950737};\\\", \\\"{x:1170,y:975,t:1526918950750};\\\", \\\"{x:1172,y:975,t:1526918950765};\\\", \\\"{x:1174,y:975,t:1526918950783};\\\", \\\"{x:1175,y:975,t:1526918950800};\\\", \\\"{x:1176,y:975,t:1526918950816};\\\", \\\"{x:1177,y:975,t:1526918950840};\\\", \\\"{x:1178,y:974,t:1526918950856};\\\", \\\"{x:1180,y:974,t:1526918950881};\\\", \\\"{x:1181,y:974,t:1526918950952};\\\", \\\"{x:1181,y:973,t:1526918950967};\\\", \\\"{x:1182,y:972,t:1526918950984};\\\", \\\"{x:1183,y:972,t:1526918951208};\\\", \\\"{x:1187,y:972,t:1526918951224};\\\", \\\"{x:1188,y:972,t:1526918951233};\\\", \\\"{x:1195,y:972,t:1526918951249};\\\", \\\"{x:1199,y:972,t:1526918951267};\\\", \\\"{x:1206,y:972,t:1526918951284};\\\", \\\"{x:1211,y:972,t:1526918951299};\\\", \\\"{x:1213,y:973,t:1526918951316};\\\", \\\"{x:1212,y:973,t:1526918951367};\\\", \\\"{x:1213,y:973,t:1526918951623};\\\", \\\"{x:1215,y:973,t:1526918951633};\\\", \\\"{x:1218,y:973,t:1526918951651};\\\", \\\"{x:1219,y:973,t:1526918951666};\\\", \\\"{x:1221,y:973,t:1526918951683};\\\", \\\"{x:1222,y:973,t:1526918951703};\\\", \\\"{x:1224,y:974,t:1526918951735};\\\", \\\"{x:1225,y:974,t:1526918951776};\\\", \\\"{x:1228,y:974,t:1526918951791};\\\", \\\"{x:1230,y:974,t:1526918951800};\\\", \\\"{x:1234,y:974,t:1526918951816};\\\", \\\"{x:1235,y:974,t:1526918951833};\\\", \\\"{x:1236,y:974,t:1526918951855};\\\", \\\"{x:1237,y:974,t:1526918951896};\\\", \\\"{x:1239,y:974,t:1526918951911};\\\", \\\"{x:1241,y:974,t:1526918951919};\\\", \\\"{x:1242,y:974,t:1526918951933};\\\", \\\"{x:1244,y:973,t:1526918951950};\\\", \\\"{x:1246,y:973,t:1526918951967};\\\", \\\"{x:1248,y:973,t:1526918951983};\\\", \\\"{x:1250,y:973,t:1526918952216};\\\", \\\"{x:1252,y:973,t:1526918952223};\\\", \\\"{x:1255,y:973,t:1526918952234};\\\", \\\"{x:1258,y:973,t:1526918952250};\\\", \\\"{x:1261,y:972,t:1526918952267};\\\", \\\"{x:1262,y:972,t:1526918952336};\\\", \\\"{x:1264,y:972,t:1526918952350};\\\", \\\"{x:1265,y:972,t:1526918952367};\\\", \\\"{x:1267,y:972,t:1526918952479};\\\", \\\"{x:1269,y:972,t:1526918952527};\\\", \\\"{x:1270,y:972,t:1526918952559};\\\", \\\"{x:1271,y:972,t:1526918952607};\\\", \\\"{x:1272,y:973,t:1526918952623};\\\", \\\"{x:1274,y:974,t:1526918952635};\\\", \\\"{x:1275,y:975,t:1526918952664};\\\", \\\"{x:1276,y:975,t:1526918952775};\\\", \\\"{x:1278,y:975,t:1526918952791};\\\", \\\"{x:1280,y:976,t:1526918952801};\\\", \\\"{x:1281,y:976,t:1526918952817};\\\", \\\"{x:1284,y:976,t:1526918952834};\\\", \\\"{x:1286,y:976,t:1526918952851};\\\", \\\"{x:1288,y:976,t:1526918952867};\\\", \\\"{x:1294,y:976,t:1526918952884};\\\", \\\"{x:1303,y:976,t:1526918952901};\\\", \\\"{x:1314,y:976,t:1526918952917};\\\", \\\"{x:1327,y:976,t:1526918952934};\\\", \\\"{x:1338,y:979,t:1526918952952};\\\", \\\"{x:1339,y:979,t:1526918953136};\\\", \\\"{x:1339,y:978,t:1526918953159};\\\", \\\"{x:1339,y:977,t:1526918953183};\\\", \\\"{x:1338,y:976,t:1526918953208};\\\", \\\"{x:1336,y:975,t:1526918953224};\\\", \\\"{x:1335,y:975,t:1526918953248};\\\", \\\"{x:1336,y:975,t:1526918953552};\\\", \\\"{x:1338,y:975,t:1526918953569};\\\", \\\"{x:1339,y:975,t:1526918953586};\\\", \\\"{x:1341,y:975,t:1526918953602};\\\", \\\"{x:1344,y:975,t:1526918953619};\\\", \\\"{x:1346,y:975,t:1526918953636};\\\", \\\"{x:1348,y:975,t:1526918953651};\\\", \\\"{x:1350,y:975,t:1526918953668};\\\", \\\"{x:1352,y:975,t:1526918953685};\\\", \\\"{x:1353,y:975,t:1526918953702};\\\", \\\"{x:1355,y:975,t:1526918953718};\\\", \\\"{x:1359,y:975,t:1526918953736};\\\", \\\"{x:1364,y:975,t:1526918953752};\\\", \\\"{x:1368,y:975,t:1526918953770};\\\", \\\"{x:1371,y:976,t:1526918953786};\\\", \\\"{x:1372,y:976,t:1526918953905};\\\", \\\"{x:1374,y:976,t:1526918954048};\\\", \\\"{x:1375,y:975,t:1526918954080};\\\", \\\"{x:1376,y:975,t:1526918954088};\\\", \\\"{x:1377,y:975,t:1526918954104};\\\", \\\"{x:1378,y:974,t:1526918954120};\\\", \\\"{x:1381,y:973,t:1526918954151};\\\", \\\"{x:1384,y:972,t:1526918954176};\\\", \\\"{x:1385,y:972,t:1526918954185};\\\", \\\"{x:1387,y:972,t:1526918954202};\\\", \\\"{x:1388,y:972,t:1526918954223};\\\", \\\"{x:1389,y:971,t:1526918954239};\\\", \\\"{x:1390,y:971,t:1526918954253};\\\", \\\"{x:1391,y:971,t:1526918954279};\\\", \\\"{x:1391,y:970,t:1526918954288};\\\", \\\"{x:1393,y:970,t:1526918954302};\\\", \\\"{x:1397,y:969,t:1526918954319};\\\", \\\"{x:1398,y:969,t:1526918954335};\\\", \\\"{x:1399,y:969,t:1526918954352};\\\", \\\"{x:1400,y:969,t:1526918954392};\\\", \\\"{x:1401,y:969,t:1526918954521};\\\", \\\"{x:1401,y:970,t:1526918954536};\\\", \\\"{x:1402,y:971,t:1526918954552};\\\", \\\"{x:1403,y:971,t:1526918954570};\\\", \\\"{x:1405,y:972,t:1526918954592};\\\", \\\"{x:1406,y:974,t:1526918954640};\\\", \\\"{x:1407,y:974,t:1526918954653};\\\", \\\"{x:1410,y:975,t:1526918954669};\\\", \\\"{x:1411,y:976,t:1526918954687};\\\", \\\"{x:1412,y:976,t:1526918954704};\\\", \\\"{x:1413,y:976,t:1526918954792};\\\", \\\"{x:1414,y:977,t:1526918954803};\\\", \\\"{x:1415,y:977,t:1526918954820};\\\", \\\"{x:1416,y:977,t:1526918954848};\\\", \\\"{x:1417,y:977,t:1526918954856};\\\", \\\"{x:1419,y:977,t:1526918954869};\\\", \\\"{x:1421,y:977,t:1526918954887};\\\", \\\"{x:1428,y:977,t:1526918954903};\\\", \\\"{x:1442,y:977,t:1526918954920};\\\", \\\"{x:1446,y:977,t:1526918954936};\\\", \\\"{x:1446,y:976,t:1526918955025};\\\", \\\"{x:1446,y:975,t:1526918955038};\\\", \\\"{x:1446,y:974,t:1526918955054};\\\", \\\"{x:1447,y:972,t:1526918955072};\\\", \\\"{x:1447,y:971,t:1526918955169};\\\", \\\"{x:1449,y:970,t:1526918955200};\\\", \\\"{x:1450,y:970,t:1526918955224};\\\", \\\"{x:1452,y:969,t:1526918955237};\\\", \\\"{x:1455,y:968,t:1526918955264};\\\", \\\"{x:1456,y:968,t:1526918955272};\\\", \\\"{x:1457,y:968,t:1526918955287};\\\", \\\"{x:1462,y:968,t:1526918955305};\\\", \\\"{x:1464,y:968,t:1526918955320};\\\", \\\"{x:1466,y:968,t:1526918955345};\\\", \\\"{x:1467,y:968,t:1526918955360};\\\", \\\"{x:1468,y:968,t:1526918955371};\\\", \\\"{x:1469,y:968,t:1526918955386};\\\", \\\"{x:1470,y:968,t:1526918955404};\\\", \\\"{x:1471,y:968,t:1526918955440};\\\", \\\"{x:1472,y:968,t:1526918955456};\\\", \\\"{x:1473,y:968,t:1526918955471};\\\", \\\"{x:1476,y:968,t:1526918955486};\\\", \\\"{x:1478,y:969,t:1526918955504};\\\", \\\"{x:1479,y:969,t:1526918955520};\\\", \\\"{x:1480,y:969,t:1526918955536};\\\", \\\"{x:1481,y:969,t:1526918955553};\\\", \\\"{x:1482,y:970,t:1526918955570};\\\", \\\"{x:1483,y:970,t:1526918955872};\\\", \\\"{x:1490,y:971,t:1526918955887};\\\", \\\"{x:1504,y:972,t:1526918955904};\\\", \\\"{x:1508,y:972,t:1526918955921};\\\", \\\"{x:1510,y:972,t:1526918955937};\\\", \\\"{x:1511,y:972,t:1526918956112};\\\", \\\"{x:1512,y:972,t:1526918956120};\\\", \\\"{x:1514,y:972,t:1526918956151};\\\", \\\"{x:1516,y:972,t:1526918956159};\\\", \\\"{x:1519,y:972,t:1526918956170};\\\", \\\"{x:1527,y:974,t:1526918956187};\\\", \\\"{x:1534,y:975,t:1526918956205};\\\", \\\"{x:1537,y:976,t:1526918956220};\\\", \\\"{x:1538,y:976,t:1526918956238};\\\", \\\"{x:1540,y:976,t:1526918956519};\\\", \\\"{x:1546,y:977,t:1526918956527};\\\", \\\"{x:1552,y:979,t:1526918956537};\\\", \\\"{x:1560,y:979,t:1526918956554};\\\", \\\"{x:1563,y:981,t:1526918956571};\\\", \\\"{x:1562,y:981,t:1526918956751};\\\", \\\"{x:1561,y:981,t:1526918956759};\\\", \\\"{x:1560,y:981,t:1526918956771};\\\", \\\"{x:1559,y:981,t:1526918956787};\\\", \\\"{x:1559,y:980,t:1526918956904};\\\", \\\"{x:1559,y:979,t:1526918956919};\\\", \\\"{x:1559,y:978,t:1526918956944};\\\", \\\"{x:1559,y:977,t:1526918956976};\\\", \\\"{x:1559,y:976,t:1526918956989};\\\", \\\"{x:1560,y:975,t:1526918957008};\\\", \\\"{x:1562,y:974,t:1526918957032};\\\", \\\"{x:1564,y:973,t:1526918957128};\\\", \\\"{x:1565,y:973,t:1526918957139};\\\", \\\"{x:1566,y:973,t:1526918957154};\\\", \\\"{x:1567,y:973,t:1526918957171};\\\", \\\"{x:1568,y:973,t:1526918957287};\\\", \\\"{x:1569,y:973,t:1526918957295};\\\", \\\"{x:1570,y:973,t:1526918957440};\\\", \\\"{x:1571,y:973,t:1526918957463};\\\", \\\"{x:1572,y:973,t:1526918957519};\\\", \\\"{x:1573,y:973,t:1526918957535};\\\", \\\"{x:1574,y:973,t:1526918957768};\\\", \\\"{x:1574,y:974,t:1526918957775};\\\", \\\"{x:1575,y:974,t:1526918957788};\\\", \\\"{x:1576,y:975,t:1526918957824};\\\", \\\"{x:1576,y:976,t:1526918957839};\\\", \\\"{x:1577,y:976,t:1526918957855};\\\", \\\"{x:1578,y:976,t:1526918957872};\\\", \\\"{x:1579,y:977,t:1526918957888};\\\", \\\"{x:1581,y:977,t:1526918957905};\\\", \\\"{x:1582,y:977,t:1526918957922};\\\", \\\"{x:1584,y:979,t:1526918957939};\\\", \\\"{x:1587,y:979,t:1526918957956};\\\", \\\"{x:1592,y:980,t:1526918957972};\\\", \\\"{x:1595,y:980,t:1526918957990};\\\", \\\"{x:1596,y:981,t:1526918958005};\\\", \\\"{x:1598,y:981,t:1526918958023};\\\", \\\"{x:1599,y:981,t:1526918958088};\\\", \\\"{x:1600,y:981,t:1526918958103};\\\", \\\"{x:1601,y:981,t:1526918958127};\\\", \\\"{x:1602,y:981,t:1526918958159};\\\", \\\"{x:1603,y:981,t:1526918958183};\\\", \\\"{x:1605,y:981,t:1526918958192};\\\", \\\"{x:1605,y:980,t:1526918958215};\\\", \\\"{x:1606,y:980,t:1526918958312};\\\", \\\"{x:1607,y:980,t:1526918958424};\\\", \\\"{x:1608,y:980,t:1526918958463};\\\", \\\"{x:1610,y:979,t:1526918958487};\\\", \\\"{x:1611,y:979,t:1526918958495};\\\", \\\"{x:1612,y:977,t:1526918958519};\\\", \\\"{x:1613,y:977,t:1526918958663};\\\", \\\"{x:1613,y:976,t:1526918958679};\\\", \\\"{x:1614,y:975,t:1526918958719};\\\", \\\"{x:1610,y:974,t:1526918959104};\\\", \\\"{x:1604,y:974,t:1526918959111};\\\", \\\"{x:1589,y:971,t:1526918959123};\\\", \\\"{x:1545,y:974,t:1526918959140};\\\", \\\"{x:1486,y:974,t:1526918959156};\\\", \\\"{x:1436,y:969,t:1526918959173};\\\", \\\"{x:1401,y:948,t:1526918959190};\\\", \\\"{x:1374,y:933,t:1526918959207};\\\", \\\"{x:1352,y:921,t:1526918959223};\\\", \\\"{x:1338,y:915,t:1526918959241};\\\", \\\"{x:1324,y:909,t:1526918959256};\\\", \\\"{x:1297,y:904,t:1526918959273};\\\", \\\"{x:1248,y:896,t:1526918959291};\\\", \\\"{x:1164,y:881,t:1526918959307};\\\", \\\"{x:1069,y:863,t:1526918959324};\\\", \\\"{x:970,y:837,t:1526918959340};\\\", \\\"{x:887,y:803,t:1526918959356};\\\", \\\"{x:834,y:776,t:1526918959374};\\\", \\\"{x:800,y:755,t:1526918959391};\\\", \\\"{x:777,y:739,t:1526918959406};\\\", \\\"{x:750,y:715,t:1526918959423};\\\", \\\"{x:730,y:700,t:1526918959441};\\\", \\\"{x:705,y:682,t:1526918959457};\\\", \\\"{x:676,y:666,t:1526918959474};\\\", \\\"{x:643,y:644,t:1526918959490};\\\", \\\"{x:599,y:626,t:1526918959506};\\\", \\\"{x:553,y:608,t:1526918959523};\\\", \\\"{x:521,y:598,t:1526918959539};\\\", \\\"{x:499,y:593,t:1526918959556};\\\", \\\"{x:481,y:587,t:1526918959572};\\\", \\\"{x:470,y:585,t:1526918959589};\\\", \\\"{x:463,y:585,t:1526918959606};\\\", \\\"{x:457,y:585,t:1526918959622};\\\", \\\"{x:450,y:585,t:1526918959640};\\\", \\\"{x:441,y:586,t:1526918959655};\\\", \\\"{x:431,y:592,t:1526918959672};\\\", \\\"{x:413,y:602,t:1526918959690};\\\", \\\"{x:399,y:614,t:1526918959706};\\\", \\\"{x:384,y:626,t:1526918959723};\\\", \\\"{x:379,y:633,t:1526918959739};\\\", \\\"{x:377,y:638,t:1526918959756};\\\", \\\"{x:377,y:644,t:1526918959772};\\\", \\\"{x:377,y:649,t:1526918959789};\\\", \\\"{x:377,y:653,t:1526918959807};\\\", \\\"{x:377,y:659,t:1526918959823};\\\", \\\"{x:379,y:665,t:1526918959839};\\\", \\\"{x:379,y:668,t:1526918959856};\\\", \\\"{x:379,y:673,t:1526918959873};\\\", \\\"{x:379,y:675,t:1526918959889};\\\", \\\"{x:379,y:681,t:1526918959907};\\\", \\\"{x:374,y:687,t:1526918959924};\\\", \\\"{x:370,y:690,t:1526918959939};\\\", \\\"{x:366,y:691,t:1526918959956};\\\", \\\"{x:363,y:691,t:1526918959974};\\\", \\\"{x:359,y:691,t:1526918959989};\\\", \\\"{x:352,y:690,t:1526918960007};\\\", \\\"{x:341,y:686,t:1526918960023};\\\", \\\"{x:325,y:679,t:1526918960040};\\\", \\\"{x:302,y:674,t:1526918960057};\\\", \\\"{x:279,y:667,t:1526918960074};\\\", \\\"{x:266,y:662,t:1526918960090};\\\", \\\"{x:259,y:658,t:1526918960107};\\\", \\\"{x:259,y:657,t:1526918960123};\\\", \\\"{x:258,y:657,t:1526918960175};\\\", \\\"{x:256,y:657,t:1526918960189};\\\", \\\"{x:254,y:657,t:1526918960206};\\\", \\\"{x:246,y:653,t:1526918960223};\\\", \\\"{x:239,y:651,t:1526918960239};\\\", \\\"{x:232,y:649,t:1526918960257};\\\", \\\"{x:227,y:646,t:1526918960274};\\\", \\\"{x:223,y:646,t:1526918960289};\\\", \\\"{x:221,y:645,t:1526918960306};\\\", \\\"{x:219,y:643,t:1526918960323};\\\", \\\"{x:218,y:642,t:1526918960340};\\\", \\\"{x:217,y:642,t:1526918960357};\\\", \\\"{x:216,y:640,t:1526918960373};\\\", \\\"{x:216,y:638,t:1526918960399};\\\", \\\"{x:218,y:636,t:1526918960407};\\\", \\\"{x:230,y:634,t:1526918960423};\\\", \\\"{x:250,y:629,t:1526918960441};\\\", \\\"{x:271,y:623,t:1526918960457};\\\", \\\"{x:297,y:615,t:1526918960473};\\\", \\\"{x:318,y:608,t:1526918960490};\\\", \\\"{x:328,y:606,t:1526918960506};\\\", \\\"{x:330,y:606,t:1526918960523};\\\", \\\"{x:332,y:603,t:1526918960679};\\\", \\\"{x:338,y:603,t:1526918960691};\\\", \\\"{x:360,y:603,t:1526918960706};\\\", \\\"{x:386,y:603,t:1526918960724};\\\", \\\"{x:411,y:603,t:1526918960741};\\\", \\\"{x:438,y:603,t:1526918960757};\\\", \\\"{x:455,y:603,t:1526918960774};\\\", \\\"{x:473,y:603,t:1526918960791};\\\", \\\"{x:493,y:603,t:1526918960806};\\\", \\\"{x:519,y:603,t:1526918960823};\\\", \\\"{x:532,y:604,t:1526918960841};\\\", \\\"{x:540,y:605,t:1526918960857};\\\", \\\"{x:542,y:606,t:1526918960873};\\\", \\\"{x:545,y:607,t:1526918960891};\\\", \\\"{x:549,y:609,t:1526918960907};\\\", \\\"{x:556,y:609,t:1526918960923};\\\", \\\"{x:562,y:610,t:1526918960940};\\\", \\\"{x:567,y:613,t:1526918960958};\\\", \\\"{x:568,y:613,t:1526918960973};\\\", \\\"{x:572,y:613,t:1526918960990};\\\", \\\"{x:583,y:614,t:1526918961007};\\\", \\\"{x:599,y:617,t:1526918961023};\\\", \\\"{x:623,y:618,t:1526918961040};\\\", \\\"{x:661,y:618,t:1526918961057};\\\", \\\"{x:706,y:618,t:1526918961074};\\\", \\\"{x:729,y:618,t:1526918961091};\\\", \\\"{x:749,y:621,t:1526918961107};\\\", \\\"{x:753,y:622,t:1526918961124};\\\", \\\"{x:754,y:622,t:1526918961247};\\\", \\\"{x:754,y:623,t:1526918961271};\\\", \\\"{x:755,y:623,t:1526918961287};\\\", \\\"{x:755,y:624,t:1526918961311};\\\", \\\"{x:755,y:625,t:1526918961324};\\\", \\\"{x:755,y:627,t:1526918961351};\\\", \\\"{x:755,y:628,t:1526918961359};\\\", \\\"{x:755,y:629,t:1526918961375};\\\", \\\"{x:753,y:630,t:1526918961391};\\\", \\\"{x:750,y:633,t:1526918961407};\\\", \\\"{x:746,y:635,t:1526918961424};\\\", \\\"{x:746,y:636,t:1526918961440};\\\", \\\"{x:744,y:637,t:1526918961457};\\\", \\\"{x:742,y:639,t:1526918961474};\\\", \\\"{x:739,y:641,t:1526918961490};\\\", \\\"{x:738,y:641,t:1526918961511};\\\", \\\"{x:736,y:643,t:1526918961524};\\\", \\\"{x:732,y:643,t:1526918961540};\\\", \\\"{x:725,y:646,t:1526918961557};\\\", \\\"{x:720,y:647,t:1526918961575};\\\", \\\"{x:713,y:648,t:1526918961591};\\\", \\\"{x:700,y:648,t:1526918961607};\\\", \\\"{x:691,y:648,t:1526918961624};\\\", \\\"{x:682,y:650,t:1526918961642};\\\", \\\"{x:673,y:650,t:1526918961657};\\\", \\\"{x:660,y:650,t:1526918961675};\\\", \\\"{x:652,y:651,t:1526918961691};\\\", \\\"{x:641,y:651,t:1526918961708};\\\", \\\"{x:626,y:651,t:1526918961725};\\\", \\\"{x:612,y:652,t:1526918961742};\\\", \\\"{x:603,y:654,t:1526918961757};\\\", \\\"{x:595,y:657,t:1526918961775};\\\", \\\"{x:584,y:662,t:1526918961791};\\\", \\\"{x:572,y:667,t:1526918961807};\\\", \\\"{x:561,y:670,t:1526918961825};\\\", \\\"{x:549,y:674,t:1526918961841};\\\", \\\"{x:540,y:677,t:1526918961859};\\\", \\\"{x:528,y:683,t:1526918961875};\\\", \\\"{x:516,y:688,t:1526918961892};\\\", \\\"{x:502,y:695,t:1526918961909};\\\", \\\"{x:493,y:698,t:1526918961925};\\\", \\\"{x:481,y:701,t:1526918961942};\\\", \\\"{x:471,y:704,t:1526918961957};\\\", \\\"{x:465,y:706,t:1526918961974};\\\", \\\"{x:459,y:706,t:1526918961991};\\\", \\\"{x:451,y:706,t:1526918962007};\\\", \\\"{x:442,y:706,t:1526918962024};\\\", \\\"{x:432,y:706,t:1526918962041};\\\", \\\"{x:422,y:706,t:1526918962058};\\\", \\\"{x:408,y:705,t:1526918962074};\\\", \\\"{x:398,y:705,t:1526918962091};\\\", \\\"{x:386,y:702,t:1526918962108};\\\", \\\"{x:374,y:701,t:1526918962124};\\\", \\\"{x:361,y:698,t:1526918962141};\\\", \\\"{x:350,y:697,t:1526918962158};\\\", \\\"{x:343,y:695,t:1526918962175};\\\", \\\"{x:327,y:692,t:1526918962192};\\\", \\\"{x:309,y:690,t:1526918962208};\\\", \\\"{x:291,y:687,t:1526918962225};\\\", \\\"{x:271,y:682,t:1526918962242};\\\", \\\"{x:253,y:679,t:1526918962258};\\\", \\\"{x:239,y:676,t:1526918962275};\\\", \\\"{x:238,y:676,t:1526918962292};\\\", \\\"{x:238,y:674,t:1526918962351};\\\", \\\"{x:242,y:672,t:1526918962359};\\\", \\\"{x:248,y:671,t:1526918962375};\\\", \\\"{x:281,y:665,t:1526918962391};\\\", \\\"{x:312,y:661,t:1526918962408};\\\", \\\"{x:350,y:655,t:1526918962424};\\\", \\\"{x:383,y:650,t:1526918962442};\\\", \\\"{x:407,y:650,t:1526918962459};\\\", \\\"{x:431,y:650,t:1526918962475};\\\", \\\"{x:453,y:650,t:1526918962491};\\\", \\\"{x:472,y:649,t:1526918962509};\\\", \\\"{x:497,y:644,t:1526918962525};\\\", \\\"{x:519,y:642,t:1526918962542};\\\", \\\"{x:542,y:638,t:1526918962558};\\\", \\\"{x:572,y:636,t:1526918962575};\\\", \\\"{x:582,y:636,t:1526918962591};\\\", \\\"{x:590,y:636,t:1526918962608};\\\", \\\"{x:595,y:633,t:1526918962625};\\\", \\\"{x:605,y:633,t:1526918962642};\\\", \\\"{x:624,y:631,t:1526918962659};\\\", \\\"{x:646,y:631,t:1526918962676};\\\", \\\"{x:669,y:631,t:1526918962691};\\\", \\\"{x:691,y:631,t:1526918962709};\\\", \\\"{x:705,y:629,t:1526918962725};\\\", \\\"{x:710,y:629,t:1526918962741};\\\", \\\"{x:713,y:628,t:1526918962758};\\\", \\\"{x:714,y:628,t:1526918962775};\\\", \\\"{x:718,y:626,t:1526918962791};\\\", \\\"{x:720,y:625,t:1526918962809};\\\", \\\"{x:722,y:624,t:1526918962826};\\\", \\\"{x:725,y:623,t:1526918962843};\\\", \\\"{x:726,y:621,t:1526918962859};\\\", \\\"{x:729,y:621,t:1526918962876};\\\", \\\"{x:736,y:621,t:1526918962892};\\\", \\\"{x:752,y:617,t:1526918962909};\\\", \\\"{x:765,y:615,t:1526918962925};\\\", \\\"{x:775,y:615,t:1526918962941};\\\", \\\"{x:778,y:615,t:1526918962959};\\\", \\\"{x:781,y:613,t:1526918962975};\\\", \\\"{x:782,y:612,t:1526918962999};\\\", \\\"{x:783,y:612,t:1526918963009};\\\", \\\"{x:786,y:610,t:1526918963026};\\\", \\\"{x:789,y:609,t:1526918963043};\\\", \\\"{x:792,y:608,t:1526918963059};\\\", \\\"{x:793,y:606,t:1526918963076};\\\", \\\"{x:794,y:604,t:1526918963119};\\\", \\\"{x:797,y:603,t:1526918963135};\\\", \\\"{x:798,y:602,t:1526918963143};\\\", \\\"{x:799,y:602,t:1526918963158};\\\", \\\"{x:799,y:601,t:1526918963264};\\\", \\\"{x:798,y:600,t:1526918963408};\\\", \\\"{x:788,y:599,t:1526918963426};\\\", \\\"{x:768,y:597,t:1526918963442};\\\", \\\"{x:740,y:592,t:1526918963459};\\\", \\\"{x:711,y:591,t:1526918963478};\\\", \\\"{x:681,y:586,t:1526918963491};\\\", \\\"{x:643,y:582,t:1526918963510};\\\", \\\"{x:618,y:581,t:1526918963526};\\\", \\\"{x:592,y:581,t:1526918963543};\\\", \\\"{x:562,y:581,t:1526918963559};\\\", \\\"{x:544,y:581,t:1526918963576};\\\", \\\"{x:529,y:581,t:1526918963592};\\\", \\\"{x:510,y:581,t:1526918963610};\\\", \\\"{x:493,y:581,t:1526918963628};\\\", \\\"{x:477,y:581,t:1526918963643};\\\", \\\"{x:454,y:581,t:1526918963660};\\\", \\\"{x:428,y:581,t:1526918963676};\\\", \\\"{x:404,y:581,t:1526918963693};\\\", \\\"{x:377,y:581,t:1526918963710};\\\", \\\"{x:357,y:581,t:1526918963726};\\\", \\\"{x:348,y:581,t:1526918963743};\\\", \\\"{x:342,y:581,t:1526918963759};\\\", \\\"{x:339,y:582,t:1526918963776};\\\", \\\"{x:333,y:583,t:1526918963793};\\\", \\\"{x:325,y:586,t:1526918963810};\\\", \\\"{x:307,y:589,t:1526918963826};\\\", \\\"{x:293,y:590,t:1526918963842};\\\", \\\"{x:285,y:591,t:1526918963860};\\\", \\\"{x:279,y:592,t:1526918963877};\\\", \\\"{x:273,y:594,t:1526918963893};\\\", \\\"{x:268,y:595,t:1526918963912};\\\", \\\"{x:263,y:597,t:1526918963926};\\\", \\\"{x:257,y:598,t:1526918963942};\\\", \\\"{x:248,y:600,t:1526918963960};\\\", \\\"{x:242,y:600,t:1526918963977};\\\", \\\"{x:237,y:602,t:1526918963994};\\\", \\\"{x:230,y:602,t:1526918964010};\\\", \\\"{x:226,y:602,t:1526918964027};\\\", \\\"{x:225,y:602,t:1526918964044};\\\", \\\"{x:225,y:601,t:1526918964112};\\\", \\\"{x:230,y:599,t:1526918964127};\\\", \\\"{x:261,y:596,t:1526918964144};\\\", \\\"{x:287,y:596,t:1526918964162};\\\", \\\"{x:335,y:593,t:1526918964177};\\\", \\\"{x:371,y:593,t:1526918964193};\\\", \\\"{x:398,y:593,t:1526918964209};\\\", \\\"{x:413,y:593,t:1526918964227};\\\", \\\"{x:422,y:593,t:1526918964244};\\\", \\\"{x:427,y:593,t:1526918964260};\\\", \\\"{x:430,y:593,t:1526918964277};\\\", \\\"{x:431,y:593,t:1526918964294};\\\", \\\"{x:433,y:593,t:1526918964367};\\\", \\\"{x:434,y:592,t:1526918964383};\\\", \\\"{x:434,y:591,t:1526918964400};\\\", \\\"{x:434,y:590,t:1526918964409};\\\", \\\"{x:434,y:587,t:1526918964426};\\\", \\\"{x:434,y:586,t:1526918964448};\\\", \\\"{x:434,y:584,t:1526918964463};\\\", \\\"{x:434,y:583,t:1526918964480};\\\", \\\"{x:434,y:582,t:1526918964552};\\\", \\\"{x:432,y:584,t:1526918964561};\\\", \\\"{x:427,y:587,t:1526918964577};\\\", \\\"{x:426,y:589,t:1526918964594};\\\", \\\"{x:426,y:595,t:1526918964611};\\\", \\\"{x:426,y:597,t:1526918964627};\\\", \\\"{x:426,y:598,t:1526918964644};\\\", \\\"{x:426,y:599,t:1526918964664};\\\", \\\"{x:427,y:600,t:1526918964678};\\\", \\\"{x:427,y:601,t:1526918964913};\\\", \\\"{x:428,y:604,t:1526918964928};\\\", \\\"{x:431,y:608,t:1526918964944};\\\", \\\"{x:436,y:616,t:1526918964962};\\\", \\\"{x:438,y:621,t:1526918964978};\\\", \\\"{x:440,y:626,t:1526918964994};\\\", \\\"{x:440,y:629,t:1526918965010};\\\", \\\"{x:442,y:632,t:1526918965028};\\\", \\\"{x:442,y:634,t:1526918965224};\\\", \\\"{x:442,y:636,t:1526918965231};\\\", \\\"{x:442,y:638,t:1526918965245};\\\", \\\"{x:443,y:643,t:1526918965261};\\\", \\\"{x:443,y:649,t:1526918965278};\\\", \\\"{x:443,y:653,t:1526918965295};\\\", \\\"{x:444,y:655,t:1526918965311};\\\", \\\"{x:444,y:656,t:1526918965328};\\\", \\\"{x:444,y:657,t:1526918965391};\\\", \\\"{x:444,y:659,t:1526918965407};\\\", \\\"{x:444,y:660,t:1526918965511};\\\", \\\"{x:445,y:661,t:1526918965576};\\\", \\\"{x:448,y:661,t:1526918965583};\\\", \\\"{x:454,y:661,t:1526918965595};\\\", \\\"{x:475,y:661,t:1526918965611};\\\", \\\"{x:504,y:661,t:1526918965629};\\\", \\\"{x:541,y:661,t:1526918965644};\\\", \\\"{x:575,y:661,t:1526918965661};\\\", \\\"{x:596,y:661,t:1526918965678};\\\", \\\"{x:607,y:661,t:1526918965695};\\\", \\\"{x:611,y:661,t:1526918965711};\\\", \\\"{x:616,y:661,t:1526918965728};\\\", \\\"{x:621,y:659,t:1526918965745};\\\", \\\"{x:628,y:654,t:1526918965761};\\\", \\\"{x:635,y:649,t:1526918965778};\\\", \\\"{x:641,y:644,t:1526918965794};\\\", \\\"{x:648,y:637,t:1526918965811};\\\", \\\"{x:653,y:630,t:1526918965828};\\\", \\\"{x:662,y:619,t:1526918965844};\\\", \\\"{x:666,y:614,t:1526918965861};\\\", \\\"{x:669,y:609,t:1526918965878};\\\", \\\"{x:669,y:608,t:1526918965895};\\\", \\\"{x:669,y:610,t:1526918966047};\\\", \\\"{x:669,y:611,t:1526918966062};\\\", \\\"{x:669,y:614,t:1526918966078};\\\", \\\"{x:670,y:617,t:1526918966095};\\\", \\\"{x:670,y:621,t:1526918966112};\\\", \\\"{x:670,y:622,t:1526918966127};\\\", \\\"{x:670,y:625,t:1526918966144};\\\", \\\"{x:670,y:627,t:1526918966162};\\\", \\\"{x:670,y:628,t:1526918966177};\\\", \\\"{x:670,y:630,t:1526918966194};\\\", \\\"{x:670,y:631,t:1526918966215};\\\", \\\"{x:668,y:629,t:1526918966688};\\\", \\\"{x:667,y:628,t:1526918966695};\\\", \\\"{x:665,y:622,t:1526918966712};\\\", \\\"{x:662,y:620,t:1526918966729};\\\", \\\"{x:662,y:618,t:1526918966746};\\\", \\\"{x:665,y:617,t:1526918967129};\\\", \\\"{x:683,y:620,t:1526918967146};\\\", \\\"{x:701,y:620,t:1526918967163};\\\", \\\"{x:719,y:622,t:1526918967179};\\\", \\\"{x:733,y:624,t:1526918967196};\\\", \\\"{x:747,y:625,t:1526918967212};\\\", \\\"{x:757,y:626,t:1526918967228};\\\", \\\"{x:765,y:626,t:1526918967245};\\\", \\\"{x:774,y:626,t:1526918967263};\\\", \\\"{x:783,y:625,t:1526918967279};\\\", \\\"{x:790,y:624,t:1526918967296};\\\", \\\"{x:791,y:623,t:1526918967312};\\\", \\\"{x:793,y:623,t:1526918967330};\\\", \\\"{x:794,y:622,t:1526918967347};\\\", \\\"{x:795,y:621,t:1526918967362};\\\", \\\"{x:795,y:620,t:1526918967383};\\\", \\\"{x:798,y:618,t:1526918967399};\\\", \\\"{x:798,y:617,t:1526918967415};\\\", \\\"{x:798,y:616,t:1526918967431};\\\", \\\"{x:798,y:615,t:1526918967456};\\\", \\\"{x:798,y:614,t:1526918967528};\\\", \\\"{x:797,y:613,t:1526918967584};\\\", \\\"{x:797,y:612,t:1526918967599};\\\", \\\"{x:796,y:611,t:1526918967613};\\\", \\\"{x:795,y:610,t:1526918967631};\\\", \\\"{x:794,y:609,t:1526918967646};\\\", \\\"{x:792,y:605,t:1526918967663};\\\", \\\"{x:792,y:602,t:1526918967680};\\\", \\\"{x:792,y:600,t:1526918967696};\\\", \\\"{x:792,y:599,t:1526918967713};\\\", \\\"{x:792,y:597,t:1526918967730};\\\", \\\"{x:797,y:593,t:1526918967745};\\\", \\\"{x:803,y:590,t:1526918967763};\\\", \\\"{x:810,y:586,t:1526918967780};\\\", \\\"{x:814,y:584,t:1526918967796};\\\", \\\"{x:815,y:583,t:1526918967813};\\\", \\\"{x:815,y:581,t:1526918967888};\\\", \\\"{x:815,y:577,t:1526918967897};\\\", \\\"{x:816,y:573,t:1526918967912};\\\", \\\"{x:817,y:571,t:1526918967930};\\\", \\\"{x:817,y:570,t:1526918967946};\\\", \\\"{x:817,y:569,t:1526918967999};\\\", \\\"{x:818,y:567,t:1526918968031};\\\", \\\"{x:818,y:566,t:1526918968047};\\\", \\\"{x:819,y:566,t:1526918968176};\\\", \\\"{x:816,y:566,t:1526918968408};\\\", \\\"{x:807,y:572,t:1526918968415};\\\", \\\"{x:793,y:581,t:1526918968432};\\\", \\\"{x:769,y:606,t:1526918968447};\\\", \\\"{x:759,y:617,t:1526918968463};\\\", \\\"{x:750,y:627,t:1526918968480};\\\", \\\"{x:741,y:641,t:1526918968497};\\\", \\\"{x:730,y:653,t:1526918968514};\\\", \\\"{x:714,y:669,t:1526918968530};\\\", \\\"{x:692,y:685,t:1526918968546};\\\", \\\"{x:676,y:696,t:1526918968564};\\\", \\\"{x:663,y:703,t:1526918968579};\\\", \\\"{x:657,y:705,t:1526918968597};\\\", \\\"{x:655,y:705,t:1526918968614};\\\", \\\"{x:653,y:705,t:1526918968629};\\\", \\\"{x:641,y:709,t:1526918968647};\\\", \\\"{x:626,y:713,t:1526918968664};\\\", \\\"{x:610,y:718,t:1526918968679};\\\", \\\"{x:598,y:724,t:1526918968696};\\\", \\\"{x:591,y:728,t:1526918968714};\\\", \\\"{x:584,y:736,t:1526918968730};\\\", \\\"{x:576,y:743,t:1526918968747};\\\", \\\"{x:570,y:752,t:1526918968764};\\\", \\\"{x:567,y:755,t:1526918968780};\\\", \\\"{x:566,y:752,t:1526918968881};\\\", \\\"{x:575,y:732,t:1526918968897};\\\", \\\"{x:593,y:710,t:1526918968915};\\\", \\\"{x:623,y:692,t:1526918968932};\\\", \\\"{x:652,y:682,t:1526918968948};\\\", \\\"{x:690,y:668,t:1526918968964};\\\", \\\"{x:727,y:656,t:1526918968982};\\\", \\\"{x:767,y:641,t:1526918968997};\\\", \\\"{x:792,y:626,t:1526918969014};\\\", \\\"{x:814,y:615,t:1526918969032};\\\", \\\"{x:815,y:615,t:1526918969047};\\\", \\\"{x:815,y:613,t:1526918969087};\\\", \\\"{x:815,y:611,t:1526918969096};\\\", \\\"{x:818,y:604,t:1526918969114};\\\", \\\"{x:819,y:600,t:1526918969131};\\\", \\\"{x:821,y:592,t:1526918969147};\\\", \\\"{x:825,y:580,t:1526918969164};\\\", \\\"{x:834,y:569,t:1526918969181};\\\", \\\"{x:839,y:560,t:1526918969197};\\\", \\\"{x:840,y:558,t:1526918969214};\\\", \\\"{x:840,y:557,t:1526918969231};\\\", \\\"{x:840,y:558,t:1526918970047};\\\", \\\"{x:840,y:561,t:1526918970065};\\\", \\\"{x:840,y:562,t:1526918970082};\\\", \\\"{x:840,y:563,t:1526918970098};\\\", \\\"{x:840,y:564,t:1526918970115};\\\", \\\"{x:840,y:565,t:1526918970176};\\\", \\\"{x:840,y:566,t:1526918970199};\\\", \\\"{x:840,y:567,t:1526918970231};\\\", \\\"{x:840,y:568,t:1526918970287};\\\", \\\"{x:840,y:570,t:1526918970304};\\\", \\\"{x:840,y:571,t:1526918970315};\\\", \\\"{x:840,y:572,t:1526918970335};\\\", \\\"{x:840,y:573,t:1526918970351};\\\", \\\"{x:840,y:574,t:1526918970365};\\\", \\\"{x:840,y:579,t:1526918970381};\\\", \\\"{x:840,y:586,t:1526918970398};\\\", \\\"{x:837,y:596,t:1526918970414};\\\", \\\"{x:832,y:603,t:1526918970431};\\\", \\\"{x:829,y:608,t:1526918970448};\\\", \\\"{x:821,y:617,t:1526918970465};\\\", \\\"{x:814,y:626,t:1526918970482};\\\", \\\"{x:796,y:640,t:1526918970497};\\\", \\\"{x:783,y:651,t:1526918970516};\\\", \\\"{x:767,y:662,t:1526918970532};\\\", \\\"{x:752,y:673,t:1526918970549};\\\", \\\"{x:741,y:684,t:1526918970564};\\\", \\\"{x:722,y:697,t:1526918970582};\\\", \\\"{x:700,y:718,t:1526918970599};\\\", \\\"{x:678,y:731,t:1526918970616};\\\", \\\"{x:657,y:741,t:1526918970632};\\\", \\\"{x:645,y:745,t:1526918970649};\\\", \\\"{x:634,y:748,t:1526918970666};\\\", \\\"{x:616,y:751,t:1526918970683};\\\", \\\"{x:593,y:757,t:1526918970699};\\\", \\\"{x:572,y:762,t:1526918970716};\\\", \\\"{x:554,y:764,t:1526918970733};\\\", \\\"{x:542,y:764,t:1526918970750};\\\", \\\"{x:537,y:764,t:1526918970764};\\\", \\\"{x:537,y:763,t:1526918971175};\\\", \\\"{x:537,y:762,t:1526918971664};\\\", \\\"{x:537,y:761,t:1526918971840};\\\" ] }, { \\\"rt\\\": 32197, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 245113, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\", \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ], [ null, \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-09 AM-09 AM-08 AM-10 AM-11 AM-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:758,t:1526918973015};\\\", \\\"{x:536,y:752,t:1526918973023};\\\", \\\"{x:536,y:749,t:1526918973036};\\\", \\\"{x:535,y:737,t:1526918973052};\\\", \\\"{x:532,y:717,t:1526918973067};\\\", \\\"{x:526,y:695,t:1526918973085};\\\", \\\"{x:521,y:672,t:1526918973101};\\\", \\\"{x:510,y:649,t:1526918973117};\\\", \\\"{x:503,y:632,t:1526918973133};\\\", \\\"{x:492,y:610,t:1526918973151};\\\", \\\"{x:487,y:599,t:1526918973167};\\\", \\\"{x:480,y:587,t:1526918973184};\\\", \\\"{x:473,y:575,t:1526918973202};\\\", \\\"{x:466,y:562,t:1526918973217};\\\", \\\"{x:458,y:554,t:1526918973234};\\\", \\\"{x:456,y:550,t:1526918973251};\\\", \\\"{x:454,y:547,t:1526918973267};\\\", \\\"{x:450,y:543,t:1526918973284};\\\", \\\"{x:448,y:540,t:1526918973301};\\\", \\\"{x:444,y:537,t:1526918973317};\\\", \\\"{x:440,y:531,t:1526918973334};\\\", \\\"{x:434,y:525,t:1526918973351};\\\", \\\"{x:431,y:523,t:1526918973367};\\\", \\\"{x:427,y:520,t:1526918973384};\\\", \\\"{x:423,y:517,t:1526918973401};\\\", \\\"{x:420,y:514,t:1526918973417};\\\", \\\"{x:413,y:508,t:1526918973434};\\\", \\\"{x:412,y:508,t:1526918973450};\\\", \\\"{x:412,y:507,t:1526918973468};\\\", \\\"{x:410,y:507,t:1526918973503};\\\", \\\"{x:416,y:507,t:1526918973952};\\\", \\\"{x:422,y:507,t:1526918973968};\\\", \\\"{x:427,y:506,t:1526918973985};\\\", \\\"{x:433,y:505,t:1526918974002};\\\", \\\"{x:439,y:505,t:1526918974019};\\\", \\\"{x:446,y:504,t:1526918974035};\\\", \\\"{x:450,y:503,t:1526918974052};\\\", \\\"{x:452,y:503,t:1526918974068};\\\", \\\"{x:455,y:503,t:1526918974086};\\\", \\\"{x:462,y:502,t:1526918974101};\\\", \\\"{x:468,y:502,t:1526918974118};\\\", \\\"{x:483,y:502,t:1526918974136};\\\", \\\"{x:492,y:502,t:1526918974152};\\\", \\\"{x:499,y:502,t:1526918974168};\\\", \\\"{x:504,y:502,t:1526918974185};\\\", \\\"{x:506,y:502,t:1526918974202};\\\", \\\"{x:508,y:502,t:1526918974218};\\\", \\\"{x:510,y:502,t:1526918974264};\\\", \\\"{x:511,y:502,t:1526918974271};\\\", \\\"{x:512,y:502,t:1526918974286};\\\", \\\"{x:515,y:502,t:1526918974301};\\\", \\\"{x:519,y:504,t:1526918974318};\\\", \\\"{x:523,y:504,t:1526918974335};\\\", \\\"{x:529,y:504,t:1526918974352};\\\", \\\"{x:534,y:505,t:1526918974369};\\\", \\\"{x:539,y:505,t:1526918974385};\\\", \\\"{x:541,y:505,t:1526918974403};\\\", \\\"{x:542,y:506,t:1526918974424};\\\", \\\"{x:544,y:507,t:1526918974527};\\\", \\\"{x:546,y:508,t:1526918974534};\\\", \\\"{x:552,y:511,t:1526918974552};\\\", \\\"{x:560,y:513,t:1526918974568};\\\", \\\"{x:570,y:517,t:1526918974585};\\\", \\\"{x:580,y:518,t:1526918974602};\\\", \\\"{x:592,y:522,t:1526918974618};\\\", \\\"{x:607,y:528,t:1526918974635};\\\", \\\"{x:625,y:535,t:1526918974652};\\\", \\\"{x:643,y:545,t:1526918974668};\\\", \\\"{x:669,y:560,t:1526918974686};\\\", \\\"{x:699,y:576,t:1526918974702};\\\", \\\"{x:731,y:595,t:1526918974718};\\\", \\\"{x:793,y:633,t:1526918974735};\\\", \\\"{x:836,y:665,t:1526918974753};\\\", \\\"{x:873,y:693,t:1526918974769};\\\", \\\"{x:911,y:725,t:1526918974785};\\\", \\\"{x:941,y:748,t:1526918974802};\\\", \\\"{x:954,y:763,t:1526918974819};\\\", \\\"{x:970,y:775,t:1526918974836};\\\", \\\"{x:976,y:782,t:1526918974852};\\\", \\\"{x:979,y:787,t:1526918974869};\\\", \\\"{x:980,y:787,t:1526918974894};\\\", \\\"{x:980,y:788,t:1526918974951};\\\", \\\"{x:979,y:789,t:1526918974975};\\\", \\\"{x:978,y:790,t:1526918975007};\\\", \\\"{x:977,y:790,t:1526918975020};\\\", \\\"{x:976,y:792,t:1526918975036};\\\", \\\"{x:974,y:794,t:1526918975053};\\\", \\\"{x:972,y:796,t:1526918975070};\\\", \\\"{x:971,y:798,t:1526918975086};\\\", \\\"{x:967,y:803,t:1526918975103};\\\", \\\"{x:966,y:808,t:1526918975120};\\\", \\\"{x:966,y:810,t:1526918975137};\\\", \\\"{x:965,y:817,t:1526918975153};\\\", \\\"{x:965,y:823,t:1526918975171};\\\", \\\"{x:967,y:833,t:1526918975187};\\\", \\\"{x:976,y:845,t:1526918975204};\\\", \\\"{x:986,y:854,t:1526918975221};\\\", \\\"{x:994,y:861,t:1526918975237};\\\", \\\"{x:1003,y:866,t:1526918975255};\\\", \\\"{x:1008,y:870,t:1526918975271};\\\", \\\"{x:1021,y:880,t:1526918975288};\\\", \\\"{x:1028,y:886,t:1526918975304};\\\", \\\"{x:1036,y:890,t:1526918975321};\\\", \\\"{x:1043,y:893,t:1526918975337};\\\", \\\"{x:1051,y:898,t:1526918975355};\\\", \\\"{x:1060,y:904,t:1526918975372};\\\", \\\"{x:1070,y:909,t:1526918975388};\\\", \\\"{x:1081,y:915,t:1526918975404};\\\", \\\"{x:1089,y:919,t:1526918975422};\\\", \\\"{x:1097,y:922,t:1526918975439};\\\", \\\"{x:1105,y:926,t:1526918975454};\\\", \\\"{x:1111,y:930,t:1526918975472};\\\", \\\"{x:1119,y:933,t:1526918975489};\\\", \\\"{x:1124,y:936,t:1526918975506};\\\", \\\"{x:1131,y:940,t:1526918975521};\\\", \\\"{x:1139,y:943,t:1526918975539};\\\", \\\"{x:1146,y:945,t:1526918975556};\\\", \\\"{x:1151,y:948,t:1526918975572};\\\", \\\"{x:1155,y:948,t:1526918975588};\\\", \\\"{x:1158,y:950,t:1526918975606};\\\", \\\"{x:1162,y:951,t:1526918975622};\\\", \\\"{x:1167,y:953,t:1526918975638};\\\", \\\"{x:1172,y:956,t:1526918975655};\\\", \\\"{x:1175,y:956,t:1526918975673};\\\", \\\"{x:1178,y:958,t:1526918975689};\\\", \\\"{x:1180,y:959,t:1526918975705};\\\", \\\"{x:1182,y:959,t:1526918975722};\\\", \\\"{x:1186,y:962,t:1526918975739};\\\", \\\"{x:1189,y:963,t:1526918975755};\\\", \\\"{x:1193,y:965,t:1526918975772};\\\", \\\"{x:1195,y:966,t:1526918975789};\\\", \\\"{x:1196,y:966,t:1526918975806};\\\", \\\"{x:1198,y:968,t:1526918975822};\\\", \\\"{x:1200,y:969,t:1526918975839};\\\", \\\"{x:1201,y:969,t:1526918975856};\\\", \\\"{x:1203,y:970,t:1526918975873};\\\", \\\"{x:1204,y:971,t:1526918975889};\\\", \\\"{x:1206,y:972,t:1526918975906};\\\", \\\"{x:1209,y:973,t:1526918975923};\\\", \\\"{x:1211,y:975,t:1526918975939};\\\", \\\"{x:1212,y:975,t:1526918975957};\\\", \\\"{x:1214,y:976,t:1526918975974};\\\", \\\"{x:1215,y:977,t:1526918975991};\\\", \\\"{x:1216,y:978,t:1526918976015};\\\", \\\"{x:1217,y:978,t:1526918976031};\\\", \\\"{x:1217,y:979,t:1526918976040};\\\", \\\"{x:1219,y:979,t:1526918976056};\\\", \\\"{x:1222,y:982,t:1526918976073};\\\", \\\"{x:1223,y:983,t:1526918976095};\\\", \\\"{x:1225,y:984,t:1526918976111};\\\", \\\"{x:1225,y:985,t:1526918976123};\\\", \\\"{x:1227,y:985,t:1526918976140};\\\", \\\"{x:1229,y:986,t:1526918976156};\\\", \\\"{x:1230,y:987,t:1526918976174};\\\", \\\"{x:1230,y:988,t:1526918976303};\\\", \\\"{x:1227,y:988,t:1526918976311};\\\", \\\"{x:1223,y:988,t:1526918976324};\\\", \\\"{x:1206,y:988,t:1526918976341};\\\", \\\"{x:1193,y:988,t:1526918976358};\\\", \\\"{x:1177,y:987,t:1526918976374};\\\", \\\"{x:1166,y:985,t:1526918976391};\\\", \\\"{x:1165,y:985,t:1526918976408};\\\", \\\"{x:1164,y:985,t:1526918976487};\\\", \\\"{x:1163,y:984,t:1526918976728};\\\", \\\"{x:1162,y:984,t:1526918976767};\\\", \\\"{x:1161,y:984,t:1526918976776};\\\", \\\"{x:1159,y:984,t:1526918976799};\\\", \\\"{x:1158,y:984,t:1526918976822};\\\", \\\"{x:1156,y:984,t:1526918976839};\\\", \\\"{x:1155,y:984,t:1526918977033};\\\", \\\"{x:1154,y:984,t:1526918977048};\\\", \\\"{x:1153,y:984,t:1526918977061};\\\", \\\"{x:1147,y:981,t:1526918977078};\\\", \\\"{x:1142,y:976,t:1526918977093};\\\", \\\"{x:1142,y:975,t:1526918979049};\\\", \\\"{x:1142,y:973,t:1526918979064};\\\", \\\"{x:1140,y:972,t:1526918979080};\\\", \\\"{x:1140,y:969,t:1526918979096};\\\", \\\"{x:1140,y:968,t:1526918979104};\\\", \\\"{x:1139,y:967,t:1526918979117};\\\", \\\"{x:1138,y:962,t:1526918979134};\\\", \\\"{x:1136,y:958,t:1526918979151};\\\", \\\"{x:1134,y:951,t:1526918979167};\\\", \\\"{x:1131,y:945,t:1526918979184};\\\", \\\"{x:1126,y:936,t:1526918979201};\\\", \\\"{x:1122,y:927,t:1526918979218};\\\", \\\"{x:1118,y:917,t:1526918979234};\\\", \\\"{x:1112,y:907,t:1526918979252};\\\", \\\"{x:1104,y:897,t:1526918979268};\\\", \\\"{x:1098,y:888,t:1526918979285};\\\", \\\"{x:1089,y:879,t:1526918979301};\\\", \\\"{x:1082,y:869,t:1526918979318};\\\", \\\"{x:1071,y:861,t:1526918979335};\\\", \\\"{x:1061,y:854,t:1526918979351};\\\", \\\"{x:1048,y:847,t:1526918979369};\\\", \\\"{x:1033,y:839,t:1526918979385};\\\", \\\"{x:1018,y:832,t:1526918979403};\\\", \\\"{x:1005,y:825,t:1526918979418};\\\", \\\"{x:993,y:817,t:1526918979435};\\\", \\\"{x:980,y:809,t:1526918979452};\\\", \\\"{x:965,y:801,t:1526918979468};\\\", \\\"{x:950,y:789,t:1526918979485};\\\", \\\"{x:935,y:780,t:1526918979502};\\\", \\\"{x:916,y:767,t:1526918979519};\\\", \\\"{x:905,y:761,t:1526918979535};\\\", \\\"{x:899,y:759,t:1526918979552};\\\", \\\"{x:897,y:758,t:1526918979569};\\\", \\\"{x:896,y:758,t:1526918979719};\\\", \\\"{x:892,y:756,t:1526918980854};\\\", \\\"{x:887,y:751,t:1526918980862};\\\", \\\"{x:883,y:748,t:1526918980873};\\\", \\\"{x:871,y:738,t:1526918980890};\\\", \\\"{x:861,y:728,t:1526918980907};\\\", \\\"{x:855,y:725,t:1526918980924};\\\", \\\"{x:849,y:722,t:1526918980941};\\\", \\\"{x:846,y:719,t:1526918980958};\\\", \\\"{x:840,y:715,t:1526918980974};\\\", \\\"{x:834,y:711,t:1526918980991};\\\", \\\"{x:821,y:703,t:1526918981007};\\\", \\\"{x:810,y:697,t:1526918981025};\\\", \\\"{x:799,y:691,t:1526918981041};\\\", \\\"{x:785,y:683,t:1526918981057};\\\", \\\"{x:755,y:668,t:1526918981074};\\\", \\\"{x:718,y:649,t:1526918981093};\\\", \\\"{x:680,y:626,t:1526918981109};\\\", \\\"{x:639,y:603,t:1526918981125};\\\", \\\"{x:609,y:584,t:1526918981136};\\\", \\\"{x:587,y:572,t:1526918981152};\\\", \\\"{x:576,y:565,t:1526918981174};\\\", \\\"{x:561,y:558,t:1526918981190};\\\", \\\"{x:546,y:552,t:1526918981207};\\\", \\\"{x:541,y:550,t:1526918981224};\\\", \\\"{x:540,y:550,t:1526918981240};\\\", \\\"{x:538,y:550,t:1526918981287};\\\", \\\"{x:537,y:550,t:1526918981303};\\\", \\\"{x:536,y:551,t:1526918981311};\\\", \\\"{x:534,y:551,t:1526918981324};\\\", \\\"{x:533,y:552,t:1526918981341};\\\", \\\"{x:532,y:553,t:1526918981358};\\\", \\\"{x:532,y:558,t:1526918981375};\\\", \\\"{x:534,y:568,t:1526918981391};\\\", \\\"{x:546,y:578,t:1526918981407};\\\", \\\"{x:563,y:588,t:1526918981424};\\\", \\\"{x:583,y:599,t:1526918981442};\\\", \\\"{x:594,y:602,t:1526918981457};\\\", \\\"{x:609,y:607,t:1526918981474};\\\", \\\"{x:615,y:608,t:1526918981491};\\\", \\\"{x:616,y:609,t:1526918981507};\\\", \\\"{x:617,y:609,t:1526918981720};\\\", \\\"{x:618,y:609,t:1526918981767};\\\", \\\"{x:618,y:608,t:1526918981782};\\\", \\\"{x:617,y:608,t:1526918981807};\\\", \\\"{x:617,y:614,t:1526918983999};\\\", \\\"{x:619,y:620,t:1526918984010};\\\", \\\"{x:631,y:639,t:1526918984027};\\\", \\\"{x:651,y:657,t:1526918984043};\\\", \\\"{x:670,y:672,t:1526918984060};\\\", \\\"{x:697,y:688,t:1526918984076};\\\", \\\"{x:721,y:699,t:1526918984093};\\\", \\\"{x:754,y:713,t:1526918984109};\\\", \\\"{x:797,y:737,t:1526918984127};\\\", \\\"{x:868,y:777,t:1526918984142};\\\", \\\"{x:917,y:799,t:1526918984159};\\\", \\\"{x:965,y:821,t:1526918984176};\\\", \\\"{x:1008,y:836,t:1526918984194};\\\", \\\"{x:1039,y:850,t:1526918984209};\\\", \\\"{x:1069,y:863,t:1526918984227};\\\", \\\"{x:1090,y:871,t:1526918984243};\\\", \\\"{x:1109,y:879,t:1526918984260};\\\", \\\"{x:1130,y:887,t:1526918984276};\\\", \\\"{x:1148,y:897,t:1526918984294};\\\", \\\"{x:1162,y:903,t:1526918984310};\\\", \\\"{x:1178,y:912,t:1526918984326};\\\", \\\"{x:1184,y:916,t:1526918984343};\\\", \\\"{x:1187,y:920,t:1526918984360};\\\", \\\"{x:1192,y:923,t:1526918984376};\\\", \\\"{x:1197,y:927,t:1526918984394};\\\", \\\"{x:1202,y:930,t:1526918984410};\\\", \\\"{x:1203,y:932,t:1526918984427};\\\", \\\"{x:1204,y:934,t:1526918984444};\\\", \\\"{x:1205,y:936,t:1526918984460};\\\", \\\"{x:1205,y:938,t:1526918984476};\\\", \\\"{x:1205,y:941,t:1526918984493};\\\", \\\"{x:1205,y:944,t:1526918984510};\\\", \\\"{x:1205,y:947,t:1526918984526};\\\", \\\"{x:1205,y:954,t:1526918984543};\\\", \\\"{x:1203,y:959,t:1526918984560};\\\", \\\"{x:1199,y:964,t:1526918984576};\\\", \\\"{x:1190,y:968,t:1526918984593};\\\", \\\"{x:1175,y:972,t:1526918984609};\\\", \\\"{x:1160,y:976,t:1526918984626};\\\", \\\"{x:1149,y:977,t:1526918984643};\\\", \\\"{x:1136,y:977,t:1526918984660};\\\", \\\"{x:1126,y:977,t:1526918984676};\\\", \\\"{x:1113,y:977,t:1526918984693};\\\", \\\"{x:1107,y:977,t:1526918984710};\\\", \\\"{x:1101,y:980,t:1526918984727};\\\", \\\"{x:1094,y:980,t:1526918984743};\\\", \\\"{x:1093,y:981,t:1526918984759};\\\", \\\"{x:1092,y:981,t:1526918984777};\\\", \\\"{x:1094,y:981,t:1526918984872};\\\", \\\"{x:1097,y:981,t:1526918984880};\\\", \\\"{x:1101,y:982,t:1526918984893};\\\", \\\"{x:1108,y:984,t:1526918984910};\\\", \\\"{x:1117,y:985,t:1526918984927};\\\", \\\"{x:1122,y:985,t:1526918984942};\\\", \\\"{x:1124,y:985,t:1526918984959};\\\", \\\"{x:1126,y:985,t:1526918984976};\\\", \\\"{x:1127,y:986,t:1526918984993};\\\", \\\"{x:1128,y:986,t:1526918985009};\\\", \\\"{x:1129,y:986,t:1526918985027};\\\", \\\"{x:1132,y:988,t:1526918985044};\\\", \\\"{x:1136,y:988,t:1526918985060};\\\", \\\"{x:1138,y:988,t:1526918985077};\\\", \\\"{x:1140,y:988,t:1526918985094};\\\", \\\"{x:1142,y:988,t:1526918985184};\\\", \\\"{x:1143,y:988,t:1526918985223};\\\", \\\"{x:1144,y:988,t:1526918985328};\\\", \\\"{x:1145,y:988,t:1526918985344};\\\", \\\"{x:1146,y:988,t:1526918985384};\\\", \\\"{x:1147,y:988,t:1526918985416};\\\", \\\"{x:1148,y:988,t:1526918985432};\\\", \\\"{x:1149,y:988,t:1526918985448};\\\", \\\"{x:1150,y:988,t:1526918985464};\\\", \\\"{x:1151,y:988,t:1526918985552};\\\", \\\"{x:1152,y:988,t:1526918985776};\\\", \\\"{x:1153,y:988,t:1526918985823};\\\", \\\"{x:1154,y:988,t:1526918985855};\\\", \\\"{x:1154,y:987,t:1526918985920};\\\", \\\"{x:1155,y:987,t:1526918985943};\\\", \\\"{x:1156,y:986,t:1526918985975};\\\", \\\"{x:1157,y:985,t:1526918986008};\\\", \\\"{x:1158,y:985,t:1526918986152};\\\", \\\"{x:1160,y:985,t:1526918986175};\\\", \\\"{x:1162,y:985,t:1526918986199};\\\", \\\"{x:1165,y:985,t:1526918986215};\\\", \\\"{x:1166,y:985,t:1526918986231};\\\", \\\"{x:1167,y:985,t:1526918986243};\\\", \\\"{x:1168,y:985,t:1526918986287};\\\", \\\"{x:1169,y:985,t:1526918986295};\\\", \\\"{x:1170,y:985,t:1526918986310};\\\", \\\"{x:1171,y:986,t:1526918986326};\\\", \\\"{x:1176,y:986,t:1526918986343};\\\", \\\"{x:1179,y:987,t:1526918986359};\\\", \\\"{x:1184,y:988,t:1526918986377};\\\", \\\"{x:1186,y:988,t:1526918986392};\\\", \\\"{x:1187,y:988,t:1526918986430};\\\", \\\"{x:1188,y:988,t:1526918986447};\\\", \\\"{x:1189,y:988,t:1526918986463};\\\", \\\"{x:1191,y:988,t:1526918986477};\\\", \\\"{x:1194,y:988,t:1526918986492};\\\", \\\"{x:1197,y:988,t:1526918986509};\\\", \\\"{x:1199,y:988,t:1526918986551};\\\", \\\"{x:1200,y:988,t:1526918986567};\\\", \\\"{x:1202,y:988,t:1526918986591};\\\", \\\"{x:1204,y:988,t:1526918986615};\\\", \\\"{x:1205,y:988,t:1526918986638};\\\", \\\"{x:1206,y:988,t:1526918986647};\\\", \\\"{x:1207,y:988,t:1526918986663};\\\", \\\"{x:1209,y:988,t:1526918986679};\\\", \\\"{x:1210,y:988,t:1526918986693};\\\", \\\"{x:1213,y:988,t:1526918986710};\\\", \\\"{x:1216,y:988,t:1526918986727};\\\", \\\"{x:1219,y:988,t:1526918986742};\\\", \\\"{x:1221,y:987,t:1526918986760};\\\", \\\"{x:1222,y:987,t:1526918986943};\\\", \\\"{x:1223,y:987,t:1526918986982};\\\", \\\"{x:1223,y:986,t:1526918986999};\\\", \\\"{x:1223,y:985,t:1526918987009};\\\", \\\"{x:1225,y:985,t:1526918987026};\\\", \\\"{x:1226,y:985,t:1526918987042};\\\", \\\"{x:1229,y:984,t:1526918987059};\\\", \\\"{x:1232,y:984,t:1526918987076};\\\", \\\"{x:1236,y:983,t:1526918987092};\\\", \\\"{x:1239,y:982,t:1526918987110};\\\", \\\"{x:1241,y:981,t:1526918987127};\\\", \\\"{x:1242,y:980,t:1526918987143};\\\", \\\"{x:1243,y:979,t:1526918987160};\\\", \\\"{x:1245,y:978,t:1526918987176};\\\", \\\"{x:1246,y:978,t:1526918987215};\\\", \\\"{x:1249,y:978,t:1526918987227};\\\", \\\"{x:1254,y:977,t:1526918987243};\\\", \\\"{x:1255,y:976,t:1526918987259};\\\", \\\"{x:1256,y:976,t:1526918987277};\\\", \\\"{x:1257,y:976,t:1526918987292};\\\", \\\"{x:1258,y:976,t:1526918987310};\\\", \\\"{x:1259,y:976,t:1526918987351};\\\", \\\"{x:1261,y:976,t:1526918987415};\\\", \\\"{x:1262,y:976,t:1526918987488};\\\", \\\"{x:1264,y:976,t:1526918987519};\\\", \\\"{x:1265,y:976,t:1526918987534};\\\", \\\"{x:1267,y:976,t:1526918987551};\\\", \\\"{x:1268,y:976,t:1526918987599};\\\", \\\"{x:1270,y:976,t:1526918987623};\\\", \\\"{x:1271,y:976,t:1526918987639};\\\", \\\"{x:1272,y:976,t:1526918987655};\\\", \\\"{x:1274,y:976,t:1526918987767};\\\", \\\"{x:1275,y:976,t:1526918987798};\\\", \\\"{x:1276,y:976,t:1526918987809};\\\", \\\"{x:1277,y:976,t:1526918987827};\\\", \\\"{x:1280,y:976,t:1526918987843};\\\", \\\"{x:1280,y:977,t:1526918987860};\\\", \\\"{x:1283,y:977,t:1526918987877};\\\", \\\"{x:1286,y:977,t:1526918987892};\\\", \\\"{x:1289,y:977,t:1526918987910};\\\", \\\"{x:1294,y:977,t:1526918987927};\\\", \\\"{x:1296,y:977,t:1526918987942};\\\", \\\"{x:1298,y:977,t:1526918987960};\\\", \\\"{x:1299,y:977,t:1526918987991};\\\", \\\"{x:1300,y:977,t:1526918988006};\\\", \\\"{x:1302,y:977,t:1526918988015};\\\", \\\"{x:1303,y:977,t:1526918988027};\\\", \\\"{x:1306,y:977,t:1526918988042};\\\", \\\"{x:1310,y:977,t:1526918988059};\\\", \\\"{x:1319,y:977,t:1526918988077};\\\", \\\"{x:1329,y:979,t:1526918988093};\\\", \\\"{x:1338,y:981,t:1526918988109};\\\", \\\"{x:1346,y:981,t:1526918988126};\\\", \\\"{x:1347,y:982,t:1526918988143};\\\", \\\"{x:1348,y:982,t:1526918988568};\\\", \\\"{x:1348,y:983,t:1526918990928};\\\", \\\"{x:1348,y:984,t:1526918990944};\\\", \\\"{x:1347,y:984,t:1526918990959};\\\", \\\"{x:1346,y:985,t:1526918990977};\\\", \\\"{x:1345,y:985,t:1526918990999};\\\", \\\"{x:1344,y:985,t:1526918991010};\\\", \\\"{x:1343,y:985,t:1526918991026};\\\", \\\"{x:1342,y:985,t:1526918991043};\\\", \\\"{x:1339,y:986,t:1526918991059};\\\", \\\"{x:1336,y:987,t:1526918991075};\\\", \\\"{x:1335,y:987,t:1526918991093};\\\", \\\"{x:1333,y:988,t:1526918991110};\\\", \\\"{x:1332,y:988,t:1526918991126};\\\", \\\"{x:1330,y:988,t:1526918991143};\\\", \\\"{x:1329,y:988,t:1526918991159};\\\", \\\"{x:1326,y:990,t:1526918991175};\\\", \\\"{x:1325,y:991,t:1526918991193};\\\", \\\"{x:1322,y:991,t:1526918991210};\\\", \\\"{x:1319,y:991,t:1526918991225};\\\", \\\"{x:1317,y:991,t:1526918991295};\\\", \\\"{x:1316,y:991,t:1526918991311};\\\", \\\"{x:1315,y:991,t:1526918991325};\\\", \\\"{x:1313,y:991,t:1526918991343};\\\", \\\"{x:1312,y:991,t:1526918991360};\\\", \\\"{x:1311,y:991,t:1526918991376};\\\", \\\"{x:1310,y:991,t:1526918991399};\\\", \\\"{x:1308,y:991,t:1526918991439};\\\", \\\"{x:1306,y:991,t:1526918991447};\\\", \\\"{x:1305,y:991,t:1526918991460};\\\", \\\"{x:1303,y:991,t:1526918991476};\\\", \\\"{x:1301,y:991,t:1526918991493};\\\", \\\"{x:1300,y:990,t:1526918991509};\\\", \\\"{x:1299,y:990,t:1526918991543};\\\", \\\"{x:1297,y:990,t:1526918991559};\\\", \\\"{x:1298,y:990,t:1526918991728};\\\", \\\"{x:1301,y:990,t:1526918991743};\\\", \\\"{x:1302,y:990,t:1526918991759};\\\", \\\"{x:1304,y:990,t:1526918991776};\\\", \\\"{x:1305,y:990,t:1526918991793};\\\", \\\"{x:1305,y:989,t:1526918991814};\\\", \\\"{x:1306,y:989,t:1526918991846};\\\", \\\"{x:1308,y:988,t:1526918991895};\\\", \\\"{x:1309,y:988,t:1526918991935};\\\", \\\"{x:1310,y:987,t:1526918991942};\\\", \\\"{x:1311,y:987,t:1526918991960};\\\", \\\"{x:1313,y:987,t:1526918991976};\\\", \\\"{x:1314,y:987,t:1526918991994};\\\", \\\"{x:1316,y:986,t:1526918992010};\\\", \\\"{x:1317,y:986,t:1526918992026};\\\", \\\"{x:1318,y:985,t:1526918992043};\\\", \\\"{x:1319,y:985,t:1526918992060};\\\", \\\"{x:1320,y:984,t:1526918992076};\\\", \\\"{x:1322,y:984,t:1526918992093};\\\", \\\"{x:1324,y:983,t:1526918992110};\\\", \\\"{x:1326,y:983,t:1526918992126};\\\", \\\"{x:1329,y:983,t:1526918992144};\\\", \\\"{x:1331,y:983,t:1526918992160};\\\", \\\"{x:1332,y:983,t:1526918992279};\\\", \\\"{x:1333,y:983,t:1526918992447};\\\", \\\"{x:1335,y:981,t:1526918992463};\\\", \\\"{x:1336,y:981,t:1526918992518};\\\", \\\"{x:1337,y:981,t:1526918992551};\\\", \\\"{x:1338,y:981,t:1526918992567};\\\", \\\"{x:1339,y:981,t:1526918992615};\\\", \\\"{x:1340,y:981,t:1526918992631};\\\", \\\"{x:1341,y:981,t:1526918992711};\\\", \\\"{x:1342,y:981,t:1526918992751};\\\", \\\"{x:1343,y:981,t:1526918992807};\\\", \\\"{x:1344,y:981,t:1526918992895};\\\", \\\"{x:1344,y:980,t:1526918992910};\\\", \\\"{x:1345,y:980,t:1526918996224};\\\", \\\"{x:1346,y:980,t:1526918996872};\\\", \\\"{x:1347,y:980,t:1526918996896};\\\", \\\"{x:1348,y:980,t:1526918996927};\\\", \\\"{x:1349,y:980,t:1526918996976};\\\", \\\"{x:1350,y:980,t:1526918996993};\\\", \\\"{x:1352,y:981,t:1526918997136};\\\", \\\"{x:1353,y:981,t:1526918997152};\\\", \\\"{x:1353,y:982,t:1526918997160};\\\", \\\"{x:1355,y:982,t:1526918997184};\\\", \\\"{x:1356,y:982,t:1526918997207};\\\", \\\"{x:1357,y:982,t:1526918997215};\\\", \\\"{x:1359,y:983,t:1526918997256};\\\", \\\"{x:1360,y:984,t:1526918997288};\\\", \\\"{x:1362,y:984,t:1526918997320};\\\", \\\"{x:1363,y:984,t:1526918997335};\\\", \\\"{x:1365,y:985,t:1526918997351};\\\", \\\"{x:1366,y:985,t:1526918997359};\\\", \\\"{x:1369,y:985,t:1526918997376};\\\", \\\"{x:1370,y:985,t:1526918997393};\\\", \\\"{x:1371,y:985,t:1526918997408};\\\", \\\"{x:1372,y:985,t:1526918997426};\\\", \\\"{x:1373,y:985,t:1526918997455};\\\", \\\"{x:1374,y:985,t:1526918997462};\\\", \\\"{x:1375,y:985,t:1526918997478};\\\", \\\"{x:1376,y:985,t:1526918997495};\\\", \\\"{x:1377,y:985,t:1526918997509};\\\", \\\"{x:1378,y:985,t:1526918997526};\\\", \\\"{x:1380,y:985,t:1526918997543};\\\", \\\"{x:1381,y:985,t:1526918997575};\\\", \\\"{x:1382,y:985,t:1526918997679};\\\", \\\"{x:1382,y:982,t:1526918997702};\\\", \\\"{x:1380,y:980,t:1526918997710};\\\", \\\"{x:1375,y:976,t:1526918997726};\\\", \\\"{x:1349,y:959,t:1526918997743};\\\", \\\"{x:1323,y:938,t:1526918997759};\\\", \\\"{x:1266,y:905,t:1526918997776};\\\", \\\"{x:1188,y:869,t:1526918997793};\\\", \\\"{x:1100,y:837,t:1526918997808};\\\", \\\"{x:1019,y:810,t:1526918997826};\\\", \\\"{x:941,y:784,t:1526918997842};\\\", \\\"{x:893,y:768,t:1526918997859};\\\", \\\"{x:871,y:764,t:1526918997875};\\\", \\\"{x:855,y:759,t:1526918997893};\\\", \\\"{x:843,y:754,t:1526918997909};\\\", \\\"{x:830,y:748,t:1526918997926};\\\", \\\"{x:809,y:737,t:1526918997942};\\\", \\\"{x:788,y:732,t:1526918997959};\\\", \\\"{x:764,y:725,t:1526918997976};\\\", \\\"{x:739,y:718,t:1526918997993};\\\", \\\"{x:712,y:710,t:1526918998009};\\\", \\\"{x:694,y:702,t:1526918998026};\\\", \\\"{x:678,y:696,t:1526918998044};\\\", \\\"{x:670,y:691,t:1526918998058};\\\", \\\"{x:663,y:689,t:1526918998075};\\\", \\\"{x:659,y:686,t:1526918998087};\\\", \\\"{x:652,y:683,t:1526918998104};\\\", \\\"{x:645,y:679,t:1526918998120};\\\", \\\"{x:639,y:676,t:1526918998137};\\\", \\\"{x:638,y:676,t:1526918998207};\\\", \\\"{x:638,y:675,t:1526918998223};\\\", \\\"{x:642,y:671,t:1526918998239};\\\", \\\"{x:672,y:654,t:1526918998255};\\\", \\\"{x:700,y:645,t:1526918998272};\\\", \\\"{x:746,y:636,t:1526918998289};\\\", \\\"{x:796,y:630,t:1526918998306};\\\", \\\"{x:841,y:630,t:1526918998322};\\\", \\\"{x:889,y:630,t:1526918998338};\\\", \\\"{x:936,y:630,t:1526918998355};\\\", \\\"{x:963,y:630,t:1526918998372};\\\", \\\"{x:982,y:630,t:1526918998389};\\\", \\\"{x:984,y:630,t:1526918998404};\\\", \\\"{x:985,y:629,t:1526918998431};\\\", \\\"{x:982,y:626,t:1526918998504};\\\", \\\"{x:978,y:625,t:1526918998512};\\\", \\\"{x:970,y:625,t:1526918998522};\\\", \\\"{x:954,y:621,t:1526918998540};\\\", \\\"{x:936,y:620,t:1526918998557};\\\", \\\"{x:917,y:620,t:1526918998571};\\\", \\\"{x:897,y:620,t:1526918998589};\\\", \\\"{x:885,y:620,t:1526918998605};\\\", \\\"{x:879,y:620,t:1526918998622};\\\", \\\"{x:878,y:620,t:1526918998639};\\\", \\\"{x:876,y:620,t:1526918998656};\\\", \\\"{x:875,y:620,t:1526918998672};\\\", \\\"{x:874,y:620,t:1526918998735};\\\", \\\"{x:872,y:620,t:1526918998743};\\\", \\\"{x:869,y:620,t:1526918998759};\\\", \\\"{x:866,y:620,t:1526918998775};\\\", \\\"{x:864,y:620,t:1526918998800};\\\", \\\"{x:861,y:620,t:1526918998815};\\\", \\\"{x:854,y:619,t:1526918998832};\\\", \\\"{x:850,y:618,t:1526918998851};\\\", \\\"{x:846,y:617,t:1526918998866};\\\", \\\"{x:844,y:617,t:1526918998882};\\\", \\\"{x:843,y:617,t:1526918998898};\\\", \\\"{x:841,y:617,t:1526918998915};\\\", \\\"{x:841,y:616,t:1526918999032};\\\", \\\"{x:836,y:616,t:1526919000288};\\\", \\\"{x:825,y:619,t:1526919000300};\\\", \\\"{x:801,y:625,t:1526919000316};\\\", \\\"{x:788,y:628,t:1526919000332};\\\", \\\"{x:784,y:630,t:1526919000349};\\\", \\\"{x:784,y:631,t:1526919000365};\\\", \\\"{x:782,y:634,t:1526919000383};\\\", \\\"{x:779,y:638,t:1526919000399};\\\", \\\"{x:771,y:649,t:1526919000415};\\\", \\\"{x:768,y:654,t:1526919000432};\\\", \\\"{x:764,y:658,t:1526919000449};\\\", \\\"{x:756,y:665,t:1526919000467};\\\", \\\"{x:749,y:677,t:1526919000482};\\\", \\\"{x:730,y:694,t:1526919000499};\\\", \\\"{x:709,y:714,t:1526919000517};\\\", \\\"{x:689,y:731,t:1526919000532};\\\", \\\"{x:676,y:742,t:1526919000550};\\\", \\\"{x:673,y:746,t:1526919000566};\\\", \\\"{x:672,y:748,t:1526919000584};\\\", \\\"{x:672,y:750,t:1526919000600};\\\", \\\"{x:670,y:752,t:1526919000616};\\\", \\\"{x:665,y:755,t:1526919000633};\\\", \\\"{x:663,y:755,t:1526919000650};\\\", \\\"{x:661,y:755,t:1526919000667};\\\", \\\"{x:652,y:747,t:1526919000682};\\\", \\\"{x:642,y:726,t:1526919000700};\\\", \\\"{x:626,y:699,t:1526919000718};\\\", \\\"{x:605,y:664,t:1526919000733};\\\", \\\"{x:589,y:638,t:1526919000749};\\\", \\\"{x:583,y:621,t:1526919000767};\\\", \\\"{x:582,y:613,t:1526919000782};\\\", \\\"{x:580,y:607,t:1526919000800};\\\", \\\"{x:582,y:601,t:1526919000815};\\\", \\\"{x:584,y:598,t:1526919000832};\\\", \\\"{x:585,y:596,t:1526919000849};\\\", \\\"{x:585,y:594,t:1526919000867};\\\", \\\"{x:587,y:593,t:1526919000884};\\\", \\\"{x:588,y:592,t:1526919000899};\\\", \\\"{x:591,y:591,t:1526919000916};\\\", \\\"{x:594,y:590,t:1526919000934};\\\", \\\"{x:597,y:590,t:1526919000949};\\\", \\\"{x:605,y:592,t:1526919000967};\\\", \\\"{x:614,y:596,t:1526919000984};\\\", \\\"{x:619,y:599,t:1526919000999};\\\", \\\"{x:622,y:601,t:1526919001017};\\\", \\\"{x:623,y:602,t:1526919001048};\\\", \\\"{x:623,y:603,t:1526919001056};\\\", \\\"{x:624,y:604,t:1526919001072};\\\", \\\"{x:624,y:605,t:1526919001083};\\\", \\\"{x:624,y:606,t:1526919001100};\\\", \\\"{x:624,y:607,t:1526919001117};\\\", \\\"{x:624,y:609,t:1526919001134};\\\", \\\"{x:624,y:610,t:1526919001150};\\\", \\\"{x:621,y:616,t:1526919001167};\\\", \\\"{x:616,y:627,t:1526919001184};\\\", \\\"{x:606,y:640,t:1526919001200};\\\", \\\"{x:594,y:661,t:1526919001217};\\\", \\\"{x:590,y:671,t:1526919001233};\\\", \\\"{x:585,y:685,t:1526919001249};\\\", \\\"{x:579,y:706,t:1526919001266};\\\", \\\"{x:575,y:727,t:1526919001283};\\\", \\\"{x:574,y:744,t:1526919001300};\\\", \\\"{x:571,y:757,t:1526919001316};\\\", \\\"{x:569,y:766,t:1526919001333};\\\", \\\"{x:568,y:770,t:1526919001351};\\\", \\\"{x:568,y:771,t:1526919001368};\\\", \\\"{x:567,y:771,t:1526919001424};\\\", \\\"{x:564,y:771,t:1526919001514};\\\", \\\"{x:559,y:771,t:1526919001534};\\\", \\\"{x:551,y:771,t:1526919001549};\\\", \\\"{x:539,y:771,t:1526919001566};\\\", \\\"{x:529,y:771,t:1526919001583};\\\", \\\"{x:524,y:771,t:1526919001599};\\\", \\\"{x:523,y:771,t:1526919001616};\\\", \\\"{x:522,y:770,t:1526919001769};\\\", \\\"{x:522,y:769,t:1526919001783};\\\", \\\"{x:522,y:766,t:1526919001799};\\\", \\\"{x:522,y:760,t:1526919001816};\\\", \\\"{x:523,y:756,t:1526919001833};\\\", \\\"{x:525,y:749,t:1526919001850};\\\", \\\"{x:527,y:745,t:1526919001866};\\\", \\\"{x:530,y:737,t:1526919001883};\\\", \\\"{x:534,y:731,t:1526919001900};\\\", \\\"{x:541,y:723,t:1526919001917};\\\", \\\"{x:550,y:713,t:1526919001933};\\\", \\\"{x:554,y:709,t:1526919001951};\\\", \\\"{x:557,y:705,t:1526919001967};\\\", \\\"{x:563,y:700,t:1526919001983};\\\", \\\"{x:565,y:698,t:1526919002000};\\\", \\\"{x:567,y:696,t:1526919002017};\\\", \\\"{x:569,y:695,t:1526919002033};\\\", \\\"{x:570,y:694,t:1526919002050};\\\", \\\"{x:570,y:693,t:1526919002067};\\\", \\\"{x:571,y:693,t:1526919002176};\\\", \\\"{x:574,y:693,t:1526919002184};\\\", \\\"{x:580,y:704,t:1526919002201};\\\", \\\"{x:585,y:711,t:1526919002217};\\\", \\\"{x:590,y:721,t:1526919002234};\\\", \\\"{x:592,y:726,t:1526919002250};\\\", \\\"{x:595,y:730,t:1526919002268};\\\", \\\"{x:597,y:733,t:1526919002284};\\\", \\\"{x:600,y:735,t:1526919002300};\\\", \\\"{x:600,y:737,t:1526919002317};\\\", \\\"{x:601,y:738,t:1526919002335};\\\", \\\"{x:602,y:739,t:1526919002350};\\\", \\\"{x:603,y:740,t:1526919002368};\\\", \\\"{x:602,y:740,t:1526919002568};\\\", \\\"{x:593,y:741,t:1526919002584};\\\", \\\"{x:587,y:741,t:1526919002602};\\\", \\\"{x:582,y:742,t:1526919002617};\\\", \\\"{x:578,y:742,t:1526919002634};\\\", \\\"{x:575,y:744,t:1526919002652};\\\", \\\"{x:573,y:744,t:1526919002668};\\\", \\\"{x:572,y:744,t:1526919002685};\\\", \\\"{x:570,y:744,t:1526919002720};\\\", \\\"{x:569,y:744,t:1526919002768};\\\", \\\"{x:567,y:744,t:1526919002801};\\\", \\\"{x:566,y:744,t:1526919002817};\\\", \\\"{x:565,y:745,t:1526919002833};\\\", \\\"{x:564,y:745,t:1526919002841};\\\", \\\"{x:563,y:745,t:1526919002897};\\\", \\\"{x:562,y:742,t:1526919002913};\\\", \\\"{x:562,y:738,t:1526919002921};\\\", \\\"{x:560,y:733,t:1526919002935};\\\", \\\"{x:559,y:721,t:1526919002951};\\\", \\\"{x:560,y:696,t:1526919002969};\\\", \\\"{x:566,y:685,t:1526919002984};\\\", \\\"{x:572,y:678,t:1526919003001};\\\", \\\"{x:580,y:672,t:1526919003018};\\\", \\\"{x:586,y:668,t:1526919003035};\\\", \\\"{x:588,y:667,t:1526919003051};\\\", \\\"{x:591,y:665,t:1526919003068};\\\", \\\"{x:592,y:664,t:1526919003088};\\\", \\\"{x:593,y:664,t:1526919003101};\\\", \\\"{x:593,y:663,t:1526919003127};\\\", \\\"{x:597,y:663,t:1526919003159};\\\", \\\"{x:598,y:665,t:1526919003167};\\\", \\\"{x:602,y:669,t:1526919003184};\\\", \\\"{x:606,y:680,t:1526919003202};\\\", \\\"{x:608,y:695,t:1526919003218};\\\", \\\"{x:613,y:710,t:1526919003235};\\\", \\\"{x:613,y:722,t:1526919003251};\\\", \\\"{x:613,y:728,t:1526919003268};\\\", \\\"{x:613,y:736,t:1526919003284};\\\", \\\"{x:613,y:739,t:1526919003301};\\\", \\\"{x:611,y:745,t:1526919003318};\\\", \\\"{x:610,y:750,t:1526919003334};\\\", \\\"{x:607,y:759,t:1526919003351};\\\", \\\"{x:606,y:760,t:1526919003368};\\\", \\\"{x:604,y:762,t:1526919003385};\\\", \\\"{x:602,y:763,t:1526919003401};\\\", \\\"{x:600,y:763,t:1526919003418};\\\", \\\"{x:596,y:766,t:1526919003435};\\\", \\\"{x:588,y:766,t:1526919003451};\\\", \\\"{x:579,y:766,t:1526919003468};\\\", \\\"{x:572,y:766,t:1526919003485};\\\", \\\"{x:563,y:766,t:1526919003502};\\\", \\\"{x:554,y:766,t:1526919003518};\\\", \\\"{x:548,y:766,t:1526919003535};\\\" ] }, { \\\"rt\\\": 104804, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 351194, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 19, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"E\\\", \\\"F\\\", \\\"B\\\", \\\"M\\\", \\\"A\\\", \\\"G\\\", \\\"C\\\", \\\"K\\\", \\\"P\\\", \\\"L\\\", \\\"N\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -X -M -10 AM-10 AM-01 PM-05 PM-10 AM-10 AM-12 PM-01 PM-02 PM-02 PM-03 PM-04 PM-05 PM-06 PM-05 PM-04 PM-03 PM-01 PM-06 PM-07 PM-07 PM-03 PM-02 PM-01 PM-12 PM-F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:766,t:1526919006400};\\\", \\\"{x:547,y:761,t:1526919006482};\\\", \\\"{x:547,y:760,t:1526919006489};\\\", \\\"{x:547,y:759,t:1526919006505};\\\", \\\"{x:547,y:757,t:1526919006521};\\\", \\\"{x:547,y:756,t:1526919006537};\\\", \\\"{x:547,y:754,t:1526919006554};\\\", \\\"{x:547,y:751,t:1526919006571};\\\", \\\"{x:547,y:748,t:1526919006587};\\\", \\\"{x:547,y:747,t:1526919006605};\\\", \\\"{x:547,y:743,t:1526919006620};\\\", \\\"{x:547,y:740,t:1526919006637};\\\", \\\"{x:547,y:737,t:1526919006654};\\\", \\\"{x:547,y:733,t:1526919006671};\\\", \\\"{x:547,y:723,t:1526919006687};\\\", \\\"{x:547,y:717,t:1526919006705};\\\", \\\"{x:547,y:713,t:1526919006721};\\\", \\\"{x:547,y:710,t:1526919006737};\\\", \\\"{x:547,y:706,t:1526919006755};\\\", \\\"{x:547,y:700,t:1526919006772};\\\", \\\"{x:547,y:693,t:1526919006788};\\\", \\\"{x:547,y:688,t:1526919006804};\\\", \\\"{x:547,y:679,t:1526919006822};\\\", \\\"{x:547,y:673,t:1526919006838};\\\", \\\"{x:544,y:666,t:1526919006854};\\\", \\\"{x:538,y:653,t:1526919006871};\\\", \\\"{x:532,y:643,t:1526919006888};\\\", \\\"{x:525,y:633,t:1526919006905};\\\", \\\"{x:519,y:625,t:1526919006922};\\\", \\\"{x:511,y:617,t:1526919006937};\\\", \\\"{x:501,y:609,t:1526919006954};\\\", \\\"{x:490,y:600,t:1526919006972};\\\", \\\"{x:469,y:587,t:1526919006989};\\\", \\\"{x:442,y:570,t:1526919007004};\\\", \\\"{x:417,y:555,t:1526919007022};\\\", \\\"{x:403,y:547,t:1526919007038};\\\", \\\"{x:398,y:544,t:1526919007054};\\\", \\\"{x:402,y:544,t:1526919007208};\\\", \\\"{x:414,y:544,t:1526919007221};\\\", \\\"{x:455,y:544,t:1526919007239};\\\", \\\"{x:567,y:544,t:1526919007256};\\\", \\\"{x:649,y:550,t:1526919007272};\\\", \\\"{x:735,y:563,t:1526919007289};\\\", \\\"{x:816,y:576,t:1526919007305};\\\", \\\"{x:889,y:585,t:1526919007321};\\\", \\\"{x:957,y:601,t:1526919007339};\\\", \\\"{x:1006,y:612,t:1526919007354};\\\", \\\"{x:1076,y:633,t:1526919007371};\\\", \\\"{x:1130,y:653,t:1526919007388};\\\", \\\"{x:1174,y:673,t:1526919007404};\\\", \\\"{x:1214,y:692,t:1526919007422};\\\", \\\"{x:1240,y:708,t:1526919007438};\\\", \\\"{x:1269,y:726,t:1526919007456};\\\", \\\"{x:1282,y:736,t:1526919007472};\\\", \\\"{x:1288,y:743,t:1526919007488};\\\", \\\"{x:1292,y:747,t:1526919007506};\\\", \\\"{x:1295,y:752,t:1526919007521};\\\", \\\"{x:1301,y:757,t:1526919007538};\\\", \\\"{x:1304,y:762,t:1526919007556};\\\", \\\"{x:1308,y:766,t:1526919007571};\\\", \\\"{x:1313,y:770,t:1526919007589};\\\", \\\"{x:1319,y:773,t:1526919007605};\\\", \\\"{x:1324,y:778,t:1526919007622};\\\", \\\"{x:1331,y:782,t:1526919007639};\\\", \\\"{x:1340,y:788,t:1526919007655};\\\", \\\"{x:1345,y:791,t:1526919007672};\\\", \\\"{x:1350,y:793,t:1526919007689};\\\", \\\"{x:1357,y:796,t:1526919007706};\\\", \\\"{x:1364,y:798,t:1526919007723};\\\", \\\"{x:1372,y:802,t:1526919007738};\\\", \\\"{x:1380,y:804,t:1526919007755};\\\", \\\"{x:1385,y:807,t:1526919007773};\\\", \\\"{x:1393,y:808,t:1526919007788};\\\", \\\"{x:1397,y:811,t:1526919007805};\\\", \\\"{x:1403,y:814,t:1526919007823};\\\", \\\"{x:1409,y:817,t:1526919007839};\\\", \\\"{x:1414,y:819,t:1526919007856};\\\", \\\"{x:1417,y:821,t:1526919007873};\\\", \\\"{x:1421,y:825,t:1526919007889};\\\", \\\"{x:1427,y:829,t:1526919007906};\\\", \\\"{x:1433,y:833,t:1526919007923};\\\", \\\"{x:1435,y:834,t:1526919007939};\\\", \\\"{x:1437,y:834,t:1526919007956};\\\", \\\"{x:1437,y:836,t:1526919008089};\\\", \\\"{x:1430,y:836,t:1526919008107};\\\", \\\"{x:1420,y:836,t:1526919008123};\\\", \\\"{x:1413,y:836,t:1526919008140};\\\", \\\"{x:1404,y:836,t:1526919008156};\\\", \\\"{x:1395,y:834,t:1526919008173};\\\", \\\"{x:1387,y:831,t:1526919008190};\\\", \\\"{x:1381,y:827,t:1526919008208};\\\", \\\"{x:1371,y:827,t:1526919008224};\\\", \\\"{x:1370,y:827,t:1526919008240};\\\", \\\"{x:1369,y:827,t:1526919008265};\\\", \\\"{x:1368,y:827,t:1526919008305};\\\", \\\"{x:1367,y:827,t:1526919008345};\\\", \\\"{x:1367,y:826,t:1526919008465};\\\", \\\"{x:1366,y:826,t:1526919008480};\\\", \\\"{x:1366,y:825,t:1526919008505};\\\", \\\"{x:1366,y:824,t:1526919008545};\\\", \\\"{x:1365,y:823,t:1526919008569};\\\", \\\"{x:1364,y:823,t:1526919008601};\\\", \\\"{x:1364,y:822,t:1526919008616};\\\", \\\"{x:1364,y:821,t:1526919009058};\\\", \\\"{x:1364,y:820,t:1526919009075};\\\", \\\"{x:1363,y:819,t:1526919009092};\\\", \\\"{x:1361,y:819,t:1526919009107};\\\", \\\"{x:1360,y:817,t:1526919009124};\\\", \\\"{x:1358,y:814,t:1526919009142};\\\", \\\"{x:1355,y:811,t:1526919009159};\\\", \\\"{x:1351,y:808,t:1526919009175};\\\", \\\"{x:1349,y:807,t:1526919009192};\\\", \\\"{x:1349,y:806,t:1526919009208};\\\", \\\"{x:1348,y:806,t:1526919009321};\\\", \\\"{x:1347,y:806,t:1526919009329};\\\", \\\"{x:1346,y:807,t:1526919009342};\\\", \\\"{x:1344,y:810,t:1526919009359};\\\", \\\"{x:1343,y:815,t:1526919009376};\\\", \\\"{x:1342,y:818,t:1526919009392};\\\", \\\"{x:1341,y:822,t:1526919009408};\\\", \\\"{x:1341,y:826,t:1526919009426};\\\", \\\"{x:1340,y:831,t:1526919009442};\\\", \\\"{x:1340,y:837,t:1526919009459};\\\", \\\"{x:1340,y:841,t:1526919009476};\\\", \\\"{x:1339,y:846,t:1526919009492};\\\", \\\"{x:1338,y:851,t:1526919009510};\\\", \\\"{x:1338,y:856,t:1526919009527};\\\", \\\"{x:1338,y:863,t:1526919009542};\\\", \\\"{x:1336,y:869,t:1526919009559};\\\", \\\"{x:1334,y:875,t:1526919009576};\\\", \\\"{x:1332,y:880,t:1526919009592};\\\", \\\"{x:1330,y:883,t:1526919009609};\\\", \\\"{x:1329,y:885,t:1526919009626};\\\", \\\"{x:1325,y:886,t:1526919009644};\\\", \\\"{x:1322,y:886,t:1526919009659};\\\", \\\"{x:1316,y:887,t:1526919009676};\\\", \\\"{x:1302,y:887,t:1526919009693};\\\", \\\"{x:1279,y:880,t:1526919009709};\\\", \\\"{x:1253,y:873,t:1526919009726};\\\", \\\"{x:1232,y:864,t:1526919009743};\\\", \\\"{x:1216,y:854,t:1526919009760};\\\", \\\"{x:1215,y:854,t:1526919009777};\\\", \\\"{x:1214,y:850,t:1526919009793};\\\", \\\"{x:1214,y:848,t:1526919009817};\\\", \\\"{x:1214,y:847,t:1526919009826};\\\", \\\"{x:1214,y:845,t:1526919009843};\\\", \\\"{x:1214,y:844,t:1526919009861};\\\", \\\"{x:1214,y:843,t:1526919009876};\\\", \\\"{x:1214,y:842,t:1526919009893};\\\", \\\"{x:1213,y:840,t:1526919009910};\\\", \\\"{x:1213,y:839,t:1526919009928};\\\", \\\"{x:1213,y:838,t:1526919009942};\\\", \\\"{x:1215,y:836,t:1526919009959};\\\", \\\"{x:1215,y:835,t:1526919009977};\\\", \\\"{x:1216,y:834,t:1526919010528};\\\", \\\"{x:1218,y:838,t:1526919010545};\\\", \\\"{x:1222,y:849,t:1526919010561};\\\", \\\"{x:1224,y:858,t:1526919010578};\\\", \\\"{x:1224,y:862,t:1526919010591};\\\", \\\"{x:1225,y:873,t:1526919010607};\\\", \\\"{x:1225,y:875,t:1526919010624};\\\", \\\"{x:1225,y:876,t:1526919010641};\\\", \\\"{x:1225,y:877,t:1526919010658};\\\", \\\"{x:1225,y:879,t:1526919010675};\\\", \\\"{x:1225,y:881,t:1526919010691};\\\", \\\"{x:1224,y:883,t:1526919010707};\\\", \\\"{x:1224,y:884,t:1526919010725};\\\", \\\"{x:1224,y:886,t:1526919010741};\\\", \\\"{x:1223,y:887,t:1526919010757};\\\", \\\"{x:1221,y:888,t:1526919010896};\\\", \\\"{x:1219,y:888,t:1526919010912};\\\", \\\"{x:1218,y:888,t:1526919010925};\\\", \\\"{x:1217,y:888,t:1526919010928};\\\", \\\"{x:1214,y:885,t:1526919010942};\\\", \\\"{x:1210,y:878,t:1526919010958};\\\", \\\"{x:1208,y:869,t:1526919010975};\\\", \\\"{x:1202,y:852,t:1526919010992};\\\", \\\"{x:1199,y:843,t:1526919011008};\\\", \\\"{x:1196,y:835,t:1526919011025};\\\", \\\"{x:1195,y:829,t:1526919011042};\\\", \\\"{x:1195,y:827,t:1526919011058};\\\", \\\"{x:1195,y:826,t:1526919011075};\\\", \\\"{x:1195,y:824,t:1526919011092};\\\", \\\"{x:1195,y:822,t:1526919011108};\\\", \\\"{x:1195,y:820,t:1526919011125};\\\", \\\"{x:1196,y:819,t:1526919011142};\\\", \\\"{x:1196,y:818,t:1526919011159};\\\", \\\"{x:1198,y:818,t:1526919011400};\\\", \\\"{x:1199,y:818,t:1526919011408};\\\", \\\"{x:1202,y:820,t:1526919011425};\\\", \\\"{x:1203,y:824,t:1526919011441};\\\", \\\"{x:1206,y:828,t:1526919011459};\\\", \\\"{x:1209,y:831,t:1526919011475};\\\", \\\"{x:1210,y:833,t:1526919011492};\\\", \\\"{x:1213,y:835,t:1526919011508};\\\", \\\"{x:1214,y:836,t:1526919011525};\\\", \\\"{x:1217,y:837,t:1526919011541};\\\", \\\"{x:1223,y:837,t:1526919011558};\\\", \\\"{x:1228,y:837,t:1526919011575};\\\", \\\"{x:1238,y:837,t:1526919011591};\\\", \\\"{x:1242,y:837,t:1526919011609};\\\", \\\"{x:1250,y:837,t:1526919011625};\\\", \\\"{x:1256,y:837,t:1526919011642};\\\", \\\"{x:1259,y:837,t:1526919011658};\\\", \\\"{x:1263,y:837,t:1526919011675};\\\", \\\"{x:1269,y:837,t:1526919011692};\\\", \\\"{x:1275,y:838,t:1526919011709};\\\", \\\"{x:1281,y:840,t:1526919011724};\\\", \\\"{x:1285,y:841,t:1526919011742};\\\", \\\"{x:1289,y:841,t:1526919011758};\\\", \\\"{x:1294,y:844,t:1526919011774};\\\", \\\"{x:1302,y:848,t:1526919011791};\\\", \\\"{x:1309,y:853,t:1526919011808};\\\", \\\"{x:1314,y:856,t:1526919011826};\\\", \\\"{x:1322,y:860,t:1526919011842};\\\", \\\"{x:1333,y:868,t:1526919011858};\\\", \\\"{x:1343,y:875,t:1526919011875};\\\", \\\"{x:1353,y:883,t:1526919011891};\\\", \\\"{x:1363,y:891,t:1526919011909};\\\", \\\"{x:1371,y:896,t:1526919011926};\\\", \\\"{x:1379,y:902,t:1526919011941};\\\", \\\"{x:1383,y:906,t:1526919011959};\\\", \\\"{x:1392,y:911,t:1526919011975};\\\", \\\"{x:1395,y:913,t:1526919011992};\\\", \\\"{x:1400,y:916,t:1526919012008};\\\", \\\"{x:1403,y:918,t:1526919012025};\\\", \\\"{x:1406,y:920,t:1526919012042};\\\", \\\"{x:1407,y:921,t:1526919012072};\\\", \\\"{x:1408,y:922,t:1526919012136};\\\", \\\"{x:1408,y:921,t:1526919012857};\\\", \\\"{x:1408,y:920,t:1526919014081};\\\", \\\"{x:1408,y:919,t:1526919014295};\\\", \\\"{x:1408,y:918,t:1526919014311};\\\", \\\"{x:1408,y:917,t:1526919014327};\\\", \\\"{x:1408,y:916,t:1526919014343};\\\", \\\"{x:1408,y:915,t:1526919014361};\\\", \\\"{x:1408,y:914,t:1526919014377};\\\", \\\"{x:1408,y:910,t:1526919014394};\\\", \\\"{x:1408,y:906,t:1526919014411};\\\", \\\"{x:1410,y:899,t:1526919014428};\\\", \\\"{x:1414,y:892,t:1526919014444};\\\", \\\"{x:1416,y:886,t:1526919014461};\\\", \\\"{x:1418,y:876,t:1526919014477};\\\", \\\"{x:1419,y:871,t:1526919014494};\\\", \\\"{x:1422,y:863,t:1526919014511};\\\", \\\"{x:1426,y:851,t:1526919014527};\\\", \\\"{x:1429,y:848,t:1526919014544};\\\", \\\"{x:1431,y:846,t:1526919014561};\\\", \\\"{x:1432,y:844,t:1526919014584};\\\", \\\"{x:1433,y:844,t:1526919014594};\\\", \\\"{x:1446,y:843,t:1526919014635};\\\", \\\"{x:1449,y:843,t:1526919014644};\\\", \\\"{x:1452,y:843,t:1526919014661};\\\", \\\"{x:1456,y:844,t:1526919014678};\\\", \\\"{x:1457,y:844,t:1526919014694};\\\", \\\"{x:1460,y:845,t:1526919014711};\\\", \\\"{x:1465,y:845,t:1526919014727};\\\", \\\"{x:1469,y:845,t:1526919014744};\\\", \\\"{x:1470,y:845,t:1526919014760};\\\", \\\"{x:1471,y:845,t:1526919014778};\\\", \\\"{x:1473,y:845,t:1526919014794};\\\", \\\"{x:1476,y:845,t:1526919014811};\\\", \\\"{x:1479,y:845,t:1526919014828};\\\", \\\"{x:1482,y:845,t:1526919014845};\\\", \\\"{x:1483,y:844,t:1526919014861};\\\", \\\"{x:1484,y:844,t:1526919014878};\\\", \\\"{x:1485,y:844,t:1526919014894};\\\", \\\"{x:1487,y:843,t:1526919014911};\\\", \\\"{x:1488,y:842,t:1526919014927};\\\", \\\"{x:1488,y:840,t:1526919014945};\\\", \\\"{x:1490,y:838,t:1526919014961};\\\", \\\"{x:1490,y:836,t:1526919014984};\\\", \\\"{x:1490,y:835,t:1526919015008};\\\", \\\"{x:1490,y:834,t:1526919015039};\\\", \\\"{x:1490,y:833,t:1526919015063};\\\", \\\"{x:1490,y:832,t:1526919015080};\\\", \\\"{x:1490,y:831,t:1526919015112};\\\", \\\"{x:1490,y:830,t:1526919015128};\\\", \\\"{x:1490,y:829,t:1526919015152};\\\", \\\"{x:1489,y:829,t:1526919015264};\\\", \\\"{x:1488,y:829,t:1526919015319};\\\", \\\"{x:1487,y:829,t:1526919015328};\\\", \\\"{x:1486,y:829,t:1526919015352};\\\", \\\"{x:1483,y:829,t:1526919015378};\\\", \\\"{x:1482,y:829,t:1526919015399};\\\", \\\"{x:1481,y:829,t:1526919015412};\\\", \\\"{x:1480,y:829,t:1526919015439};\\\", \\\"{x:1479,y:829,t:1526919015512};\\\", \\\"{x:1478,y:829,t:1526919015551};\\\", \\\"{x:1477,y:829,t:1526919016265};\\\", \\\"{x:1471,y:832,t:1526919016280};\\\", \\\"{x:1463,y:839,t:1526919016296};\\\", \\\"{x:1456,y:843,t:1526919016312};\\\", \\\"{x:1447,y:848,t:1526919016329};\\\", \\\"{x:1444,y:850,t:1526919016346};\\\", \\\"{x:1439,y:853,t:1526919016362};\\\", \\\"{x:1432,y:859,t:1526919016379};\\\", \\\"{x:1425,y:864,t:1526919016396};\\\", \\\"{x:1417,y:868,t:1526919016412};\\\", \\\"{x:1411,y:872,t:1526919016430};\\\", \\\"{x:1405,y:874,t:1526919016446};\\\", \\\"{x:1401,y:875,t:1526919016462};\\\", \\\"{x:1393,y:879,t:1526919016479};\\\", \\\"{x:1380,y:883,t:1526919016496};\\\", \\\"{x:1371,y:883,t:1526919016513};\\\", \\\"{x:1363,y:883,t:1526919016529};\\\", \\\"{x:1356,y:883,t:1526919016547};\\\", \\\"{x:1353,y:883,t:1526919016563};\\\", \\\"{x:1349,y:883,t:1526919016579};\\\", \\\"{x:1345,y:883,t:1526919016596};\\\", \\\"{x:1340,y:883,t:1526919016613};\\\", \\\"{x:1332,y:882,t:1526919016629};\\\", \\\"{x:1325,y:881,t:1526919016646};\\\", \\\"{x:1314,y:877,t:1526919016663};\\\", \\\"{x:1310,y:875,t:1526919016680};\\\", \\\"{x:1304,y:873,t:1526919016696};\\\", \\\"{x:1303,y:873,t:1526919016713};\\\", \\\"{x:1302,y:872,t:1526919016730};\\\", \\\"{x:1301,y:871,t:1526919016747};\\\", \\\"{x:1300,y:870,t:1526919016764};\\\", \\\"{x:1298,y:870,t:1526919016780};\\\", \\\"{x:1297,y:868,t:1526919016796};\\\", \\\"{x:1296,y:867,t:1526919016904};\\\", \\\"{x:1296,y:866,t:1526919017201};\\\", \\\"{x:1295,y:865,t:1526919017213};\\\", \\\"{x:1294,y:864,t:1526919017240};\\\", \\\"{x:1293,y:863,t:1526919017248};\\\", \\\"{x:1293,y:862,t:1526919017263};\\\", \\\"{x:1289,y:861,t:1526919017279};\\\", \\\"{x:1276,y:858,t:1526919017296};\\\", \\\"{x:1267,y:855,t:1526919017312};\\\", \\\"{x:1252,y:844,t:1526919017330};\\\", \\\"{x:1247,y:840,t:1526919017346};\\\", \\\"{x:1246,y:839,t:1526919017363};\\\", \\\"{x:1245,y:838,t:1526919017379};\\\", \\\"{x:1244,y:837,t:1526919017396};\\\", \\\"{x:1243,y:837,t:1526919017415};\\\", \\\"{x:1242,y:836,t:1526919017430};\\\", \\\"{x:1241,y:836,t:1526919017456};\\\", \\\"{x:1240,y:836,t:1526919017472};\\\", \\\"{x:1239,y:836,t:1526919017583};\\\", \\\"{x:1238,y:835,t:1526919017599};\\\", \\\"{x:1236,y:835,t:1526919017613};\\\", \\\"{x:1233,y:834,t:1526919017629};\\\", \\\"{x:1227,y:831,t:1526919017647};\\\", \\\"{x:1216,y:823,t:1526919017663};\\\", \\\"{x:1206,y:807,t:1526919017680};\\\", \\\"{x:1203,y:799,t:1526919017697};\\\", \\\"{x:1198,y:793,t:1526919017713};\\\", \\\"{x:1197,y:789,t:1526919017730};\\\", \\\"{x:1196,y:784,t:1526919017747};\\\", \\\"{x:1194,y:779,t:1526919017763};\\\", \\\"{x:1193,y:776,t:1526919017779};\\\", \\\"{x:1192,y:772,t:1526919017797};\\\", \\\"{x:1191,y:769,t:1526919017813};\\\", \\\"{x:1190,y:764,t:1526919017830};\\\", \\\"{x:1190,y:760,t:1526919017847};\\\", \\\"{x:1189,y:758,t:1526919017863};\\\", \\\"{x:1188,y:757,t:1526919017880};\\\", \\\"{x:1188,y:755,t:1526919017904};\\\", \\\"{x:1188,y:754,t:1526919017920};\\\", \\\"{x:1188,y:753,t:1526919017952};\\\", \\\"{x:1190,y:753,t:1526919023352};\\\", \\\"{x:1193,y:755,t:1526919023368};\\\", \\\"{x:1195,y:759,t:1526919023384};\\\", \\\"{x:1196,y:761,t:1526919023402};\\\", \\\"{x:1198,y:766,t:1526919023419};\\\", \\\"{x:1203,y:775,t:1526919023434};\\\", \\\"{x:1210,y:786,t:1526919023452};\\\", \\\"{x:1216,y:796,t:1526919023469};\\\", \\\"{x:1221,y:804,t:1526919023485};\\\", \\\"{x:1225,y:809,t:1526919023501};\\\", \\\"{x:1228,y:813,t:1526919023519};\\\", \\\"{x:1232,y:819,t:1526919023535};\\\", \\\"{x:1239,y:829,t:1526919023552};\\\", \\\"{x:1242,y:836,t:1526919023568};\\\", \\\"{x:1248,y:844,t:1526919023585};\\\", \\\"{x:1253,y:853,t:1526919023602};\\\", \\\"{x:1261,y:861,t:1526919023619};\\\", \\\"{x:1268,y:873,t:1526919023634};\\\", \\\"{x:1275,y:886,t:1526919023652};\\\", \\\"{x:1280,y:895,t:1526919023668};\\\", \\\"{x:1285,y:904,t:1526919023685};\\\", \\\"{x:1288,y:909,t:1526919023701};\\\", \\\"{x:1292,y:917,t:1526919023719};\\\", \\\"{x:1298,y:931,t:1526919023735};\\\", \\\"{x:1303,y:942,t:1526919023751};\\\", \\\"{x:1308,y:951,t:1526919023768};\\\", \\\"{x:1311,y:959,t:1526919023785};\\\", \\\"{x:1312,y:962,t:1526919023802};\\\", \\\"{x:1314,y:967,t:1526919023818};\\\", \\\"{x:1314,y:969,t:1526919023847};\\\", \\\"{x:1314,y:970,t:1526919023855};\\\", \\\"{x:1314,y:971,t:1526919023895};\\\", \\\"{x:1313,y:973,t:1526919023903};\\\", \\\"{x:1311,y:975,t:1526919023991};\\\", \\\"{x:1311,y:976,t:1526919024001};\\\", \\\"{x:1311,y:974,t:1526919024136};\\\", \\\"{x:1311,y:971,t:1526919024151};\\\", \\\"{x:1311,y:969,t:1526919024169};\\\", \\\"{x:1311,y:966,t:1526919024185};\\\", \\\"{x:1311,y:964,t:1526919024203};\\\", \\\"{x:1311,y:963,t:1526919024218};\\\", \\\"{x:1311,y:960,t:1526919024235};\\\", \\\"{x:1311,y:959,t:1526919024252};\\\", \\\"{x:1309,y:956,t:1526919024268};\\\", \\\"{x:1308,y:956,t:1526919024285};\\\", \\\"{x:1307,y:955,t:1526919024302};\\\", \\\"{x:1306,y:955,t:1526919024318};\\\", \\\"{x:1299,y:955,t:1526919024335};\\\", \\\"{x:1290,y:957,t:1526919024352};\\\", \\\"{x:1275,y:962,t:1526919024368};\\\", \\\"{x:1261,y:967,t:1526919024385};\\\", \\\"{x:1247,y:973,t:1526919024402};\\\", \\\"{x:1234,y:977,t:1526919024418};\\\", \\\"{x:1225,y:979,t:1526919024435};\\\", \\\"{x:1222,y:982,t:1526919024452};\\\", \\\"{x:1221,y:983,t:1526919024468};\\\", \\\"{x:1219,y:985,t:1526919024485};\\\", \\\"{x:1217,y:987,t:1526919024502};\\\", \\\"{x:1216,y:990,t:1526919024519};\\\", \\\"{x:1214,y:992,t:1526919024535};\\\", \\\"{x:1213,y:994,t:1526919024552};\\\", \\\"{x:1212,y:995,t:1526919024569};\\\", \\\"{x:1210,y:996,t:1526919024585};\\\", \\\"{x:1205,y:996,t:1526919024602};\\\", \\\"{x:1199,y:996,t:1526919024619};\\\", \\\"{x:1191,y:996,t:1526919024635};\\\", \\\"{x:1182,y:996,t:1526919024653};\\\", \\\"{x:1178,y:994,t:1526919024670};\\\", \\\"{x:1174,y:994,t:1526919024686};\\\", \\\"{x:1172,y:994,t:1526919024702};\\\", \\\"{x:1171,y:993,t:1526919024719};\\\", \\\"{x:1170,y:992,t:1526919024743};\\\", \\\"{x:1170,y:991,t:1526919024783};\\\", \\\"{x:1170,y:989,t:1526919024816};\\\", \\\"{x:1170,y:988,t:1526919024823};\\\", \\\"{x:1171,y:988,t:1526919024835};\\\", \\\"{x:1171,y:987,t:1526919024853};\\\", \\\"{x:1172,y:987,t:1526919024871};\\\", \\\"{x:1174,y:987,t:1526919024919};\\\", \\\"{x:1175,y:986,t:1526919025072};\\\", \\\"{x:1175,y:985,t:1526919025095};\\\", \\\"{x:1175,y:984,t:1526919025128};\\\", \\\"{x:1176,y:984,t:1526919025136};\\\", \\\"{x:1177,y:983,t:1526919025153};\\\", \\\"{x:1177,y:982,t:1526919025170};\\\", \\\"{x:1178,y:979,t:1526919025186};\\\", \\\"{x:1178,y:977,t:1526919025202};\\\", \\\"{x:1178,y:973,t:1526919025220};\\\", \\\"{x:1178,y:972,t:1526919025237};\\\", \\\"{x:1179,y:972,t:1526919025253};\\\", \\\"{x:1180,y:969,t:1526919025270};\\\", \\\"{x:1180,y:968,t:1526919025287};\\\", \\\"{x:1181,y:968,t:1526919025321};\\\", \\\"{x:1183,y:968,t:1526919025353};\\\", \\\"{x:1188,y:971,t:1526919025370};\\\", \\\"{x:1193,y:974,t:1526919025387};\\\", \\\"{x:1196,y:977,t:1526919025404};\\\", \\\"{x:1200,y:980,t:1526919025420};\\\", \\\"{x:1203,y:982,t:1526919025437};\\\", \\\"{x:1205,y:982,t:1526919025454};\\\", \\\"{x:1207,y:984,t:1526919025470};\\\", \\\"{x:1209,y:986,t:1526919025487};\\\", \\\"{x:1212,y:988,t:1526919025504};\\\", \\\"{x:1216,y:991,t:1526919025521};\\\", \\\"{x:1218,y:992,t:1526919025537};\\\", \\\"{x:1226,y:995,t:1526919025554};\\\", \\\"{x:1234,y:997,t:1526919025569};\\\", \\\"{x:1240,y:997,t:1526919025587};\\\", \\\"{x:1250,y:999,t:1526919025604};\\\", \\\"{x:1259,y:1001,t:1526919025620};\\\", \\\"{x:1266,y:1002,t:1526919025636};\\\", \\\"{x:1275,y:1004,t:1526919025658};\\\", \\\"{x:1278,y:1004,t:1526919025671};\\\", \\\"{x:1281,y:1005,t:1526919025686};\\\", \\\"{x:1287,y:1006,t:1526919025703};\\\", \\\"{x:1292,y:1007,t:1526919025719};\\\", \\\"{x:1295,y:1007,t:1526919025737};\\\", \\\"{x:1298,y:1007,t:1526919025753};\\\", \\\"{x:1303,y:1007,t:1526919025770};\\\", \\\"{x:1305,y:1007,t:1526919025787};\\\", \\\"{x:1307,y:1006,t:1526919025992};\\\", \\\"{x:1307,y:1005,t:1526919026004};\\\", \\\"{x:1307,y:1004,t:1526919026021};\\\", \\\"{x:1308,y:1003,t:1526919026037};\\\", \\\"{x:1309,y:1002,t:1526919026056};\\\", \\\"{x:1310,y:1001,t:1526919026088};\\\", \\\"{x:1310,y:1000,t:1526919026104};\\\", \\\"{x:1312,y:999,t:1526919026121};\\\", \\\"{x:1313,y:998,t:1526919026144};\\\", \\\"{x:1314,y:998,t:1526919026168};\\\", \\\"{x:1315,y:998,t:1526919026176};\\\", \\\"{x:1316,y:998,t:1526919026192};\\\", \\\"{x:1317,y:998,t:1526919026204};\\\", \\\"{x:1320,y:998,t:1526919026221};\\\", \\\"{x:1323,y:997,t:1526919026237};\\\", \\\"{x:1325,y:997,t:1526919026254};\\\", \\\"{x:1328,y:995,t:1526919026271};\\\", \\\"{x:1335,y:995,t:1526919026289};\\\", \\\"{x:1344,y:995,t:1526919026304};\\\", \\\"{x:1351,y:995,t:1526919026321};\\\", \\\"{x:1359,y:994,t:1526919026337};\\\", \\\"{x:1367,y:993,t:1526919026354};\\\", \\\"{x:1376,y:991,t:1526919026371};\\\", \\\"{x:1382,y:990,t:1526919026388};\\\", \\\"{x:1389,y:986,t:1526919026404};\\\", \\\"{x:1396,y:982,t:1526919026421};\\\", \\\"{x:1402,y:978,t:1526919026438};\\\", \\\"{x:1409,y:976,t:1526919026455};\\\", \\\"{x:1415,y:973,t:1526919026470};\\\", \\\"{x:1425,y:969,t:1526919026488};\\\", \\\"{x:1431,y:969,t:1526919026504};\\\", \\\"{x:1436,y:966,t:1526919026522};\\\", \\\"{x:1439,y:965,t:1526919026538};\\\", \\\"{x:1445,y:965,t:1526919026554};\\\", \\\"{x:1448,y:964,t:1526919026571};\\\", \\\"{x:1454,y:962,t:1526919026588};\\\", \\\"{x:1457,y:962,t:1526919026604};\\\", \\\"{x:1464,y:961,t:1526919026621};\\\", \\\"{x:1470,y:961,t:1526919026637};\\\", \\\"{x:1477,y:960,t:1526919026655};\\\", \\\"{x:1484,y:958,t:1526919026671};\\\", \\\"{x:1493,y:956,t:1526919026688};\\\", \\\"{x:1497,y:954,t:1526919026704};\\\", \\\"{x:1498,y:954,t:1526919026720};\\\", \\\"{x:1498,y:953,t:1526919026744};\\\", \\\"{x:1499,y:953,t:1526919026755};\\\", \\\"{x:1500,y:951,t:1526919026771};\\\", \\\"{x:1502,y:947,t:1526919026788};\\\", \\\"{x:1505,y:943,t:1526919026805};\\\", \\\"{x:1505,y:940,t:1526919026820};\\\", \\\"{x:1507,y:935,t:1526919026838};\\\", \\\"{x:1507,y:932,t:1526919026854};\\\", \\\"{x:1507,y:929,t:1526919026870};\\\", \\\"{x:1507,y:923,t:1526919026887};\\\", \\\"{x:1507,y:921,t:1526919026904};\\\", \\\"{x:1507,y:916,t:1526919026920};\\\", \\\"{x:1507,y:915,t:1526919026937};\\\", \\\"{x:1507,y:912,t:1526919026954};\\\", \\\"{x:1507,y:910,t:1526919026970};\\\", \\\"{x:1507,y:908,t:1526919026988};\\\", \\\"{x:1507,y:906,t:1526919027004};\\\", \\\"{x:1507,y:903,t:1526919027020};\\\", \\\"{x:1507,y:902,t:1526919027037};\\\", \\\"{x:1506,y:900,t:1526919027055};\\\", \\\"{x:1505,y:899,t:1526919027071};\\\", \\\"{x:1505,y:898,t:1526919027095};\\\", \\\"{x:1505,y:897,t:1526919027104};\\\", \\\"{x:1505,y:896,t:1526919027143};\\\", \\\"{x:1505,y:894,t:1526919027159};\\\", \\\"{x:1505,y:893,t:1526919027183};\\\", \\\"{x:1505,y:891,t:1526919027215};\\\", \\\"{x:1505,y:890,t:1526919027247};\\\", \\\"{x:1505,y:889,t:1526919027255};\\\", \\\"{x:1505,y:888,t:1526919027271};\\\", \\\"{x:1506,y:885,t:1526919027288};\\\", \\\"{x:1506,y:883,t:1526919027304};\\\", \\\"{x:1506,y:881,t:1526919027322};\\\", \\\"{x:1507,y:878,t:1526919027338};\\\", \\\"{x:1508,y:875,t:1526919027355};\\\", \\\"{x:1510,y:872,t:1526919027372};\\\", \\\"{x:1514,y:867,t:1526919027387};\\\", \\\"{x:1518,y:863,t:1526919027405};\\\", \\\"{x:1521,y:861,t:1526919027421};\\\", \\\"{x:1525,y:859,t:1526919027438};\\\", \\\"{x:1527,y:858,t:1526919027455};\\\", \\\"{x:1530,y:857,t:1526919027472};\\\", \\\"{x:1532,y:857,t:1526919027487};\\\", \\\"{x:1534,y:856,t:1526919027504};\\\", \\\"{x:1537,y:856,t:1526919027521};\\\", \\\"{x:1542,y:856,t:1526919027538};\\\", \\\"{x:1549,y:856,t:1526919027555};\\\", \\\"{x:1562,y:858,t:1526919027572};\\\", \\\"{x:1575,y:863,t:1526919027588};\\\", \\\"{x:1587,y:865,t:1526919027604};\\\", \\\"{x:1598,y:868,t:1526919027621};\\\", \\\"{x:1608,y:869,t:1526919027638};\\\", \\\"{x:1617,y:872,t:1526919027654};\\\", \\\"{x:1629,y:876,t:1526919027671};\\\", \\\"{x:1639,y:883,t:1526919027688};\\\", \\\"{x:1654,y:893,t:1526919027705};\\\", \\\"{x:1670,y:906,t:1526919027722};\\\", \\\"{x:1681,y:920,t:1526919027738};\\\", \\\"{x:1691,y:931,t:1526919027754};\\\", \\\"{x:1695,y:939,t:1526919027771};\\\", \\\"{x:1697,y:943,t:1526919027788};\\\", \\\"{x:1697,y:948,t:1526919027805};\\\", \\\"{x:1697,y:954,t:1526919027822};\\\", \\\"{x:1687,y:968,t:1526919027838};\\\", \\\"{x:1673,y:984,t:1526919027854};\\\", \\\"{x:1630,y:1003,t:1526919027872};\\\", \\\"{x:1566,y:1018,t:1526919027888};\\\", \\\"{x:1501,y:1023,t:1526919027904};\\\", \\\"{x:1420,y:1023,t:1526919027922};\\\", \\\"{x:1367,y:1023,t:1526919027939};\\\", \\\"{x:1328,y:1023,t:1526919027954};\\\", \\\"{x:1305,y:1024,t:1526919027971};\\\", \\\"{x:1289,y:1026,t:1526919027988};\\\", \\\"{x:1280,y:1029,t:1526919028005};\\\", \\\"{x:1271,y:1034,t:1526919028021};\\\", \\\"{x:1264,y:1036,t:1526919028038};\\\", \\\"{x:1259,y:1037,t:1526919028055};\\\", \\\"{x:1252,y:1037,t:1526919028071};\\\", \\\"{x:1241,y:1034,t:1526919028088};\\\", \\\"{x:1231,y:1029,t:1526919028106};\\\", \\\"{x:1226,y:1025,t:1526919028121};\\\", \\\"{x:1219,y:1019,t:1526919028139};\\\", \\\"{x:1215,y:1010,t:1526919028155};\\\", \\\"{x:1212,y:1002,t:1526919028172};\\\", \\\"{x:1210,y:996,t:1526919028188};\\\", \\\"{x:1210,y:993,t:1526919028206};\\\", \\\"{x:1210,y:991,t:1526919028223};\\\", \\\"{x:1210,y:990,t:1526919028304};\\\", \\\"{x:1211,y:990,t:1526919028319};\\\", \\\"{x:1211,y:991,t:1526919028360};\\\", \\\"{x:1212,y:992,t:1526919028375};\\\", \\\"{x:1212,y:993,t:1526919028455};\\\", \\\"{x:1210,y:993,t:1526919028472};\\\", \\\"{x:1208,y:991,t:1526919028489};\\\", \\\"{x:1206,y:989,t:1526919028505};\\\", \\\"{x:1204,y:988,t:1526919028522};\\\", \\\"{x:1202,y:987,t:1526919028538};\\\", \\\"{x:1200,y:986,t:1526919028555};\\\", \\\"{x:1198,y:985,t:1526919028572};\\\", \\\"{x:1196,y:983,t:1526919028589};\\\", \\\"{x:1192,y:981,t:1526919028606};\\\", \\\"{x:1188,y:980,t:1526919028623};\\\", \\\"{x:1186,y:978,t:1526919028638};\\\", \\\"{x:1183,y:976,t:1526919028655};\\\", \\\"{x:1180,y:973,t:1526919028673};\\\", \\\"{x:1179,y:973,t:1526919028689};\\\", \\\"{x:1177,y:972,t:1526919028706};\\\", \\\"{x:1177,y:971,t:1526919028735};\\\", \\\"{x:1177,y:970,t:1526919028751};\\\", \\\"{x:1178,y:970,t:1526919028944};\\\", \\\"{x:1179,y:970,t:1526919029023};\\\", \\\"{x:1180,y:970,t:1526919029392};\\\", \\\"{x:1182,y:970,t:1526919029405};\\\", \\\"{x:1185,y:970,t:1526919029423};\\\", \\\"{x:1190,y:970,t:1526919029439};\\\", \\\"{x:1193,y:971,t:1526919029456};\\\", \\\"{x:1195,y:971,t:1526919029569};\\\", \\\"{x:1197,y:972,t:1526919029608};\\\", \\\"{x:1198,y:972,t:1526919029632};\\\", \\\"{x:1200,y:973,t:1526919029640};\\\", \\\"{x:1202,y:973,t:1526919029664};\\\", \\\"{x:1204,y:973,t:1526919029688};\\\", \\\"{x:1205,y:973,t:1526919029704};\\\", \\\"{x:1206,y:973,t:1526919029712};\\\", \\\"{x:1207,y:973,t:1526919029728};\\\", \\\"{x:1209,y:973,t:1526919029740};\\\", \\\"{x:1210,y:973,t:1526919029776};\\\", \\\"{x:1211,y:973,t:1526919029904};\\\", \\\"{x:1213,y:973,t:1526919029976};\\\", \\\"{x:1216,y:973,t:1526919029992};\\\", \\\"{x:1217,y:973,t:1526919030007};\\\", \\\"{x:1222,y:972,t:1526919030024};\\\", \\\"{x:1223,y:972,t:1526919030040};\\\", \\\"{x:1225,y:971,t:1526919030057};\\\", \\\"{x:1226,y:970,t:1526919030074};\\\", \\\"{x:1227,y:970,t:1526919030090};\\\", \\\"{x:1229,y:970,t:1526919030107};\\\", \\\"{x:1230,y:970,t:1526919030128};\\\", \\\"{x:1231,y:970,t:1526919030140};\\\", \\\"{x:1232,y:970,t:1526919030156};\\\", \\\"{x:1233,y:969,t:1526919030174};\\\", \\\"{x:1234,y:969,t:1526919030189};\\\", \\\"{x:1238,y:969,t:1526919030206};\\\", \\\"{x:1241,y:968,t:1526919030223};\\\", \\\"{x:1245,y:967,t:1526919030240};\\\", \\\"{x:1248,y:967,t:1526919030256};\\\", \\\"{x:1249,y:966,t:1526919030273};\\\", \\\"{x:1251,y:966,t:1526919030291};\\\", \\\"{x:1252,y:966,t:1526919030306};\\\", \\\"{x:1255,y:966,t:1526919030323};\\\", \\\"{x:1257,y:966,t:1526919030341};\\\", \\\"{x:1258,y:966,t:1526919030357};\\\", \\\"{x:1260,y:965,t:1526919030374};\\\", \\\"{x:1261,y:965,t:1526919030391};\\\", \\\"{x:1262,y:964,t:1526919030407};\\\", \\\"{x:1265,y:963,t:1526919030424};\\\", \\\"{x:1267,y:963,t:1526919030440};\\\", \\\"{x:1268,y:963,t:1526919030456};\\\", \\\"{x:1269,y:963,t:1526919030474};\\\", \\\"{x:1270,y:963,t:1526919030496};\\\", \\\"{x:1271,y:963,t:1526919030507};\\\", \\\"{x:1277,y:963,t:1526919030524};\\\", \\\"{x:1281,y:963,t:1526919030541};\\\", \\\"{x:1286,y:963,t:1526919030558};\\\", \\\"{x:1288,y:963,t:1526919030574};\\\", \\\"{x:1289,y:963,t:1526919030591};\\\", \\\"{x:1290,y:963,t:1526919030831};\\\", \\\"{x:1291,y:963,t:1526919030840};\\\", \\\"{x:1293,y:963,t:1526919030887};\\\", \\\"{x:1295,y:964,t:1526919030903};\\\", \\\"{x:1296,y:964,t:1526919030919};\\\", \\\"{x:1297,y:964,t:1526919030928};\\\", \\\"{x:1298,y:964,t:1526919030941};\\\", \\\"{x:1301,y:965,t:1526919030957};\\\", \\\"{x:1306,y:967,t:1526919030973};\\\", \\\"{x:1316,y:969,t:1526919030991};\\\", \\\"{x:1331,y:973,t:1526919031008};\\\", \\\"{x:1338,y:975,t:1526919031024};\\\", \\\"{x:1340,y:976,t:1526919031041};\\\", \\\"{x:1341,y:976,t:1526919031057};\\\", \\\"{x:1343,y:976,t:1526919031393};\\\", \\\"{x:1348,y:976,t:1526919031408};\\\", \\\"{x:1355,y:977,t:1526919031425};\\\", \\\"{x:1359,y:977,t:1526919031441};\\\", \\\"{x:1367,y:977,t:1526919031458};\\\", \\\"{x:1369,y:978,t:1526919031475};\\\", \\\"{x:1370,y:978,t:1526919031491};\\\", \\\"{x:1371,y:979,t:1526919031507};\\\", \\\"{x:1373,y:979,t:1526919031591};\\\", \\\"{x:1376,y:979,t:1526919031607};\\\", \\\"{x:1377,y:979,t:1526919031625};\\\", \\\"{x:1383,y:979,t:1526919031641};\\\", \\\"{x:1389,y:979,t:1526919031657};\\\", \\\"{x:1392,y:979,t:1526919031675};\\\", \\\"{x:1395,y:979,t:1526919031848};\\\", \\\"{x:1399,y:979,t:1526919031911};\\\", \\\"{x:1402,y:979,t:1526919031925};\\\", \\\"{x:1411,y:979,t:1526919031941};\\\", \\\"{x:1419,y:980,t:1526919031958};\\\", \\\"{x:1422,y:981,t:1526919031975};\\\", \\\"{x:1423,y:981,t:1526919031991};\\\", \\\"{x:1426,y:981,t:1526919032223};\\\", \\\"{x:1429,y:981,t:1526919032239};\\\", \\\"{x:1430,y:981,t:1526919032247};\\\", \\\"{x:1432,y:981,t:1526919032258};\\\", \\\"{x:1434,y:981,t:1526919032274};\\\", \\\"{x:1435,y:981,t:1526919032295};\\\", \\\"{x:1437,y:981,t:1526919032329};\\\", \\\"{x:1440,y:981,t:1526919032344};\\\", \\\"{x:1444,y:981,t:1526919032359};\\\", \\\"{x:1454,y:981,t:1526919032376};\\\", \\\"{x:1472,y:984,t:1526919032392};\\\", \\\"{x:1478,y:985,t:1526919032409};\\\", \\\"{x:1481,y:986,t:1526919032425};\\\", \\\"{x:1482,y:986,t:1526919032536};\\\", \\\"{x:1483,y:986,t:1526919032592};\\\", \\\"{x:1484,y:986,t:1526919032719};\\\", \\\"{x:1486,y:986,t:1526919032727};\\\", \\\"{x:1489,y:985,t:1526919032741};\\\", \\\"{x:1493,y:984,t:1526919032758};\\\", \\\"{x:1501,y:984,t:1526919032775};\\\", \\\"{x:1502,y:984,t:1526919032791};\\\", \\\"{x:1505,y:984,t:1526919032809};\\\", \\\"{x:1510,y:984,t:1526919032826};\\\", \\\"{x:1516,y:984,t:1526919032841};\\\", \\\"{x:1519,y:984,t:1526919032858};\\\", \\\"{x:1523,y:984,t:1526919032876};\\\", \\\"{x:1524,y:984,t:1526919032892};\\\", \\\"{x:1526,y:983,t:1526919032909};\\\", \\\"{x:1529,y:982,t:1526919032992};\\\", \\\"{x:1530,y:982,t:1526919033016};\\\", \\\"{x:1531,y:982,t:1526919033026};\\\", \\\"{x:1532,y:982,t:1526919033043};\\\", \\\"{x:1533,y:981,t:1526919033058};\\\", \\\"{x:1535,y:980,t:1526919033076};\\\", \\\"{x:1537,y:980,t:1526919033092};\\\", \\\"{x:1538,y:980,t:1526919033109};\\\", \\\"{x:1539,y:980,t:1526919033153};\\\", \\\"{x:1541,y:980,t:1526919033158};\\\", \\\"{x:1543,y:978,t:1526919033175};\\\", \\\"{x:1545,y:977,t:1526919033199};\\\", \\\"{x:1546,y:977,t:1526919033210};\\\", \\\"{x:1548,y:977,t:1526919033255};\\\", \\\"{x:1549,y:977,t:1526919033271};\\\", \\\"{x:1551,y:977,t:1526919033287};\\\", \\\"{x:1552,y:977,t:1526919033294};\\\", \\\"{x:1553,y:977,t:1526919033327};\\\", \\\"{x:1554,y:977,t:1526919033342};\\\", \\\"{x:1560,y:976,t:1526919033359};\\\", \\\"{x:1568,y:976,t:1526919033375};\\\", \\\"{x:1582,y:976,t:1526919033393};\\\", \\\"{x:1596,y:974,t:1526919033410};\\\", \\\"{x:1603,y:973,t:1526919033425};\\\", \\\"{x:1604,y:973,t:1526919033442};\\\", \\\"{x:1605,y:973,t:1526919033528};\\\", \\\"{x:1607,y:973,t:1526919033544};\\\", \\\"{x:1608,y:973,t:1526919033568};\\\", \\\"{x:1610,y:973,t:1526919033816};\\\", \\\"{x:1612,y:973,t:1526919033827};\\\", \\\"{x:1624,y:975,t:1526919033843};\\\", \\\"{x:1641,y:981,t:1526919033860};\\\", \\\"{x:1656,y:986,t:1526919033877};\\\", \\\"{x:1669,y:989,t:1526919033893};\\\", \\\"{x:1672,y:991,t:1526919033910};\\\", \\\"{x:1673,y:991,t:1526919034119};\\\", \\\"{x:1674,y:991,t:1526919034135};\\\", \\\"{x:1675,y:991,t:1526919034143};\\\", \\\"{x:1677,y:990,t:1526919034160};\\\", \\\"{x:1677,y:989,t:1526919034192};\\\", \\\"{x:1678,y:989,t:1526919034208};\\\", \\\"{x:1678,y:988,t:1526919034215};\\\", \\\"{x:1680,y:988,t:1526919034226};\\\", \\\"{x:1680,y:987,t:1526919034244};\\\", \\\"{x:1682,y:987,t:1526919034259};\\\", \\\"{x:1683,y:985,t:1526919034277};\\\", \\\"{x:1684,y:985,t:1526919034294};\\\", \\\"{x:1686,y:983,t:1526919034310};\\\", \\\"{x:1688,y:983,t:1526919034327};\\\", \\\"{x:1689,y:983,t:1526919034344};\\\", \\\"{x:1689,y:982,t:1526919034360};\\\", \\\"{x:1690,y:982,t:1526919034408};\\\", \\\"{x:1690,y:981,t:1526919034424};\\\", \\\"{x:1691,y:981,t:1526919034552};\\\", \\\"{x:1692,y:981,t:1526919034584};\\\", \\\"{x:1693,y:981,t:1526919034599};\\\", \\\"{x:1694,y:981,t:1526919034610};\\\", \\\"{x:1697,y:980,t:1526919034626};\\\", \\\"{x:1700,y:979,t:1526919034644};\\\", \\\"{x:1704,y:977,t:1526919034660};\\\", \\\"{x:1709,y:977,t:1526919034677};\\\", \\\"{x:1713,y:977,t:1526919034694};\\\", \\\"{x:1715,y:976,t:1526919034710};\\\", \\\"{x:1716,y:976,t:1526919034727};\\\", \\\"{x:1718,y:976,t:1526919034743};\\\", \\\"{x:1719,y:976,t:1526919034767};\\\", \\\"{x:1721,y:976,t:1526919034799};\\\", \\\"{x:1722,y:976,t:1526919034815};\\\", \\\"{x:1723,y:976,t:1526919034879};\\\", \\\"{x:1725,y:976,t:1526919034903};\\\", \\\"{x:1727,y:976,t:1526919034919};\\\", \\\"{x:1730,y:976,t:1526919034928};\\\", \\\"{x:1733,y:975,t:1526919034944};\\\", \\\"{x:1737,y:974,t:1526919034961};\\\", \\\"{x:1738,y:973,t:1526919034992};\\\", \\\"{x:1739,y:973,t:1526919035016};\\\", \\\"{x:1740,y:973,t:1526919035039};\\\", \\\"{x:1741,y:973,t:1526919035231};\\\", \\\"{x:1742,y:974,t:1526919035311};\\\", \\\"{x:1743,y:975,t:1526919035351};\\\", \\\"{x:1743,y:976,t:1526919035361};\\\", \\\"{x:1744,y:976,t:1526919035383};\\\", \\\"{x:1745,y:977,t:1526919035455};\\\", \\\"{x:1744,y:977,t:1526919036632};\\\", \\\"{x:1741,y:977,t:1526919036646};\\\", \\\"{x:1731,y:977,t:1526919036661};\\\", \\\"{x:1721,y:977,t:1526919036679};\\\", \\\"{x:1716,y:977,t:1526919036694};\\\", \\\"{x:1715,y:977,t:1526919036712};\\\", \\\"{x:1713,y:977,t:1526919036729};\\\", \\\"{x:1711,y:977,t:1526919036745};\\\", \\\"{x:1709,y:977,t:1526919036761};\\\", \\\"{x:1706,y:977,t:1526919036779};\\\", \\\"{x:1702,y:977,t:1526919036795};\\\", \\\"{x:1700,y:977,t:1526919036812};\\\", \\\"{x:1699,y:977,t:1526919036829};\\\", \\\"{x:1698,y:977,t:1526919036846};\\\", \\\"{x:1697,y:977,t:1526919036862};\\\", \\\"{x:1696,y:977,t:1526919036879};\\\", \\\"{x:1694,y:977,t:1526919036895};\\\", \\\"{x:1693,y:977,t:1526919036912};\\\", \\\"{x:1692,y:977,t:1526919036929};\\\", \\\"{x:1691,y:977,t:1526919036946};\\\", \\\"{x:1690,y:976,t:1526919036976};\\\", \\\"{x:1689,y:976,t:1526919037000};\\\", \\\"{x:1687,y:975,t:1526919037023};\\\", \\\"{x:1686,y:975,t:1526919037096};\\\", \\\"{x:1684,y:975,t:1526919037119};\\\", \\\"{x:1681,y:975,t:1526919037160};\\\", \\\"{x:1679,y:975,t:1526919037168};\\\", \\\"{x:1675,y:973,t:1526919037179};\\\", \\\"{x:1664,y:973,t:1526919037196};\\\", \\\"{x:1653,y:970,t:1526919037213};\\\", \\\"{x:1643,y:970,t:1526919037230};\\\", \\\"{x:1640,y:970,t:1526919037246};\\\", \\\"{x:1638,y:970,t:1526919037456};\\\", \\\"{x:1637,y:970,t:1526919037464};\\\", \\\"{x:1636,y:970,t:1526919037480};\\\", \\\"{x:1635,y:970,t:1526919037496};\\\", \\\"{x:1634,y:970,t:1526919037513};\\\", \\\"{x:1633,y:970,t:1526919037529};\\\", \\\"{x:1630,y:970,t:1526919037546};\\\", \\\"{x:1630,y:969,t:1526919037564};\\\", \\\"{x:1626,y:968,t:1526919037579};\\\", \\\"{x:1624,y:968,t:1526919037596};\\\", \\\"{x:1623,y:968,t:1526919037615};\\\", \\\"{x:1622,y:968,t:1526919037631};\\\", \\\"{x:1621,y:968,t:1526919037647};\\\", \\\"{x:1620,y:968,t:1526919037767};\\\", \\\"{x:1619,y:968,t:1526919037799};\\\", \\\"{x:1618,y:967,t:1526919037813};\\\", \\\"{x:1617,y:966,t:1526919037830};\\\", \\\"{x:1615,y:965,t:1526919037863};\\\", \\\"{x:1614,y:965,t:1526919037904};\\\", \\\"{x:1612,y:965,t:1526919037919};\\\", \\\"{x:1610,y:962,t:1526919039071};\\\", \\\"{x:1609,y:961,t:1526919039103};\\\", \\\"{x:1608,y:961,t:1526919039151};\\\", \\\"{x:1608,y:960,t:1526919039163};\\\", \\\"{x:1608,y:959,t:1526919040136};\\\", \\\"{x:1607,y:958,t:1526919040148};\\\", \\\"{x:1607,y:957,t:1526919040164};\\\", \\\"{x:1606,y:955,t:1526919040181};\\\", \\\"{x:1605,y:955,t:1526919040197};\\\", \\\"{x:1605,y:954,t:1526919040214};\\\", \\\"{x:1604,y:953,t:1526919040231};\\\", \\\"{x:1604,y:952,t:1526919040255};\\\", \\\"{x:1604,y:951,t:1526919040279};\\\", \\\"{x:1603,y:949,t:1526919040303};\\\", \\\"{x:1602,y:948,t:1526919040328};\\\", \\\"{x:1602,y:947,t:1526919040343};\\\", \\\"{x:1601,y:947,t:1526919040359};\\\", \\\"{x:1601,y:946,t:1526919040376};\\\", \\\"{x:1600,y:946,t:1526919040384};\\\", \\\"{x:1600,y:944,t:1526919040407};\\\", \\\"{x:1600,y:943,t:1526919040432};\\\", \\\"{x:1599,y:941,t:1526919040448};\\\", \\\"{x:1599,y:940,t:1526919040465};\\\", \\\"{x:1598,y:939,t:1526919040482};\\\", \\\"{x:1597,y:939,t:1526919040499};\\\", \\\"{x:1597,y:938,t:1526919040515};\\\", \\\"{x:1597,y:937,t:1526919040532};\\\", \\\"{x:1596,y:936,t:1526919040548};\\\", \\\"{x:1595,y:936,t:1526919040565};\\\", \\\"{x:1594,y:935,t:1526919040582};\\\", \\\"{x:1594,y:934,t:1526919040598};\\\", \\\"{x:1593,y:933,t:1526919040615};\\\", \\\"{x:1593,y:932,t:1526919040663};\\\", \\\"{x:1592,y:932,t:1526919040671};\\\", \\\"{x:1591,y:932,t:1526919040887};\\\", \\\"{x:1590,y:932,t:1526919040899};\\\", \\\"{x:1587,y:933,t:1526919040915};\\\", \\\"{x:1586,y:934,t:1526919040932};\\\", \\\"{x:1585,y:936,t:1526919040959};\\\", \\\"{x:1585,y:937,t:1526919040967};\\\", \\\"{x:1584,y:938,t:1526919040982};\\\", \\\"{x:1584,y:941,t:1526919040999};\\\", \\\"{x:1583,y:943,t:1526919041015};\\\", \\\"{x:1583,y:944,t:1526919041032};\\\", \\\"{x:1583,y:946,t:1526919041049};\\\", \\\"{x:1582,y:948,t:1526919041065};\\\", \\\"{x:1582,y:949,t:1526919041082};\\\", \\\"{x:1582,y:950,t:1526919041099};\\\", \\\"{x:1582,y:952,t:1526919041115};\\\", \\\"{x:1582,y:953,t:1526919041132};\\\", \\\"{x:1582,y:954,t:1526919041150};\\\", \\\"{x:1582,y:955,t:1526919041166};\\\", \\\"{x:1582,y:956,t:1526919041183};\\\", \\\"{x:1582,y:957,t:1526919041200};\\\", \\\"{x:1582,y:958,t:1526919041224};\\\", \\\"{x:1583,y:959,t:1526919041233};\\\", \\\"{x:1583,y:960,t:1526919041256};\\\", \\\"{x:1583,y:961,t:1526919041271};\\\", \\\"{x:1583,y:962,t:1526919041282};\\\", \\\"{x:1584,y:963,t:1526919041300};\\\", \\\"{x:1585,y:964,t:1526919041317};\\\", \\\"{x:1585,y:965,t:1526919041333};\\\", \\\"{x:1587,y:967,t:1526919041349};\\\", \\\"{x:1587,y:969,t:1526919041367};\\\", \\\"{x:1588,y:971,t:1526919041382};\\\", \\\"{x:1590,y:973,t:1526919041399};\\\", \\\"{x:1590,y:974,t:1526919041415};\\\", \\\"{x:1591,y:975,t:1526919041432};\\\", \\\"{x:1591,y:976,t:1526919041449};\\\", \\\"{x:1591,y:977,t:1526919041471};\\\", \\\"{x:1592,y:978,t:1526919041495};\\\", \\\"{x:1593,y:979,t:1526919041502};\\\", \\\"{x:1592,y:979,t:1526919041864};\\\", \\\"{x:1589,y:980,t:1526919041872};\\\", \\\"{x:1583,y:980,t:1526919041884};\\\", \\\"{x:1572,y:982,t:1526919041899};\\\", \\\"{x:1563,y:983,t:1526919041917};\\\", \\\"{x:1562,y:983,t:1526919041933};\\\", \\\"{x:1561,y:983,t:1526919041949};\\\", \\\"{x:1561,y:982,t:1526919042087};\\\", \\\"{x:1561,y:979,t:1526919042099};\\\", \\\"{x:1561,y:973,t:1526919042116};\\\", \\\"{x:1561,y:967,t:1526919042133};\\\", \\\"{x:1562,y:961,t:1526919042150};\\\", \\\"{x:1563,y:955,t:1526919042165};\\\", \\\"{x:1564,y:949,t:1526919042183};\\\", \\\"{x:1566,y:946,t:1526919042199};\\\", \\\"{x:1566,y:945,t:1526919042216};\\\", \\\"{x:1566,y:943,t:1526919042233};\\\", \\\"{x:1566,y:942,t:1526919042250};\\\", \\\"{x:1566,y:941,t:1526919042266};\\\", \\\"{x:1566,y:940,t:1526919042283};\\\", \\\"{x:1566,y:939,t:1526919042300};\\\", \\\"{x:1567,y:942,t:1526919042496};\\\", \\\"{x:1568,y:946,t:1526919042504};\\\", \\\"{x:1568,y:948,t:1526919042516};\\\", \\\"{x:1569,y:956,t:1526919042533};\\\", \\\"{x:1571,y:963,t:1526919042550};\\\", \\\"{x:1571,y:968,t:1526919042567};\\\", \\\"{x:1571,y:971,t:1526919042583};\\\", \\\"{x:1571,y:972,t:1526919042600};\\\", \\\"{x:1572,y:974,t:1526919042617};\\\", \\\"{x:1572,y:975,t:1526919042839};\\\", \\\"{x:1571,y:973,t:1526919042856};\\\", \\\"{x:1571,y:972,t:1526919042866};\\\", \\\"{x:1570,y:969,t:1526919042883};\\\", \\\"{x:1570,y:968,t:1526919042900};\\\", \\\"{x:1570,y:967,t:1526919042919};\\\", \\\"{x:1570,y:966,t:1526919042976};\\\", \\\"{x:1568,y:962,t:1526919045976};\\\", \\\"{x:1562,y:957,t:1526919045986};\\\", \\\"{x:1540,y:941,t:1526919046003};\\\", \\\"{x:1499,y:915,t:1526919046019};\\\", \\\"{x:1436,y:881,t:1526919046037};\\\", \\\"{x:1369,y:844,t:1526919046055};\\\", \\\"{x:1295,y:805,t:1526919046069};\\\", \\\"{x:1236,y:772,t:1526919046086};\\\", \\\"{x:1158,y:723,t:1526919046103};\\\", \\\"{x:1123,y:702,t:1526919046119};\\\", \\\"{x:1101,y:683,t:1526919046136};\\\", \\\"{x:1076,y:667,t:1526919046153};\\\", \\\"{x:1035,y:644,t:1526919046169};\\\", \\\"{x:986,y:625,t:1526919046186};\\\", \\\"{x:927,y:605,t:1526919046203};\\\", \\\"{x:855,y:585,t:1526919046220};\\\", \\\"{x:794,y:568,t:1526919046236};\\\", \\\"{x:754,y:561,t:1526919046254};\\\", \\\"{x:732,y:556,t:1526919046270};\\\", \\\"{x:722,y:555,t:1526919046287};\\\", \\\"{x:719,y:555,t:1526919046303};\\\", \\\"{x:715,y:556,t:1526919046320};\\\", \\\"{x:707,y:560,t:1526919046337};\\\", \\\"{x:696,y:566,t:1526919046355};\\\", \\\"{x:685,y:575,t:1526919046371};\\\", \\\"{x:678,y:578,t:1526919046387};\\\", \\\"{x:673,y:582,t:1526919046404};\\\", \\\"{x:672,y:584,t:1526919046421};\\\", \\\"{x:671,y:584,t:1526919046437};\\\", \\\"{x:670,y:585,t:1526919046454};\\\", \\\"{x:668,y:586,t:1526919046471};\\\", \\\"{x:668,y:587,t:1526919046488};\\\", \\\"{x:667,y:589,t:1526919046504};\\\", \\\"{x:666,y:590,t:1526919046521};\\\", \\\"{x:665,y:590,t:1526919046538};\\\", \\\"{x:664,y:592,t:1526919046599};\\\", \\\"{x:663,y:592,t:1526919046607};\\\", \\\"{x:662,y:592,t:1526919046623};\\\", \\\"{x:661,y:592,t:1526919046639};\\\", \\\"{x:657,y:592,t:1526919046654};\\\", \\\"{x:655,y:592,t:1526919046671};\\\", \\\"{x:645,y:587,t:1526919046688};\\\", \\\"{x:641,y:584,t:1526919046705};\\\", \\\"{x:638,y:583,t:1526919046721};\\\", \\\"{x:634,y:580,t:1526919046737};\\\", \\\"{x:632,y:579,t:1526919046754};\\\", \\\"{x:631,y:577,t:1526919046771};\\\", \\\"{x:630,y:576,t:1526919046799};\\\", \\\"{x:629,y:576,t:1526919047216};\\\", \\\"{x:628,y:576,t:1526919047223};\\\", \\\"{x:627,y:576,t:1526919047247};\\\", \\\"{x:626,y:576,t:1526919047304};\\\", \\\"{x:625,y:576,t:1526919047360};\\\", \\\"{x:624,y:576,t:1526919047372};\\\", \\\"{x:623,y:576,t:1526919047416};\\\", \\\"{x:622,y:576,t:1526919047423};\\\", \\\"{x:621,y:576,t:1526919047438};\\\", \\\"{x:620,y:576,t:1526919047456};\\\", \\\"{x:618,y:577,t:1526919047471};\\\", \\\"{x:617,y:577,t:1526919047488};\\\", \\\"{x:614,y:578,t:1526919047505};\\\", \\\"{x:613,y:579,t:1526919047521};\\\", \\\"{x:612,y:579,t:1526919047538};\\\", \\\"{x:610,y:579,t:1526919047555};\\\", \\\"{x:610,y:580,t:1526919047571};\\\", \\\"{x:608,y:580,t:1526919047588};\\\", \\\"{x:607,y:581,t:1526919047605};\\\", \\\"{x:605,y:581,t:1526919047622};\\\", \\\"{x:603,y:583,t:1526919047638};\\\", \\\"{x:600,y:584,t:1526919047655};\\\", \\\"{x:597,y:584,t:1526919047673};\\\", \\\"{x:595,y:585,t:1526919047688};\\\", \\\"{x:591,y:587,t:1526919047705};\\\", \\\"{x:584,y:587,t:1526919047722};\\\", \\\"{x:573,y:588,t:1526919047738};\\\", \\\"{x:564,y:589,t:1526919047755};\\\", \\\"{x:553,y:591,t:1526919047772};\\\", \\\"{x:544,y:592,t:1526919047788};\\\", \\\"{x:533,y:593,t:1526919047805};\\\", \\\"{x:528,y:594,t:1526919047823};\\\", \\\"{x:520,y:595,t:1526919047838};\\\", \\\"{x:507,y:596,t:1526919047855};\\\", \\\"{x:493,y:597,t:1526919047872};\\\", \\\"{x:481,y:597,t:1526919047888};\\\", \\\"{x:467,y:598,t:1526919047905};\\\", \\\"{x:460,y:598,t:1526919047922};\\\", \\\"{x:451,y:598,t:1526919047938};\\\", \\\"{x:436,y:601,t:1526919047956};\\\", \\\"{x:414,y:602,t:1526919047972};\\\", \\\"{x:396,y:606,t:1526919047989};\\\", \\\"{x:375,y:608,t:1526919048005};\\\", \\\"{x:362,y:611,t:1526919048022};\\\", \\\"{x:356,y:612,t:1526919048038};\\\", \\\"{x:348,y:613,t:1526919048055};\\\", \\\"{x:341,y:617,t:1526919048072};\\\", \\\"{x:333,y:620,t:1526919048089};\\\", \\\"{x:318,y:625,t:1526919048105};\\\", \\\"{x:301,y:630,t:1526919048122};\\\", \\\"{x:286,y:631,t:1526919048139};\\\", \\\"{x:280,y:634,t:1526919048157};\\\", \\\"{x:269,y:634,t:1526919048173};\\\", \\\"{x:259,y:634,t:1526919048188};\\\", \\\"{x:243,y:634,t:1526919048205};\\\", \\\"{x:221,y:634,t:1526919048223};\\\", \\\"{x:206,y:633,t:1526919048238};\\\", \\\"{x:186,y:629,t:1526919048256};\\\", \\\"{x:182,y:628,t:1526919048272};\\\", \\\"{x:178,y:626,t:1526919048289};\\\", \\\"{x:174,y:624,t:1526919048305};\\\", \\\"{x:168,y:620,t:1526919048322};\\\", \\\"{x:159,y:614,t:1526919048339};\\\", \\\"{x:151,y:607,t:1526919048355};\\\", \\\"{x:143,y:597,t:1526919048372};\\\", \\\"{x:136,y:589,t:1526919048389};\\\", \\\"{x:132,y:581,t:1526919048406};\\\", \\\"{x:129,y:575,t:1526919048422};\\\", \\\"{x:129,y:571,t:1526919048439};\\\", \\\"{x:129,y:570,t:1526919048456};\\\", \\\"{x:129,y:566,t:1526919048472};\\\", \\\"{x:129,y:564,t:1526919048489};\\\", \\\"{x:129,y:562,t:1526919048507};\\\", \\\"{x:129,y:560,t:1526919048522};\\\", \\\"{x:130,y:556,t:1526919048539};\\\", \\\"{x:133,y:553,t:1526919048557};\\\", \\\"{x:136,y:549,t:1526919048573};\\\", \\\"{x:141,y:543,t:1526919048589};\\\", \\\"{x:145,y:537,t:1526919048606};\\\", \\\"{x:147,y:533,t:1526919048622};\\\", \\\"{x:149,y:529,t:1526919048640};\\\", \\\"{x:151,y:526,t:1526919048656};\\\", \\\"{x:151,y:525,t:1526919048672};\\\", \\\"{x:151,y:523,t:1526919048689};\\\", \\\"{x:152,y:521,t:1526919048706};\\\", \\\"{x:154,y:519,t:1526919048722};\\\", \\\"{x:154,y:518,t:1526919048739};\\\", \\\"{x:156,y:515,t:1526919048756};\\\", \\\"{x:157,y:514,t:1526919048782};\\\", \\\"{x:157,y:513,t:1526919048799};\\\", \\\"{x:158,y:512,t:1526919048806};\\\", \\\"{x:159,y:512,t:1526919048831};\\\", \\\"{x:159,y:511,t:1526919048871};\\\", \\\"{x:162,y:510,t:1526919048887};\\\", \\\"{x:163,y:510,t:1526919048903};\\\", \\\"{x:165,y:510,t:1526919048919};\\\", \\\"{x:166,y:510,t:1526919048927};\\\", \\\"{x:168,y:510,t:1526919048939};\\\", \\\"{x:169,y:510,t:1526919048956};\\\", \\\"{x:171,y:510,t:1526919048974};\\\", \\\"{x:172,y:510,t:1526919048989};\\\", \\\"{x:173,y:510,t:1526919049031};\\\", \\\"{x:174,y:510,t:1526919049064};\\\", \\\"{x:175,y:510,t:1526919049080};\\\", \\\"{x:176,y:510,t:1526919049176};\\\", \\\"{x:177,y:511,t:1526919050143};\\\", \\\"{x:177,y:513,t:1526919050158};\\\", \\\"{x:178,y:516,t:1526919050174};\\\", \\\"{x:179,y:521,t:1526919050191};\\\", \\\"{x:182,y:529,t:1526919050207};\\\", \\\"{x:184,y:531,t:1526919050224};\\\", \\\"{x:184,y:533,t:1526919050240};\\\", \\\"{x:185,y:534,t:1526919050257};\\\", \\\"{x:186,y:536,t:1526919050279};\\\", \\\"{x:186,y:538,t:1526919050303};\\\", \\\"{x:186,y:540,t:1526919050319};\\\", \\\"{x:186,y:541,t:1526919050327};\\\", \\\"{x:187,y:541,t:1526919050340};\\\", \\\"{x:188,y:542,t:1526919050357};\\\", \\\"{x:188,y:543,t:1526919050375};\\\", \\\"{x:188,y:544,t:1526919050391};\\\", \\\"{x:189,y:545,t:1526919050407};\\\", \\\"{x:189,y:546,t:1526919050424};\\\", \\\"{x:190,y:548,t:1526919050441};\\\", \\\"{x:191,y:551,t:1526919050458};\\\", \\\"{x:192,y:552,t:1526919050474};\\\", \\\"{x:192,y:553,t:1526919050491};\\\", \\\"{x:193,y:554,t:1526919050507};\\\", \\\"{x:193,y:555,t:1526919050524};\\\", \\\"{x:195,y:558,t:1526919050542};\\\", \\\"{x:197,y:560,t:1526919050557};\\\", \\\"{x:200,y:563,t:1526919050575};\\\", \\\"{x:205,y:566,t:1526919050591};\\\", \\\"{x:209,y:569,t:1526919050607};\\\", \\\"{x:214,y:570,t:1526919050624};\\\", \\\"{x:222,y:573,t:1526919050642};\\\", \\\"{x:234,y:578,t:1526919050658};\\\", \\\"{x:249,y:582,t:1526919050674};\\\", \\\"{x:270,y:587,t:1526919050691};\\\", \\\"{x:287,y:591,t:1526919050709};\\\", \\\"{x:301,y:594,t:1526919050724};\\\", \\\"{x:314,y:597,t:1526919050741};\\\", \\\"{x:327,y:601,t:1526919050758};\\\", \\\"{x:340,y:602,t:1526919050774};\\\", \\\"{x:353,y:604,t:1526919050790};\\\", \\\"{x:359,y:606,t:1526919050809};\\\", \\\"{x:365,y:608,t:1526919050824};\\\", \\\"{x:370,y:610,t:1526919050841};\\\", \\\"{x:374,y:611,t:1526919050858};\\\", \\\"{x:377,y:611,t:1526919050875};\\\", \\\"{x:379,y:611,t:1526919050891};\\\", \\\"{x:381,y:611,t:1526919050907};\\\", \\\"{x:383,y:613,t:1526919050924};\\\", \\\"{x:386,y:613,t:1526919050941};\\\", \\\"{x:389,y:613,t:1526919050957};\\\", \\\"{x:393,y:613,t:1526919050974};\\\", \\\"{x:398,y:614,t:1526919050991};\\\", \\\"{x:401,y:614,t:1526919051007};\\\", \\\"{x:404,y:615,t:1526919051024};\\\", \\\"{x:407,y:615,t:1526919051040};\\\", \\\"{x:408,y:617,t:1526919051058};\\\", \\\"{x:412,y:618,t:1526919051074};\\\", \\\"{x:419,y:618,t:1526919051090};\\\", \\\"{x:432,y:619,t:1526919051107};\\\", \\\"{x:441,y:621,t:1526919051124};\\\", \\\"{x:447,y:621,t:1526919051141};\\\", \\\"{x:450,y:621,t:1526919051158};\\\", \\\"{x:454,y:623,t:1526919051174};\\\", \\\"{x:456,y:623,t:1526919051192};\\\", \\\"{x:458,y:624,t:1526919051208};\\\", \\\"{x:460,y:624,t:1526919051225};\\\", \\\"{x:462,y:624,t:1526919051241};\\\", \\\"{x:463,y:625,t:1526919051259};\\\", \\\"{x:464,y:625,t:1526919051275};\\\", \\\"{x:465,y:625,t:1526919051291};\\\", \\\"{x:466,y:625,t:1526919051311};\\\", \\\"{x:467,y:625,t:1526919051351};\\\", \\\"{x:468,y:625,t:1526919051359};\\\", \\\"{x:470,y:625,t:1526919051375};\\\", \\\"{x:471,y:625,t:1526919051391};\\\", \\\"{x:472,y:625,t:1526919051408};\\\", \\\"{x:473,y:625,t:1526919051425};\\\", \\\"{x:474,y:625,t:1526919052447};\\\", \\\"{x:477,y:625,t:1526919052459};\\\", \\\"{x:485,y:626,t:1526919052476};\\\", \\\"{x:493,y:630,t:1526919052494};\\\", \\\"{x:498,y:631,t:1526919052509};\\\", \\\"{x:500,y:632,t:1526919052528};\\\", \\\"{x:503,y:634,t:1526919052543};\\\", \\\"{x:503,y:635,t:1526919052559};\\\", \\\"{x:504,y:635,t:1526919052576};\\\", \\\"{x:505,y:635,t:1526919052607};\\\", \\\"{x:503,y:633,t:1526919052847};\\\", \\\"{x:502,y:633,t:1526919052859};\\\", \\\"{x:497,y:631,t:1526919052876};\\\", \\\"{x:495,y:629,t:1526919052892};\\\", \\\"{x:494,y:628,t:1526919052910};\\\", \\\"{x:493,y:627,t:1526919052926};\\\", \\\"{x:492,y:626,t:1526919052942};\\\", \\\"{x:492,y:624,t:1526919052983};\\\", \\\"{x:498,y:624,t:1526919053143};\\\", \\\"{x:515,y:631,t:1526919053159};\\\", \\\"{x:537,y:639,t:1526919053177};\\\", \\\"{x:560,y:645,t:1526919053193};\\\", \\\"{x:582,y:652,t:1526919053209};\\\", \\\"{x:603,y:658,t:1526919053226};\\\", \\\"{x:620,y:661,t:1526919053244};\\\", \\\"{x:634,y:664,t:1526919053259};\\\", \\\"{x:646,y:667,t:1526919053276};\\\", \\\"{x:662,y:672,t:1526919053294};\\\", \\\"{x:681,y:677,t:1526919053309};\\\", \\\"{x:700,y:683,t:1526919053326};\\\", \\\"{x:733,y:693,t:1526919053344};\\\", \\\"{x:760,y:701,t:1526919053359};\\\", \\\"{x:792,y:713,t:1526919053376};\\\", \\\"{x:838,y:728,t:1526919053394};\\\", \\\"{x:885,y:750,t:1526919053409};\\\", \\\"{x:954,y:779,t:1526919053426};\\\", \\\"{x:1020,y:806,t:1526919053443};\\\", \\\"{x:1097,y:838,t:1526919053460};\\\", \\\"{x:1157,y:873,t:1526919053476};\\\", \\\"{x:1231,y:901,t:1526919053494};\\\", \\\"{x:1295,y:931,t:1526919053511};\\\", \\\"{x:1346,y:959,t:1526919053527};\\\", \\\"{x:1414,y:988,t:1526919053543};\\\", \\\"{x:1435,y:994,t:1526919053560};\\\", \\\"{x:1442,y:997,t:1526919053576};\\\", \\\"{x:1442,y:998,t:1526919053704};\\\", \\\"{x:1438,y:996,t:1526919053712};\\\", \\\"{x:1405,y:975,t:1526919053727};\\\", \\\"{x:1348,y:944,t:1526919053744};\\\", \\\"{x:1299,y:917,t:1526919053761};\\\", \\\"{x:1247,y:887,t:1526919053777};\\\", \\\"{x:1202,y:865,t:1526919053793};\\\", \\\"{x:1169,y:851,t:1526919053811};\\\", \\\"{x:1145,y:842,t:1526919053828};\\\", \\\"{x:1125,y:833,t:1526919053843};\\\", \\\"{x:1101,y:822,t:1526919053860};\\\", \\\"{x:1080,y:812,t:1526919053878};\\\", \\\"{x:1062,y:804,t:1526919053893};\\\", \\\"{x:1044,y:795,t:1526919053910};\\\", \\\"{x:1017,y:788,t:1526919053926};\\\", \\\"{x:1005,y:784,t:1526919053943};\\\", \\\"{x:998,y:783,t:1526919053960};\\\", \\\"{x:997,y:783,t:1526919053978};\\\", \\\"{x:995,y:781,t:1526919055487};\\\", \\\"{x:995,y:778,t:1526919055495};\\\", \\\"{x:994,y:773,t:1526919055511};\\\", \\\"{x:992,y:768,t:1526919055528};\\\", \\\"{x:991,y:761,t:1526919055545};\\\", \\\"{x:989,y:756,t:1526919055562};\\\", \\\"{x:988,y:753,t:1526919055579};\\\", \\\"{x:987,y:749,t:1526919055595};\\\", \\\"{x:986,y:745,t:1526919055611};\\\", \\\"{x:984,y:742,t:1526919055628};\\\", \\\"{x:983,y:738,t:1526919055645};\\\", \\\"{x:983,y:731,t:1526919055662};\\\", \\\"{x:983,y:721,t:1526919055678};\\\", \\\"{x:983,y:716,t:1526919055695};\\\", \\\"{x:978,y:708,t:1526919055712};\\\", \\\"{x:970,y:699,t:1526919055728};\\\", \\\"{x:957,y:690,t:1526919055745};\\\", \\\"{x:938,y:676,t:1526919055763};\\\", \\\"{x:921,y:661,t:1526919055778};\\\", \\\"{x:905,y:648,t:1526919055796};\\\", \\\"{x:893,y:636,t:1526919055813};\\\", \\\"{x:884,y:625,t:1526919055829};\\\", \\\"{x:876,y:615,t:1526919055845};\\\", \\\"{x:870,y:611,t:1526919055863};\\\", \\\"{x:867,y:610,t:1526919055879};\\\", \\\"{x:865,y:610,t:1526919055911};\\\", \\\"{x:865,y:609,t:1526919055918};\\\", \\\"{x:864,y:608,t:1526919055928};\\\", \\\"{x:863,y:608,t:1526919055950};\\\", \\\"{x:862,y:608,t:1526919055961};\\\", \\\"{x:860,y:608,t:1526919055978};\\\", \\\"{x:857,y:607,t:1526919055996};\\\", \\\"{x:852,y:604,t:1526919056011};\\\", \\\"{x:846,y:601,t:1526919056029};\\\", \\\"{x:838,y:597,t:1526919056046};\\\", \\\"{x:832,y:595,t:1526919056061};\\\", \\\"{x:827,y:592,t:1526919056079};\\\", \\\"{x:825,y:590,t:1526919056095};\\\", \\\"{x:824,y:590,t:1526919056112};\\\", \\\"{x:824,y:589,t:1526919056130};\\\", \\\"{x:824,y:587,t:1526919056223};\\\", \\\"{x:824,y:588,t:1526919056816};\\\", \\\"{x:825,y:590,t:1526919056831};\\\", \\\"{x:827,y:594,t:1526919056847};\\\", \\\"{x:827,y:598,t:1526919056862};\\\", \\\"{x:829,y:600,t:1526919056878};\\\", \\\"{x:829,y:602,t:1526919056903};\\\", \\\"{x:830,y:604,t:1526919056935};\\\", \\\"{x:831,y:604,t:1526919057055};\\\", \\\"{x:832,y:604,t:1526919057151};\\\", \\\"{x:833,y:601,t:1526919057163};\\\", \\\"{x:835,y:594,t:1526919057180};\\\", \\\"{x:838,y:589,t:1526919057197};\\\", \\\"{x:838,y:587,t:1526919057212};\\\", \\\"{x:840,y:582,t:1526919057230};\\\", \\\"{x:840,y:580,t:1526919057247};\\\", \\\"{x:849,y:586,t:1526919059154};\\\", \\\"{x:868,y:595,t:1526919059161};\\\", \\\"{x:884,y:606,t:1526919059175};\\\", \\\"{x:971,y:637,t:1526919059192};\\\", \\\"{x:1073,y:675,t:1526919059208};\\\", \\\"{x:1250,y:732,t:1526919059225};\\\", \\\"{x:1375,y:770,t:1526919059242};\\\", \\\"{x:1495,y:810,t:1526919059257};\\\", \\\"{x:1603,y:843,t:1526919059274};\\\", \\\"{x:1694,y:880,t:1526919059291};\\\", \\\"{x:1766,y:913,t:1526919059307};\\\", \\\"{x:1809,y:928,t:1526919059324};\\\", \\\"{x:1824,y:936,t:1526919059341};\\\", \\\"{x:1826,y:936,t:1526919059358};\\\", \\\"{x:1827,y:936,t:1526919059374};\\\", \\\"{x:1827,y:937,t:1526919059393};\\\", \\\"{x:1825,y:938,t:1526919059408};\\\", \\\"{x:1822,y:939,t:1526919059424};\\\", \\\"{x:1810,y:939,t:1526919059442};\\\", \\\"{x:1787,y:937,t:1526919059458};\\\", \\\"{x:1767,y:937,t:1526919059474};\\\", \\\"{x:1759,y:937,t:1526919059491};\\\", \\\"{x:1757,y:937,t:1526919059509};\\\", \\\"{x:1756,y:938,t:1526919059553};\\\", \\\"{x:1755,y:942,t:1526919059560};\\\", \\\"{x:1751,y:947,t:1526919059574};\\\", \\\"{x:1749,y:951,t:1526919059592};\\\", \\\"{x:1746,y:954,t:1526919059608};\\\", \\\"{x:1746,y:955,t:1526919059625};\\\", \\\"{x:1746,y:957,t:1526919059649};\\\", \\\"{x:1746,y:959,t:1526919059704};\\\", \\\"{x:1746,y:960,t:1526919059712};\\\", \\\"{x:1746,y:962,t:1526919059728};\\\", \\\"{x:1746,y:964,t:1526919059741};\\\", \\\"{x:1746,y:965,t:1526919059759};\\\", \\\"{x:1746,y:966,t:1526919059775};\\\", \\\"{x:1746,y:967,t:1526919059791};\\\", \\\"{x:1746,y:969,t:1526919059817};\\\", \\\"{x:1747,y:970,t:1526919059849};\\\", \\\"{x:1748,y:970,t:1526919059864};\\\", \\\"{x:1748,y:971,t:1526919059888};\\\", \\\"{x:1748,y:972,t:1526919059897};\\\", \\\"{x:1749,y:972,t:1526919059908};\\\", \\\"{x:1751,y:973,t:1526919059925};\\\", \\\"{x:1755,y:975,t:1526919059941};\\\", \\\"{x:1761,y:977,t:1526919059959};\\\", \\\"{x:1769,y:978,t:1526919059975};\\\", \\\"{x:1774,y:979,t:1526919059992};\\\", \\\"{x:1791,y:982,t:1526919060009};\\\", \\\"{x:1801,y:983,t:1526919060025};\\\", \\\"{x:1811,y:984,t:1526919060042};\\\", \\\"{x:1818,y:985,t:1526919060059};\\\", \\\"{x:1821,y:986,t:1526919060075};\\\", \\\"{x:1822,y:986,t:1526919060289};\\\", \\\"{x:1822,y:984,t:1526919060312};\\\", \\\"{x:1822,y:983,t:1526919060325};\\\", \\\"{x:1822,y:982,t:1526919060342};\\\", \\\"{x:1821,y:981,t:1526919060360};\\\", \\\"{x:1821,y:980,t:1526919060376};\\\", \\\"{x:1821,y:979,t:1526919060393};\\\", \\\"{x:1821,y:978,t:1526919060408};\\\", \\\"{x:1821,y:977,t:1526919060441};\\\", \\\"{x:1820,y:977,t:1526919060456};\\\", \\\"{x:1819,y:977,t:1526919060920};\\\", \\\"{x:1818,y:977,t:1526919060944};\\\", \\\"{x:1817,y:976,t:1526919060959};\\\", \\\"{x:1816,y:976,t:1526919060975};\\\", \\\"{x:1815,y:976,t:1526919061009};\\\", \\\"{x:1814,y:975,t:1526919061026};\\\", \\\"{x:1813,y:974,t:1526919061043};\\\", \\\"{x:1812,y:974,t:1526919061059};\\\", \\\"{x:1811,y:974,t:1526919061075};\\\", \\\"{x:1810,y:974,t:1526919061093};\\\", \\\"{x:1809,y:974,t:1526919061169};\\\", \\\"{x:1807,y:974,t:1526919061234};\\\", \\\"{x:1806,y:974,t:1526919061298};\\\", \\\"{x:1804,y:974,t:1526919061310};\\\", \\\"{x:1803,y:974,t:1526919061327};\\\", \\\"{x:1801,y:974,t:1526919061345};\\\", \\\"{x:1800,y:974,t:1526919061360};\\\", \\\"{x:1798,y:974,t:1526919061386};\\\", \\\"{x:1797,y:974,t:1526919061409};\\\", \\\"{x:1795,y:974,t:1526919061441};\\\", \\\"{x:1794,y:974,t:1526919061466};\\\", \\\"{x:1793,y:974,t:1526919061489};\\\", \\\"{x:1792,y:974,t:1526919061497};\\\", \\\"{x:1791,y:974,t:1526919061522};\\\", \\\"{x:1790,y:974,t:1526919061529};\\\", \\\"{x:1789,y:974,t:1526919061553};\\\", \\\"{x:1788,y:973,t:1526919061570};\\\", \\\"{x:1786,y:973,t:1526919061633};\\\", \\\"{x:1785,y:973,t:1526919061690};\\\", \\\"{x:1784,y:972,t:1526919061713};\\\", \\\"{x:1783,y:971,t:1526919061727};\\\", \\\"{x:1782,y:971,t:1526919061744};\\\", \\\"{x:1781,y:970,t:1526919061817};\\\", \\\"{x:1780,y:970,t:1526919061857};\\\", \\\"{x:1776,y:970,t:1526919062242};\\\", \\\"{x:1772,y:969,t:1526919062249};\\\", \\\"{x:1771,y:968,t:1526919062261};\\\", \\\"{x:1758,y:968,t:1526919062276};\\\", \\\"{x:1742,y:968,t:1526919062294};\\\", \\\"{x:1726,y:967,t:1526919062311};\\\", \\\"{x:1716,y:966,t:1526919062326};\\\", \\\"{x:1709,y:966,t:1526919062343};\\\", \\\"{x:1703,y:965,t:1526919062360};\\\", \\\"{x:1702,y:965,t:1526919062378};\\\", \\\"{x:1698,y:965,t:1526919062393};\\\", \\\"{x:1690,y:965,t:1526919062410};\\\", \\\"{x:1677,y:965,t:1526919062427};\\\", \\\"{x:1662,y:965,t:1526919062443};\\\", \\\"{x:1644,y:965,t:1526919062461};\\\", \\\"{x:1626,y:965,t:1526919062478};\\\", \\\"{x:1616,y:965,t:1526919062493};\\\", \\\"{x:1611,y:965,t:1526919062510};\\\", \\\"{x:1608,y:965,t:1526919062528};\\\", \\\"{x:1605,y:965,t:1526919062543};\\\", \\\"{x:1601,y:965,t:1526919062561};\\\", \\\"{x:1598,y:965,t:1526919062585};\\\", \\\"{x:1595,y:965,t:1526919062593};\\\", \\\"{x:1590,y:967,t:1526919062610};\\\", \\\"{x:1584,y:967,t:1526919062627};\\\", \\\"{x:1579,y:968,t:1526919062643};\\\", \\\"{x:1574,y:969,t:1526919062661};\\\", \\\"{x:1568,y:970,t:1526919062677};\\\", \\\"{x:1561,y:971,t:1526919062694};\\\", \\\"{x:1555,y:972,t:1526919062710};\\\", \\\"{x:1549,y:973,t:1526919062728};\\\", \\\"{x:1547,y:973,t:1526919062744};\\\", \\\"{x:1546,y:974,t:1526919062760};\\\", \\\"{x:1544,y:975,t:1526919062824};\\\", \\\"{x:1542,y:975,t:1526919062840};\\\", \\\"{x:1540,y:975,t:1526919062856};\\\", \\\"{x:1538,y:976,t:1526919062864};\\\", \\\"{x:1537,y:976,t:1526919062888};\\\", \\\"{x:1536,y:977,t:1526919062921};\\\", \\\"{x:1535,y:977,t:1526919062936};\\\", \\\"{x:1535,y:978,t:1526919063529};\\\", \\\"{x:1534,y:978,t:1526919063626};\\\", \\\"{x:1532,y:979,t:1526919063641};\\\", \\\"{x:1530,y:980,t:1526919063690};\\\", \\\"{x:1529,y:980,t:1526919063697};\\\", \\\"{x:1528,y:980,t:1526919063712};\\\", \\\"{x:1523,y:980,t:1526919063729};\\\", \\\"{x:1519,y:981,t:1526919063745};\\\", \\\"{x:1517,y:981,t:1526919063762};\\\", \\\"{x:1508,y:982,t:1526919063779};\\\", \\\"{x:1502,y:982,t:1526919063795};\\\", \\\"{x:1497,y:983,t:1526919063812};\\\", \\\"{x:1494,y:983,t:1526919063829};\\\", \\\"{x:1492,y:983,t:1526919063845};\\\", \\\"{x:1489,y:984,t:1526919063862};\\\", \\\"{x:1485,y:985,t:1526919063880};\\\", \\\"{x:1479,y:985,t:1526919063895};\\\", \\\"{x:1473,y:985,t:1526919063913};\\\", \\\"{x:1466,y:985,t:1526919063928};\\\", \\\"{x:1462,y:985,t:1526919063945};\\\", \\\"{x:1460,y:985,t:1526919063962};\\\", \\\"{x:1457,y:985,t:1526919063978};\\\", \\\"{x:1454,y:985,t:1526919063994};\\\", \\\"{x:1450,y:985,t:1526919064012};\\\", \\\"{x:1446,y:985,t:1526919064028};\\\", \\\"{x:1442,y:984,t:1526919064044};\\\", \\\"{x:1436,y:984,t:1526919064061};\\\", \\\"{x:1430,y:984,t:1526919064078};\\\", \\\"{x:1424,y:983,t:1526919064095};\\\", \\\"{x:1420,y:981,t:1526919064111};\\\", \\\"{x:1412,y:981,t:1526919064129};\\\", \\\"{x:1409,y:980,t:1526919064145};\\\", \\\"{x:1404,y:979,t:1526919064161};\\\", \\\"{x:1401,y:979,t:1526919064178};\\\", \\\"{x:1396,y:978,t:1526919064195};\\\", \\\"{x:1394,y:978,t:1526919064212};\\\", \\\"{x:1389,y:977,t:1526919064229};\\\", \\\"{x:1386,y:977,t:1526919064246};\\\", \\\"{x:1382,y:976,t:1526919064262};\\\", \\\"{x:1379,y:976,t:1526919064279};\\\", \\\"{x:1376,y:976,t:1526919064296};\\\", \\\"{x:1374,y:976,t:1526919064313};\\\", \\\"{x:1373,y:975,t:1526919064360};\\\", \\\"{x:1372,y:974,t:1526919064369};\\\", \\\"{x:1371,y:974,t:1526919064400};\\\", \\\"{x:1369,y:974,t:1526919064416};\\\", \\\"{x:1368,y:974,t:1526919064440};\\\", \\\"{x:1367,y:974,t:1526919064456};\\\", \\\"{x:1366,y:973,t:1526919064537};\\\", \\\"{x:1365,y:973,t:1526919064568};\\\", \\\"{x:1364,y:973,t:1526919064664};\\\", \\\"{x:1363,y:973,t:1526919064872};\\\", \\\"{x:1363,y:972,t:1526919064929};\\\", \\\"{x:1362,y:971,t:1526919065041};\\\", \\\"{x:1360,y:971,t:1526919065096};\\\", \\\"{x:1360,y:970,t:1526919065137};\\\", \\\"{x:1360,y:969,t:1526919065192};\\\", \\\"{x:1359,y:968,t:1526919065200};\\\", \\\"{x:1359,y:967,t:1526919065241};\\\", \\\"{x:1358,y:967,t:1526919065248};\\\", \\\"{x:1358,y:966,t:1526919065272};\\\", \\\"{x:1358,y:965,t:1526919065288};\\\", \\\"{x:1357,y:964,t:1526919065304};\\\", \\\"{x:1357,y:962,t:1526919065320};\\\", \\\"{x:1356,y:962,t:1526919065330};\\\", \\\"{x:1356,y:959,t:1526919065346};\\\", \\\"{x:1354,y:957,t:1526919065363};\\\", \\\"{x:1354,y:955,t:1526919065379};\\\", \\\"{x:1354,y:951,t:1526919065396};\\\", \\\"{x:1354,y:946,t:1526919065413};\\\", \\\"{x:1353,y:940,t:1526919065429};\\\", \\\"{x:1353,y:936,t:1526919065447};\\\", \\\"{x:1351,y:929,t:1526919065463};\\\", \\\"{x:1351,y:920,t:1526919065479};\\\", \\\"{x:1350,y:909,t:1526919065496};\\\", \\\"{x:1350,y:900,t:1526919065513};\\\", \\\"{x:1350,y:895,t:1526919065529};\\\", \\\"{x:1350,y:888,t:1526919065546};\\\", \\\"{x:1350,y:882,t:1526919065563};\\\", \\\"{x:1350,y:871,t:1526919065579};\\\", \\\"{x:1349,y:850,t:1526919065597};\\\", \\\"{x:1343,y:834,t:1526919065613};\\\", \\\"{x:1338,y:822,t:1526919065629};\\\", \\\"{x:1336,y:811,t:1526919065646};\\\", \\\"{x:1335,y:807,t:1526919065662};\\\", \\\"{x:1335,y:804,t:1526919065679};\\\", \\\"{x:1334,y:799,t:1526919065696};\\\", \\\"{x:1334,y:794,t:1526919065713};\\\", \\\"{x:1334,y:791,t:1526919065729};\\\", \\\"{x:1332,y:787,t:1526919065747};\\\", \\\"{x:1332,y:780,t:1526919065763};\\\", \\\"{x:1332,y:770,t:1526919065780};\\\", \\\"{x:1332,y:757,t:1526919065797};\\\", \\\"{x:1334,y:744,t:1526919065812};\\\", \\\"{x:1337,y:734,t:1526919065830};\\\", \\\"{x:1341,y:725,t:1526919065846};\\\", \\\"{x:1345,y:714,t:1526919065864};\\\", \\\"{x:1348,y:705,t:1526919065879};\\\", \\\"{x:1350,y:691,t:1526919065896};\\\", \\\"{x:1351,y:678,t:1526919065913};\\\", \\\"{x:1351,y:674,t:1526919065930};\\\", \\\"{x:1351,y:670,t:1526919065946};\\\", \\\"{x:1351,y:666,t:1526919065964};\\\", \\\"{x:1351,y:663,t:1526919065980};\\\", \\\"{x:1351,y:660,t:1526919065997};\\\", \\\"{x:1351,y:656,t:1526919066013};\\\", \\\"{x:1351,y:650,t:1526919066030};\\\", \\\"{x:1351,y:645,t:1526919066046};\\\", \\\"{x:1351,y:639,t:1526919066064};\\\", \\\"{x:1349,y:634,t:1526919066080};\\\", \\\"{x:1346,y:626,t:1526919066096};\\\", \\\"{x:1343,y:618,t:1526919066114};\\\", \\\"{x:1343,y:615,t:1526919066130};\\\", \\\"{x:1341,y:609,t:1526919066147};\\\", \\\"{x:1339,y:603,t:1526919066163};\\\", \\\"{x:1337,y:597,t:1526919066179};\\\", \\\"{x:1334,y:592,t:1526919066196};\\\", \\\"{x:1332,y:589,t:1526919066214};\\\", \\\"{x:1331,y:586,t:1526919066230};\\\", \\\"{x:1330,y:582,t:1526919066247};\\\", \\\"{x:1328,y:576,t:1526919066263};\\\", \\\"{x:1326,y:571,t:1526919066279};\\\", \\\"{x:1325,y:565,t:1526919066296};\\\", \\\"{x:1324,y:562,t:1526919066314};\\\", \\\"{x:1323,y:560,t:1526919066329};\\\", \\\"{x:1323,y:557,t:1526919066346};\\\", \\\"{x:1323,y:554,t:1526919066369};\\\", \\\"{x:1322,y:551,t:1526919066385};\\\", \\\"{x:1322,y:550,t:1526919066397};\\\", \\\"{x:1321,y:543,t:1526919066414};\\\", \\\"{x:1321,y:539,t:1526919066431};\\\", \\\"{x:1321,y:535,t:1526919066447};\\\", \\\"{x:1320,y:531,t:1526919066464};\\\", \\\"{x:1320,y:528,t:1526919066481};\\\", \\\"{x:1319,y:525,t:1526919066497};\\\", \\\"{x:1319,y:523,t:1526919066514};\\\", \\\"{x:1319,y:522,t:1526919066561};\\\", \\\"{x:1319,y:525,t:1526919066825};\\\", \\\"{x:1319,y:529,t:1526919066833};\\\", \\\"{x:1319,y:531,t:1526919066848};\\\", \\\"{x:1319,y:537,t:1526919066865};\\\", \\\"{x:1320,y:543,t:1526919066882};\\\", \\\"{x:1321,y:545,t:1526919066898};\\\", \\\"{x:1322,y:548,t:1526919066914};\\\", \\\"{x:1323,y:552,t:1526919066931};\\\", \\\"{x:1324,y:558,t:1526919066948};\\\", \\\"{x:1325,y:565,t:1526919066964};\\\", \\\"{x:1327,y:573,t:1526919066981};\\\", \\\"{x:1328,y:582,t:1526919066998};\\\", \\\"{x:1329,y:588,t:1526919067015};\\\", \\\"{x:1332,y:595,t:1526919067031};\\\", \\\"{x:1333,y:599,t:1526919067049};\\\", \\\"{x:1335,y:605,t:1526919067065};\\\", \\\"{x:1336,y:611,t:1526919067081};\\\", \\\"{x:1336,y:615,t:1526919067098};\\\", \\\"{x:1337,y:619,t:1526919067115};\\\", \\\"{x:1339,y:623,t:1526919067131};\\\", \\\"{x:1339,y:630,t:1526919067148};\\\", \\\"{x:1340,y:639,t:1526919067164};\\\", \\\"{x:1343,y:648,t:1526919067181};\\\", \\\"{x:1344,y:659,t:1526919067198};\\\", \\\"{x:1345,y:670,t:1526919067215};\\\", \\\"{x:1346,y:676,t:1526919067231};\\\", \\\"{x:1347,y:683,t:1526919067249};\\\", \\\"{x:1347,y:687,t:1526919067265};\\\", \\\"{x:1347,y:691,t:1526919067282};\\\", \\\"{x:1348,y:698,t:1526919067299};\\\", \\\"{x:1349,y:708,t:1526919067316};\\\", \\\"{x:1352,y:720,t:1526919067332};\\\", \\\"{x:1352,y:726,t:1526919067348};\\\", \\\"{x:1353,y:732,t:1526919067365};\\\", \\\"{x:1354,y:738,t:1526919067382};\\\", \\\"{x:1356,y:745,t:1526919067399};\\\", \\\"{x:1356,y:750,t:1526919067415};\\\", \\\"{x:1357,y:756,t:1526919067431};\\\", \\\"{x:1357,y:759,t:1526919067448};\\\", \\\"{x:1357,y:763,t:1526919067465};\\\", \\\"{x:1357,y:764,t:1526919067481};\\\", \\\"{x:1357,y:767,t:1526919067499};\\\", \\\"{x:1357,y:774,t:1526919067516};\\\", \\\"{x:1357,y:784,t:1526919067531};\\\", \\\"{x:1357,y:794,t:1526919067549};\\\", \\\"{x:1357,y:797,t:1526919067565};\\\", \\\"{x:1357,y:799,t:1526919067581};\\\", \\\"{x:1357,y:800,t:1526919067598};\\\", \\\"{x:1356,y:802,t:1526919067615};\\\", \\\"{x:1356,y:803,t:1526919067632};\\\", \\\"{x:1356,y:808,t:1526919067648};\\\", \\\"{x:1353,y:815,t:1526919067665};\\\", \\\"{x:1348,y:823,t:1526919067682};\\\", \\\"{x:1346,y:826,t:1526919067698};\\\", \\\"{x:1344,y:826,t:1526919068272};\\\", \\\"{x:1333,y:824,t:1526919068281};\\\", \\\"{x:1304,y:819,t:1526919068299};\\\", \\\"{x:1283,y:817,t:1526919068315};\\\", \\\"{x:1262,y:813,t:1526919068332};\\\", \\\"{x:1239,y:808,t:1526919068349};\\\", \\\"{x:1212,y:806,t:1526919068365};\\\", \\\"{x:1193,y:798,t:1526919068382};\\\", \\\"{x:1164,y:790,t:1526919068399};\\\", \\\"{x:1123,y:777,t:1526919068415};\\\", \\\"{x:1053,y:757,t:1526919068431};\\\", \\\"{x:951,y:729,t:1526919068448};\\\", \\\"{x:891,y:707,t:1526919068464};\\\", \\\"{x:833,y:681,t:1526919068481};\\\", \\\"{x:771,y:652,t:1526919068498};\\\", \\\"{x:700,y:611,t:1526919068515};\\\", \\\"{x:623,y:581,t:1526919068532};\\\", \\\"{x:555,y:552,t:1526919068549};\\\", \\\"{x:490,y:519,t:1526919068566};\\\", \\\"{x:409,y:479,t:1526919068582};\\\", \\\"{x:341,y:442,t:1526919068599};\\\", \\\"{x:291,y:418,t:1526919068615};\\\", \\\"{x:270,y:408,t:1526919068631};\\\", \\\"{x:254,y:402,t:1526919068648};\\\", \\\"{x:250,y:400,t:1526919068666};\\\", \\\"{x:248,y:400,t:1526919068729};\\\", \\\"{x:247,y:402,t:1526919068736};\\\", \\\"{x:245,y:407,t:1526919068749};\\\", \\\"{x:240,y:420,t:1526919068766};\\\", \\\"{x:237,y:433,t:1526919068783};\\\", \\\"{x:237,y:445,t:1526919068799};\\\", \\\"{x:237,y:457,t:1526919068815};\\\", \\\"{x:244,y:480,t:1526919068832};\\\", \\\"{x:248,y:497,t:1526919068849};\\\", \\\"{x:251,y:512,t:1526919068865};\\\", \\\"{x:252,y:527,t:1526919068884};\\\", \\\"{x:252,y:533,t:1526919068898};\\\", \\\"{x:250,y:539,t:1526919068916};\\\", \\\"{x:246,y:541,t:1526919068932};\\\", \\\"{x:244,y:543,t:1526919068949};\\\", \\\"{x:242,y:543,t:1526919068985};\\\", \\\"{x:240,y:543,t:1526919068998};\\\", \\\"{x:233,y:543,t:1526919069016};\\\", \\\"{x:215,y:543,t:1526919069033};\\\", \\\"{x:198,y:538,t:1526919069048};\\\", \\\"{x:186,y:534,t:1526919069067};\\\", \\\"{x:175,y:529,t:1526919069082};\\\", \\\"{x:171,y:526,t:1526919069099};\\\", \\\"{x:170,y:526,t:1526919069115};\\\", \\\"{x:169,y:525,t:1526919069132};\\\", \\\"{x:168,y:524,t:1526919069150};\\\", \\\"{x:167,y:523,t:1526919069166};\\\", \\\"{x:166,y:522,t:1526919069182};\\\", \\\"{x:165,y:521,t:1526919069240};\\\", \\\"{x:164,y:521,t:1526919069249};\\\", \\\"{x:162,y:520,t:1526919069272};\\\", \\\"{x:161,y:519,t:1526919069283};\\\", \\\"{x:160,y:517,t:1526919069301};\\\", \\\"{x:159,y:514,t:1526919069317};\\\", \\\"{x:158,y:514,t:1526919069333};\\\", \\\"{x:158,y:513,t:1526919070929};\\\", \\\"{x:158,y:514,t:1526919071008};\\\", \\\"{x:158,y:515,t:1526919071081};\\\", \\\"{x:158,y:516,t:1526919071105};\\\", \\\"{x:158,y:517,t:1526919071129};\\\", \\\"{x:158,y:518,t:1526919071146};\\\", \\\"{x:158,y:519,t:1526919071161};\\\", \\\"{x:158,y:520,t:1526919071169};\\\", \\\"{x:158,y:521,t:1526919071193};\\\", \\\"{x:158,y:522,t:1526919071209};\\\", \\\"{x:158,y:523,t:1526919071225};\\\", \\\"{x:158,y:524,t:1526919071249};\\\", \\\"{x:158,y:525,t:1526919071266};\\\", \\\"{x:158,y:526,t:1526919071288};\\\", \\\"{x:158,y:527,t:1526919071320};\\\", \\\"{x:158,y:528,t:1526919071352};\\\", \\\"{x:158,y:529,t:1526919071368};\\\", \\\"{x:158,y:532,t:1526919071384};\\\", \\\"{x:159,y:533,t:1526919071400};\\\", \\\"{x:159,y:534,t:1526919071432};\\\", \\\"{x:159,y:536,t:1526919071720};\\\", \\\"{x:161,y:537,t:1526919071734};\\\", \\\"{x:163,y:539,t:1526919071752};\\\", \\\"{x:164,y:540,t:1526919071767};\\\", \\\"{x:165,y:542,t:1526919071784};\\\", \\\"{x:165,y:543,t:1526919071801};\\\", \\\"{x:166,y:543,t:1526919071824};\\\", \\\"{x:167,y:543,t:1526919072290};\\\", \\\"{x:165,y:542,t:1526919072400};\\\", \\\"{x:165,y:542,t:1526919072510};\\\", \\\"{x:162,y:542,t:1526919072720};\\\", \\\"{x:160,y:539,t:1526919072736};\\\", \\\"{x:157,y:538,t:1526919072752};\\\", \\\"{x:156,y:536,t:1526919072769};\\\", \\\"{x:156,y:532,t:1526919072785};\\\", \\\"{x:155,y:531,t:1526919072808};\\\", \\\"{x:155,y:529,t:1526919072841};\\\", \\\"{x:155,y:527,t:1526919072856};\\\", \\\"{x:155,y:526,t:1526919072868};\\\", \\\"{x:156,y:523,t:1526919072887};\\\", \\\"{x:158,y:522,t:1526919072902};\\\", \\\"{x:159,y:519,t:1526919072918};\\\", \\\"{x:160,y:518,t:1526919072936};\\\", \\\"{x:161,y:516,t:1526919072953};\\\", \\\"{x:161,y:514,t:1526919073457};\\\", \\\"{x:161,y:513,t:1526919073473};\\\", \\\"{x:161,y:518,t:1526919074082};\\\", \\\"{x:161,y:521,t:1526919074088};\\\", \\\"{x:162,y:525,t:1526919074103};\\\", \\\"{x:164,y:534,t:1526919074120};\\\", \\\"{x:165,y:543,t:1526919074136};\\\", \\\"{x:165,y:546,t:1526919074153};\\\", \\\"{x:165,y:549,t:1526919074169};\\\", \\\"{x:165,y:550,t:1526919074187};\\\", \\\"{x:165,y:552,t:1526919074204};\\\", \\\"{x:165,y:555,t:1526919074220};\\\", \\\"{x:165,y:558,t:1526919074237};\\\", \\\"{x:164,y:563,t:1526919074253};\\\", \\\"{x:164,y:567,t:1526919074270};\\\", \\\"{x:164,y:570,t:1526919074287};\\\", \\\"{x:164,y:571,t:1526919074304};\\\", \\\"{x:164,y:572,t:1526919074336};\\\", \\\"{x:164,y:573,t:1526919074344};\\\", \\\"{x:163,y:574,t:1526919074360};\\\", \\\"{x:163,y:575,t:1526919074384};\\\", \\\"{x:163,y:576,t:1526919074392};\\\", \\\"{x:162,y:576,t:1526919074416};\\\", \\\"{x:161,y:579,t:1526919074848};\\\", \\\"{x:161,y:583,t:1526919074856};\\\", \\\"{x:161,y:586,t:1526919074870};\\\", \\\"{x:161,y:590,t:1526919074887};\\\", \\\"{x:161,y:592,t:1526919074904};\\\", \\\"{x:161,y:593,t:1526919075057};\\\", \\\"{x:161,y:594,t:1526919075073};\\\", \\\"{x:161,y:595,t:1526919075088};\\\", \\\"{x:161,y:596,t:1526919075104};\\\", \\\"{x:161,y:598,t:1526919075121};\\\", \\\"{x:161,y:600,t:1526919075139};\\\", \\\"{x:161,y:604,t:1526919075155};\\\", \\\"{x:160,y:606,t:1526919075171};\\\", \\\"{x:159,y:607,t:1526919075188};\\\", \\\"{x:158,y:609,t:1526919075204};\\\", \\\"{x:158,y:611,t:1526919075472};\\\", \\\"{x:157,y:618,t:1526919075488};\\\", \\\"{x:157,y:621,t:1526919075505};\\\", \\\"{x:155,y:626,t:1526919075520};\\\", \\\"{x:154,y:629,t:1526919075538};\\\", \\\"{x:154,y:632,t:1526919075556};\\\", \\\"{x:154,y:635,t:1526919075571};\\\", \\\"{x:154,y:638,t:1526919075588};\\\", \\\"{x:154,y:641,t:1526919075608};\\\", \\\"{x:154,y:643,t:1526919075621};\\\", \\\"{x:154,y:644,t:1526919075637};\\\", \\\"{x:154,y:645,t:1526919075655};\\\", \\\"{x:154,y:646,t:1526919075873};\\\", \\\"{x:154,y:648,t:1526919075888};\\\", \\\"{x:155,y:649,t:1526919075905};\\\", \\\"{x:155,y:651,t:1526919075922};\\\", \\\"{x:156,y:652,t:1526919075952};\\\", \\\"{x:157,y:652,t:1526919076176};\\\", \\\"{x:158,y:652,t:1526919076296};\\\", \\\"{x:159,y:652,t:1526919076328};\\\", \\\"{x:160,y:652,t:1526919076344};\\\", \\\"{x:161,y:652,t:1526919076354};\\\", \\\"{x:165,y:652,t:1526919076372};\\\", \\\"{x:176,y:652,t:1526919076390};\\\", \\\"{x:183,y:652,t:1526919076404};\\\", \\\"{x:204,y:650,t:1526919076422};\\\", \\\"{x:224,y:644,t:1526919076439};\\\", \\\"{x:234,y:633,t:1526919076455};\\\", \\\"{x:242,y:603,t:1526919076472};\\\", \\\"{x:248,y:581,t:1526919076490};\\\", \\\"{x:261,y:558,t:1526919076505};\\\", \\\"{x:281,y:541,t:1526919076522};\\\", \\\"{x:303,y:532,t:1526919076539};\\\", \\\"{x:323,y:523,t:1526919076555};\\\", \\\"{x:340,y:516,t:1526919076572};\\\", \\\"{x:356,y:511,t:1526919076589};\\\", \\\"{x:366,y:510,t:1526919076605};\\\", \\\"{x:367,y:510,t:1526919076729};\\\", \\\"{x:369,y:510,t:1526919076739};\\\", \\\"{x:373,y:510,t:1526919076756};\\\", \\\"{x:374,y:512,t:1526919076773};\\\", \\\"{x:375,y:512,t:1526919076906};\\\", \\\"{x:378,y:516,t:1526919076923};\\\", \\\"{x:380,y:520,t:1526919076941};\\\", \\\"{x:384,y:528,t:1526919076956};\\\", \\\"{x:384,y:535,t:1526919076972};\\\", \\\"{x:385,y:541,t:1526919076988};\\\", \\\"{x:385,y:547,t:1526919077005};\\\", \\\"{x:385,y:551,t:1526919077022};\\\", \\\"{x:386,y:552,t:1526919077040};\\\", \\\"{x:386,y:551,t:1526919077104};\\\", \\\"{x:384,y:547,t:1526919077122};\\\", \\\"{x:383,y:547,t:1526919077144};\\\", \\\"{x:383,y:546,t:1526919077168};\\\", \\\"{x:383,y:545,t:1526919077192};\\\", \\\"{x:382,y:542,t:1526919077393};\\\", \\\"{x:382,y:540,t:1526919077406};\\\", \\\"{x:380,y:534,t:1526919077423};\\\", \\\"{x:379,y:530,t:1526919077439};\\\", \\\"{x:379,y:523,t:1526919077457};\\\", \\\"{x:379,y:519,t:1526919077472};\\\", \\\"{x:379,y:516,t:1526919077490};\\\", \\\"{x:379,y:515,t:1526919077506};\\\", \\\"{x:379,y:513,t:1526919077523};\\\", \\\"{x:379,y:511,t:1526919077540};\\\", \\\"{x:379,y:510,t:1526919077556};\\\", \\\"{x:379,y:509,t:1526919077573};\\\", \\\"{x:379,y:512,t:1526919077888};\\\", \\\"{x:379,y:516,t:1526919077896};\\\", \\\"{x:379,y:518,t:1526919077908};\\\", \\\"{x:379,y:524,t:1526919077923};\\\", \\\"{x:379,y:525,t:1526919077941};\\\", \\\"{x:379,y:526,t:1526919077960};\\\", \\\"{x:379,y:527,t:1526919078016};\\\", \\\"{x:379,y:528,t:1526919078024};\\\", \\\"{x:379,y:530,t:1526919078040};\\\", \\\"{x:379,y:531,t:1526919078057};\\\", \\\"{x:379,y:533,t:1526919078073};\\\", \\\"{x:379,y:535,t:1526919078090};\\\", \\\"{x:379,y:536,t:1526919078107};\\\", \\\"{x:379,y:537,t:1526919078124};\\\", \\\"{x:379,y:541,t:1526919078392};\\\", \\\"{x:376,y:547,t:1526919078407};\\\", \\\"{x:371,y:561,t:1526919078424};\\\", \\\"{x:367,y:575,t:1526919078440};\\\", \\\"{x:366,y:581,t:1526919078457};\\\", \\\"{x:366,y:584,t:1526919078474};\\\", \\\"{x:366,y:585,t:1526919078490};\\\", \\\"{x:366,y:584,t:1526919078713};\\\", \\\"{x:366,y:583,t:1526919078724};\\\", \\\"{x:366,y:582,t:1526919078809};\\\", \\\"{x:368,y:582,t:1526919078905};\\\", \\\"{x:369,y:582,t:1526919078913};\\\", \\\"{x:371,y:582,t:1526919078924};\\\", \\\"{x:373,y:582,t:1526919078941};\\\", \\\"{x:374,y:582,t:1526919078958};\\\", \\\"{x:375,y:582,t:1526919079216};\\\", \\\"{x:375,y:584,t:1526919079224};\\\", \\\"{x:376,y:589,t:1526919079241};\\\", \\\"{x:377,y:595,t:1526919079259};\\\", \\\"{x:378,y:597,t:1526919079274};\\\", \\\"{x:379,y:598,t:1526919079291};\\\", \\\"{x:380,y:599,t:1526919079352};\\\", \\\"{x:381,y:599,t:1526919079368};\\\", \\\"{x:382,y:600,t:1526919079377};\\\", \\\"{x:383,y:601,t:1526919079393};\\\", \\\"{x:384,y:602,t:1526919079408};\\\", \\\"{x:386,y:604,t:1526919079424};\\\", \\\"{x:387,y:605,t:1526919079441};\\\", \\\"{x:388,y:606,t:1526919079458};\\\", \\\"{x:389,y:608,t:1526919079474};\\\", \\\"{x:391,y:610,t:1526919079491};\\\", \\\"{x:391,y:611,t:1526919079752};\\\", \\\"{x:391,y:613,t:1526919079760};\\\", \\\"{x:391,y:615,t:1526919079775};\\\", \\\"{x:390,y:620,t:1526919079791};\\\", \\\"{x:387,y:631,t:1526919079808};\\\", \\\"{x:387,y:642,t:1526919079826};\\\", \\\"{x:387,y:650,t:1526919079841};\\\", \\\"{x:387,y:654,t:1526919079858};\\\", \\\"{x:387,y:655,t:1526919080152};\\\", \\\"{x:388,y:655,t:1526919080167};\\\", \\\"{x:388,y:654,t:1526919080184};\\\", \\\"{x:387,y:653,t:1526919080192};\\\", \\\"{x:386,y:651,t:1526919080208};\\\", \\\"{x:385,y:651,t:1526919080225};\\\", \\\"{x:384,y:650,t:1526919080242};\\\", \\\"{x:384,y:649,t:1526919080258};\\\", \\\"{x:384,y:648,t:1526919080275};\\\", \\\"{x:384,y:647,t:1526919080305};\\\", \\\"{x:386,y:646,t:1526919080409};\\\", \\\"{x:391,y:643,t:1526919080425};\\\", \\\"{x:396,y:637,t:1526919080443};\\\", \\\"{x:406,y:630,t:1526919080460};\\\", \\\"{x:422,y:622,t:1526919080475};\\\", \\\"{x:445,y:610,t:1526919080492};\\\", \\\"{x:470,y:596,t:1526919080509};\\\", \\\"{x:503,y:577,t:1526919080526};\\\", \\\"{x:529,y:563,t:1526919080542};\\\", \\\"{x:541,y:555,t:1526919080560};\\\", \\\"{x:543,y:551,t:1526919080575};\\\", \\\"{x:546,y:542,t:1526919080592};\\\", \\\"{x:547,y:538,t:1526919080609};\\\", \\\"{x:549,y:533,t:1526919080625};\\\", \\\"{x:551,y:531,t:1526919080642};\\\", \\\"{x:552,y:530,t:1526919080680};\\\", \\\"{x:554,y:529,t:1526919080692};\\\", \\\"{x:556,y:524,t:1526919080710};\\\", \\\"{x:559,y:520,t:1526919080726};\\\", \\\"{x:560,y:520,t:1526919080742};\\\", \\\"{x:561,y:517,t:1526919080785};\\\", \\\"{x:563,y:517,t:1526919080792};\\\", \\\"{x:567,y:513,t:1526919080809};\\\", \\\"{x:576,y:511,t:1526919080826};\\\", \\\"{x:581,y:508,t:1526919080842};\\\", \\\"{x:585,y:507,t:1526919080859};\\\", \\\"{x:587,y:507,t:1526919080876};\\\", \\\"{x:588,y:507,t:1526919081193};\\\", \\\"{x:588,y:506,t:1526919081210};\\\", \\\"{x:589,y:506,t:1526919081298};\\\", \\\"{x:590,y:506,t:1526919081313};\\\", \\\"{x:591,y:506,t:1526919081609};\\\", \\\"{x:591,y:506,t:1526919081713};\\\", \\\"{x:592,y:506,t:1526919081784};\\\", \\\"{x:592,y:508,t:1526919081793};\\\", \\\"{x:590,y:514,t:1526919081810};\\\", \\\"{x:588,y:518,t:1526919081826};\\\", \\\"{x:586,y:524,t:1526919081843};\\\", \\\"{x:585,y:526,t:1526919081860};\\\", \\\"{x:585,y:529,t:1526919081876};\\\", \\\"{x:585,y:532,t:1526919081893};\\\", \\\"{x:590,y:537,t:1526919081911};\\\", \\\"{x:598,y:543,t:1526919081926};\\\", \\\"{x:603,y:546,t:1526919081943};\\\", \\\"{x:603,y:544,t:1526919082016};\\\", \\\"{x:605,y:538,t:1526919082026};\\\", \\\"{x:605,y:527,t:1526919082044};\\\", \\\"{x:605,y:520,t:1526919082061};\\\", \\\"{x:605,y:518,t:1526919082076};\\\", \\\"{x:605,y:516,t:1526919082093};\\\", \\\"{x:605,y:515,t:1526919082110};\\\", \\\"{x:604,y:514,t:1526919082127};\\\", \\\"{x:603,y:511,t:1526919082144};\\\", \\\"{x:600,y:503,t:1526919082160};\\\", \\\"{x:599,y:500,t:1526919082177};\\\", \\\"{x:598,y:498,t:1526919082193};\\\", \\\"{x:597,y:498,t:1526919082418};\\\", \\\"{x:597,y:497,t:1526919082433};\\\", \\\"{x:598,y:497,t:1526919082649};\\\", \\\"{x:599,y:500,t:1526919082660};\\\", \\\"{x:601,y:509,t:1526919082679};\\\", \\\"{x:602,y:517,t:1526919082695};\\\", \\\"{x:605,y:524,t:1526919082712};\\\", \\\"{x:607,y:531,t:1526919082728};\\\", \\\"{x:611,y:539,t:1526919082744};\\\", \\\"{x:613,y:542,t:1526919082760};\\\", \\\"{x:614,y:544,t:1526919082778};\\\", \\\"{x:615,y:546,t:1526919082795};\\\", \\\"{x:618,y:553,t:1526919082811};\\\", \\\"{x:622,y:561,t:1526919082828};\\\", \\\"{x:626,y:566,t:1526919082844};\\\", \\\"{x:627,y:570,t:1526919082860};\\\", \\\"{x:627,y:571,t:1526919082945};\\\", \\\"{x:627,y:573,t:1526919082961};\\\", \\\"{x:625,y:572,t:1526919083033};\\\", \\\"{x:624,y:571,t:1526919083045};\\\", \\\"{x:618,y:565,t:1526919083063};\\\", \\\"{x:611,y:555,t:1526919083078};\\\", \\\"{x:608,y:546,t:1526919083094};\\\", \\\"{x:606,y:537,t:1526919083111};\\\", \\\"{x:604,y:532,t:1526919083127};\\\", \\\"{x:604,y:527,t:1526919083144};\\\", \\\"{x:604,y:526,t:1526919083162};\\\", \\\"{x:604,y:522,t:1526919083178};\\\", \\\"{x:604,y:518,t:1526919083194};\\\", \\\"{x:604,y:515,t:1526919083212};\\\", \\\"{x:604,y:513,t:1526919083227};\\\", \\\"{x:604,y:511,t:1526919083244};\\\", \\\"{x:604,y:510,t:1526919083261};\\\", \\\"{x:604,y:508,t:1526919083278};\\\", \\\"{x:605,y:507,t:1526919083294};\\\", \\\"{x:605,y:509,t:1526919083704};\\\", \\\"{x:607,y:515,t:1526919083712};\\\", \\\"{x:607,y:522,t:1526919083728};\\\", \\\"{x:608,y:531,t:1526919083745};\\\", \\\"{x:609,y:537,t:1526919083761};\\\", \\\"{x:609,y:540,t:1526919083778};\\\", \\\"{x:609,y:542,t:1526919083794};\\\", \\\"{x:609,y:543,t:1526919083811};\\\", \\\"{x:609,y:546,t:1526919083828};\\\", \\\"{x:609,y:550,t:1526919083845};\\\", \\\"{x:609,y:554,t:1526919083861};\\\", \\\"{x:609,y:559,t:1526919083878};\\\", \\\"{x:609,y:563,t:1526919083896};\\\", \\\"{x:610,y:568,t:1526919083912};\\\", \\\"{x:616,y:579,t:1526919083928};\\\", \\\"{x:619,y:586,t:1526919083945};\\\", \\\"{x:620,y:589,t:1526919083961};\\\", \\\"{x:621,y:590,t:1526919084017};\\\", \\\"{x:621,y:591,t:1526919084032};\\\", \\\"{x:620,y:591,t:1526919084201};\\\", \\\"{x:619,y:591,t:1526919084217};\\\", \\\"{x:618,y:591,t:1526919084229};\\\", \\\"{x:617,y:588,t:1526919084246};\\\", \\\"{x:616,y:586,t:1526919084262};\\\", \\\"{x:615,y:584,t:1526919084278};\\\", \\\"{x:614,y:583,t:1526919084295};\\\", \\\"{x:613,y:582,t:1526919084880};\\\", \\\"{x:612,y:581,t:1526919086448};\\\", \\\"{x:610,y:579,t:1526919086464};\\\", \\\"{x:606,y:576,t:1526919086482};\\\", \\\"{x:604,y:574,t:1526919086498};\\\", \\\"{x:600,y:570,t:1526919086514};\\\", \\\"{x:595,y:566,t:1526919086531};\\\", \\\"{x:592,y:562,t:1526919086547};\\\", \\\"{x:585,y:558,t:1526919086565};\\\", \\\"{x:578,y:554,t:1526919086581};\\\", \\\"{x:569,y:549,t:1526919086598};\\\", \\\"{x:554,y:542,t:1526919086614};\\\", \\\"{x:539,y:535,t:1526919086630};\\\", \\\"{x:522,y:531,t:1526919086648};\\\", \\\"{x:515,y:529,t:1526919086663};\\\", \\\"{x:500,y:527,t:1526919086680};\\\", \\\"{x:489,y:526,t:1526919086698};\\\", \\\"{x:481,y:523,t:1526919086714};\\\", \\\"{x:474,y:520,t:1526919086730};\\\", \\\"{x:467,y:518,t:1526919086747};\\\", \\\"{x:458,y:517,t:1526919086765};\\\", \\\"{x:447,y:516,t:1526919086780};\\\", \\\"{x:432,y:513,t:1526919086797};\\\", \\\"{x:416,y:513,t:1526919086814};\\\", \\\"{x:401,y:513,t:1526919086831};\\\", \\\"{x:391,y:513,t:1526919086848};\\\", \\\"{x:385,y:513,t:1526919086864};\\\", \\\"{x:377,y:513,t:1526919086880};\\\", \\\"{x:368,y:513,t:1526919086897};\\\", \\\"{x:354,y:514,t:1526919086914};\\\", \\\"{x:331,y:518,t:1526919086930};\\\", \\\"{x:315,y:519,t:1526919086947};\\\", \\\"{x:301,y:521,t:1526919086964};\\\", \\\"{x:291,y:523,t:1526919086980};\\\", \\\"{x:278,y:526,t:1526919086997};\\\", \\\"{x:263,y:530,t:1526919087015};\\\", \\\"{x:251,y:535,t:1526919087030};\\\", \\\"{x:242,y:539,t:1526919087047};\\\", \\\"{x:233,y:546,t:1526919087064};\\\", \\\"{x:230,y:550,t:1526919087080};\\\", \\\"{x:229,y:553,t:1526919087097};\\\", \\\"{x:228,y:558,t:1526919087114};\\\", \\\"{x:227,y:562,t:1526919087131};\\\", \\\"{x:227,y:571,t:1526919087148};\\\", \\\"{x:227,y:582,t:1526919087164};\\\", \\\"{x:228,y:594,t:1526919087180};\\\", \\\"{x:231,y:603,t:1526919087197};\\\", \\\"{x:232,y:611,t:1526919087214};\\\", \\\"{x:235,y:618,t:1526919087231};\\\", \\\"{x:236,y:624,t:1526919087247};\\\", \\\"{x:237,y:626,t:1526919087264};\\\", \\\"{x:237,y:627,t:1526919087281};\\\", \\\"{x:237,y:629,t:1526919087304};\\\", \\\"{x:237,y:630,t:1526919087320};\\\", \\\"{x:238,y:631,t:1526919087331};\\\", \\\"{x:239,y:634,t:1526919087348};\\\", \\\"{x:242,y:637,t:1526919087365};\\\", \\\"{x:245,y:638,t:1526919087381};\\\", \\\"{x:262,y:642,t:1526919087397};\\\", \\\"{x:271,y:643,t:1526919087414};\\\", \\\"{x:288,y:646,t:1526919087432};\\\", \\\"{x:295,y:649,t:1526919087447};\\\", \\\"{x:330,y:649,t:1526919087464};\\\", \\\"{x:348,y:652,t:1526919087481};\\\", \\\"{x:366,y:649,t:1526919087497};\\\", \\\"{x:375,y:649,t:1526919087514};\\\", \\\"{x:384,y:649,t:1526919087531};\\\", \\\"{x:385,y:649,t:1526919087547};\\\", \\\"{x:387,y:648,t:1526919087564};\\\", \\\"{x:388,y:648,t:1526919087584};\\\", \\\"{x:389,y:646,t:1526919087597};\\\", \\\"{x:391,y:646,t:1526919087614};\\\", \\\"{x:402,y:646,t:1526919087631};\\\", \\\"{x:418,y:646,t:1526919087648};\\\", \\\"{x:441,y:646,t:1526919087664};\\\", \\\"{x:455,y:646,t:1526919087681};\\\", \\\"{x:467,y:646,t:1526919087698};\\\", \\\"{x:477,y:643,t:1526919087714};\\\", \\\"{x:489,y:642,t:1526919087731};\\\", \\\"{x:500,y:642,t:1526919087749};\\\", \\\"{x:515,y:642,t:1526919087765};\\\", \\\"{x:534,y:640,t:1526919087781};\\\", \\\"{x:560,y:638,t:1526919087799};\\\", \\\"{x:597,y:638,t:1526919087815};\\\", \\\"{x:675,y:638,t:1526919087831};\\\", \\\"{x:800,y:638,t:1526919087848};\\\", \\\"{x:884,y:636,t:1526919087865};\\\", \\\"{x:948,y:636,t:1526919087882};\\\", \\\"{x:1002,y:633,t:1526919087899};\\\", \\\"{x:1034,y:628,t:1526919087915};\\\", \\\"{x:1054,y:622,t:1526919087931};\\\", \\\"{x:1066,y:615,t:1526919087949};\\\", \\\"{x:1073,y:607,t:1526919087966};\\\", \\\"{x:1074,y:597,t:1526919087982};\\\", \\\"{x:1074,y:588,t:1526919087998};\\\", \\\"{x:1070,y:573,t:1526919088015};\\\", \\\"{x:1067,y:566,t:1526919088032};\\\", \\\"{x:1055,y:545,t:1526919088048};\\\", \\\"{x:1039,y:531,t:1526919088066};\\\", \\\"{x:1026,y:524,t:1526919088081};\\\", \\\"{x:1010,y:518,t:1526919088099};\\\", \\\"{x:990,y:509,t:1526919088116};\\\", \\\"{x:968,y:506,t:1526919088131};\\\", \\\"{x:957,y:501,t:1526919088149};\\\", \\\"{x:948,y:500,t:1526919088166};\\\", \\\"{x:944,y:499,t:1526919088181};\\\", \\\"{x:940,y:499,t:1526919088198};\\\", \\\"{x:932,y:501,t:1526919088215};\\\", \\\"{x:920,y:506,t:1526919088231};\\\", \\\"{x:894,y:515,t:1526919088248};\\\", \\\"{x:871,y:524,t:1526919088266};\\\", \\\"{x:850,y:532,t:1526919088282};\\\", \\\"{x:830,y:538,t:1526919088298};\\\", \\\"{x:810,y:544,t:1526919088316};\\\", \\\"{x:796,y:549,t:1526919088331};\\\", \\\"{x:776,y:554,t:1526919088349};\\\", \\\"{x:760,y:555,t:1526919088365};\\\", \\\"{x:742,y:558,t:1526919088382};\\\", \\\"{x:724,y:558,t:1526919088398};\\\", \\\"{x:708,y:557,t:1526919088416};\\\", \\\"{x:690,y:554,t:1526919088432};\\\", \\\"{x:677,y:553,t:1526919088449};\\\", \\\"{x:668,y:551,t:1526919088465};\\\", \\\"{x:659,y:548,t:1526919088482};\\\", \\\"{x:652,y:544,t:1526919088498};\\\", \\\"{x:647,y:542,t:1526919088516};\\\", \\\"{x:643,y:539,t:1526919088532};\\\", \\\"{x:639,y:536,t:1526919088549};\\\", \\\"{x:637,y:535,t:1526919088565};\\\", \\\"{x:636,y:534,t:1526919088583};\\\", \\\"{x:637,y:536,t:1526919088688};\\\", \\\"{x:639,y:538,t:1526919088698};\\\", \\\"{x:643,y:542,t:1526919088715};\\\", \\\"{x:649,y:547,t:1526919088733};\\\", \\\"{x:657,y:550,t:1526919088749};\\\", \\\"{x:662,y:553,t:1526919088765};\\\", \\\"{x:668,y:553,t:1526919088782};\\\", \\\"{x:672,y:556,t:1526919088800};\\\", \\\"{x:676,y:557,t:1526919088815};\\\", \\\"{x:679,y:558,t:1526919088832};\\\", \\\"{x:684,y:560,t:1526919088850};\\\", \\\"{x:691,y:560,t:1526919088865};\\\", \\\"{x:695,y:561,t:1526919088882};\\\", \\\"{x:699,y:561,t:1526919088899};\\\", \\\"{x:703,y:562,t:1526919088915};\\\", \\\"{x:707,y:563,t:1526919088933};\\\", \\\"{x:709,y:563,t:1526919088950};\\\", \\\"{x:713,y:565,t:1526919088965};\\\", \\\"{x:715,y:565,t:1526919088984};\\\", \\\"{x:716,y:565,t:1526919089024};\\\", \\\"{x:716,y:566,t:1526919089128};\\\", \\\"{x:713,y:567,t:1526919089136};\\\", \\\"{x:711,y:568,t:1526919089148};\\\", \\\"{x:698,y:572,t:1526919089165};\\\", \\\"{x:690,y:574,t:1526919089183};\\\", \\\"{x:684,y:575,t:1526919089198};\\\", \\\"{x:680,y:575,t:1526919089216};\\\", \\\"{x:676,y:577,t:1526919089232};\\\", \\\"{x:675,y:577,t:1526919089249};\\\", \\\"{x:673,y:579,t:1526919089265};\\\", \\\"{x:671,y:580,t:1526919089283};\\\", \\\"{x:668,y:583,t:1526919089299};\\\", \\\"{x:664,y:585,t:1526919089316};\\\", \\\"{x:658,y:590,t:1526919089333};\\\", \\\"{x:656,y:592,t:1526919089349};\\\", \\\"{x:656,y:593,t:1526919089366};\\\", \\\"{x:655,y:593,t:1526919090153};\\\", \\\"{x:653,y:593,t:1526919090168};\\\", \\\"{x:652,y:592,t:1526919090313};\\\", \\\"{x:652,y:591,t:1526919090345};\\\", \\\"{x:652,y:590,t:1526919090361};\\\", \\\"{x:652,y:589,t:1526919090368};\\\", \\\"{x:653,y:588,t:1526919090383};\\\", \\\"{x:653,y:586,t:1526919090416};\\\", \\\"{x:654,y:585,t:1526919090440};\\\", \\\"{x:656,y:585,t:1526919090457};\\\", \\\"{x:656,y:584,t:1526919090466};\\\", \\\"{x:658,y:584,t:1526919090483};\\\", \\\"{x:660,y:583,t:1526919090499};\\\", \\\"{x:661,y:582,t:1526919090516};\\\", \\\"{x:668,y:582,t:1526919090533};\\\", \\\"{x:678,y:582,t:1526919090549};\\\", \\\"{x:692,y:582,t:1526919090566};\\\", \\\"{x:704,y:586,t:1526919090583};\\\", \\\"{x:710,y:588,t:1526919090599};\\\", \\\"{x:714,y:589,t:1526919090616};\\\", \\\"{x:719,y:589,t:1526919090632};\\\", \\\"{x:731,y:589,t:1526919090650};\\\", \\\"{x:743,y:589,t:1526919090666};\\\", \\\"{x:757,y:581,t:1526919090682};\\\", \\\"{x:764,y:576,t:1526919090700};\\\", \\\"{x:771,y:570,t:1526919090718};\\\", \\\"{x:776,y:562,t:1526919090734};\\\", \\\"{x:779,y:554,t:1526919090751};\\\", \\\"{x:779,y:547,t:1526919090767};\\\", \\\"{x:780,y:542,t:1526919090783};\\\", \\\"{x:785,y:536,t:1526919090800};\\\", \\\"{x:786,y:534,t:1526919090818};\\\", \\\"{x:788,y:533,t:1526919090834};\\\", \\\"{x:789,y:533,t:1526919090851};\\\", \\\"{x:790,y:532,t:1526919090868};\\\", \\\"{x:791,y:530,t:1526919090884};\\\", \\\"{x:793,y:528,t:1526919090900};\\\", \\\"{x:794,y:527,t:1526919090917};\\\", \\\"{x:796,y:524,t:1526919090934};\\\", \\\"{x:799,y:522,t:1526919090950};\\\", \\\"{x:800,y:521,t:1526919090968};\\\", \\\"{x:802,y:521,t:1526919091000};\\\", \\\"{x:803,y:521,t:1526919091008};\\\", \\\"{x:805,y:521,t:1526919091018};\\\", \\\"{x:810,y:518,t:1526919091034};\\\", \\\"{x:812,y:518,t:1526919091051};\\\", \\\"{x:813,y:518,t:1526919091068};\\\", \\\"{x:814,y:518,t:1526919091085};\\\", \\\"{x:814,y:517,t:1526919091102};\\\", \\\"{x:816,y:517,t:1526919091117};\\\", \\\"{x:819,y:516,t:1526919091135};\\\", \\\"{x:824,y:513,t:1526919091150};\\\", \\\"{x:826,y:511,t:1526919091167};\\\", \\\"{x:827,y:510,t:1526919091184};\\\", \\\"{x:828,y:510,t:1526919091224};\\\", \\\"{x:831,y:510,t:1526919091256};\\\", \\\"{x:831,y:509,t:1526919091268};\\\", \\\"{x:831,y:508,t:1526919091284};\\\", \\\"{x:830,y:510,t:1526919092192};\\\", \\\"{x:830,y:512,t:1526919092201};\\\", \\\"{x:824,y:518,t:1526919092219};\\\", \\\"{x:817,y:524,t:1526919092235};\\\", \\\"{x:812,y:529,t:1526919092252};\\\", \\\"{x:810,y:530,t:1526919092271};\\\", \\\"{x:809,y:532,t:1526919092285};\\\", \\\"{x:807,y:533,t:1526919092302};\\\", \\\"{x:802,y:537,t:1526919092318};\\\", \\\"{x:799,y:540,t:1526919092335};\\\", \\\"{x:795,y:544,t:1526919092352};\\\", \\\"{x:791,y:546,t:1526919092368};\\\", \\\"{x:784,y:547,t:1526919092385};\\\", \\\"{x:773,y:551,t:1526919092402};\\\", \\\"{x:762,y:553,t:1526919092419};\\\", \\\"{x:746,y:556,t:1526919092436};\\\", \\\"{x:733,y:557,t:1526919092452};\\\", \\\"{x:721,y:558,t:1526919092469};\\\", \\\"{x:707,y:562,t:1526919092486};\\\", \\\"{x:695,y:562,t:1526919092501};\\\", \\\"{x:681,y:564,t:1526919092519};\\\", \\\"{x:671,y:566,t:1526919092536};\\\", \\\"{x:650,y:567,t:1526919092551};\\\", \\\"{x:631,y:572,t:1526919092569};\\\", \\\"{x:614,y:574,t:1526919092586};\\\", \\\"{x:592,y:578,t:1526919092602};\\\", \\\"{x:571,y:581,t:1526919092619};\\\", \\\"{x:546,y:583,t:1526919092636};\\\", \\\"{x:520,y:585,t:1526919092653};\\\", \\\"{x:498,y:587,t:1526919092670};\\\", \\\"{x:476,y:590,t:1526919092686};\\\", \\\"{x:458,y:594,t:1526919092703};\\\", \\\"{x:436,y:596,t:1526919092718};\\\", \\\"{x:414,y:598,t:1526919092736};\\\", \\\"{x:384,y:598,t:1526919092752};\\\", \\\"{x:364,y:598,t:1526919092768};\\\", \\\"{x:345,y:598,t:1526919092786};\\\", \\\"{x:323,y:598,t:1526919092802};\\\", \\\"{x:302,y:598,t:1526919092818};\\\", \\\"{x:276,y:594,t:1526919092836};\\\", \\\"{x:253,y:590,t:1526919092854};\\\", \\\"{x:235,y:588,t:1526919092868};\\\", \\\"{x:219,y:585,t:1526919092886};\\\", \\\"{x:204,y:582,t:1526919092903};\\\", \\\"{x:195,y:580,t:1526919092919};\\\", \\\"{x:185,y:577,t:1526919092937};\\\", \\\"{x:179,y:574,t:1526919092952};\\\", \\\"{x:177,y:574,t:1526919092968};\\\", \\\"{x:176,y:574,t:1526919092986};\\\", \\\"{x:175,y:573,t:1526919093003};\\\", \\\"{x:176,y:573,t:1526919093144};\\\", \\\"{x:178,y:573,t:1526919094657};\\\", \\\"{x:180,y:574,t:1526919094671};\\\", \\\"{x:182,y:575,t:1526919094688};\\\", \\\"{x:184,y:576,t:1526919094703};\\\", \\\"{x:187,y:579,t:1526919094718};\\\", \\\"{x:195,y:584,t:1526919094736};\\\", \\\"{x:203,y:587,t:1526919094753};\\\", \\\"{x:206,y:589,t:1526919094768};\\\", \\\"{x:211,y:592,t:1526919094787};\\\", \\\"{x:214,y:594,t:1526919094804};\\\", \\\"{x:219,y:595,t:1526919094820};\\\", \\\"{x:224,y:597,t:1526919094837};\\\", \\\"{x:231,y:598,t:1526919094854};\\\", \\\"{x:240,y:601,t:1526919094871};\\\", \\\"{x:253,y:603,t:1526919094888};\\\", \\\"{x:260,y:604,t:1526919094903};\\\", \\\"{x:269,y:604,t:1526919094920};\\\", \\\"{x:279,y:606,t:1526919094938};\\\", \\\"{x:287,y:606,t:1526919094954};\\\", \\\"{x:296,y:606,t:1526919094970};\\\", \\\"{x:303,y:606,t:1526919094988};\\\", \\\"{x:312,y:606,t:1526919095003};\\\", \\\"{x:329,y:602,t:1526919095021};\\\", \\\"{x:348,y:599,t:1526919095039};\\\", \\\"{x:365,y:599,t:1526919095053};\\\", \\\"{x:377,y:597,t:1526919095071};\\\", \\\"{x:384,y:594,t:1526919095088};\\\", \\\"{x:384,y:592,t:1526919095112};\\\", \\\"{x:384,y:590,t:1526919095121};\\\", \\\"{x:384,y:585,t:1526919095138};\\\", \\\"{x:383,y:577,t:1526919095154};\\\", \\\"{x:383,y:567,t:1526919095171};\\\", \\\"{x:383,y:561,t:1526919095188};\\\", \\\"{x:382,y:556,t:1526919095204};\\\", \\\"{x:382,y:554,t:1526919095221};\\\", \\\"{x:382,y:552,t:1526919095238};\\\", \\\"{x:382,y:551,t:1526919095264};\\\", \\\"{x:383,y:549,t:1526919095271};\\\", \\\"{x:385,y:549,t:1526919096383};\\\", \\\"{x:387,y:549,t:1526919096399};\\\", \\\"{x:389,y:549,t:1526919096407};\\\", \\\"{x:389,y:550,t:1526919096422};\\\", \\\"{x:390,y:550,t:1526919096438};\\\", \\\"{x:392,y:551,t:1526919096463};\\\", \\\"{x:393,y:552,t:1526919096495};\\\", \\\"{x:393,y:553,t:1526919096544};\\\", \\\"{x:394,y:555,t:1526919096560};\\\", \\\"{x:394,y:556,t:1526919096592};\\\", \\\"{x:394,y:557,t:1526919096606};\\\", \\\"{x:394,y:559,t:1526919096622};\\\", \\\"{x:394,y:561,t:1526919096639};\\\", \\\"{x:394,y:563,t:1526919096656};\\\", \\\"{x:396,y:564,t:1526919096671};\\\", \\\"{x:396,y:565,t:1526919096689};\\\", \\\"{x:396,y:567,t:1526919096706};\\\", \\\"{x:396,y:570,t:1526919096721};\\\", \\\"{x:397,y:571,t:1526919096739};\\\", \\\"{x:399,y:575,t:1526919096755};\\\", \\\"{x:401,y:578,t:1526919096772};\\\", \\\"{x:402,y:581,t:1526919096788};\\\", \\\"{x:403,y:581,t:1526919096806};\\\", \\\"{x:404,y:582,t:1526919096824};\\\", \\\"{x:404,y:584,t:1526919096855};\\\", \\\"{x:405,y:584,t:1526919096872};\\\", \\\"{x:405,y:585,t:1526919096888};\\\", \\\"{x:406,y:586,t:1526919096912};\\\", \\\"{x:406,y:587,t:1526919097064};\\\", \\\"{x:405,y:587,t:1526919097072};\\\", \\\"{x:399,y:587,t:1526919097089};\\\", \\\"{x:390,y:587,t:1526919097106};\\\", \\\"{x:381,y:587,t:1526919097123};\\\", \\\"{x:366,y:587,t:1526919097140};\\\", \\\"{x:352,y:587,t:1526919097156};\\\", \\\"{x:339,y:587,t:1526919097173};\\\", \\\"{x:330,y:587,t:1526919097189};\\\", \\\"{x:327,y:587,t:1526919097206};\\\", \\\"{x:327,y:588,t:1526919097272};\\\", \\\"{x:328,y:588,t:1526919097280};\\\", \\\"{x:335,y:589,t:1526919097289};\\\", \\\"{x:352,y:591,t:1526919097305};\\\", \\\"{x:376,y:591,t:1526919097323};\\\", \\\"{x:397,y:591,t:1526919097340};\\\", \\\"{x:417,y:591,t:1526919097356};\\\", \\\"{x:432,y:591,t:1526919097373};\\\", \\\"{x:442,y:591,t:1526919097389};\\\", \\\"{x:454,y:591,t:1526919097407};\\\", \\\"{x:466,y:589,t:1526919097423};\\\", \\\"{x:481,y:585,t:1526919097440};\\\", \\\"{x:491,y:582,t:1526919097456};\\\", \\\"{x:498,y:581,t:1526919097473};\\\", \\\"{x:512,y:579,t:1526919097491};\\\", \\\"{x:521,y:579,t:1526919097507};\\\", \\\"{x:531,y:579,t:1526919097522};\\\", \\\"{x:539,y:577,t:1526919097540};\\\", \\\"{x:545,y:577,t:1526919097556};\\\", \\\"{x:550,y:576,t:1526919097573};\\\", \\\"{x:557,y:575,t:1526919097590};\\\", \\\"{x:563,y:575,t:1526919097606};\\\", \\\"{x:571,y:575,t:1526919097623};\\\", \\\"{x:583,y:575,t:1526919097640};\\\", \\\"{x:588,y:575,t:1526919097657};\\\", \\\"{x:591,y:575,t:1526919097673};\\\", \\\"{x:594,y:575,t:1526919097691};\\\", \\\"{x:595,y:575,t:1526919097706};\\\", \\\"{x:597,y:576,t:1526919097723};\\\", \\\"{x:598,y:576,t:1526919097740};\\\", \\\"{x:603,y:577,t:1526919097757};\\\", \\\"{x:612,y:580,t:1526919097772};\\\", \\\"{x:623,y:581,t:1526919097790};\\\", \\\"{x:633,y:583,t:1526919097806};\\\", \\\"{x:642,y:586,t:1526919097823};\\\", \\\"{x:655,y:590,t:1526919097840};\\\", \\\"{x:660,y:590,t:1526919097857};\\\", \\\"{x:666,y:592,t:1526919097872};\\\", \\\"{x:675,y:592,t:1526919097889};\\\", \\\"{x:693,y:597,t:1526919097907};\\\", \\\"{x:714,y:600,t:1526919097923};\\\", \\\"{x:737,y:601,t:1526919097940};\\\", \\\"{x:755,y:603,t:1526919097957};\\\", \\\"{x:762,y:605,t:1526919097972};\\\", \\\"{x:768,y:606,t:1526919097989};\\\", \\\"{x:770,y:606,t:1526919098006};\\\", \\\"{x:774,y:606,t:1526919098022};\\\", \\\"{x:785,y:604,t:1526919098040};\\\", \\\"{x:792,y:599,t:1526919098057};\\\", \\\"{x:799,y:593,t:1526919098074};\\\", \\\"{x:802,y:587,t:1526919098089};\\\", \\\"{x:802,y:584,t:1526919098107};\\\", \\\"{x:805,y:576,t:1526919098122};\\\", \\\"{x:806,y:567,t:1526919098140};\\\", \\\"{x:806,y:558,t:1526919098157};\\\", \\\"{x:807,y:552,t:1526919098173};\\\", \\\"{x:808,y:550,t:1526919098189};\\\", \\\"{x:809,y:547,t:1526919098207};\\\", \\\"{x:813,y:543,t:1526919098223};\\\", \\\"{x:813,y:542,t:1526919098240};\\\", \\\"{x:815,y:541,t:1526919098256};\\\", \\\"{x:815,y:540,t:1526919098279};\\\", \\\"{x:816,y:539,t:1526919098290};\\\", \\\"{x:817,y:539,t:1526919098306};\\\", \\\"{x:817,y:538,t:1526919098324};\\\", \\\"{x:817,y:537,t:1526919098351};\\\", \\\"{x:818,y:537,t:1526919098368};\\\", \\\"{x:819,y:537,t:1526919098375};\\\", \\\"{x:822,y:537,t:1526919098390};\\\", \\\"{x:827,y:538,t:1526919098408};\\\", \\\"{x:829,y:538,t:1526919098423};\\\", \\\"{x:830,y:538,t:1526919098447};\\\", \\\"{x:831,y:538,t:1526919098457};\\\", \\\"{x:832,y:539,t:1526919098473};\\\", \\\"{x:833,y:539,t:1526919098511};\\\", \\\"{x:834,y:539,t:1526919098527};\\\", \\\"{x:835,y:539,t:1526919098540};\\\", \\\"{x:835,y:540,t:1526919099488};\\\", \\\"{x:835,y:541,t:1526919099520};\\\", \\\"{x:835,y:542,t:1526919099559};\\\", \\\"{x:835,y:543,t:1526919099584};\\\", \\\"{x:835,y:544,t:1526919099664};\\\", \\\"{x:834,y:546,t:1526919099880};\\\", \\\"{x:831,y:546,t:1526919099892};\\\", \\\"{x:824,y:547,t:1526919099908};\\\", \\\"{x:815,y:548,t:1526919099925};\\\", \\\"{x:810,y:549,t:1526919099941};\\\", \\\"{x:802,y:550,t:1526919099958};\\\", \\\"{x:792,y:552,t:1526919099975};\\\", \\\"{x:778,y:553,t:1526919099992};\\\", \\\"{x:769,y:554,t:1526919100008};\\\", \\\"{x:763,y:555,t:1526919100025};\\\", \\\"{x:761,y:556,t:1526919100043};\\\", \\\"{x:761,y:558,t:1526919100160};\\\", \\\"{x:763,y:560,t:1526919100175};\\\", \\\"{x:766,y:563,t:1526919100192};\\\", \\\"{x:773,y:566,t:1526919100208};\\\", \\\"{x:779,y:569,t:1526919100224};\\\", \\\"{x:784,y:570,t:1526919100242};\\\", \\\"{x:787,y:571,t:1526919100259};\\\", \\\"{x:789,y:572,t:1526919100275};\\\", \\\"{x:790,y:572,t:1526919100296};\\\", \\\"{x:791,y:573,t:1526919100309};\\\", \\\"{x:792,y:574,t:1526919100325};\\\", \\\"{x:794,y:576,t:1526919100341};\\\", \\\"{x:794,y:577,t:1526919100416};\\\", \\\"{x:792,y:578,t:1526919100425};\\\", \\\"{x:781,y:578,t:1526919100442};\\\", \\\"{x:752,y:578,t:1526919100459};\\\", \\\"{x:712,y:578,t:1526919100475};\\\", \\\"{x:646,y:578,t:1526919100491};\\\", \\\"{x:607,y:577,t:1526919100509};\\\", \\\"{x:589,y:575,t:1526919100525};\\\", \\\"{x:586,y:574,t:1526919100542};\\\", \\\"{x:586,y:572,t:1526919100632};\\\", \\\"{x:586,y:570,t:1526919100642};\\\", \\\"{x:586,y:566,t:1526919100659};\\\", \\\"{x:587,y:563,t:1526919100675};\\\", \\\"{x:589,y:559,t:1526919100693};\\\", \\\"{x:591,y:557,t:1526919100708};\\\", \\\"{x:595,y:554,t:1526919100725};\\\", \\\"{x:600,y:550,t:1526919100742};\\\", \\\"{x:602,y:549,t:1526919100759};\\\", \\\"{x:605,y:546,t:1526919100775};\\\", \\\"{x:605,y:545,t:1526919100800};\\\", \\\"{x:606,y:544,t:1526919100816};\\\", \\\"{x:607,y:543,t:1526919100832};\\\", \\\"{x:608,y:541,t:1526919100841};\\\", \\\"{x:608,y:540,t:1526919100859};\\\", \\\"{x:611,y:541,t:1526919101409};\\\", \\\"{x:611,y:544,t:1526919101426};\\\", \\\"{x:612,y:545,t:1526919101443};\\\", \\\"{x:613,y:546,t:1526919101459};\\\", \\\"{x:614,y:548,t:1526919101477};\\\", \\\"{x:616,y:549,t:1526919101493};\\\", \\\"{x:616,y:550,t:1526919101520};\\\", \\\"{x:616,y:551,t:1526919101568};\\\", \\\"{x:617,y:551,t:1526919101584};\\\", \\\"{x:617,y:552,t:1526919101602};\\\", \\\"{x:618,y:552,t:1526919101616};\\\", \\\"{x:619,y:552,t:1526919101672};\\\", \\\"{x:620,y:552,t:1526919101704};\\\", \\\"{x:622,y:554,t:1526919101719};\\\", \\\"{x:623,y:554,t:1526919101728};\\\", \\\"{x:624,y:554,t:1526919101743};\\\", \\\"{x:629,y:555,t:1526919101760};\\\", \\\"{x:630,y:555,t:1526919101777};\\\", \\\"{x:631,y:556,t:1526919102650};\\\", \\\"{x:630,y:556,t:1526919103176};\\\", \\\"{x:629,y:556,t:1526919107153};\\\", \\\"{x:628,y:556,t:1526919107168};\\\", \\\"{x:627,y:556,t:1526919108128};\\\", \\\"{x:626,y:557,t:1526919109055};\\\", \\\"{x:625,y:558,t:1526919109392};\\\", \\\"{x:624,y:559,t:1526919109975};\\\", \\\"{x:624,y:560,t:1526919109999};\\\", \\\"{x:624,y:561,t:1526919110014};\\\", \\\"{x:624,y:564,t:1526919110032};\\\", \\\"{x:624,y:566,t:1526919110049};\\\", \\\"{x:624,y:567,t:1526919110064};\\\", \\\"{x:624,y:571,t:1526919110084};\\\", \\\"{x:622,y:577,t:1526919110100};\\\", \\\"{x:620,y:585,t:1526919110116};\\\", \\\"{x:615,y:596,t:1526919110133};\\\", \\\"{x:611,y:605,t:1526919110150};\\\", \\\"{x:607,y:614,t:1526919110166};\\\", \\\"{x:602,y:629,t:1526919110184};\\\", \\\"{x:600,y:634,t:1526919110199};\\\", \\\"{x:594,y:644,t:1526919110216};\\\", \\\"{x:589,y:659,t:1526919110233};\\\", \\\"{x:582,y:667,t:1526919110250};\\\", \\\"{x:576,y:678,t:1526919110266};\\\", \\\"{x:568,y:690,t:1526919110283};\\\", \\\"{x:566,y:697,t:1526919110301};\\\", \\\"{x:564,y:703,t:1526919110316};\\\", \\\"{x:563,y:707,t:1526919110334};\\\", \\\"{x:563,y:713,t:1526919110350};\\\", \\\"{x:558,y:724,t:1526919110368};\\\", \\\"{x:554,y:728,t:1526919110383};\\\", \\\"{x:553,y:731,t:1526919110400};\\\", \\\"{x:553,y:732,t:1526919110417};\\\", \\\"{x:552,y:732,t:1526919110433};\\\", \\\"{x:552,y:733,t:1526919110450};\\\", \\\"{x:551,y:735,t:1526919110466};\\\", \\\"{x:549,y:738,t:1526919110483};\\\", \\\"{x:548,y:740,t:1526919110501};\\\", \\\"{x:547,y:741,t:1526919110516};\\\", \\\"{x:547,y:742,t:1526919111272};\\\", \\\"{x:546,y:742,t:1526919111328};\\\" ] }, { \\\"rt\\\": 34236, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 386984, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -01 PM-02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:741,t:1526919112761};\\\", \\\"{x:543,y:741,t:1526919112792};\\\", \\\"{x:542,y:740,t:1526919112805};\\\", \\\"{x:541,y:737,t:1526919112821};\\\", \\\"{x:541,y:735,t:1526919112838};\\\", \\\"{x:538,y:732,t:1526919112855};\\\", \\\"{x:536,y:725,t:1526919112870};\\\", \\\"{x:529,y:708,t:1526919112889};\\\", \\\"{x:519,y:690,t:1526919112904};\\\", \\\"{x:513,y:681,t:1526919112918};\\\", \\\"{x:495,y:647,t:1526919112936};\\\", \\\"{x:479,y:620,t:1526919112953};\\\", \\\"{x:453,y:579,t:1526919112970};\\\", \\\"{x:429,y:541,t:1526919112986};\\\", \\\"{x:405,y:516,t:1526919113004};\\\", \\\"{x:382,y:500,t:1526919113020};\\\", \\\"{x:359,y:487,t:1526919113035};\\\", \\\"{x:341,y:476,t:1526919113053};\\\", \\\"{x:325,y:468,t:1526919113069};\\\", \\\"{x:310,y:459,t:1526919113085};\\\", \\\"{x:297,y:452,t:1526919113103};\\\", \\\"{x:287,y:447,t:1526919113119};\\\", \\\"{x:285,y:446,t:1526919113136};\\\", \\\"{x:284,y:446,t:1526919113152};\\\", \\\"{x:284,y:447,t:1526919113336};\\\", \\\"{x:285,y:448,t:1526919113343};\\\", \\\"{x:287,y:450,t:1526919113353};\\\", \\\"{x:295,y:454,t:1526919113370};\\\", \\\"{x:298,y:455,t:1526919113387};\\\", \\\"{x:301,y:456,t:1526919113403};\\\", \\\"{x:302,y:456,t:1526919113421};\\\", \\\"{x:306,y:457,t:1526919113438};\\\", \\\"{x:308,y:458,t:1526919113455};\\\", \\\"{x:313,y:458,t:1526919113471};\\\", \\\"{x:318,y:458,t:1526919113487};\\\", \\\"{x:319,y:458,t:1526919113505};\\\", \\\"{x:322,y:458,t:1526919113521};\\\", \\\"{x:325,y:458,t:1526919113537};\\\", \\\"{x:326,y:458,t:1526919113554};\\\", \\\"{x:329,y:458,t:1526919113572};\\\", \\\"{x:331,y:458,t:1526919113588};\\\", \\\"{x:335,y:458,t:1526919113605};\\\", \\\"{x:336,y:458,t:1526919113622};\\\", \\\"{x:339,y:458,t:1526919113638};\\\", \\\"{x:345,y:458,t:1526919113656};\\\", \\\"{x:351,y:458,t:1526919113671};\\\", \\\"{x:360,y:458,t:1526919113688};\\\", \\\"{x:368,y:458,t:1526919113705};\\\", \\\"{x:377,y:458,t:1526919113721};\\\", \\\"{x:384,y:458,t:1526919113738};\\\", \\\"{x:390,y:456,t:1526919113755};\\\", \\\"{x:401,y:452,t:1526919113772};\\\", \\\"{x:407,y:452,t:1526919113788};\\\", \\\"{x:415,y:450,t:1526919113805};\\\", \\\"{x:422,y:450,t:1526919113822};\\\", \\\"{x:429,y:449,t:1526919113839};\\\", \\\"{x:432,y:448,t:1526919113856};\\\", \\\"{x:433,y:448,t:1526919113873};\\\", \\\"{x:434,y:448,t:1526919113903};\\\", \\\"{x:435,y:448,t:1526919113927};\\\", \\\"{x:436,y:448,t:1526919114225};\\\", \\\"{x:438,y:448,t:1526919114240};\\\", \\\"{x:440,y:449,t:1526919114258};\\\", \\\"{x:441,y:449,t:1526919114274};\\\", \\\"{x:442,y:450,t:1526919114292};\\\", \\\"{x:443,y:450,t:1526919114351};\\\", \\\"{x:444,y:450,t:1526919114367};\\\", \\\"{x:445,y:450,t:1526919114375};\\\", \\\"{x:446,y:452,t:1526919114391};\\\", \\\"{x:447,y:452,t:1526919114528};\\\", \\\"{x:449,y:454,t:1526919114544};\\\", \\\"{x:449,y:455,t:1526919114559};\\\", \\\"{x:451,y:455,t:1526919114609};\\\", \\\"{x:456,y:454,t:1526919114626};\\\", \\\"{x:458,y:452,t:1526919115543};\\\", \\\"{x:459,y:452,t:1526919115552};\\\", \\\"{x:462,y:452,t:1526919115563};\\\", \\\"{x:466,y:452,t:1526919115579};\\\", \\\"{x:472,y:454,t:1526919115596};\\\", \\\"{x:476,y:456,t:1526919115613};\\\", \\\"{x:478,y:457,t:1526919115629};\\\", \\\"{x:480,y:457,t:1526919115646};\\\", \\\"{x:484,y:459,t:1526919115663};\\\", \\\"{x:486,y:460,t:1526919115680};\\\", \\\"{x:488,y:460,t:1526919115697};\\\", \\\"{x:489,y:461,t:1526919115714};\\\", \\\"{x:492,y:462,t:1526919115730};\\\", \\\"{x:494,y:463,t:1526919115747};\\\", \\\"{x:496,y:463,t:1526919115763};\\\", \\\"{x:498,y:464,t:1526919115780};\\\", \\\"{x:500,y:465,t:1526919115797};\\\", \\\"{x:501,y:466,t:1526919115814};\\\", \\\"{x:503,y:466,t:1526919115830};\\\", \\\"{x:505,y:468,t:1526919115847};\\\", \\\"{x:510,y:470,t:1526919115865};\\\", \\\"{x:513,y:471,t:1526919115880};\\\", \\\"{x:516,y:472,t:1526919115897};\\\", \\\"{x:519,y:474,t:1526919115915};\\\", \\\"{x:522,y:475,t:1526919115931};\\\", \\\"{x:524,y:476,t:1526919115948};\\\", \\\"{x:527,y:477,t:1526919115964};\\\", \\\"{x:529,y:477,t:1526919115981};\\\", \\\"{x:533,y:480,t:1526919115998};\\\", \\\"{x:536,y:480,t:1526919116014};\\\", \\\"{x:542,y:481,t:1526919116031};\\\", \\\"{x:547,y:481,t:1526919116048};\\\", \\\"{x:549,y:483,t:1526919116065};\\\", \\\"{x:553,y:483,t:1526919116082};\\\", \\\"{x:556,y:483,t:1526919116098};\\\", \\\"{x:560,y:484,t:1526919116116};\\\", \\\"{x:564,y:484,t:1526919116133};\\\", \\\"{x:568,y:485,t:1526919116149};\\\", \\\"{x:571,y:485,t:1526919116166};\\\", \\\"{x:576,y:485,t:1526919116182};\\\", \\\"{x:581,y:486,t:1526919116199};\\\", \\\"{x:584,y:486,t:1526919116216};\\\", \\\"{x:586,y:487,t:1526919116234};\\\", \\\"{x:587,y:487,t:1526919116303};\\\", \\\"{x:588,y:487,t:1526919116328};\\\", \\\"{x:590,y:486,t:1526919116392};\\\", \\\"{x:591,y:485,t:1526919116408};\\\", \\\"{x:591,y:484,t:1526919116455};\\\", \\\"{x:592,y:483,t:1526919116471};\\\", \\\"{x:593,y:481,t:1526919116488};\\\", \\\"{x:594,y:480,t:1526919116519};\\\", \\\"{x:595,y:480,t:1526919116535};\\\", \\\"{x:595,y:479,t:1526919116575};\\\", \\\"{x:596,y:479,t:1526919116588};\\\", \\\"{x:598,y:479,t:1526919116688};\\\", \\\"{x:598,y:478,t:1526919116695};\\\", \\\"{x:601,y:477,t:1526919117264};\\\", \\\"{x:602,y:477,t:1526919117272};\\\", \\\"{x:606,y:477,t:1526919117289};\\\", \\\"{x:609,y:477,t:1526919117305};\\\", \\\"{x:614,y:476,t:1526919117322};\\\", \\\"{x:617,y:476,t:1526919117340};\\\", \\\"{x:619,y:476,t:1526919117356};\\\", \\\"{x:621,y:476,t:1526919117372};\\\", \\\"{x:626,y:476,t:1526919117390};\\\", \\\"{x:631,y:476,t:1526919117406};\\\", \\\"{x:633,y:476,t:1526919117422};\\\", \\\"{x:637,y:476,t:1526919117439};\\\", \\\"{x:639,y:476,t:1526919117456};\\\", \\\"{x:640,y:476,t:1526919117473};\\\", \\\"{x:645,y:476,t:1526919117490};\\\", \\\"{x:649,y:476,t:1526919117505};\\\", \\\"{x:653,y:476,t:1526919117522};\\\", \\\"{x:660,y:476,t:1526919117540};\\\", \\\"{x:664,y:476,t:1526919117556};\\\", \\\"{x:670,y:476,t:1526919117573};\\\", \\\"{x:675,y:476,t:1526919117589};\\\", \\\"{x:679,y:476,t:1526919117606};\\\", \\\"{x:681,y:476,t:1526919117622};\\\", \\\"{x:682,y:476,t:1526919117640};\\\", \\\"{x:684,y:476,t:1526919117656};\\\", \\\"{x:685,y:476,t:1526919117672};\\\", \\\"{x:688,y:476,t:1526919117690};\\\", \\\"{x:691,y:476,t:1526919117707};\\\", \\\"{x:692,y:476,t:1526919117723};\\\", \\\"{x:694,y:476,t:1526919117740};\\\", \\\"{x:695,y:476,t:1526919117857};\\\", \\\"{x:695,y:475,t:1526919117874};\\\", \\\"{x:696,y:475,t:1526919117890};\\\", \\\"{x:697,y:475,t:1526919117907};\\\", \\\"{x:697,y:474,t:1526919117923};\\\", \\\"{x:698,y:474,t:1526919117940};\\\", \\\"{x:700,y:473,t:1526919117984};\\\", \\\"{x:702,y:472,t:1526919118008};\\\", \\\"{x:703,y:472,t:1526919118032};\\\", \\\"{x:703,y:471,t:1526919118048};\\\", \\\"{x:705,y:470,t:1526919118080};\\\", \\\"{x:706,y:470,t:1526919118090};\\\", \\\"{x:709,y:470,t:1526919118107};\\\", \\\"{x:715,y:470,t:1526919118124};\\\", \\\"{x:719,y:470,t:1526919118140};\\\", \\\"{x:722,y:470,t:1526919118157};\\\", \\\"{x:726,y:470,t:1526919118174};\\\", \\\"{x:731,y:470,t:1526919118190};\\\", \\\"{x:736,y:470,t:1526919118207};\\\", \\\"{x:748,y:470,t:1526919118224};\\\", \\\"{x:757,y:470,t:1526919118240};\\\", \\\"{x:770,y:470,t:1526919118257};\\\", \\\"{x:780,y:470,t:1526919118274};\\\", \\\"{x:785,y:470,t:1526919118291};\\\", \\\"{x:790,y:470,t:1526919118307};\\\", \\\"{x:795,y:470,t:1526919118324};\\\", \\\"{x:800,y:470,t:1526919118340};\\\", \\\"{x:811,y:471,t:1526919118357};\\\", \\\"{x:822,y:471,t:1526919118374};\\\", \\\"{x:834,y:472,t:1526919118391};\\\", \\\"{x:846,y:474,t:1526919118406};\\\", \\\"{x:854,y:476,t:1526919118423};\\\", \\\"{x:858,y:476,t:1526919118441};\\\", \\\"{x:865,y:477,t:1526919118456};\\\", \\\"{x:875,y:478,t:1526919118473};\\\", \\\"{x:892,y:480,t:1526919118490};\\\", \\\"{x:905,y:481,t:1526919118506};\\\", \\\"{x:924,y:483,t:1526919118523};\\\", \\\"{x:934,y:486,t:1526919118541};\\\", \\\"{x:944,y:488,t:1526919118557};\\\", \\\"{x:953,y:489,t:1526919118574};\\\", \\\"{x:958,y:491,t:1526919118591};\\\", \\\"{x:961,y:492,t:1526919118606};\\\", \\\"{x:968,y:494,t:1526919118623};\\\", \\\"{x:975,y:496,t:1526919118640};\\\", \\\"{x:985,y:500,t:1526919118656};\\\", \\\"{x:999,y:508,t:1526919118673};\\\", \\\"{x:1014,y:517,t:1526919118690};\\\", \\\"{x:1027,y:525,t:1526919118708};\\\", \\\"{x:1040,y:534,t:1526919118724};\\\", \\\"{x:1052,y:552,t:1526919118740};\\\", \\\"{x:1056,y:557,t:1526919118757};\\\", \\\"{x:1058,y:559,t:1526919119440};\\\", \\\"{x:1059,y:559,t:1526919119505};\\\", \\\"{x:1062,y:562,t:1526919119517};\\\", \\\"{x:1068,y:571,t:1526919119533};\\\", \\\"{x:1082,y:580,t:1526919119550};\\\", \\\"{x:1085,y:583,t:1526919119567};\\\", \\\"{x:1094,y:587,t:1526919119584};\\\", \\\"{x:1098,y:587,t:1526919119600};\\\", \\\"{x:1122,y:589,t:1526919119616};\\\", \\\"{x:1139,y:590,t:1526919119633};\\\", \\\"{x:1160,y:594,t:1526919119650};\\\", \\\"{x:1181,y:596,t:1526919119666};\\\", \\\"{x:1198,y:599,t:1526919119684};\\\", \\\"{x:1214,y:600,t:1526919119701};\\\", \\\"{x:1230,y:601,t:1526919119716};\\\", \\\"{x:1244,y:603,t:1526919119733};\\\", \\\"{x:1262,y:603,t:1526919119751};\\\", \\\"{x:1276,y:604,t:1526919119766};\\\", \\\"{x:1282,y:605,t:1526919119784};\\\", \\\"{x:1287,y:605,t:1526919119800};\\\", \\\"{x:1288,y:605,t:1526919119832};\\\", \\\"{x:1288,y:606,t:1526919119840};\\\", \\\"{x:1290,y:607,t:1526919119851};\\\", \\\"{x:1290,y:608,t:1526919119866};\\\", \\\"{x:1290,y:613,t:1526919119884};\\\", \\\"{x:1290,y:622,t:1526919119900};\\\", \\\"{x:1290,y:638,t:1526919119917};\\\", \\\"{x:1290,y:661,t:1526919119933};\\\", \\\"{x:1289,y:683,t:1526919119951};\\\", \\\"{x:1287,y:699,t:1526919119967};\\\", \\\"{x:1287,y:711,t:1526919119986};\\\", \\\"{x:1287,y:717,t:1526919120000};\\\", \\\"{x:1289,y:723,t:1526919120017};\\\", \\\"{x:1297,y:742,t:1526919120034};\\\", \\\"{x:1306,y:762,t:1526919120050};\\\", \\\"{x:1317,y:776,t:1526919120068};\\\", \\\"{x:1325,y:787,t:1526919120084};\\\", \\\"{x:1331,y:797,t:1526919120101};\\\", \\\"{x:1338,y:806,t:1526919120117};\\\", \\\"{x:1342,y:813,t:1526919120134};\\\", \\\"{x:1344,y:819,t:1526919120150};\\\", \\\"{x:1348,y:824,t:1526919120168};\\\", \\\"{x:1355,y:833,t:1526919120183};\\\", \\\"{x:1364,y:844,t:1526919120200};\\\", \\\"{x:1370,y:854,t:1526919120218};\\\", \\\"{x:1377,y:865,t:1526919120233};\\\", \\\"{x:1382,y:876,t:1526919120250};\\\", \\\"{x:1390,y:889,t:1526919120267};\\\", \\\"{x:1395,y:905,t:1526919120284};\\\", \\\"{x:1398,y:919,t:1526919120301};\\\", \\\"{x:1398,y:925,t:1526919120318};\\\", \\\"{x:1400,y:925,t:1526919120969};\\\", \\\"{x:1401,y:925,t:1526919120985};\\\", \\\"{x:1402,y:927,t:1526919121002};\\\", \\\"{x:1402,y:928,t:1526919121017};\\\", \\\"{x:1403,y:928,t:1526919121073};\\\", \\\"{x:1406,y:928,t:1526919121084};\\\", \\\"{x:1412,y:928,t:1526919121102};\\\", \\\"{x:1418,y:928,t:1526919121117};\\\", \\\"{x:1423,y:929,t:1526919121135};\\\", \\\"{x:1431,y:933,t:1526919121151};\\\", \\\"{x:1437,y:937,t:1526919121168};\\\", \\\"{x:1448,y:939,t:1526919121186};\\\", \\\"{x:1453,y:940,t:1526919121202};\\\", \\\"{x:1466,y:945,t:1526919121218};\\\", \\\"{x:1477,y:947,t:1526919121235};\\\", \\\"{x:1484,y:949,t:1526919121252};\\\", \\\"{x:1490,y:951,t:1526919121268};\\\", \\\"{x:1495,y:952,t:1526919121285};\\\", \\\"{x:1502,y:953,t:1526919121302};\\\", \\\"{x:1503,y:955,t:1526919121318};\\\", \\\"{x:1508,y:956,t:1526919121345};\\\", \\\"{x:1509,y:957,t:1526919121353};\\\", \\\"{x:1519,y:960,t:1526919121368};\\\", \\\"{x:1522,y:962,t:1526919121385};\\\", \\\"{x:1530,y:964,t:1526919121402};\\\", \\\"{x:1531,y:964,t:1526919121419};\\\", \\\"{x:1534,y:967,t:1526919121435};\\\", \\\"{x:1537,y:968,t:1526919121452};\\\", \\\"{x:1538,y:968,t:1526919121473};\\\", \\\"{x:1539,y:968,t:1526919121485};\\\", \\\"{x:1541,y:968,t:1526919121502};\\\", \\\"{x:1541,y:967,t:1526919121553};\\\", \\\"{x:1541,y:966,t:1526919121585};\\\", \\\"{x:1537,y:965,t:1526919121601};\\\", \\\"{x:1526,y:962,t:1526919121618};\\\", \\\"{x:1500,y:960,t:1526919121635};\\\", \\\"{x:1466,y:954,t:1526919121652};\\\", \\\"{x:1427,y:948,t:1526919121668};\\\", \\\"{x:1387,y:941,t:1526919121684};\\\", \\\"{x:1358,y:938,t:1526919121701};\\\", \\\"{x:1340,y:936,t:1526919121719};\\\", \\\"{x:1331,y:936,t:1526919121735};\\\", \\\"{x:1325,y:936,t:1526919121752};\\\", \\\"{x:1319,y:936,t:1526919121768};\\\", \\\"{x:1316,y:937,t:1526919121785};\\\", \\\"{x:1310,y:938,t:1526919121801};\\\", \\\"{x:1307,y:939,t:1526919121818};\\\", \\\"{x:1304,y:940,t:1526919121835};\\\", \\\"{x:1303,y:941,t:1526919121852};\\\", \\\"{x:1302,y:942,t:1526919121868};\\\", \\\"{x:1301,y:944,t:1526919121885};\\\", \\\"{x:1301,y:947,t:1526919121902};\\\", \\\"{x:1301,y:949,t:1526919121919};\\\", \\\"{x:1301,y:950,t:1526919121936};\\\", \\\"{x:1301,y:952,t:1526919121952};\\\", \\\"{x:1301,y:956,t:1526919121968};\\\", \\\"{x:1301,y:959,t:1526919121986};\\\", \\\"{x:1301,y:963,t:1526919122002};\\\", \\\"{x:1303,y:965,t:1526919122019};\\\", \\\"{x:1303,y:967,t:1526919122036};\\\", \\\"{x:1304,y:967,t:1526919122051};\\\", \\\"{x:1305,y:968,t:1526919122069};\\\", \\\"{x:1306,y:968,t:1526919122104};\\\", \\\"{x:1307,y:970,t:1526919122118};\\\", \\\"{x:1309,y:970,t:1526919122136};\\\", \\\"{x:1309,y:971,t:1526919122152};\\\", \\\"{x:1312,y:970,t:1526919122217};\\\", \\\"{x:1313,y:970,t:1526919122225};\\\", \\\"{x:1313,y:969,t:1526919122236};\\\", \\\"{x:1316,y:966,t:1526919122253};\\\", \\\"{x:1318,y:962,t:1526919122269};\\\", \\\"{x:1321,y:957,t:1526919122285};\\\", \\\"{x:1323,y:955,t:1526919122303};\\\", \\\"{x:1324,y:951,t:1526919122318};\\\", \\\"{x:1327,y:947,t:1526919122336};\\\", \\\"{x:1330,y:942,t:1526919122352};\\\", \\\"{x:1331,y:938,t:1526919122369};\\\", \\\"{x:1335,y:932,t:1526919122385};\\\", \\\"{x:1338,y:927,t:1526919122403};\\\", \\\"{x:1342,y:923,t:1526919122419};\\\", \\\"{x:1344,y:920,t:1526919122436};\\\", \\\"{x:1346,y:919,t:1526919122453};\\\", \\\"{x:1347,y:916,t:1526919122469};\\\", \\\"{x:1350,y:913,t:1526919122485};\\\", \\\"{x:1354,y:909,t:1526919122503};\\\", \\\"{x:1357,y:906,t:1526919122519};\\\", \\\"{x:1363,y:902,t:1526919122536};\\\", \\\"{x:1371,y:896,t:1526919122553};\\\", \\\"{x:1378,y:891,t:1526919122569};\\\", \\\"{x:1384,y:887,t:1526919122586};\\\", \\\"{x:1392,y:881,t:1526919122602};\\\", \\\"{x:1399,y:876,t:1526919122618};\\\", \\\"{x:1403,y:872,t:1526919122636};\\\", \\\"{x:1409,y:867,t:1526919122653};\\\", \\\"{x:1412,y:864,t:1526919122670};\\\", \\\"{x:1417,y:860,t:1526919122686};\\\", \\\"{x:1423,y:856,t:1526919122703};\\\", \\\"{x:1429,y:852,t:1526919122720};\\\", \\\"{x:1434,y:849,t:1526919122736};\\\", \\\"{x:1440,y:846,t:1526919122753};\\\", \\\"{x:1444,y:842,t:1526919122770};\\\", \\\"{x:1448,y:840,t:1526919122786};\\\", \\\"{x:1452,y:838,t:1526919122803};\\\", \\\"{x:1456,y:836,t:1526919122820};\\\", \\\"{x:1460,y:833,t:1526919122836};\\\", \\\"{x:1463,y:830,t:1526919122853};\\\", \\\"{x:1466,y:826,t:1526919122870};\\\", \\\"{x:1469,y:820,t:1526919122886};\\\", \\\"{x:1474,y:809,t:1526919122903};\\\", \\\"{x:1475,y:801,t:1526919122920};\\\", \\\"{x:1477,y:791,t:1526919122936};\\\", \\\"{x:1480,y:773,t:1526919122953};\\\", \\\"{x:1483,y:761,t:1526919122970};\\\", \\\"{x:1483,y:749,t:1526919122986};\\\", \\\"{x:1484,y:741,t:1526919123003};\\\", \\\"{x:1484,y:737,t:1526919123020};\\\", \\\"{x:1485,y:732,t:1526919123036};\\\", \\\"{x:1486,y:729,t:1526919123053};\\\", \\\"{x:1486,y:728,t:1526919123070};\\\", \\\"{x:1486,y:726,t:1526919123153};\\\", \\\"{x:1485,y:724,t:1526919123170};\\\", \\\"{x:1477,y:718,t:1526919123187};\\\", \\\"{x:1467,y:716,t:1526919123203};\\\", \\\"{x:1454,y:714,t:1526919123220};\\\", \\\"{x:1442,y:714,t:1526919123237};\\\", \\\"{x:1435,y:714,t:1526919123253};\\\", \\\"{x:1430,y:714,t:1526919123270};\\\", \\\"{x:1429,y:714,t:1526919123288};\\\", \\\"{x:1426,y:715,t:1526919123304};\\\", \\\"{x:1424,y:717,t:1526919123321};\\\", \\\"{x:1420,y:720,t:1526919123337};\\\", \\\"{x:1419,y:720,t:1526919123353};\\\", \\\"{x:1417,y:722,t:1526919123370};\\\", \\\"{x:1415,y:722,t:1526919123387};\\\", \\\"{x:1411,y:726,t:1526919123403};\\\", \\\"{x:1408,y:730,t:1526919123420};\\\", \\\"{x:1400,y:737,t:1526919123437};\\\", \\\"{x:1395,y:746,t:1526919123453};\\\", \\\"{x:1390,y:755,t:1526919123470};\\\", \\\"{x:1385,y:766,t:1526919123487};\\\", \\\"{x:1380,y:778,t:1526919123504};\\\", \\\"{x:1377,y:791,t:1526919123520};\\\", \\\"{x:1373,y:814,t:1526919123537};\\\", \\\"{x:1369,y:829,t:1526919123554};\\\", \\\"{x:1369,y:831,t:1526919123571};\\\", \\\"{x:1368,y:833,t:1526919123587};\\\", \\\"{x:1367,y:834,t:1526919123673};\\\", \\\"{x:1366,y:836,t:1526919123689};\\\", \\\"{x:1365,y:840,t:1526919123704};\\\", \\\"{x:1365,y:844,t:1526919123720};\\\", \\\"{x:1365,y:858,t:1526919123737};\\\", \\\"{x:1365,y:876,t:1526919123755};\\\", \\\"{x:1365,y:893,t:1526919123771};\\\", \\\"{x:1365,y:914,t:1526919123787};\\\", \\\"{x:1365,y:929,t:1526919123804};\\\", \\\"{x:1365,y:934,t:1526919123820};\\\", \\\"{x:1365,y:935,t:1526919123837};\\\", \\\"{x:1365,y:936,t:1526919123854};\\\", \\\"{x:1365,y:937,t:1526919123871};\\\", \\\"{x:1365,y:938,t:1526919123887};\\\", \\\"{x:1365,y:939,t:1526919123904};\\\", \\\"{x:1365,y:940,t:1526919124105};\\\", \\\"{x:1365,y:941,t:1526919124121};\\\", \\\"{x:1366,y:944,t:1526919124138};\\\", \\\"{x:1366,y:946,t:1526919124154};\\\", \\\"{x:1367,y:949,t:1526919124171};\\\", \\\"{x:1369,y:952,t:1526919124187};\\\", \\\"{x:1370,y:953,t:1526919124204};\\\", \\\"{x:1370,y:954,t:1526919124233};\\\", \\\"{x:1371,y:955,t:1526919124241};\\\", \\\"{x:1371,y:956,t:1526919124265};\\\", \\\"{x:1372,y:956,t:1526919124273};\\\", \\\"{x:1373,y:957,t:1526919124297};\\\", \\\"{x:1374,y:957,t:1526919124337};\\\", \\\"{x:1375,y:957,t:1526919124354};\\\", \\\"{x:1377,y:958,t:1526919124371};\\\", \\\"{x:1379,y:958,t:1526919124392};\\\", \\\"{x:1380,y:958,t:1526919124408};\\\", \\\"{x:1381,y:958,t:1526919124420};\\\", \\\"{x:1382,y:958,t:1526919124436};\\\", \\\"{x:1384,y:958,t:1526919124453};\\\", \\\"{x:1388,y:958,t:1526919124471};\\\", \\\"{x:1390,y:958,t:1526919124488};\\\", \\\"{x:1396,y:958,t:1526919124503};\\\", \\\"{x:1402,y:958,t:1526919124521};\\\", \\\"{x:1405,y:958,t:1526919124537};\\\", \\\"{x:1408,y:958,t:1526919124554};\\\", \\\"{x:1409,y:958,t:1526919124571};\\\", \\\"{x:1410,y:958,t:1526919124897};\\\", \\\"{x:1411,y:958,t:1526919124904};\\\", \\\"{x:1412,y:958,t:1526919124921};\\\", \\\"{x:1414,y:958,t:1526919124945};\\\", \\\"{x:1415,y:958,t:1526919124955};\\\", \\\"{x:1416,y:958,t:1526919124986};\\\", \\\"{x:1417,y:958,t:1526919124993};\\\", \\\"{x:1418,y:958,t:1526919125081};\\\", \\\"{x:1419,y:958,t:1526919125113};\\\", \\\"{x:1420,y:958,t:1526919125128};\\\", \\\"{x:1422,y:958,t:1526919125144};\\\", \\\"{x:1422,y:959,t:1526919125155};\\\", \\\"{x:1423,y:960,t:1526919125171};\\\", \\\"{x:1425,y:961,t:1526919125187};\\\", \\\"{x:1425,y:962,t:1526919125205};\\\", \\\"{x:1426,y:963,t:1526919125222};\\\", \\\"{x:1426,y:964,t:1526919125264};\\\", \\\"{x:1426,y:965,t:1526919125280};\\\", \\\"{x:1427,y:965,t:1526919125305};\\\", \\\"{x:1427,y:966,t:1526919125344};\\\", \\\"{x:1427,y:967,t:1526919125368};\\\", \\\"{x:1427,y:968,t:1526919125376};\\\", \\\"{x:1427,y:969,t:1526919125464};\\\", \\\"{x:1427,y:970,t:1526919125544};\\\", \\\"{x:1428,y:971,t:1526919131569};\\\", \\\"{x:1430,y:972,t:1526919131585};\\\", \\\"{x:1433,y:972,t:1526919131593};\\\", \\\"{x:1437,y:974,t:1526919131610};\\\", \\\"{x:1439,y:974,t:1526919131626};\\\", \\\"{x:1440,y:975,t:1526919131643};\\\", \\\"{x:1441,y:975,t:1526919131801};\\\", \\\"{x:1442,y:975,t:1526919131816};\\\", \\\"{x:1443,y:975,t:1526919131826};\\\", \\\"{x:1444,y:975,t:1526919131843};\\\", \\\"{x:1446,y:975,t:1526919131860};\\\", \\\"{x:1447,y:975,t:1526919131877};\\\", \\\"{x:1448,y:975,t:1526919131893};\\\", \\\"{x:1450,y:975,t:1526919131910};\\\", \\\"{x:1451,y:975,t:1526919131927};\\\", \\\"{x:1452,y:975,t:1526919131943};\\\", \\\"{x:1453,y:975,t:1526919131960};\\\", \\\"{x:1454,y:975,t:1526919131977};\\\", \\\"{x:1455,y:975,t:1526919131993};\\\", \\\"{x:1457,y:975,t:1526919132010};\\\", \\\"{x:1459,y:975,t:1526919132027};\\\", \\\"{x:1460,y:975,t:1526919132043};\\\", \\\"{x:1462,y:975,t:1526919132061};\\\", \\\"{x:1463,y:975,t:1526919132104};\\\", \\\"{x:1464,y:975,t:1526919132128};\\\", \\\"{x:1465,y:975,t:1526919132152};\\\", \\\"{x:1466,y:975,t:1526919132249};\\\", \\\"{x:1468,y:975,t:1526919132344};\\\", \\\"{x:1469,y:974,t:1526919132481};\\\", \\\"{x:1470,y:973,t:1526919132568};\\\", \\\"{x:1471,y:973,t:1526919132608};\\\", \\\"{x:1472,y:972,t:1526919132624};\\\", \\\"{x:1474,y:972,t:1526919135160};\\\", \\\"{x:1475,y:973,t:1526919135168};\\\", \\\"{x:1476,y:975,t:1526919135179};\\\", \\\"{x:1476,y:980,t:1526919135196};\\\", \\\"{x:1476,y:983,t:1526919135212};\\\", \\\"{x:1478,y:986,t:1526919135229};\\\", \\\"{x:1478,y:989,t:1526919135246};\\\", \\\"{x:1478,y:990,t:1526919135262};\\\", \\\"{x:1478,y:992,t:1526919135279};\\\", \\\"{x:1477,y:999,t:1526919135295};\\\", \\\"{x:1477,y:1004,t:1526919135312};\\\", \\\"{x:1477,y:1007,t:1526919135329};\\\", \\\"{x:1477,y:1009,t:1526919135346};\\\", \\\"{x:1476,y:1009,t:1526919135496};\\\", \\\"{x:1476,y:1006,t:1526919135513};\\\", \\\"{x:1475,y:1002,t:1526919135529};\\\", \\\"{x:1473,y:998,t:1526919135546};\\\", \\\"{x:1472,y:996,t:1526919135563};\\\", \\\"{x:1472,y:994,t:1526919135579};\\\", \\\"{x:1471,y:992,t:1526919135596};\\\", \\\"{x:1471,y:990,t:1526919135613};\\\", \\\"{x:1470,y:989,t:1526919135629};\\\", \\\"{x:1469,y:986,t:1526919135647};\\\", \\\"{x:1468,y:986,t:1526919135664};\\\", \\\"{x:1468,y:984,t:1526919135679};\\\", \\\"{x:1467,y:983,t:1526919135696};\\\", \\\"{x:1467,y:982,t:1526919135714};\\\", \\\"{x:1466,y:981,t:1526919135729};\\\", \\\"{x:1466,y:980,t:1526919135746};\\\", \\\"{x:1466,y:979,t:1526919135763};\\\", \\\"{x:1465,y:978,t:1526919135780};\\\", \\\"{x:1464,y:976,t:1526919135796};\\\", \\\"{x:1464,y:975,t:1526919135813};\\\", \\\"{x:1464,y:974,t:1526919135830};\\\", \\\"{x:1463,y:973,t:1526919135848};\\\", \\\"{x:1463,y:972,t:1526919135863};\\\", \\\"{x:1462,y:970,t:1526919135880};\\\", \\\"{x:1461,y:968,t:1526919135896};\\\", \\\"{x:1461,y:967,t:1526919135920};\\\", \\\"{x:1461,y:965,t:1526919135930};\\\", \\\"{x:1461,y:964,t:1526919135952};\\\", \\\"{x:1459,y:963,t:1526919135963};\\\", \\\"{x:1459,y:962,t:1526919135980};\\\", \\\"{x:1459,y:960,t:1526919135996};\\\", \\\"{x:1458,y:959,t:1526919136015};\\\", \\\"{x:1458,y:958,t:1526919136048};\\\", \\\"{x:1458,y:957,t:1526919136072};\\\", \\\"{x:1458,y:956,t:1526919136088};\\\", \\\"{x:1458,y:951,t:1526919137032};\\\", \\\"{x:1458,y:944,t:1526919137047};\\\", \\\"{x:1459,y:927,t:1526919137064};\\\", \\\"{x:1461,y:908,t:1526919137081};\\\", \\\"{x:1461,y:886,t:1526919137097};\\\", \\\"{x:1459,y:842,t:1526919137115};\\\", \\\"{x:1450,y:793,t:1526919137131};\\\", \\\"{x:1437,y:744,t:1526919137148};\\\", \\\"{x:1420,y:698,t:1526919137165};\\\", \\\"{x:1403,y:654,t:1526919137181};\\\", \\\"{x:1392,y:618,t:1526919137197};\\\", \\\"{x:1388,y:590,t:1526919137214};\\\", \\\"{x:1386,y:570,t:1526919137231};\\\", \\\"{x:1386,y:552,t:1526919137247};\\\", \\\"{x:1386,y:533,t:1526919137264};\\\", \\\"{x:1386,y:519,t:1526919137281};\\\", \\\"{x:1386,y:512,t:1526919137297};\\\", \\\"{x:1386,y:507,t:1526919137314};\\\", \\\"{x:1386,y:504,t:1526919137332};\\\", \\\"{x:1386,y:503,t:1526919137347};\\\", \\\"{x:1386,y:501,t:1526919137364};\\\", \\\"{x:1386,y:498,t:1526919137381};\\\", \\\"{x:1387,y:495,t:1526919137397};\\\", \\\"{x:1388,y:494,t:1526919137414};\\\", \\\"{x:1389,y:493,t:1526919137431};\\\", \\\"{x:1391,y:493,t:1526919137505};\\\", \\\"{x:1393,y:493,t:1526919137514};\\\", \\\"{x:1398,y:495,t:1526919137531};\\\", \\\"{x:1402,y:501,t:1526919137548};\\\", \\\"{x:1406,y:508,t:1526919137564};\\\", \\\"{x:1409,y:516,t:1526919137581};\\\", \\\"{x:1409,y:520,t:1526919137599};\\\", \\\"{x:1410,y:524,t:1526919137614};\\\", \\\"{x:1410,y:527,t:1526919137631};\\\", \\\"{x:1410,y:528,t:1526919137648};\\\", \\\"{x:1410,y:530,t:1526919137664};\\\", \\\"{x:1410,y:532,t:1526919137681};\\\", \\\"{x:1410,y:533,t:1526919137698};\\\", \\\"{x:1409,y:535,t:1526919137714};\\\", \\\"{x:1409,y:536,t:1526919137744};\\\", \\\"{x:1409,y:537,t:1526919137768};\\\", \\\"{x:1408,y:537,t:1526919137781};\\\", \\\"{x:1408,y:539,t:1526919137798};\\\", \\\"{x:1405,y:542,t:1526919137814};\\\", \\\"{x:1398,y:546,t:1526919137831};\\\", \\\"{x:1385,y:551,t:1526919137848};\\\", \\\"{x:1384,y:551,t:1526919137864};\\\", \\\"{x:1384,y:552,t:1526919138120};\\\", \\\"{x:1384,y:554,t:1526919138131};\\\", \\\"{x:1394,y:560,t:1526919138148};\\\", \\\"{x:1404,y:567,t:1526919138165};\\\", \\\"{x:1409,y:571,t:1526919138182};\\\", \\\"{x:1412,y:574,t:1526919138198};\\\", \\\"{x:1413,y:574,t:1526919138215};\\\", \\\"{x:1414,y:574,t:1526919138353};\\\", \\\"{x:1414,y:573,t:1526919142448};\\\", \\\"{x:1410,y:571,t:1526919142456};\\\", \\\"{x:1405,y:568,t:1526919142468};\\\", \\\"{x:1393,y:562,t:1526919142485};\\\", \\\"{x:1377,y:556,t:1526919142502};\\\", \\\"{x:1355,y:551,t:1526919142518};\\\", \\\"{x:1333,y:546,t:1526919142535};\\\", \\\"{x:1320,y:545,t:1526919142551};\\\", \\\"{x:1303,y:542,t:1526919142569};\\\", \\\"{x:1289,y:540,t:1526919142585};\\\", \\\"{x:1265,y:536,t:1526919142601};\\\", \\\"{x:1242,y:533,t:1526919142618};\\\", \\\"{x:1211,y:529,t:1526919142635};\\\", \\\"{x:1177,y:528,t:1526919142651};\\\", \\\"{x:1154,y:525,t:1526919142668};\\\", \\\"{x:1137,y:525,t:1526919142686};\\\", \\\"{x:1124,y:525,t:1526919142702};\\\", \\\"{x:1115,y:524,t:1526919142718};\\\", \\\"{x:1092,y:524,t:1526919142735};\\\", \\\"{x:1059,y:524,t:1526919142752};\\\", \\\"{x:981,y:524,t:1526919142768};\\\", \\\"{x:917,y:524,t:1526919142785};\\\", \\\"{x:850,y:524,t:1526919142802};\\\", \\\"{x:786,y:524,t:1526919142818};\\\", \\\"{x:727,y:533,t:1526919142835};\\\", \\\"{x:695,y:540,t:1526919142853};\\\", \\\"{x:666,y:544,t:1526919142867};\\\", \\\"{x:659,y:549,t:1526919142885};\\\", \\\"{x:649,y:556,t:1526919142901};\\\", \\\"{x:634,y:563,t:1526919142918};\\\", \\\"{x:615,y:575,t:1526919142936};\\\", \\\"{x:604,y:582,t:1526919142952};\\\", \\\"{x:589,y:588,t:1526919142970};\\\", \\\"{x:568,y:596,t:1526919142986};\\\", \\\"{x:547,y:601,t:1526919143003};\\\", \\\"{x:524,y:602,t:1526919143020};\\\", \\\"{x:506,y:602,t:1526919143036};\\\", \\\"{x:485,y:602,t:1526919143053};\\\", \\\"{x:468,y:599,t:1526919143070};\\\", \\\"{x:435,y:594,t:1526919143086};\\\", \\\"{x:376,y:584,t:1526919143104};\\\", \\\"{x:311,y:572,t:1526919143120};\\\", \\\"{x:263,y:569,t:1526919143136};\\\", \\\"{x:256,y:569,t:1526919143152};\\\", \\\"{x:255,y:569,t:1526919143176};\\\", \\\"{x:254,y:569,t:1526919143186};\\\", \\\"{x:254,y:573,t:1526919143202};\\\", \\\"{x:254,y:582,t:1526919143219};\\\", \\\"{x:254,y:591,t:1526919143236};\\\", \\\"{x:254,y:599,t:1526919143253};\\\", \\\"{x:254,y:606,t:1526919143270};\\\", \\\"{x:252,y:611,t:1526919143286};\\\", \\\"{x:248,y:616,t:1526919143303};\\\", \\\"{x:244,y:619,t:1526919143319};\\\", \\\"{x:239,y:621,t:1526919143336};\\\", \\\"{x:239,y:622,t:1526919143360};\\\", \\\"{x:241,y:622,t:1526919143400};\\\", \\\"{x:243,y:622,t:1526919143407};\\\", \\\"{x:250,y:621,t:1526919143420};\\\", \\\"{x:266,y:613,t:1526919143437};\\\", \\\"{x:294,y:606,t:1526919143454};\\\", \\\"{x:304,y:600,t:1526919143471};\\\", \\\"{x:305,y:598,t:1526919143487};\\\", \\\"{x:314,y:594,t:1526919143503};\\\", \\\"{x:327,y:589,t:1526919143520};\\\", \\\"{x:330,y:586,t:1526919143538};\\\", \\\"{x:333,y:582,t:1526919143554};\\\", \\\"{x:337,y:581,t:1526919143570};\\\", \\\"{x:338,y:581,t:1526919143587};\\\", \\\"{x:344,y:580,t:1526919143603};\\\", \\\"{x:359,y:578,t:1526919143620};\\\", \\\"{x:376,y:577,t:1526919143636};\\\", \\\"{x:398,y:577,t:1526919143653};\\\", \\\"{x:419,y:577,t:1526919143670};\\\", \\\"{x:462,y:577,t:1526919143686};\\\", \\\"{x:523,y:583,t:1526919143703};\\\", \\\"{x:616,y:594,t:1526919143720};\\\", \\\"{x:674,y:599,t:1526919143737};\\\", \\\"{x:704,y:599,t:1526919143753};\\\", \\\"{x:731,y:600,t:1526919143771};\\\", \\\"{x:745,y:600,t:1526919143786};\\\", \\\"{x:746,y:600,t:1526919143804};\\\", \\\"{x:747,y:600,t:1526919143840};\\\", \\\"{x:747,y:598,t:1526919143853};\\\", \\\"{x:742,y:594,t:1526919143871};\\\", \\\"{x:738,y:591,t:1526919143887};\\\", \\\"{x:733,y:586,t:1526919143904};\\\", \\\"{x:713,y:573,t:1526919143921};\\\", \\\"{x:693,y:568,t:1526919143937};\\\", \\\"{x:675,y:560,t:1526919143954};\\\", \\\"{x:662,y:555,t:1526919143971};\\\", \\\"{x:657,y:554,t:1526919143986};\\\", \\\"{x:656,y:554,t:1526919144003};\\\", \\\"{x:655,y:554,t:1526919144023};\\\", \\\"{x:654,y:554,t:1526919144037};\\\", \\\"{x:653,y:554,t:1526919144054};\\\", \\\"{x:652,y:553,t:1526919144071};\\\", \\\"{x:650,y:553,t:1526919144088};\\\", \\\"{x:647,y:552,t:1526919144104};\\\", \\\"{x:643,y:550,t:1526919144121};\\\", \\\"{x:642,y:550,t:1526919144138};\\\", \\\"{x:641,y:550,t:1526919144160};\\\", \\\"{x:640,y:550,t:1526919144176};\\\", \\\"{x:638,y:550,t:1526919144192};\\\", \\\"{x:636,y:549,t:1526919144203};\\\", \\\"{x:631,y:546,t:1526919144221};\\\", \\\"{x:626,y:545,t:1526919144237};\\\", \\\"{x:624,y:544,t:1526919144253};\\\", \\\"{x:621,y:544,t:1526919144271};\\\", \\\"{x:617,y:544,t:1526919144288};\\\", \\\"{x:616,y:542,t:1526919144312};\\\", \\\"{x:615,y:542,t:1526919144336};\\\", \\\"{x:614,y:542,t:1526919144352};\\\", \\\"{x:612,y:542,t:1526919144360};\\\", \\\"{x:613,y:546,t:1526919144752};\\\", \\\"{x:617,y:551,t:1526919144760};\\\", \\\"{x:622,y:556,t:1526919144771};\\\", \\\"{x:636,y:567,t:1526919144788};\\\", \\\"{x:649,y:572,t:1526919144805};\\\", \\\"{x:666,y:573,t:1526919144821};\\\", \\\"{x:682,y:575,t:1526919144838};\\\", \\\"{x:699,y:575,t:1526919144855};\\\", \\\"{x:713,y:575,t:1526919144871};\\\", \\\"{x:726,y:571,t:1526919144888};\\\", \\\"{x:742,y:561,t:1526919144904};\\\", \\\"{x:750,y:556,t:1526919144922};\\\", \\\"{x:753,y:553,t:1526919144938};\\\", \\\"{x:754,y:550,t:1526919144954};\\\", \\\"{x:757,y:546,t:1526919144972};\\\", \\\"{x:760,y:544,t:1526919144988};\\\", \\\"{x:766,y:540,t:1526919145004};\\\", \\\"{x:778,y:536,t:1526919145022};\\\", \\\"{x:791,y:534,t:1526919145039};\\\", \\\"{x:806,y:532,t:1526919145054};\\\", \\\"{x:819,y:532,t:1526919145071};\\\", \\\"{x:827,y:532,t:1526919145089};\\\", \\\"{x:828,y:532,t:1526919145159};\\\", \\\"{x:829,y:532,t:1526919145171};\\\", \\\"{x:830,y:534,t:1526919145191};\\\", \\\"{x:830,y:535,t:1526919145208};\\\", \\\"{x:831,y:535,t:1526919145221};\\\", \\\"{x:832,y:537,t:1526919145238};\\\", \\\"{x:832,y:539,t:1526919145512};\\\", \\\"{x:828,y:541,t:1526919145522};\\\", \\\"{x:813,y:549,t:1526919145539};\\\", \\\"{x:796,y:562,t:1526919145554};\\\", \\\"{x:782,y:580,t:1526919145572};\\\", \\\"{x:770,y:595,t:1526919145589};\\\", \\\"{x:760,y:612,t:1526919145604};\\\", \\\"{x:745,y:629,t:1526919145621};\\\", \\\"{x:730,y:643,t:1526919145639};\\\", \\\"{x:714,y:656,t:1526919145655};\\\", \\\"{x:694,y:673,t:1526919145671};\\\", \\\"{x:684,y:682,t:1526919145688};\\\", \\\"{x:675,y:690,t:1526919145706};\\\", \\\"{x:659,y:698,t:1526919145722};\\\", \\\"{x:644,y:701,t:1526919145738};\\\", \\\"{x:626,y:704,t:1526919145756};\\\", \\\"{x:609,y:705,t:1526919145773};\\\", \\\"{x:591,y:706,t:1526919145789};\\\", \\\"{x:568,y:712,t:1526919145805};\\\", \\\"{x:544,y:716,t:1526919145822};\\\", \\\"{x:528,y:721,t:1526919145839};\\\", \\\"{x:522,y:726,t:1526919145856};\\\", \\\"{x:521,y:727,t:1526919145872};\\\", \\\"{x:521,y:728,t:1526919145889};\\\", \\\"{x:520,y:729,t:1526919145906};\\\", \\\"{x:520,y:730,t:1526919145922};\\\", \\\"{x:519,y:731,t:1526919145939};\\\", \\\"{x:519,y:733,t:1526919145956};\\\", \\\"{x:519,y:734,t:1526919145976};\\\", \\\"{x:519,y:735,t:1526919145989};\\\", \\\"{x:519,y:737,t:1526919146005};\\\", \\\"{x:519,y:739,t:1526919146022};\\\", \\\"{x:519,y:740,t:1526919146928};\\\", \\\"{x:521,y:739,t:1526919146940};\\\", \\\"{x:522,y:739,t:1526919146956};\\\", \\\"{x:524,y:737,t:1526919146972};\\\", \\\"{x:525,y:736,t:1526919146989};\\\", \\\"{x:526,y:735,t:1526919147006};\\\", \\\"{x:527,y:735,t:1526919147024};\\\", \\\"{x:528,y:733,t:1526919147056};\\\", \\\"{x:529,y:732,t:1526919147096};\\\", \\\"{x:530,y:732,t:1526919147111};\\\", \\\"{x:530,y:730,t:1526919147168};\\\", \\\"{x:532,y:729,t:1526919147208};\\\", \\\"{x:532,y:728,t:1526919147256};\\\", \\\"{x:533,y:728,t:1526919147279};\\\", \\\"{x:533,y:727,t:1526919147328};\\\", \\\"{x:535,y:726,t:1526919147359};\\\", \\\"{x:535,y:725,t:1526919147391};\\\", \\\"{x:536,y:725,t:1526919147416};\\\", \\\"{x:536,y:724,t:1526919147456};\\\", \\\"{x:537,y:724,t:1526919147504};\\\", \\\"{x:538,y:724,t:1526919147521};\\\", \\\"{x:538,y:723,t:1526919147543};\\\", \\\"{x:539,y:722,t:1526919147575};\\\", \\\"{x:540,y:722,t:1526919147600};\\\", \\\"{x:541,y:722,t:1526919147648};\\\" ] }, { \\\"rt\\\": 37242, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 425594, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-07 PM-07 PM-07 PM-08 PM-07 PM-05 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:720,t:1526919147867};\\\", \\\"{x:545,y:719,t:1526919148216};\\\", \\\"{x:547,y:718,t:1526919148223};\\\", \\\"{x:547,y:717,t:1526919148296};\\\", \\\"{x:548,y:717,t:1526919148344};\\\", \\\"{x:548,y:716,t:1526919148357};\\\", \\\"{x:550,y:714,t:1526919148373};\\\", \\\"{x:551,y:713,t:1526919148390};\\\", \\\"{x:551,y:710,t:1526919148408};\\\", \\\"{x:552,y:705,t:1526919148424};\\\", \\\"{x:553,y:701,t:1526919148440};\\\", \\\"{x:555,y:694,t:1526919148457};\\\", \\\"{x:556,y:690,t:1526919148473};\\\", \\\"{x:557,y:685,t:1526919148490};\\\", \\\"{x:557,y:679,t:1526919148508};\\\", \\\"{x:557,y:667,t:1526919148524};\\\", \\\"{x:550,y:645,t:1526919148540};\\\", \\\"{x:539,y:616,t:1526919148558};\\\", \\\"{x:526,y:590,t:1526919148575};\\\", \\\"{x:513,y:566,t:1526919148591};\\\", \\\"{x:502,y:546,t:1526919148608};\\\", \\\"{x:494,y:536,t:1526919148625};\\\", \\\"{x:486,y:527,t:1526919148640};\\\", \\\"{x:481,y:521,t:1526919148658};\\\", \\\"{x:475,y:515,t:1526919148675};\\\", \\\"{x:468,y:509,t:1526919148691};\\\", \\\"{x:457,y:504,t:1526919148707};\\\", \\\"{x:446,y:500,t:1526919148724};\\\", \\\"{x:439,y:497,t:1526919148741};\\\", \\\"{x:434,y:496,t:1526919148758};\\\", \\\"{x:429,y:495,t:1526919148774};\\\", \\\"{x:426,y:493,t:1526919148790};\\\", \\\"{x:418,y:492,t:1526919148808};\\\", \\\"{x:411,y:492,t:1526919148824};\\\", \\\"{x:405,y:491,t:1526919148841};\\\", \\\"{x:398,y:489,t:1526919148858};\\\", \\\"{x:395,y:488,t:1526919148874};\\\", \\\"{x:394,y:488,t:1526919148890};\\\", \\\"{x:393,y:488,t:1526919148991};\\\", \\\"{x:392,y:488,t:1526919149080};\\\", \\\"{x:392,y:486,t:1526919149104};\\\", \\\"{x:393,y:485,t:1526919149144};\\\", \\\"{x:393,y:484,t:1526919149160};\\\", \\\"{x:394,y:483,t:1526919149176};\\\", \\\"{x:394,y:482,t:1526919149200};\\\", \\\"{x:396,y:480,t:1526919149208};\\\", \\\"{x:396,y:479,t:1526919149248};\\\", \\\"{x:397,y:478,t:1526919149259};\\\", \\\"{x:398,y:478,t:1526919149280};\\\", \\\"{x:398,y:477,t:1526919149292};\\\", \\\"{x:398,y:475,t:1526919149312};\\\", \\\"{x:399,y:475,t:1526919149344};\\\", \\\"{x:399,y:474,t:1526919149358};\\\", \\\"{x:401,y:473,t:1526919149376};\\\", \\\"{x:401,y:472,t:1526919149392};\\\", \\\"{x:402,y:472,t:1526919149409};\\\", \\\"{x:403,y:472,t:1526919149488};\\\", \\\"{x:404,y:471,t:1526919149505};\\\", \\\"{x:405,y:471,t:1526919149520};\\\", \\\"{x:406,y:471,t:1526919149576};\\\", \\\"{x:407,y:470,t:1526919149593};\\\", \\\"{x:408,y:470,t:1526919149656};\\\", \\\"{x:409,y:470,t:1526919149688};\\\", \\\"{x:410,y:470,t:1526919149704};\\\", \\\"{x:411,y:470,t:1526919149727};\\\", \\\"{x:412,y:470,t:1526919149743};\\\", \\\"{x:414,y:470,t:1526919149760};\\\", \\\"{x:416,y:470,t:1526919149776};\\\", \\\"{x:417,y:470,t:1526919149808};\\\", \\\"{x:418,y:470,t:1526919149816};\\\", \\\"{x:419,y:470,t:1526919149832};\\\", \\\"{x:420,y:470,t:1526919149843};\\\", \\\"{x:421,y:470,t:1526919149860};\\\", \\\"{x:424,y:470,t:1526919149877};\\\", \\\"{x:425,y:470,t:1526919149894};\\\", \\\"{x:428,y:470,t:1526919149910};\\\", \\\"{x:431,y:470,t:1526919149927};\\\", \\\"{x:433,y:470,t:1526919149944};\\\", \\\"{x:436,y:470,t:1526919149960};\\\", \\\"{x:437,y:470,t:1526919149977};\\\", \\\"{x:438,y:470,t:1526919150016};\\\", \\\"{x:440,y:470,t:1526919150032};\\\", \\\"{x:441,y:470,t:1526919150095};\\\", \\\"{x:443,y:470,t:1526919150112};\\\", \\\"{x:444,y:470,t:1526919150143};\\\", \\\"{x:445,y:471,t:1526919150160};\\\", \\\"{x:446,y:471,t:1526919150178};\\\", \\\"{x:447,y:471,t:1526919150194};\\\", \\\"{x:450,y:471,t:1526919150211};\\\", \\\"{x:452,y:471,t:1526919150228};\\\", \\\"{x:455,y:471,t:1526919150244};\\\", \\\"{x:456,y:471,t:1526919150260};\\\", \\\"{x:458,y:471,t:1526919150277};\\\", \\\"{x:459,y:471,t:1526919150295};\\\", \\\"{x:460,y:471,t:1526919150311};\\\", \\\"{x:461,y:471,t:1526919150328};\\\", \\\"{x:462,y:471,t:1526919150345};\\\", \\\"{x:463,y:471,t:1526919150361};\\\", \\\"{x:464,y:471,t:1526919150378};\\\", \\\"{x:465,y:471,t:1526919150395};\\\", \\\"{x:466,y:471,t:1526919150411};\\\", \\\"{x:467,y:471,t:1526919150428};\\\", \\\"{x:468,y:471,t:1526919150444};\\\", \\\"{x:470,y:471,t:1526919150461};\\\", \\\"{x:471,y:471,t:1526919150478};\\\", \\\"{x:472,y:471,t:1526919150495};\\\", \\\"{x:473,y:471,t:1526919150544};\\\", \\\"{x:474,y:471,t:1526919150559};\\\", \\\"{x:476,y:471,t:1526919150576};\\\", \\\"{x:477,y:471,t:1526919150592};\\\", \\\"{x:479,y:471,t:1526919150600};\\\", \\\"{x:480,y:471,t:1526919150611};\\\", \\\"{x:484,y:471,t:1526919150629};\\\", \\\"{x:487,y:471,t:1526919150645};\\\", \\\"{x:490,y:471,t:1526919150662};\\\", \\\"{x:493,y:471,t:1526919150679};\\\", \\\"{x:498,y:471,t:1526919150696};\\\", \\\"{x:501,y:471,t:1526919150711};\\\", \\\"{x:504,y:471,t:1526919150729};\\\", \\\"{x:508,y:471,t:1526919150746};\\\", \\\"{x:511,y:471,t:1526919150762};\\\", \\\"{x:514,y:471,t:1526919150779};\\\", \\\"{x:517,y:471,t:1526919150796};\\\", \\\"{x:519,y:471,t:1526919150812};\\\", \\\"{x:521,y:472,t:1526919150829};\\\", \\\"{x:523,y:472,t:1526919150845};\\\", \\\"{x:524,y:472,t:1526919150863};\\\", \\\"{x:526,y:473,t:1526919150879};\\\", \\\"{x:527,y:473,t:1526919150959};\\\", \\\"{x:529,y:474,t:1526919150968};\\\", \\\"{x:530,y:474,t:1526919150978};\\\", \\\"{x:531,y:474,t:1526919150996};\\\", \\\"{x:534,y:474,t:1526919151013};\\\", \\\"{x:537,y:474,t:1526919151030};\\\", \\\"{x:540,y:474,t:1526919151045};\\\", \\\"{x:543,y:475,t:1526919151063};\\\", \\\"{x:548,y:477,t:1526919151079};\\\", \\\"{x:552,y:477,t:1526919151097};\\\", \\\"{x:559,y:477,t:1526919151112};\\\", \\\"{x:564,y:478,t:1526919151130};\\\", \\\"{x:573,y:480,t:1526919151147};\\\", \\\"{x:581,y:482,t:1526919151163};\\\", \\\"{x:594,y:483,t:1526919151180};\\\", \\\"{x:602,y:485,t:1526919151197};\\\", \\\"{x:614,y:488,t:1526919151213};\\\", \\\"{x:624,y:490,t:1526919151229};\\\", \\\"{x:635,y:491,t:1526919151247};\\\", \\\"{x:645,y:492,t:1526919151260};\\\", \\\"{x:654,y:493,t:1526919151277};\\\", \\\"{x:658,y:494,t:1526919151292};\\\", \\\"{x:664,y:495,t:1526919151309};\\\", \\\"{x:670,y:496,t:1526919151327};\\\", \\\"{x:673,y:496,t:1526919151343};\\\", \\\"{x:680,y:498,t:1526919151359};\\\", \\\"{x:683,y:498,t:1526919151377};\\\", \\\"{x:684,y:498,t:1526919151393};\\\", \\\"{x:686,y:498,t:1526919151410};\\\", \\\"{x:690,y:498,t:1526919151427};\\\", \\\"{x:691,y:498,t:1526919151443};\\\", \\\"{x:693,y:499,t:1526919151460};\\\", \\\"{x:694,y:499,t:1526919151497};\\\", \\\"{x:696,y:499,t:1526919151776};\\\", \\\"{x:697,y:499,t:1526919151794};\\\", \\\"{x:700,y:499,t:1526919151810};\\\", \\\"{x:703,y:499,t:1526919151827};\\\", \\\"{x:706,y:499,t:1526919151844};\\\", \\\"{x:710,y:499,t:1526919151860};\\\", \\\"{x:715,y:499,t:1526919151877};\\\", \\\"{x:721,y:500,t:1526919151894};\\\", \\\"{x:729,y:502,t:1526919151911};\\\", \\\"{x:736,y:502,t:1526919151926};\\\", \\\"{x:758,y:505,t:1526919151944};\\\", \\\"{x:778,y:509,t:1526919151960};\\\", \\\"{x:799,y:513,t:1526919151976};\\\", \\\"{x:816,y:520,t:1526919151994};\\\", \\\"{x:832,y:525,t:1526919152011};\\\", \\\"{x:843,y:528,t:1526919152027};\\\", \\\"{x:851,y:533,t:1526919152043};\\\", \\\"{x:859,y:535,t:1526919152060};\\\", \\\"{x:874,y:543,t:1526919152077};\\\", \\\"{x:894,y:550,t:1526919152093};\\\", \\\"{x:920,y:560,t:1526919152110};\\\", \\\"{x:963,y:571,t:1526919152127};\\\", \\\"{x:1020,y:589,t:1526919152144};\\\", \\\"{x:1055,y:596,t:1526919152161};\\\", \\\"{x:1066,y:603,t:1526919152177};\\\", \\\"{x:1069,y:605,t:1526919152194};\\\", \\\"{x:1070,y:605,t:1526919152768};\\\", \\\"{x:1071,y:605,t:1526919153153};\\\", \\\"{x:1072,y:605,t:1526919153215};\\\", \\\"{x:1073,y:605,t:1526919153256};\\\", \\\"{x:1074,y:605,t:1526919153296};\\\", \\\"{x:1075,y:605,t:1526919153311};\\\", \\\"{x:1076,y:606,t:1526919153343};\\\", \\\"{x:1077,y:606,t:1526919153376};\\\", \\\"{x:1078,y:606,t:1526919153384};\\\", \\\"{x:1079,y:606,t:1526919153408};\\\", \\\"{x:1081,y:606,t:1526919153416};\\\", \\\"{x:1082,y:606,t:1526919153432};\\\", \\\"{x:1083,y:606,t:1526919153448};\\\", \\\"{x:1083,y:607,t:1526919153462};\\\", \\\"{x:1085,y:607,t:1526919153478};\\\", \\\"{x:1086,y:607,t:1526919153544};\\\", \\\"{x:1087,y:608,t:1526919153607};\\\", \\\"{x:1088,y:608,t:1526919153623};\\\", \\\"{x:1089,y:608,t:1526919153663};\\\", \\\"{x:1090,y:608,t:1526919153696};\\\", \\\"{x:1091,y:608,t:1526919153775};\\\", \\\"{x:1092,y:608,t:1526919153824};\\\", \\\"{x:1093,y:608,t:1526919153832};\\\", \\\"{x:1094,y:608,t:1526919153896};\\\", \\\"{x:1094,y:609,t:1526919153959};\\\", \\\"{x:1095,y:610,t:1526919153968};\\\", \\\"{x:1097,y:611,t:1526919153979};\\\", \\\"{x:1106,y:614,t:1526919153994};\\\", \\\"{x:1121,y:618,t:1526919154012};\\\", \\\"{x:1145,y:623,t:1526919154029};\\\", \\\"{x:1167,y:629,t:1526919154045};\\\", \\\"{x:1188,y:636,t:1526919154062};\\\", \\\"{x:1208,y:643,t:1526919154079};\\\", \\\"{x:1221,y:650,t:1526919154095};\\\", \\\"{x:1242,y:661,t:1526919154111};\\\", \\\"{x:1260,y:671,t:1526919154129};\\\", \\\"{x:1280,y:678,t:1526919154145};\\\", \\\"{x:1304,y:691,t:1526919154162};\\\", \\\"{x:1324,y:701,t:1526919154178};\\\", \\\"{x:1341,y:713,t:1526919154195};\\\", \\\"{x:1361,y:725,t:1526919154212};\\\", \\\"{x:1382,y:738,t:1526919154229};\\\", \\\"{x:1403,y:751,t:1526919154246};\\\", \\\"{x:1422,y:763,t:1526919154261};\\\", \\\"{x:1443,y:779,t:1526919154278};\\\", \\\"{x:1480,y:805,t:1526919154295};\\\", \\\"{x:1508,y:825,t:1526919154311};\\\", \\\"{x:1532,y:844,t:1526919154329};\\\", \\\"{x:1553,y:863,t:1526919154346};\\\", \\\"{x:1567,y:881,t:1526919154362};\\\", \\\"{x:1579,y:896,t:1526919154379};\\\", \\\"{x:1588,y:909,t:1526919154396};\\\", \\\"{x:1594,y:921,t:1526919154412};\\\", \\\"{x:1599,y:931,t:1526919154428};\\\", \\\"{x:1603,y:940,t:1526919154446};\\\", \\\"{x:1606,y:949,t:1526919154462};\\\", \\\"{x:1606,y:957,t:1526919154479};\\\", \\\"{x:1607,y:963,t:1526919154496};\\\", \\\"{x:1607,y:967,t:1526919154512};\\\", \\\"{x:1607,y:969,t:1526919154529};\\\", \\\"{x:1607,y:970,t:1526919154546};\\\", \\\"{x:1607,y:972,t:1526919154562};\\\", \\\"{x:1606,y:974,t:1526919154579};\\\", \\\"{x:1604,y:975,t:1526919154596};\\\", \\\"{x:1603,y:975,t:1526919154611};\\\", \\\"{x:1602,y:975,t:1526919154629};\\\", \\\"{x:1600,y:975,t:1526919154646};\\\", \\\"{x:1599,y:975,t:1526919154663};\\\", \\\"{x:1597,y:975,t:1526919154679};\\\", \\\"{x:1593,y:975,t:1526919154696};\\\", \\\"{x:1589,y:974,t:1526919154713};\\\", \\\"{x:1586,y:971,t:1526919154729};\\\", \\\"{x:1586,y:969,t:1526919154746};\\\", \\\"{x:1586,y:968,t:1526919154763};\\\", \\\"{x:1586,y:967,t:1526919154800};\\\", \\\"{x:1586,y:966,t:1526919154815};\\\", \\\"{x:1586,y:964,t:1526919154829};\\\", \\\"{x:1590,y:964,t:1526919154846};\\\", \\\"{x:1597,y:963,t:1526919154863};\\\", \\\"{x:1605,y:962,t:1526919154879};\\\", \\\"{x:1624,y:960,t:1526919154896};\\\", \\\"{x:1630,y:960,t:1526919154912};\\\", \\\"{x:1640,y:960,t:1526919154929};\\\", \\\"{x:1652,y:960,t:1526919154946};\\\", \\\"{x:1659,y:960,t:1526919154963};\\\", \\\"{x:1673,y:960,t:1526919154979};\\\", \\\"{x:1688,y:960,t:1526919154996};\\\", \\\"{x:1710,y:960,t:1526919155013};\\\", \\\"{x:1732,y:960,t:1526919155029};\\\", \\\"{x:1754,y:960,t:1526919155046};\\\", \\\"{x:1767,y:960,t:1526919155063};\\\", \\\"{x:1776,y:960,t:1526919155079};\\\", \\\"{x:1779,y:960,t:1526919155096};\\\", \\\"{x:1780,y:960,t:1526919155168};\\\", \\\"{x:1781,y:960,t:1526919155184};\\\", \\\"{x:1782,y:960,t:1526919155196};\\\", \\\"{x:1784,y:960,t:1526919155264};\\\", \\\"{x:1785,y:960,t:1526919155296};\\\", \\\"{x:1787,y:960,t:1526919155313};\\\", \\\"{x:1789,y:961,t:1526919155329};\\\", \\\"{x:1792,y:962,t:1526919155346};\\\", \\\"{x:1793,y:963,t:1526919155363};\\\", \\\"{x:1794,y:964,t:1526919155380};\\\", \\\"{x:1795,y:964,t:1526919155396};\\\", \\\"{x:1796,y:964,t:1526919155413};\\\", \\\"{x:1798,y:965,t:1526919155429};\\\", \\\"{x:1800,y:966,t:1526919155446};\\\", \\\"{x:1804,y:969,t:1526919155463};\\\", \\\"{x:1807,y:970,t:1526919155480};\\\", \\\"{x:1807,y:971,t:1526919155496};\\\", \\\"{x:1809,y:971,t:1526919155575};\\\", \\\"{x:1809,y:972,t:1526919155600};\\\", \\\"{x:1810,y:972,t:1526919155623};\\\", \\\"{x:1811,y:973,t:1526919155656};\\\", \\\"{x:1811,y:974,t:1526919155672};\\\", \\\"{x:1812,y:975,t:1526919155680};\\\", \\\"{x:1813,y:976,t:1526919155697};\\\", \\\"{x:1814,y:977,t:1526919155713};\\\", \\\"{x:1814,y:978,t:1526919155815};\\\", \\\"{x:1815,y:979,t:1526919155830};\\\", \\\"{x:1815,y:980,t:1526919155904};\\\", \\\"{x:1815,y:982,t:1526919155913};\\\", \\\"{x:1815,y:983,t:1526919155944};\\\", \\\"{x:1815,y:984,t:1526919155952};\\\", \\\"{x:1815,y:985,t:1526919156264};\\\", \\\"{x:1814,y:985,t:1526919156311};\\\", \\\"{x:1813,y:985,t:1526919156352};\\\", \\\"{x:1812,y:985,t:1526919156383};\\\", \\\"{x:1811,y:985,t:1526919156416};\\\", \\\"{x:1810,y:985,t:1526919156430};\\\", \\\"{x:1808,y:985,t:1526919156463};\\\", \\\"{x:1806,y:985,t:1526919156480};\\\", \\\"{x:1805,y:984,t:1526919156511};\\\", \\\"{x:1804,y:984,t:1526919156519};\\\", \\\"{x:1803,y:984,t:1526919156535};\\\", \\\"{x:1801,y:984,t:1526919156551};\\\", \\\"{x:1799,y:983,t:1526919156563};\\\", \\\"{x:1797,y:982,t:1526919156581};\\\", \\\"{x:1794,y:982,t:1526919156597};\\\", \\\"{x:1792,y:981,t:1526919156614};\\\", \\\"{x:1790,y:980,t:1526919156630};\\\", \\\"{x:1789,y:980,t:1526919156647};\\\", \\\"{x:1788,y:980,t:1526919156664};\\\", \\\"{x:1788,y:979,t:1526919156681};\\\", \\\"{x:1787,y:979,t:1526919156697};\\\", \\\"{x:1786,y:978,t:1526919156720};\\\", \\\"{x:1785,y:978,t:1526919156784};\\\", \\\"{x:1784,y:978,t:1526919156797};\\\", \\\"{x:1782,y:977,t:1526919156840};\\\", \\\"{x:1780,y:976,t:1526919156864};\\\", \\\"{x:1780,y:975,t:1526919156881};\\\", \\\"{x:1778,y:975,t:1526919156897};\\\", \\\"{x:1777,y:974,t:1526919156915};\\\", \\\"{x:1776,y:974,t:1526919156931};\\\", \\\"{x:1774,y:972,t:1526919156949};\\\", \\\"{x:1773,y:972,t:1526919156984};\\\", \\\"{x:1771,y:971,t:1526919157841};\\\", \\\"{x:1773,y:971,t:1526919159888};\\\", \\\"{x:1774,y:971,t:1526919159904};\\\", \\\"{x:1776,y:971,t:1526919159916};\\\", \\\"{x:1780,y:971,t:1526919159933};\\\", \\\"{x:1788,y:971,t:1526919159950};\\\", \\\"{x:1798,y:971,t:1526919159967};\\\", \\\"{x:1807,y:971,t:1526919159983};\\\", \\\"{x:1813,y:971,t:1526919160000};\\\", \\\"{x:1814,y:971,t:1526919160017};\\\", \\\"{x:1816,y:971,t:1526919160033};\\\", \\\"{x:1818,y:971,t:1526919160049};\\\", \\\"{x:1824,y:971,t:1526919160067};\\\", \\\"{x:1827,y:971,t:1526919160083};\\\", \\\"{x:1831,y:971,t:1526919160100};\\\", \\\"{x:1833,y:971,t:1526919160117};\\\", \\\"{x:1835,y:971,t:1526919160134};\\\", \\\"{x:1836,y:972,t:1526919160151};\\\", \\\"{x:1841,y:972,t:1526919160167};\\\", \\\"{x:1847,y:973,t:1526919160183};\\\", \\\"{x:1859,y:974,t:1526919160199};\\\", \\\"{x:1863,y:974,t:1526919160217};\\\", \\\"{x:1865,y:974,t:1526919160233};\\\", \\\"{x:1866,y:974,t:1526919160311};\\\", \\\"{x:1867,y:974,t:1526919160815};\\\", \\\"{x:1868,y:974,t:1526919160848};\\\", \\\"{x:1869,y:974,t:1526919160904};\\\", \\\"{x:1869,y:973,t:1526919161736};\\\", \\\"{x:1870,y:973,t:1526919161760};\\\", \\\"{x:1870,y:972,t:1526919161936};\\\", \\\"{x:1869,y:972,t:1526919163528};\\\", \\\"{x:1868,y:972,t:1526919163536};\\\", \\\"{x:1862,y:972,t:1526919163553};\\\", \\\"{x:1850,y:974,t:1526919163569};\\\", \\\"{x:1842,y:974,t:1526919163586};\\\", \\\"{x:1835,y:978,t:1526919163603};\\\", \\\"{x:1829,y:979,t:1526919163619};\\\", \\\"{x:1819,y:984,t:1526919163636};\\\", \\\"{x:1807,y:988,t:1526919163653};\\\", \\\"{x:1801,y:991,t:1526919163669};\\\", \\\"{x:1800,y:992,t:1526919163686};\\\", \\\"{x:1794,y:993,t:1526919163703};\\\", \\\"{x:1792,y:993,t:1526919163719};\\\", \\\"{x:1775,y:995,t:1526919163736};\\\", \\\"{x:1761,y:996,t:1526919163753};\\\", \\\"{x:1744,y:997,t:1526919163770};\\\", \\\"{x:1727,y:997,t:1526919163786};\\\", \\\"{x:1714,y:997,t:1526919163804};\\\", \\\"{x:1705,y:997,t:1526919163819};\\\", \\\"{x:1697,y:994,t:1526919163836};\\\", \\\"{x:1691,y:991,t:1526919163853};\\\", \\\"{x:1685,y:985,t:1526919163869};\\\", \\\"{x:1676,y:978,t:1526919163887};\\\", \\\"{x:1663,y:966,t:1526919163904};\\\", \\\"{x:1637,y:946,t:1526919163920};\\\", \\\"{x:1622,y:932,t:1526919163937};\\\", \\\"{x:1607,y:919,t:1526919163954};\\\", \\\"{x:1595,y:906,t:1526919163970};\\\", \\\"{x:1585,y:891,t:1526919163986};\\\", \\\"{x:1572,y:872,t:1526919164003};\\\", \\\"{x:1557,y:852,t:1526919164021};\\\", \\\"{x:1539,y:834,t:1526919164036};\\\", \\\"{x:1523,y:817,t:1526919164054};\\\", \\\"{x:1502,y:801,t:1526919164070};\\\", \\\"{x:1483,y:790,t:1526919164086};\\\", \\\"{x:1458,y:777,t:1526919164104};\\\", \\\"{x:1447,y:772,t:1526919164119};\\\", \\\"{x:1438,y:769,t:1526919164136};\\\", \\\"{x:1429,y:767,t:1526919164153};\\\", \\\"{x:1415,y:767,t:1526919164170};\\\", \\\"{x:1398,y:767,t:1526919164187};\\\", \\\"{x:1375,y:767,t:1526919164203};\\\", \\\"{x:1356,y:767,t:1526919164221};\\\", \\\"{x:1338,y:767,t:1526919164236};\\\", \\\"{x:1328,y:767,t:1526919164254};\\\", \\\"{x:1325,y:767,t:1526919164270};\\\", \\\"{x:1324,y:767,t:1526919164286};\\\", \\\"{x:1324,y:766,t:1526919164535};\\\", \\\"{x:1326,y:765,t:1526919164552};\\\", \\\"{x:1328,y:765,t:1526919164567};\\\", \\\"{x:1330,y:765,t:1526919164575};\\\", \\\"{x:1331,y:765,t:1526919164588};\\\", \\\"{x:1334,y:765,t:1526919164604};\\\", \\\"{x:1337,y:765,t:1526919164620};\\\", \\\"{x:1338,y:765,t:1526919164637};\\\", \\\"{x:1340,y:765,t:1526919164653};\\\", \\\"{x:1341,y:764,t:1526919164670};\\\", \\\"{x:1342,y:764,t:1526919164696};\\\", \\\"{x:1343,y:764,t:1526919164721};\\\", \\\"{x:1344,y:764,t:1526919164832};\\\", \\\"{x:1345,y:764,t:1526919164856};\\\", \\\"{x:1346,y:764,t:1526919173119};\\\", \\\"{x:1333,y:761,t:1526919175680};\\\", \\\"{x:1287,y:746,t:1526919175696};\\\", \\\"{x:1226,y:728,t:1526919175713};\\\", \\\"{x:1167,y:702,t:1526919175729};\\\", \\\"{x:1141,y:690,t:1526919175746};\\\", \\\"{x:1127,y:685,t:1526919175763};\\\", \\\"{x:1120,y:681,t:1526919175780};\\\", \\\"{x:1114,y:678,t:1526919175796};\\\", \\\"{x:1110,y:676,t:1526919175812};\\\", \\\"{x:1102,y:672,t:1526919175830};\\\", \\\"{x:1090,y:668,t:1526919175846};\\\", \\\"{x:1081,y:665,t:1526919175863};\\\", \\\"{x:1065,y:662,t:1526919175879};\\\", \\\"{x:1054,y:659,t:1526919175896};\\\", \\\"{x:1039,y:655,t:1526919175912};\\\", \\\"{x:1029,y:652,t:1526919175930};\\\", \\\"{x:1014,y:648,t:1526919175946};\\\", \\\"{x:1009,y:646,t:1526919175963};\\\", \\\"{x:996,y:644,t:1526919175980};\\\", \\\"{x:986,y:641,t:1526919175995};\\\", \\\"{x:973,y:639,t:1526919176013};\\\", \\\"{x:960,y:636,t:1526919176030};\\\", \\\"{x:946,y:633,t:1526919176045};\\\", \\\"{x:929,y:630,t:1526919176063};\\\", \\\"{x:906,y:625,t:1526919176079};\\\", \\\"{x:896,y:623,t:1526919176096};\\\", \\\"{x:886,y:621,t:1526919176114};\\\", \\\"{x:877,y:619,t:1526919176131};\\\", \\\"{x:870,y:619,t:1526919176147};\\\", \\\"{x:861,y:616,t:1526919176164};\\\", \\\"{x:856,y:616,t:1526919176180};\\\", \\\"{x:848,y:615,t:1526919176197};\\\", \\\"{x:838,y:614,t:1526919176214};\\\", \\\"{x:828,y:612,t:1526919176230};\\\", \\\"{x:816,y:611,t:1526919176247};\\\", \\\"{x:801,y:606,t:1526919176263};\\\", \\\"{x:795,y:605,t:1526919176281};\\\", \\\"{x:790,y:604,t:1526919176296};\\\", \\\"{x:785,y:602,t:1526919176313};\\\", \\\"{x:778,y:601,t:1526919176330};\\\", \\\"{x:765,y:599,t:1526919176348};\\\", \\\"{x:753,y:597,t:1526919176364};\\\", \\\"{x:738,y:596,t:1526919176381};\\\", \\\"{x:730,y:592,t:1526919176397};\\\", \\\"{x:720,y:591,t:1526919176414};\\\", \\\"{x:705,y:591,t:1526919176431};\\\", \\\"{x:688,y:587,t:1526919176447};\\\", \\\"{x:670,y:586,t:1526919176463};\\\", \\\"{x:659,y:586,t:1526919176481};\\\", \\\"{x:647,y:586,t:1526919176496};\\\", \\\"{x:637,y:586,t:1526919176514};\\\", \\\"{x:633,y:589,t:1526919176531};\\\", \\\"{x:633,y:590,t:1526919176559};\\\", \\\"{x:633,y:591,t:1526919176566};\\\", \\\"{x:633,y:592,t:1526919176591};\\\", \\\"{x:633,y:595,t:1526919176600};\\\", \\\"{x:633,y:596,t:1526919177104};\\\", \\\"{x:633,y:595,t:1526919177375};\\\", \\\"{x:633,y:594,t:1526919177383};\\\", \\\"{x:633,y:593,t:1526919177416};\\\", \\\"{x:632,y:592,t:1526919177447};\\\", \\\"{x:632,y:591,t:1526919177479};\\\", \\\"{x:631,y:591,t:1526919177495};\\\", \\\"{x:631,y:590,t:1526919177527};\\\", \\\"{x:631,y:589,t:1526919177640};\\\", \\\"{x:631,y:588,t:1526919177680};\\\", \\\"{x:630,y:588,t:1526919177768};\\\", \\\"{x:630,y:587,t:1526919177784};\\\", \\\"{x:629,y:586,t:1526919177863};\\\", \\\"{x:629,y:584,t:1526919178023};\\\", \\\"{x:629,y:583,t:1526919178127};\\\", \\\"{x:629,y:581,t:1526919178431};\\\", \\\"{x:628,y:579,t:1526919178671};\\\", \\\"{x:628,y:578,t:1526919178776};\\\", \\\"{x:627,y:577,t:1526919178847};\\\", \\\"{x:627,y:576,t:1526919178872};\\\", \\\"{x:627,y:575,t:1526919178903};\\\", \\\"{x:627,y:574,t:1526919179052};\\\", \\\"{x:627,y:573,t:1526919179083};\\\", \\\"{x:626,y:571,t:1526919179139};\\\", \\\"{x:626,y:570,t:1526919179195};\\\", \\\"{x:626,y:568,t:1526919179203};\\\", \\\"{x:625,y:568,t:1526919179220};\\\", \\\"{x:624,y:567,t:1526919179236};\\\", \\\"{x:624,y:566,t:1526919179267};\\\", \\\"{x:624,y:565,t:1526919179275};\\\", \\\"{x:623,y:565,t:1526919179292};\\\", \\\"{x:621,y:563,t:1526919179307};\\\", \\\"{x:621,y:562,t:1526919179320};\\\", \\\"{x:618,y:561,t:1526919179337};\\\", \\\"{x:616,y:557,t:1526919179354};\\\", \\\"{x:613,y:555,t:1526919179371};\\\", \\\"{x:607,y:551,t:1526919179387};\\\", \\\"{x:596,y:545,t:1526919179404};\\\", \\\"{x:589,y:541,t:1526919179420};\\\", \\\"{x:582,y:537,t:1526919179437};\\\", \\\"{x:576,y:534,t:1526919179454};\\\", \\\"{x:572,y:531,t:1526919179471};\\\", \\\"{x:562,y:528,t:1526919179487};\\\", \\\"{x:551,y:519,t:1526919179505};\\\", \\\"{x:537,y:512,t:1526919179522};\\\", \\\"{x:520,y:502,t:1526919179538};\\\", \\\"{x:499,y:493,t:1526919179554};\\\", \\\"{x:476,y:478,t:1526919179572};\\\", \\\"{x:468,y:474,t:1526919179588};\\\", \\\"{x:461,y:467,t:1526919179604};\\\", \\\"{x:452,y:462,t:1526919179621};\\\", \\\"{x:447,y:459,t:1526919179636};\\\", \\\"{x:441,y:457,t:1526919179654};\\\", \\\"{x:432,y:456,t:1526919179671};\\\", \\\"{x:409,y:461,t:1526919179688};\\\", \\\"{x:372,y:481,t:1526919179703};\\\", \\\"{x:319,y:504,t:1526919179721};\\\", \\\"{x:273,y:513,t:1526919179737};\\\", \\\"{x:234,y:518,t:1526919179755};\\\", \\\"{x:213,y:519,t:1526919179771};\\\", \\\"{x:212,y:519,t:1526919179787};\\\", \\\"{x:211,y:519,t:1526919179819};\\\", \\\"{x:210,y:519,t:1526919179835};\\\", \\\"{x:208,y:519,t:1526919179843};\\\", \\\"{x:206,y:519,t:1526919179853};\\\", \\\"{x:204,y:519,t:1526919179923};\\\", \\\"{x:202,y:519,t:1526919179937};\\\", \\\"{x:195,y:517,t:1526919179954};\\\", \\\"{x:191,y:511,t:1526919179971};\\\", \\\"{x:180,y:502,t:1526919179987};\\\", \\\"{x:173,y:500,t:1526919180004};\\\", \\\"{x:169,y:500,t:1526919180021};\\\", \\\"{x:170,y:501,t:1526919180452};\\\", \\\"{x:173,y:506,t:1526919180459};\\\", \\\"{x:178,y:511,t:1526919180471};\\\", \\\"{x:193,y:523,t:1526919180488};\\\", \\\"{x:217,y:535,t:1526919180506};\\\", \\\"{x:259,y:557,t:1526919180522};\\\", \\\"{x:319,y:579,t:1526919180538};\\\", \\\"{x:404,y:600,t:1526919180556};\\\", \\\"{x:473,y:618,t:1526919180571};\\\", \\\"{x:490,y:620,t:1526919180588};\\\", \\\"{x:492,y:621,t:1526919180605};\\\", \\\"{x:492,y:620,t:1526919180627};\\\", \\\"{x:491,y:620,t:1526919180638};\\\", \\\"{x:488,y:620,t:1526919180655};\\\", \\\"{x:487,y:620,t:1526919180671};\\\", \\\"{x:486,y:620,t:1526919180787};\\\", \\\"{x:485,y:620,t:1526919180827};\\\", \\\"{x:486,y:618,t:1526919180838};\\\", \\\"{x:493,y:612,t:1526919180854};\\\", \\\"{x:510,y:595,t:1526919180873};\\\", \\\"{x:538,y:580,t:1526919180888};\\\", \\\"{x:571,y:576,t:1526919180905};\\\", \\\"{x:595,y:576,t:1526919180921};\\\", \\\"{x:622,y:576,t:1526919180938};\\\", \\\"{x:643,y:575,t:1526919180955};\\\", \\\"{x:646,y:575,t:1526919180971};\\\", \\\"{x:646,y:574,t:1526919181060};\\\", \\\"{x:648,y:574,t:1526919181084};\\\", \\\"{x:649,y:577,t:1526919181092};\\\", \\\"{x:650,y:580,t:1526919181106};\\\", \\\"{x:653,y:588,t:1526919181122};\\\", \\\"{x:658,y:596,t:1526919181140};\\\", \\\"{x:668,y:606,t:1526919181156};\\\", \\\"{x:672,y:610,t:1526919181171};\\\", \\\"{x:676,y:613,t:1526919181189};\\\", \\\"{x:681,y:615,t:1526919181206};\\\", \\\"{x:686,y:616,t:1526919181222};\\\", \\\"{x:696,y:617,t:1526919181239};\\\", \\\"{x:710,y:617,t:1526919181256};\\\", \\\"{x:733,y:618,t:1526919181276};\\\", \\\"{x:762,y:618,t:1526919181288};\\\", \\\"{x:782,y:618,t:1526919181306};\\\", \\\"{x:811,y:617,t:1526919181322};\\\", \\\"{x:832,y:613,t:1526919181339};\\\", \\\"{x:855,y:608,t:1526919181356};\\\", \\\"{x:862,y:605,t:1526919181372};\\\", \\\"{x:865,y:603,t:1526919181389};\\\", \\\"{x:861,y:603,t:1526919181531};\\\", \\\"{x:851,y:603,t:1526919181539};\\\", \\\"{x:827,y:603,t:1526919181555};\\\", \\\"{x:795,y:603,t:1526919181572};\\\", \\\"{x:753,y:603,t:1526919181589};\\\", \\\"{x:708,y:608,t:1526919181607};\\\", \\\"{x:664,y:614,t:1526919181622};\\\", \\\"{x:639,y:616,t:1526919181639};\\\", \\\"{x:619,y:621,t:1526919181656};\\\", \\\"{x:605,y:628,t:1526919181672};\\\", \\\"{x:594,y:634,t:1526919181689};\\\", \\\"{x:584,y:639,t:1526919181706};\\\", \\\"{x:572,y:644,t:1526919181722};\\\", \\\"{x:556,y:654,t:1526919181739};\\\", \\\"{x:542,y:655,t:1526919181755};\\\", \\\"{x:541,y:656,t:1526919181772};\\\", \\\"{x:540,y:657,t:1526919181789};\\\", \\\"{x:538,y:657,t:1526919181806};\\\", \\\"{x:534,y:657,t:1526919181822};\\\", \\\"{x:532,y:657,t:1526919181839};\\\", \\\"{x:521,y:657,t:1526919181856};\\\", \\\"{x:520,y:657,t:1526919181872};\\\", \\\"{x:520,y:656,t:1526919181955};\\\", \\\"{x:520,y:655,t:1526919181972};\\\", \\\"{x:520,y:654,t:1526919181989};\\\", \\\"{x:520,y:653,t:1526919182027};\\\", \\\"{x:521,y:651,t:1526919182039};\\\", \\\"{x:521,y:649,t:1526919182059};\\\", \\\"{x:521,y:647,t:1526919182072};\\\", \\\"{x:519,y:644,t:1526919182089};\\\", \\\"{x:508,y:638,t:1526919182106};\\\", \\\"{x:503,y:634,t:1526919182122};\\\", \\\"{x:492,y:630,t:1526919182139};\\\", \\\"{x:486,y:626,t:1526919182155};\\\", \\\"{x:479,y:623,t:1526919182172};\\\", \\\"{x:471,y:619,t:1526919182190};\\\", \\\"{x:464,y:616,t:1526919182206};\\\", \\\"{x:457,y:612,t:1526919182223};\\\", \\\"{x:445,y:605,t:1526919182240};\\\", \\\"{x:430,y:595,t:1526919182256};\\\", \\\"{x:416,y:587,t:1526919182273};\\\", \\\"{x:406,y:582,t:1526919182289};\\\", \\\"{x:395,y:574,t:1526919182306};\\\", \\\"{x:382,y:562,t:1526919182324};\\\", \\\"{x:376,y:557,t:1526919182339};\\\", \\\"{x:373,y:554,t:1526919182356};\\\", \\\"{x:372,y:552,t:1526919182373};\\\", \\\"{x:372,y:551,t:1526919182390};\\\", \\\"{x:371,y:548,t:1526919182405};\\\", \\\"{x:369,y:546,t:1526919182423};\\\", \\\"{x:368,y:542,t:1526919182439};\\\", \\\"{x:366,y:537,t:1526919182456};\\\", \\\"{x:366,y:535,t:1526919182473};\\\", \\\"{x:367,y:532,t:1526919182490};\\\", \\\"{x:369,y:530,t:1526919182506};\\\", \\\"{x:371,y:527,t:1526919182523};\\\", \\\"{x:373,y:525,t:1526919182539};\\\", \\\"{x:373,y:523,t:1526919182556};\\\", \\\"{x:374,y:522,t:1526919182573};\\\", \\\"{x:375,y:518,t:1526919182589};\\\", \\\"{x:376,y:517,t:1526919182606};\\\", \\\"{x:377,y:515,t:1526919182623};\\\", \\\"{x:377,y:513,t:1526919182651};\\\", \\\"{x:377,y:512,t:1526919182731};\\\", \\\"{x:378,y:512,t:1526919183284};\\\", \\\"{x:380,y:514,t:1526919183293};\\\", \\\"{x:384,y:518,t:1526919183308};\\\", \\\"{x:389,y:523,t:1526919183323};\\\", \\\"{x:393,y:526,t:1526919183341};\\\", \\\"{x:399,y:529,t:1526919183358};\\\", \\\"{x:404,y:532,t:1526919183374};\\\", \\\"{x:404,y:533,t:1526919183390};\\\", \\\"{x:404,y:534,t:1526919183407};\\\", \\\"{x:407,y:534,t:1526919183499};\\\", \\\"{x:411,y:536,t:1526919183507};\\\", \\\"{x:416,y:536,t:1526919183525};\\\", \\\"{x:422,y:537,t:1526919183540};\\\", \\\"{x:425,y:538,t:1526919183557};\\\", \\\"{x:426,y:538,t:1526919183574};\\\", \\\"{x:433,y:540,t:1526919183591};\\\", \\\"{x:434,y:540,t:1526919183607};\\\", \\\"{x:437,y:540,t:1526919183628};\\\", \\\"{x:441,y:540,t:1526919183641};\\\", \\\"{x:448,y:540,t:1526919183658};\\\", \\\"{x:454,y:540,t:1526919183674};\\\", \\\"{x:464,y:540,t:1526919183691};\\\", \\\"{x:468,y:540,t:1526919183708};\\\", \\\"{x:473,y:540,t:1526919183725};\\\", \\\"{x:480,y:540,t:1526919183741};\\\", \\\"{x:485,y:540,t:1526919183759};\\\", \\\"{x:492,y:539,t:1526919183774};\\\", \\\"{x:501,y:538,t:1526919183792};\\\", \\\"{x:508,y:537,t:1526919183808};\\\", \\\"{x:514,y:536,t:1526919183824};\\\", \\\"{x:521,y:535,t:1526919183841};\\\", \\\"{x:529,y:533,t:1526919183857};\\\", \\\"{x:535,y:530,t:1526919183874};\\\", \\\"{x:540,y:527,t:1526919183891};\\\", \\\"{x:542,y:526,t:1526919183907};\\\", \\\"{x:543,y:525,t:1526919183925};\\\", \\\"{x:544,y:524,t:1526919183941};\\\", \\\"{x:545,y:524,t:1526919183957};\\\", \\\"{x:545,y:523,t:1526919183979};\\\", \\\"{x:546,y:523,t:1526919183991};\\\", \\\"{x:548,y:521,t:1526919184007};\\\", \\\"{x:551,y:521,t:1526919184024};\\\", \\\"{x:558,y:518,t:1526919184041};\\\", \\\"{x:562,y:517,t:1526919184058};\\\", \\\"{x:567,y:517,t:1526919184074};\\\", \\\"{x:582,y:516,t:1526919184092};\\\", \\\"{x:589,y:514,t:1526919184108};\\\", \\\"{x:595,y:513,t:1526919184125};\\\", \\\"{x:596,y:512,t:1526919184141};\\\", \\\"{x:598,y:512,t:1526919184158};\\\", \\\"{x:600,y:510,t:1526919184174};\\\", \\\"{x:603,y:509,t:1526919184191};\\\", \\\"{x:606,y:508,t:1526919184208};\\\", \\\"{x:610,y:507,t:1526919184224};\\\", \\\"{x:610,y:506,t:1526919184364};\\\", \\\"{x:610,y:507,t:1526919184531};\\\", \\\"{x:610,y:514,t:1526919184542};\\\", \\\"{x:607,y:533,t:1526919184559};\\\", \\\"{x:604,y:560,t:1526919184576};\\\", \\\"{x:598,y:591,t:1526919184592};\\\", \\\"{x:590,y:610,t:1526919184608};\\\", \\\"{x:586,y:627,t:1526919184625};\\\", \\\"{x:584,y:639,t:1526919184642};\\\", \\\"{x:580,y:651,t:1526919184658};\\\", \\\"{x:570,y:673,t:1526919184675};\\\", \\\"{x:565,y:688,t:1526919184691};\\\", \\\"{x:560,y:704,t:1526919184708};\\\", \\\"{x:555,y:713,t:1526919184725};\\\", \\\"{x:553,y:717,t:1526919184742};\\\", \\\"{x:550,y:721,t:1526919184759};\\\", \\\"{x:549,y:724,t:1526919184775};\\\", \\\"{x:545,y:730,t:1526919184791};\\\", \\\"{x:543,y:733,t:1526919184808};\\\", \\\"{x:542,y:736,t:1526919184825};\\\", \\\"{x:542,y:739,t:1526919184841};\\\", \\\"{x:541,y:739,t:1526919184858};\\\", \\\"{x:541,y:740,t:1526919184884};\\\", \\\"{x:541,y:741,t:1526919184915};\\\", \\\"{x:541,y:740,t:1526919185619};\\\", \\\"{x:541,y:739,t:1526919185651};\\\", \\\"{x:541,y:737,t:1526919185692};\\\", \\\"{x:541,y:736,t:1526919185787};\\\", \\\"{x:541,y:734,t:1526919186003};\\\", \\\"{x:542,y:733,t:1526919186019};\\\", \\\"{x:543,y:732,t:1526919186116};\\\", \\\"{x:543,y:731,t:1526919186147};\\\" ] }, { \\\"rt\\\": 9495, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 436410, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:730,t:1526919186424};\\\", \\\"{x:545,y:730,t:1526919186576};\\\", \\\"{x:546,y:729,t:1526919186595};\\\", \\\"{x:547,y:729,t:1526919186899};\\\", \\\"{x:550,y:727,t:1526919186910};\\\", \\\"{x:550,y:724,t:1526919186926};\\\", \\\"{x:551,y:717,t:1526919186943};\\\", \\\"{x:554,y:701,t:1526919186960};\\\", \\\"{x:554,y:685,t:1526919186977};\\\", \\\"{x:554,y:663,t:1526919186993};\\\", \\\"{x:546,y:626,t:1526919187010};\\\", \\\"{x:526,y:584,t:1526919187027};\\\", \\\"{x:515,y:565,t:1526919187043};\\\", \\\"{x:506,y:551,t:1526919187061};\\\", \\\"{x:499,y:543,t:1526919187077};\\\", \\\"{x:497,y:540,t:1526919187094};\\\", \\\"{x:496,y:539,t:1526919187111};\\\", \\\"{x:495,y:539,t:1526919187155};\\\", \\\"{x:494,y:538,t:1526919187163};\\\", \\\"{x:492,y:537,t:1526919187177};\\\", \\\"{x:488,y:533,t:1526919187193};\\\", \\\"{x:484,y:531,t:1526919187210};\\\", \\\"{x:476,y:523,t:1526919187227};\\\", \\\"{x:472,y:522,t:1526919187243};\\\", \\\"{x:472,y:521,t:1526919187267};\\\", \\\"{x:474,y:519,t:1526919187379};\\\", \\\"{x:479,y:517,t:1526919187395};\\\", \\\"{x:486,y:511,t:1526919187410};\\\", \\\"{x:500,y:505,t:1526919187427};\\\", \\\"{x:509,y:501,t:1526919187444};\\\", \\\"{x:514,y:498,t:1526919187460};\\\", \\\"{x:517,y:498,t:1526919187477};\\\", \\\"{x:518,y:498,t:1526919187494};\\\", \\\"{x:519,y:498,t:1526919187530};\\\", \\\"{x:519,y:497,t:1526919187547};\\\", \\\"{x:520,y:497,t:1526919187563};\\\", \\\"{x:521,y:497,t:1526919187643};\\\", \\\"{x:522,y:497,t:1526919187675};\\\", \\\"{x:522,y:496,t:1526919187684};\\\", \\\"{x:523,y:495,t:1526919187747};\\\", \\\"{x:525,y:495,t:1526919187795};\\\", \\\"{x:525,y:494,t:1526919187811};\\\", \\\"{x:526,y:494,t:1526919187836};\\\", \\\"{x:526,y:493,t:1526919187844};\\\", \\\"{x:528,y:490,t:1526919187860};\\\", \\\"{x:529,y:488,t:1526919187877};\\\", \\\"{x:530,y:487,t:1526919187895};\\\", \\\"{x:531,y:486,t:1526919187911};\\\", \\\"{x:531,y:485,t:1526919187971};\\\", \\\"{x:532,y:485,t:1526919188707};\\\", \\\"{x:536,y:485,t:1526919188715};\\\", \\\"{x:542,y:485,t:1526919188729};\\\", \\\"{x:555,y:486,t:1526919188747};\\\", \\\"{x:574,y:488,t:1526919188763};\\\", \\\"{x:587,y:491,t:1526919188779};\\\", \\\"{x:596,y:492,t:1526919188795};\\\", \\\"{x:601,y:494,t:1526919188812};\\\", \\\"{x:606,y:495,t:1526919188828};\\\", \\\"{x:612,y:498,t:1526919188845};\\\", \\\"{x:616,y:501,t:1526919188861};\\\", \\\"{x:626,y:506,t:1526919188878};\\\", \\\"{x:638,y:514,t:1526919188896};\\\", \\\"{x:653,y:521,t:1526919188912};\\\", \\\"{x:676,y:531,t:1526919188929};\\\", \\\"{x:698,y:543,t:1526919188945};\\\", \\\"{x:724,y:553,t:1526919188962};\\\", \\\"{x:749,y:563,t:1526919188979};\\\", \\\"{x:770,y:577,t:1526919188995};\\\", \\\"{x:790,y:587,t:1526919189012};\\\", \\\"{x:808,y:597,t:1526919189029};\\\", \\\"{x:828,y:608,t:1526919189045};\\\", \\\"{x:849,y:621,t:1526919189061};\\\", \\\"{x:867,y:632,t:1526919189079};\\\", \\\"{x:890,y:645,t:1526919189095};\\\", \\\"{x:910,y:655,t:1526919189111};\\\", \\\"{x:928,y:669,t:1526919189128};\\\", \\\"{x:953,y:685,t:1526919189145};\\\", \\\"{x:982,y:702,t:1526919189162};\\\", \\\"{x:1000,y:715,t:1526919189178};\\\", \\\"{x:1028,y:733,t:1526919189195};\\\", \\\"{x:1042,y:746,t:1526919189211};\\\", \\\"{x:1048,y:753,t:1526919189228};\\\", \\\"{x:1056,y:759,t:1526919189244};\\\", \\\"{x:1072,y:770,t:1526919189261};\\\", \\\"{x:1087,y:781,t:1526919189278};\\\", \\\"{x:1102,y:791,t:1526919189295};\\\", \\\"{x:1117,y:801,t:1526919189312};\\\", \\\"{x:1128,y:809,t:1526919189328};\\\", \\\"{x:1136,y:817,t:1526919189344};\\\", \\\"{x:1148,y:826,t:1526919189361};\\\", \\\"{x:1157,y:832,t:1526919189378};\\\", \\\"{x:1165,y:838,t:1526919189395};\\\", \\\"{x:1184,y:849,t:1526919189411};\\\", \\\"{x:1196,y:856,t:1526919189427};\\\", \\\"{x:1209,y:862,t:1526919189444};\\\", \\\"{x:1226,y:867,t:1526919189461};\\\", \\\"{x:1242,y:872,t:1526919189477};\\\", \\\"{x:1263,y:877,t:1526919189495};\\\", \\\"{x:1287,y:881,t:1526919189511};\\\", \\\"{x:1307,y:884,t:1526919189527};\\\", \\\"{x:1324,y:885,t:1526919189544};\\\", \\\"{x:1334,y:885,t:1526919189561};\\\", \\\"{x:1340,y:885,t:1526919189578};\\\", \\\"{x:1345,y:885,t:1526919189594};\\\", \\\"{x:1351,y:885,t:1526919189610};\\\", \\\"{x:1371,y:883,t:1526919189627};\\\", \\\"{x:1381,y:883,t:1526919189643};\\\", \\\"{x:1395,y:882,t:1526919189661};\\\", \\\"{x:1406,y:882,t:1526919189677};\\\", \\\"{x:1413,y:881,t:1526919189693};\\\", \\\"{x:1414,y:879,t:1526919189711};\\\", \\\"{x:1419,y:878,t:1526919189726};\\\", \\\"{x:1425,y:876,t:1526919189744};\\\", \\\"{x:1429,y:875,t:1526919189760};\\\", \\\"{x:1435,y:874,t:1526919189777};\\\", \\\"{x:1444,y:874,t:1526919189793};\\\", \\\"{x:1449,y:874,t:1526919189810};\\\", \\\"{x:1453,y:873,t:1526919189826};\\\", \\\"{x:1452,y:873,t:1526919189964};\\\", \\\"{x:1444,y:872,t:1526919189976};\\\", \\\"{x:1430,y:870,t:1526919189992};\\\", \\\"{x:1412,y:867,t:1526919190009};\\\", \\\"{x:1391,y:864,t:1526919190027};\\\", \\\"{x:1380,y:862,t:1526919190042};\\\", \\\"{x:1371,y:861,t:1526919190059};\\\", \\\"{x:1369,y:861,t:1526919190077};\\\", \\\"{x:1365,y:860,t:1526919190092};\\\", \\\"{x:1361,y:860,t:1526919190110};\\\", \\\"{x:1353,y:858,t:1526919190126};\\\", \\\"{x:1340,y:855,t:1526919190142};\\\", \\\"{x:1324,y:852,t:1526919190159};\\\", \\\"{x:1309,y:850,t:1526919190175};\\\", \\\"{x:1296,y:848,t:1526919190193};\\\", \\\"{x:1283,y:847,t:1526919190209};\\\", \\\"{x:1274,y:845,t:1526919190225};\\\", \\\"{x:1270,y:845,t:1526919190242};\\\", \\\"{x:1266,y:844,t:1526919190260};\\\", \\\"{x:1265,y:844,t:1526919190274};\\\", \\\"{x:1263,y:844,t:1526919190292};\\\", \\\"{x:1256,y:843,t:1526919190308};\\\", \\\"{x:1252,y:842,t:1526919190325};\\\", \\\"{x:1238,y:839,t:1526919190342};\\\", \\\"{x:1229,y:839,t:1526919190358};\\\", \\\"{x:1221,y:838,t:1526919190375};\\\", \\\"{x:1216,y:835,t:1526919190392};\\\", \\\"{x:1215,y:835,t:1526919190408};\\\", \\\"{x:1214,y:835,t:1526919190427};\\\", \\\"{x:1212,y:834,t:1526919190451};\\\", \\\"{x:1210,y:834,t:1526919190459};\\\", \\\"{x:1206,y:831,t:1526919190475};\\\", \\\"{x:1200,y:827,t:1526919190491};\\\", \\\"{x:1189,y:824,t:1526919190508};\\\", \\\"{x:1177,y:819,t:1526919190524};\\\", \\\"{x:1165,y:812,t:1526919190541};\\\", \\\"{x:1157,y:807,t:1526919190558};\\\", \\\"{x:1148,y:799,t:1526919190574};\\\", \\\"{x:1143,y:792,t:1526919190591};\\\", \\\"{x:1133,y:785,t:1526919190608};\\\", \\\"{x:1127,y:780,t:1526919190624};\\\", \\\"{x:1125,y:776,t:1526919190642};\\\", \\\"{x:1124,y:774,t:1526919190657};\\\", \\\"{x:1124,y:773,t:1526919190675};\\\", \\\"{x:1124,y:771,t:1526919190715};\\\", \\\"{x:1124,y:770,t:1526919190731};\\\", \\\"{x:1125,y:770,t:1526919190741};\\\", \\\"{x:1128,y:770,t:1526919190757};\\\", \\\"{x:1131,y:770,t:1526919190774};\\\", \\\"{x:1135,y:770,t:1526919190791};\\\", \\\"{x:1138,y:770,t:1526919190808};\\\", \\\"{x:1139,y:770,t:1526919190824};\\\", \\\"{x:1141,y:770,t:1526919190840};\\\", \\\"{x:1142,y:770,t:1526919190858};\\\", \\\"{x:1146,y:770,t:1526919190874};\\\", \\\"{x:1149,y:770,t:1526919190890};\\\", \\\"{x:1156,y:770,t:1526919190908};\\\", \\\"{x:1162,y:770,t:1526919190923};\\\", \\\"{x:1166,y:770,t:1526919190941};\\\", \\\"{x:1171,y:770,t:1526919190957};\\\", \\\"{x:1175,y:770,t:1526919190974};\\\", \\\"{x:1178,y:770,t:1526919190990};\\\", \\\"{x:1179,y:770,t:1526919191019};\\\", \\\"{x:1179,y:771,t:1526919191427};\\\", \\\"{x:1178,y:771,t:1526919191439};\\\", \\\"{x:1174,y:771,t:1526919191455};\\\", \\\"{x:1172,y:771,t:1526919191475};\\\", \\\"{x:1171,y:771,t:1526919191489};\\\", \\\"{x:1170,y:770,t:1526919191505};\\\", \\\"{x:1168,y:769,t:1526919191522};\\\", \\\"{x:1164,y:766,t:1526919191538};\\\", \\\"{x:1159,y:761,t:1526919191555};\\\", \\\"{x:1154,y:759,t:1526919191573};\\\", \\\"{x:1146,y:754,t:1526919191588};\\\", \\\"{x:1141,y:751,t:1526919191605};\\\", \\\"{x:1133,y:748,t:1526919191623};\\\", \\\"{x:1122,y:745,t:1526919191638};\\\", \\\"{x:1109,y:740,t:1526919191655};\\\", \\\"{x:1095,y:736,t:1526919191673};\\\", \\\"{x:1082,y:733,t:1526919191688};\\\", \\\"{x:1069,y:729,t:1526919191705};\\\", \\\"{x:1060,y:726,t:1526919191722};\\\", \\\"{x:1055,y:725,t:1526919191738};\\\", \\\"{x:1049,y:722,t:1526919191755};\\\", \\\"{x:1048,y:722,t:1526919191771};\\\", \\\"{x:1047,y:721,t:1526919191788};\\\", \\\"{x:1045,y:719,t:1526919192715};\\\", \\\"{x:1042,y:717,t:1526919192723};\\\", \\\"{x:1032,y:711,t:1526919192735};\\\", \\\"{x:1010,y:700,t:1526919192752};\\\", \\\"{x:979,y:686,t:1526919192769};\\\", \\\"{x:935,y:668,t:1526919192785};\\\", \\\"{x:885,y:647,t:1526919192802};\\\", \\\"{x:822,y:619,t:1526919192819};\\\", \\\"{x:770,y:598,t:1526919192836};\\\", \\\"{x:711,y:568,t:1526919192853};\\\", \\\"{x:678,y:558,t:1526919192865};\\\", \\\"{x:609,y:527,t:1526919192882};\\\", \\\"{x:544,y:508,t:1526919192898};\\\", \\\"{x:509,y:494,t:1526919192915};\\\", \\\"{x:485,y:489,t:1526919192931};\\\", \\\"{x:484,y:489,t:1526919192948};\\\", \\\"{x:479,y:489,t:1526919193011};\\\", \\\"{x:473,y:489,t:1526919193019};\\\", \\\"{x:462,y:489,t:1526919193031};\\\", \\\"{x:439,y:493,t:1526919193048};\\\", \\\"{x:417,y:498,t:1526919193065};\\\", \\\"{x:397,y:501,t:1526919193083};\\\", \\\"{x:381,y:502,t:1526919193098};\\\", \\\"{x:360,y:503,t:1526919193115};\\\", \\\"{x:321,y:503,t:1526919193131};\\\", \\\"{x:299,y:503,t:1526919193149};\\\", \\\"{x:287,y:503,t:1526919193165};\\\", \\\"{x:280,y:502,t:1526919193182};\\\", \\\"{x:277,y:502,t:1526919193198};\\\", \\\"{x:274,y:501,t:1526919193216};\\\", \\\"{x:269,y:500,t:1526919193233};\\\", \\\"{x:259,y:498,t:1526919193248};\\\", \\\"{x:239,y:495,t:1526919193265};\\\", \\\"{x:225,y:493,t:1526919193283};\\\", \\\"{x:220,y:492,t:1526919193298};\\\", \\\"{x:219,y:491,t:1526919193315};\\\", \\\"{x:218,y:491,t:1526919193380};\\\", \\\"{x:216,y:491,t:1526919193387};\\\", \\\"{x:214,y:491,t:1526919193399};\\\", \\\"{x:211,y:491,t:1526919193416};\\\", \\\"{x:210,y:491,t:1526919193435};\\\", \\\"{x:209,y:491,t:1526919193468};\\\", \\\"{x:208,y:491,t:1526919193483};\\\", \\\"{x:206,y:495,t:1526919193500};\\\", \\\"{x:204,y:497,t:1526919193516};\\\", \\\"{x:203,y:499,t:1526919193533};\\\", \\\"{x:202,y:499,t:1526919193550};\\\", \\\"{x:201,y:499,t:1526919193629};\\\", \\\"{x:200,y:500,t:1526919193644};\\\", \\\"{x:198,y:501,t:1526919194115};\\\", \\\"{x:196,y:502,t:1526919194123};\\\", \\\"{x:196,y:503,t:1526919194133};\\\", \\\"{x:194,y:503,t:1526919194150};\\\", \\\"{x:193,y:503,t:1526919194168};\\\", \\\"{x:190,y:503,t:1526919194184};\\\", \\\"{x:189,y:503,t:1526919194371};\\\", \\\"{x:188,y:503,t:1526919194384};\\\", \\\"{x:187,y:503,t:1526919194400};\\\", \\\"{x:185,y:503,t:1526919194449};\\\", \\\"{x:184,y:503,t:1526919194475};\\\", \\\"{x:183,y:503,t:1526919194531};\\\", \\\"{x:182,y:504,t:1526919194564};\\\", \\\"{x:182,y:504,t:1526919194646};\\\", \\\"{x:182,y:507,t:1526919194747};\\\", \\\"{x:186,y:511,t:1526919194755};\\\", \\\"{x:192,y:515,t:1526919194767};\\\", \\\"{x:206,y:525,t:1526919194784};\\\", \\\"{x:227,y:537,t:1526919194799};\\\", \\\"{x:243,y:545,t:1526919194817};\\\", \\\"{x:256,y:551,t:1526919194833};\\\", \\\"{x:266,y:556,t:1526919194850};\\\", \\\"{x:275,y:564,t:1526919194867};\\\", \\\"{x:297,y:583,t:1526919194883};\\\", \\\"{x:312,y:596,t:1526919194900};\\\", \\\"{x:330,y:609,t:1526919194917};\\\", \\\"{x:342,y:621,t:1526919194933};\\\", \\\"{x:352,y:628,t:1526919194949};\\\", \\\"{x:361,y:638,t:1526919194967};\\\", \\\"{x:368,y:647,t:1526919194984};\\\", \\\"{x:374,y:656,t:1526919195000};\\\", \\\"{x:381,y:667,t:1526919195016};\\\", \\\"{x:391,y:680,t:1526919195034};\\\", \\\"{x:401,y:691,t:1526919195050};\\\", \\\"{x:411,y:704,t:1526919195066};\\\", \\\"{x:428,y:718,t:1526919195084};\\\", \\\"{x:441,y:729,t:1526919195100};\\\", \\\"{x:450,y:734,t:1526919195118};\\\", \\\"{x:459,y:742,t:1526919195133};\\\", \\\"{x:466,y:745,t:1526919195151};\\\", \\\"{x:467,y:745,t:1526919195167};\\\", \\\"{x:469,y:745,t:1526919195244};\\\", \\\"{x:471,y:745,t:1526919195251};\\\", \\\"{x:474,y:744,t:1526919195267};\\\", \\\"{x:477,y:742,t:1526919195284};\\\" ] }, { \\\"rt\\\": 42999, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 480632, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -02 PM-12 PM-02 PM-03 PM-N \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:741,t:1526919197452};\\\", \\\"{x:480,y:741,t:1526919197468};\\\", \\\"{x:481,y:741,t:1526919197485};\\\", \\\"{x:481,y:740,t:1526919197524};\\\", \\\"{x:483,y:738,t:1526919197590};\\\", \\\"{x:484,y:738,t:1526919197601};\\\", \\\"{x:486,y:736,t:1526919197617};\\\", \\\"{x:487,y:735,t:1526919197634};\\\", \\\"{x:491,y:730,t:1526919197651};\\\", \\\"{x:493,y:721,t:1526919197667};\\\", \\\"{x:497,y:710,t:1526919197684};\\\", \\\"{x:497,y:700,t:1526919197700};\\\", \\\"{x:497,y:687,t:1526919197718};\\\", \\\"{x:497,y:673,t:1526919197736};\\\", \\\"{x:494,y:652,t:1526919197753};\\\", \\\"{x:482,y:637,t:1526919197770};\\\", \\\"{x:470,y:618,t:1526919197786};\\\", \\\"{x:458,y:601,t:1526919197802};\\\", \\\"{x:438,y:581,t:1526919197819};\\\", \\\"{x:433,y:571,t:1526919197836};\\\", \\\"{x:427,y:564,t:1526919197853};\\\", \\\"{x:421,y:551,t:1526919197871};\\\", \\\"{x:413,y:541,t:1526919197885};\\\", \\\"{x:404,y:524,t:1526919197903};\\\", \\\"{x:398,y:513,t:1526919197920};\\\", \\\"{x:394,y:506,t:1526919197936};\\\", \\\"{x:391,y:501,t:1526919197953};\\\", \\\"{x:390,y:497,t:1526919197969};\\\", \\\"{x:390,y:495,t:1526919197985};\\\", \\\"{x:390,y:493,t:1526919198003};\\\", \\\"{x:390,y:491,t:1526919198019};\\\", \\\"{x:390,y:488,t:1526919198036};\\\", \\\"{x:391,y:487,t:1526919198059};\\\", \\\"{x:392,y:486,t:1526919198069};\\\", \\\"{x:394,y:484,t:1526919198086};\\\", \\\"{x:397,y:482,t:1526919198102};\\\", \\\"{x:401,y:481,t:1526919198120};\\\", \\\"{x:403,y:479,t:1526919198135};\\\", \\\"{x:408,y:479,t:1526919198153};\\\", \\\"{x:413,y:477,t:1526919198170};\\\", \\\"{x:423,y:475,t:1526919198186};\\\", \\\"{x:442,y:473,t:1526919198203};\\\", \\\"{x:454,y:472,t:1526919198219};\\\", \\\"{x:469,y:469,t:1526919198236};\\\", \\\"{x:476,y:469,t:1526919198252};\\\", \\\"{x:481,y:469,t:1526919198270};\\\", \\\"{x:483,y:468,t:1526919198285};\\\", \\\"{x:484,y:468,t:1526919198302};\\\", \\\"{x:486,y:468,t:1526919198320};\\\", \\\"{x:489,y:467,t:1526919198336};\\\", \\\"{x:492,y:467,t:1526919198353};\\\", \\\"{x:494,y:467,t:1526919198369};\\\", \\\"{x:495,y:467,t:1526919198385};\\\", \\\"{x:498,y:467,t:1526919198402};\\\", \\\"{x:501,y:467,t:1526919198419};\\\", \\\"{x:504,y:467,t:1526919198436};\\\", \\\"{x:507,y:466,t:1526919198452};\\\", \\\"{x:509,y:466,t:1526919198469};\\\", \\\"{x:514,y:466,t:1526919198487};\\\", \\\"{x:519,y:466,t:1526919198502};\\\", \\\"{x:524,y:466,t:1526919198519};\\\", \\\"{x:529,y:466,t:1526919198536};\\\", \\\"{x:532,y:466,t:1526919198553};\\\", \\\"{x:537,y:466,t:1526919198570};\\\", \\\"{x:544,y:466,t:1526919198587};\\\", \\\"{x:553,y:466,t:1526919198603};\\\", \\\"{x:556,y:466,t:1526919198620};\\\", \\\"{x:560,y:466,t:1526919198637};\\\", \\\"{x:563,y:466,t:1526919198652};\\\", \\\"{x:568,y:466,t:1526919198670};\\\", \\\"{x:571,y:466,t:1526919198686};\\\", \\\"{x:576,y:466,t:1526919198703};\\\", \\\"{x:581,y:469,t:1526919198719};\\\", \\\"{x:584,y:469,t:1526919198736};\\\", \\\"{x:588,y:469,t:1526919198753};\\\", \\\"{x:589,y:469,t:1526919198770};\\\", \\\"{x:590,y:469,t:1526919198787};\\\", \\\"{x:592,y:469,t:1526919198803};\\\", \\\"{x:596,y:470,t:1526919198819};\\\", \\\"{x:599,y:471,t:1526919198837};\\\", \\\"{x:603,y:471,t:1526919198853};\\\", \\\"{x:607,y:472,t:1526919198870};\\\", \\\"{x:611,y:473,t:1526919198887};\\\", \\\"{x:613,y:473,t:1526919198903};\\\", \\\"{x:618,y:474,t:1526919198919};\\\", \\\"{x:623,y:476,t:1526919198937};\\\", \\\"{x:627,y:477,t:1526919198954};\\\", \\\"{x:629,y:478,t:1526919198970};\\\", \\\"{x:637,y:480,t:1526919198987};\\\", \\\"{x:643,y:480,t:1526919199003};\\\", \\\"{x:651,y:482,t:1526919199020};\\\", \\\"{x:665,y:487,t:1526919199038};\\\", \\\"{x:680,y:491,t:1526919199054};\\\", \\\"{x:691,y:494,t:1526919199070};\\\", \\\"{x:708,y:497,t:1526919199087};\\\", \\\"{x:727,y:503,t:1526919199105};\\\", \\\"{x:746,y:508,t:1526919199120};\\\", \\\"{x:770,y:516,t:1526919199136};\\\", \\\"{x:800,y:525,t:1526919199155};\\\", \\\"{x:828,y:532,t:1526919199170};\\\", \\\"{x:878,y:550,t:1526919199187};\\\", \\\"{x:900,y:557,t:1526919199204};\\\", \\\"{x:928,y:568,t:1526919199220};\\\", \\\"{x:961,y:575,t:1526919199237};\\\", \\\"{x:986,y:581,t:1526919199254};\\\", \\\"{x:1002,y:586,t:1526919199271};\\\", \\\"{x:1024,y:594,t:1526919199287};\\\", \\\"{x:1052,y:600,t:1526919199304};\\\", \\\"{x:1080,y:607,t:1526919199321};\\\", \\\"{x:1108,y:612,t:1526919199338};\\\", \\\"{x:1136,y:620,t:1526919199353};\\\", \\\"{x:1160,y:624,t:1526919199371};\\\", \\\"{x:1182,y:630,t:1526919199387};\\\", \\\"{x:1195,y:634,t:1526919199404};\\\", \\\"{x:1201,y:638,t:1526919199421};\\\", \\\"{x:1207,y:640,t:1526919199437};\\\", \\\"{x:1216,y:645,t:1526919199455};\\\", \\\"{x:1221,y:649,t:1526919199471};\\\", \\\"{x:1230,y:656,t:1526919199488};\\\", \\\"{x:1241,y:663,t:1526919199505};\\\", \\\"{x:1255,y:674,t:1526919199522};\\\", \\\"{x:1267,y:682,t:1526919199538};\\\", \\\"{x:1276,y:690,t:1526919199555};\\\", \\\"{x:1283,y:695,t:1526919199571};\\\", \\\"{x:1287,y:700,t:1526919199588};\\\", \\\"{x:1295,y:710,t:1526919199605};\\\", \\\"{x:1307,y:722,t:1526919199622};\\\", \\\"{x:1316,y:734,t:1526919199639};\\\", \\\"{x:1333,y:748,t:1526919199655};\\\", \\\"{x:1347,y:758,t:1526919199674};\\\", \\\"{x:1363,y:767,t:1526919199689};\\\", \\\"{x:1375,y:773,t:1526919199705};\\\", \\\"{x:1386,y:779,t:1526919199721};\\\", \\\"{x:1407,y:786,t:1526919199739};\\\", \\\"{x:1424,y:788,t:1526919199755};\\\", \\\"{x:1444,y:791,t:1526919199772};\\\", \\\"{x:1463,y:795,t:1526919199789};\\\", \\\"{x:1484,y:799,t:1526919199806};\\\", \\\"{x:1506,y:803,t:1526919199823};\\\", \\\"{x:1528,y:806,t:1526919199839};\\\", \\\"{x:1546,y:809,t:1526919199856};\\\", \\\"{x:1555,y:810,t:1526919199873};\\\", \\\"{x:1559,y:811,t:1526919199889};\\\", \\\"{x:1561,y:811,t:1526919199906};\\\", \\\"{x:1563,y:811,t:1526919199923};\\\", \\\"{x:1568,y:811,t:1526919199939};\\\", \\\"{x:1575,y:811,t:1526919199956};\\\", \\\"{x:1587,y:811,t:1526919199972};\\\", \\\"{x:1602,y:811,t:1526919199989};\\\", \\\"{x:1611,y:811,t:1526919200007};\\\", \\\"{x:1616,y:811,t:1526919200023};\\\", \\\"{x:1617,y:811,t:1526919200040};\\\", \\\"{x:1617,y:809,t:1526919200056};\\\", \\\"{x:1617,y:806,t:1526919200073};\\\", \\\"{x:1617,y:800,t:1526919200090};\\\", \\\"{x:1617,y:794,t:1526919200106};\\\", \\\"{x:1617,y:792,t:1526919200163};\\\", \\\"{x:1617,y:791,t:1526919200173};\\\", \\\"{x:1617,y:789,t:1526919200190};\\\", \\\"{x:1617,y:787,t:1526919200206};\\\", \\\"{x:1617,y:785,t:1526919200224};\\\", \\\"{x:1617,y:781,t:1526919200241};\\\", \\\"{x:1617,y:778,t:1526919200256};\\\", \\\"{x:1617,y:776,t:1526919200274};\\\", \\\"{x:1617,y:771,t:1526919200291};\\\", \\\"{x:1617,y:765,t:1526919200307};\\\", \\\"{x:1617,y:761,t:1526919200324};\\\", \\\"{x:1617,y:757,t:1526919200341};\\\", \\\"{x:1617,y:751,t:1526919200357};\\\", \\\"{x:1616,y:745,t:1526919200374};\\\", \\\"{x:1614,y:738,t:1526919200391};\\\", \\\"{x:1611,y:730,t:1526919200407};\\\", \\\"{x:1607,y:725,t:1526919200425};\\\", \\\"{x:1604,y:718,t:1526919200440};\\\", \\\"{x:1601,y:713,t:1526919200458};\\\", \\\"{x:1594,y:707,t:1526919200474};\\\", \\\"{x:1590,y:705,t:1526919200491};\\\", \\\"{x:1587,y:705,t:1526919200508};\\\", \\\"{x:1585,y:703,t:1526919200524};\\\", \\\"{x:1582,y:703,t:1526919200542};\\\", \\\"{x:1581,y:703,t:1526919200558};\\\", \\\"{x:1577,y:701,t:1526919200575};\\\", \\\"{x:1575,y:701,t:1526919200592};\\\", \\\"{x:1572,y:701,t:1526919200609};\\\", \\\"{x:1569,y:701,t:1526919200625};\\\", \\\"{x:1567,y:701,t:1526919200642};\\\", \\\"{x:1560,y:703,t:1526919200659};\\\", \\\"{x:1554,y:706,t:1526919200675};\\\", \\\"{x:1544,y:711,t:1526919200692};\\\", \\\"{x:1536,y:717,t:1526919200709};\\\", \\\"{x:1527,y:723,t:1526919200725};\\\", \\\"{x:1524,y:726,t:1526919200741};\\\", \\\"{x:1520,y:729,t:1526919200759};\\\", \\\"{x:1518,y:731,t:1526919200776};\\\", \\\"{x:1516,y:734,t:1526919200793};\\\", \\\"{x:1512,y:738,t:1526919200809};\\\", \\\"{x:1507,y:743,t:1526919200826};\\\", \\\"{x:1502,y:746,t:1526919200843};\\\", \\\"{x:1500,y:747,t:1526919200859};\\\", \\\"{x:1496,y:749,t:1526919200875};\\\", \\\"{x:1492,y:749,t:1526919200893};\\\", \\\"{x:1486,y:749,t:1526919200910};\\\", \\\"{x:1476,y:749,t:1526919200926};\\\", \\\"{x:1469,y:749,t:1526919200942};\\\", \\\"{x:1457,y:749,t:1526919200959};\\\", \\\"{x:1442,y:748,t:1526919200977};\\\", \\\"{x:1434,y:747,t:1526919200993};\\\", \\\"{x:1424,y:743,t:1526919201010};\\\", \\\"{x:1412,y:739,t:1526919201027};\\\", \\\"{x:1404,y:737,t:1526919201042};\\\", \\\"{x:1399,y:734,t:1526919201060};\\\", \\\"{x:1391,y:732,t:1526919201077};\\\", \\\"{x:1381,y:729,t:1526919201094};\\\", \\\"{x:1372,y:726,t:1526919201110};\\\", \\\"{x:1365,y:724,t:1526919201127};\\\", \\\"{x:1360,y:721,t:1526919201144};\\\", \\\"{x:1358,y:720,t:1526919201161};\\\", \\\"{x:1357,y:719,t:1526919201177};\\\", \\\"{x:1354,y:717,t:1526919201194};\\\", \\\"{x:1353,y:716,t:1526919201211};\\\", \\\"{x:1350,y:715,t:1526919201227};\\\", \\\"{x:1349,y:714,t:1526919201244};\\\", \\\"{x:1348,y:713,t:1526919201261};\\\", \\\"{x:1347,y:712,t:1526919201278};\\\", \\\"{x:1347,y:711,t:1526919201308};\\\", \\\"{x:1346,y:711,t:1526919201340};\\\", \\\"{x:1346,y:709,t:1526919201380};\\\", \\\"{x:1346,y:708,t:1526919203275};\\\", \\\"{x:1347,y:708,t:1526919203285};\\\", \\\"{x:1350,y:709,t:1526919203301};\\\", \\\"{x:1351,y:710,t:1526919203318};\\\", \\\"{x:1352,y:711,t:1526919203339};\\\", \\\"{x:1353,y:713,t:1526919203427};\\\", \\\"{x:1354,y:713,t:1526919203443};\\\", \\\"{x:1354,y:714,t:1526919203459};\\\", \\\"{x:1354,y:715,t:1526919203468};\\\", \\\"{x:1354,y:716,t:1526919203485};\\\", \\\"{x:1354,y:718,t:1526919203516};\\\", \\\"{x:1354,y:719,t:1526919203532};\\\", \\\"{x:1355,y:719,t:1526919203540};\\\", \\\"{x:1355,y:721,t:1526919203552};\\\", \\\"{x:1357,y:723,t:1526919203569};\\\", \\\"{x:1358,y:725,t:1526919203586};\\\", \\\"{x:1359,y:733,t:1526919207980};\\\", \\\"{x:1361,y:740,t:1526919207987};\\\", \\\"{x:1362,y:747,t:1526919208001};\\\", \\\"{x:1366,y:761,t:1526919208017};\\\", \\\"{x:1372,y:780,t:1526919208035};\\\", \\\"{x:1379,y:801,t:1526919208051};\\\", \\\"{x:1383,y:817,t:1526919208068};\\\", \\\"{x:1388,y:831,t:1526919208085};\\\", \\\"{x:1394,y:845,t:1526919208101};\\\", \\\"{x:1401,y:859,t:1526919208118};\\\", \\\"{x:1408,y:875,t:1526919208135};\\\", \\\"{x:1415,y:889,t:1526919208151};\\\", \\\"{x:1425,y:905,t:1526919208168};\\\", \\\"{x:1434,y:923,t:1526919208185};\\\", \\\"{x:1443,y:939,t:1526919208201};\\\", \\\"{x:1454,y:953,t:1526919208219};\\\", \\\"{x:1464,y:968,t:1526919208234};\\\", \\\"{x:1470,y:977,t:1526919208252};\\\", \\\"{x:1474,y:979,t:1526919208268};\\\", \\\"{x:1479,y:983,t:1526919208285};\\\", \\\"{x:1485,y:988,t:1526919208302};\\\", \\\"{x:1498,y:995,t:1526919208319};\\\", \\\"{x:1509,y:1002,t:1526919208335};\\\", \\\"{x:1519,y:1006,t:1526919208352};\\\", \\\"{x:1522,y:1008,t:1526919208369};\\\", \\\"{x:1523,y:1009,t:1526919208707};\\\", \\\"{x:1523,y:1010,t:1526919208720};\\\", \\\"{x:1522,y:1015,t:1526919208737};\\\", \\\"{x:1520,y:1020,t:1526919208753};\\\", \\\"{x:1517,y:1025,t:1526919208770};\\\", \\\"{x:1515,y:1029,t:1526919208787};\\\", \\\"{x:1513,y:1032,t:1526919208804};\\\", \\\"{x:1512,y:1033,t:1526919208834};\\\", \\\"{x:1511,y:1035,t:1526919208843};\\\", \\\"{x:1510,y:1035,t:1526919208854};\\\", \\\"{x:1507,y:1035,t:1526919208871};\\\", \\\"{x:1501,y:1037,t:1526919208887};\\\", \\\"{x:1495,y:1038,t:1526919208904};\\\", \\\"{x:1487,y:1038,t:1526919208921};\\\", \\\"{x:1481,y:1039,t:1526919208937};\\\", \\\"{x:1475,y:1039,t:1526919208954};\\\", \\\"{x:1466,y:1039,t:1526919208971};\\\", \\\"{x:1458,y:1039,t:1526919208988};\\\", \\\"{x:1445,y:1034,t:1526919209004};\\\", \\\"{x:1438,y:1034,t:1526919209021};\\\", \\\"{x:1428,y:1033,t:1526919209038};\\\", \\\"{x:1422,y:1030,t:1526919209054};\\\", \\\"{x:1411,y:1029,t:1526919209071};\\\", \\\"{x:1404,y:1028,t:1526919209088};\\\", \\\"{x:1394,y:1024,t:1526919209105};\\\", \\\"{x:1383,y:1019,t:1526919209121};\\\", \\\"{x:1371,y:1014,t:1526919209138};\\\", \\\"{x:1357,y:1007,t:1526919209154};\\\", \\\"{x:1352,y:1004,t:1526919209171};\\\", \\\"{x:1346,y:998,t:1526919209189};\\\", \\\"{x:1340,y:993,t:1526919209205};\\\", \\\"{x:1329,y:981,t:1526919209223};\\\", \\\"{x:1316,y:966,t:1526919209238};\\\", \\\"{x:1302,y:947,t:1526919209255};\\\", \\\"{x:1291,y:932,t:1526919209272};\\\", \\\"{x:1286,y:924,t:1526919209289};\\\", \\\"{x:1284,y:918,t:1526919209305};\\\", \\\"{x:1283,y:914,t:1526919209322};\\\", \\\"{x:1281,y:907,t:1526919209339};\\\", \\\"{x:1280,y:905,t:1526919209355};\\\", \\\"{x:1280,y:902,t:1526919209372};\\\", \\\"{x:1280,y:899,t:1526919209389};\\\", \\\"{x:1279,y:899,t:1526919209406};\\\", \\\"{x:1279,y:898,t:1526919209556};\\\", \\\"{x:1283,y:901,t:1526919209573};\\\", \\\"{x:1288,y:907,t:1526919209590};\\\", \\\"{x:1295,y:912,t:1526919209607};\\\", \\\"{x:1302,y:917,t:1526919209623};\\\", \\\"{x:1308,y:920,t:1526919209641};\\\", \\\"{x:1315,y:922,t:1526919209657};\\\", \\\"{x:1322,y:926,t:1526919209674};\\\", \\\"{x:1335,y:932,t:1526919209690};\\\", \\\"{x:1352,y:937,t:1526919209708};\\\", \\\"{x:1364,y:941,t:1526919209724};\\\", \\\"{x:1370,y:941,t:1526919209741};\\\", \\\"{x:1377,y:945,t:1526919209757};\\\", \\\"{x:1380,y:945,t:1526919209774};\\\", \\\"{x:1386,y:947,t:1526919209790};\\\", \\\"{x:1391,y:949,t:1526919209808};\\\", \\\"{x:1394,y:949,t:1526919209824};\\\", \\\"{x:1396,y:950,t:1526919209841};\\\", \\\"{x:1397,y:950,t:1526919209857};\\\", \\\"{x:1401,y:951,t:1526919209874};\\\", \\\"{x:1408,y:952,t:1526919209891};\\\", \\\"{x:1415,y:955,t:1526919209907};\\\", \\\"{x:1422,y:957,t:1526919209924};\\\", \\\"{x:1428,y:959,t:1526919209942};\\\", \\\"{x:1433,y:960,t:1526919209958};\\\", \\\"{x:1434,y:961,t:1526919209975};\\\", \\\"{x:1438,y:962,t:1526919209991};\\\", \\\"{x:1441,y:964,t:1526919210009};\\\", \\\"{x:1447,y:968,t:1526919210025};\\\", \\\"{x:1457,y:973,t:1526919210042};\\\", \\\"{x:1469,y:978,t:1526919210059};\\\", \\\"{x:1485,y:987,t:1526919210076};\\\", \\\"{x:1492,y:990,t:1526919210092};\\\", \\\"{x:1496,y:992,t:1526919210109};\\\", \\\"{x:1501,y:994,t:1526919210125};\\\", \\\"{x:1503,y:995,t:1526919210142};\\\", \\\"{x:1505,y:996,t:1526919210171};\\\", \\\"{x:1508,y:998,t:1526919210179};\\\", \\\"{x:1510,y:1000,t:1526919210192};\\\", \\\"{x:1515,y:1004,t:1526919210208};\\\", \\\"{x:1518,y:1007,t:1526919210225};\\\", \\\"{x:1524,y:1010,t:1526919210243};\\\", \\\"{x:1531,y:1014,t:1526919210259};\\\", \\\"{x:1535,y:1017,t:1526919210275};\\\", \\\"{x:1540,y:1021,t:1526919210292};\\\", \\\"{x:1546,y:1025,t:1526919210309};\\\", \\\"{x:1551,y:1029,t:1526919210325};\\\", \\\"{x:1554,y:1031,t:1526919210343};\\\", \\\"{x:1557,y:1033,t:1526919210359};\\\", \\\"{x:1558,y:1034,t:1526919210395};\\\", \\\"{x:1559,y:1036,t:1526919210427};\\\", \\\"{x:1559,y:1037,t:1526919210532};\\\", \\\"{x:1559,y:1038,t:1526919210544};\\\", \\\"{x:1559,y:1039,t:1526919210563};\\\", \\\"{x:1559,y:1040,t:1526919210579};\\\", \\\"{x:1559,y:1041,t:1526919210596};\\\", \\\"{x:1559,y:1042,t:1526919210635};\\\", \\\"{x:1558,y:1042,t:1526919210652};\\\", \\\"{x:1558,y:1043,t:1526919210660};\\\", \\\"{x:1557,y:1044,t:1526919210677};\\\", \\\"{x:1555,y:1046,t:1526919210694};\\\", \\\"{x:1553,y:1048,t:1526919210711};\\\", \\\"{x:1552,y:1050,t:1526919210728};\\\", \\\"{x:1550,y:1051,t:1526919210744};\\\", \\\"{x:1549,y:1053,t:1526919210760};\\\", \\\"{x:1549,y:1054,t:1526919210778};\\\", \\\"{x:1548,y:1054,t:1526919210794};\\\", \\\"{x:1548,y:1051,t:1526919211035};\\\", \\\"{x:1547,y:1048,t:1526919211045};\\\", \\\"{x:1545,y:1044,t:1526919211061};\\\", \\\"{x:1544,y:1040,t:1526919211078};\\\", \\\"{x:1542,y:1036,t:1526919211095};\\\", \\\"{x:1542,y:1033,t:1526919211112};\\\", \\\"{x:1541,y:1032,t:1526919211129};\\\", \\\"{x:1540,y:1030,t:1526919211146};\\\", \\\"{x:1540,y:1029,t:1526919211180};\\\", \\\"{x:1539,y:1027,t:1526919211196};\\\", \\\"{x:1539,y:1026,t:1526919211293};\\\", \\\"{x:1539,y:1025,t:1526919211315};\\\", \\\"{x:1539,y:1024,t:1526919211331};\\\", \\\"{x:1539,y:1023,t:1526919211371};\\\", \\\"{x:1539,y:1022,t:1526919211395};\\\", \\\"{x:1539,y:1021,t:1526919211412};\\\", \\\"{x:1539,y:1020,t:1526919211467};\\\", \\\"{x:1539,y:1019,t:1526919211482};\\\", \\\"{x:1539,y:1018,t:1526919211497};\\\", \\\"{x:1539,y:1017,t:1526919211523};\\\", \\\"{x:1539,y:1016,t:1526919211538};\\\", \\\"{x:1539,y:1015,t:1526919211563};\\\", \\\"{x:1539,y:1014,t:1526919211611};\\\", \\\"{x:1539,y:1013,t:1526919211619};\\\", \\\"{x:1538,y:1011,t:1526919211635};\\\", \\\"{x:1538,y:1009,t:1526919211648};\\\", \\\"{x:1538,y:1004,t:1526919211663};\\\", \\\"{x:1538,y:994,t:1526919211681};\\\", \\\"{x:1538,y:981,t:1526919211698};\\\", \\\"{x:1539,y:975,t:1526919211714};\\\", \\\"{x:1540,y:967,t:1526919211731};\\\", \\\"{x:1542,y:961,t:1526919211747};\\\", \\\"{x:1546,y:951,t:1526919211764};\\\", \\\"{x:1550,y:937,t:1526919211781};\\\", \\\"{x:1557,y:920,t:1526919211797};\\\", \\\"{x:1562,y:911,t:1526919211814};\\\", \\\"{x:1564,y:906,t:1526919211832};\\\", \\\"{x:1566,y:902,t:1526919211848};\\\", \\\"{x:1568,y:900,t:1526919211865};\\\", \\\"{x:1569,y:899,t:1526919211881};\\\", \\\"{x:1569,y:897,t:1526919211899};\\\", \\\"{x:1570,y:897,t:1526919211915};\\\", \\\"{x:1571,y:896,t:1526919211931};\\\", \\\"{x:1572,y:893,t:1526919213404};\\\", \\\"{x:1580,y:890,t:1526919213420};\\\", \\\"{x:1582,y:889,t:1526919213436};\\\", \\\"{x:1587,y:888,t:1526919213454};\\\", \\\"{x:1593,y:884,t:1526919213470};\\\", \\\"{x:1599,y:882,t:1526919213487};\\\", \\\"{x:1608,y:880,t:1526919213504};\\\", \\\"{x:1622,y:875,t:1526919213521};\\\", \\\"{x:1634,y:870,t:1526919213538};\\\", \\\"{x:1646,y:866,t:1526919213554};\\\", \\\"{x:1654,y:862,t:1526919213571};\\\", \\\"{x:1656,y:861,t:1526919213588};\\\", \\\"{x:1658,y:860,t:1526919213604};\\\", \\\"{x:1658,y:859,t:1526919213636};\\\", \\\"{x:1660,y:857,t:1526919213652};\\\", \\\"{x:1660,y:856,t:1526919213660};\\\", \\\"{x:1662,y:854,t:1526919213671};\\\", \\\"{x:1663,y:853,t:1526919213688};\\\", \\\"{x:1665,y:851,t:1526919213705};\\\", \\\"{x:1666,y:850,t:1526919213722};\\\", \\\"{x:1667,y:849,t:1526919213737};\\\", \\\"{x:1670,y:847,t:1526919213756};\\\", \\\"{x:1671,y:845,t:1526919213772};\\\", \\\"{x:1672,y:844,t:1526919213788};\\\", \\\"{x:1673,y:843,t:1526919213804};\\\", \\\"{x:1675,y:842,t:1526919213892};\\\", \\\"{x:1675,y:841,t:1526919213904};\\\", \\\"{x:1677,y:840,t:1526919213921};\\\", \\\"{x:1679,y:838,t:1526919213938};\\\", \\\"{x:1679,y:836,t:1526919213955};\\\", \\\"{x:1680,y:835,t:1526919213972};\\\", \\\"{x:1680,y:833,t:1526919213988};\\\", \\\"{x:1682,y:832,t:1526919214005};\\\", \\\"{x:1682,y:830,t:1526919214022};\\\", \\\"{x:1683,y:829,t:1526919214038};\\\", \\\"{x:1682,y:829,t:1526919214339};\\\", \\\"{x:1679,y:831,t:1526919214356};\\\", \\\"{x:1669,y:836,t:1526919214373};\\\", \\\"{x:1663,y:842,t:1526919214389};\\\", \\\"{x:1659,y:846,t:1526919214407};\\\", \\\"{x:1654,y:850,t:1526919214423};\\\", \\\"{x:1652,y:852,t:1526919214440};\\\", \\\"{x:1649,y:855,t:1526919214456};\\\", \\\"{x:1645,y:859,t:1526919214473};\\\", \\\"{x:1640,y:864,t:1526919214490};\\\", \\\"{x:1639,y:867,t:1526919214506};\\\", \\\"{x:1637,y:868,t:1526919214523};\\\", \\\"{x:1636,y:869,t:1526919214541};\\\", \\\"{x:1634,y:871,t:1526919214557};\\\", \\\"{x:1633,y:872,t:1526919214573};\\\", \\\"{x:1632,y:874,t:1526919214591};\\\", \\\"{x:1630,y:875,t:1526919214607};\\\", \\\"{x:1627,y:879,t:1526919214624};\\\", \\\"{x:1625,y:881,t:1526919214641};\\\", \\\"{x:1624,y:883,t:1526919214657};\\\", \\\"{x:1624,y:883,t:1526919214755};\\\", \\\"{x:1624,y:884,t:1526919214794};\\\", \\\"{x:1622,y:886,t:1526919214810};\\\", \\\"{x:1621,y:886,t:1526919214842};\\\", \\\"{x:1620,y:887,t:1526919214858};\\\", \\\"{x:1619,y:888,t:1526919214914};\\\", \\\"{x:1617,y:889,t:1526919214939};\\\", \\\"{x:1616,y:890,t:1526919214970};\\\", \\\"{x:1615,y:890,t:1526919214979};\\\", \\\"{x:1614,y:890,t:1526919215002};\\\", \\\"{x:1612,y:890,t:1526919215010};\\\", \\\"{x:1611,y:890,t:1526919215027};\\\", \\\"{x:1609,y:890,t:1526919215042};\\\", \\\"{x:1607,y:890,t:1526919215058};\\\", \\\"{x:1604,y:891,t:1526919215076};\\\", \\\"{x:1599,y:891,t:1526919215093};\\\", \\\"{x:1595,y:891,t:1526919215109};\\\", \\\"{x:1588,y:891,t:1526919215125};\\\", \\\"{x:1582,y:891,t:1526919215143};\\\", \\\"{x:1576,y:891,t:1526919215159};\\\", \\\"{x:1573,y:891,t:1526919215176};\\\", \\\"{x:1571,y:891,t:1526919215192};\\\", \\\"{x:1569,y:891,t:1526919215209};\\\", \\\"{x:1568,y:891,t:1526919215226};\\\", \\\"{x:1567,y:891,t:1526919215251};\\\", \\\"{x:1566,y:891,t:1526919215260};\\\", \\\"{x:1563,y:891,t:1526919215277};\\\", \\\"{x:1557,y:890,t:1526919215294};\\\", \\\"{x:1554,y:890,t:1526919215309};\\\", \\\"{x:1553,y:890,t:1526919215326};\\\", \\\"{x:1552,y:890,t:1526919215343};\\\", \\\"{x:1549,y:890,t:1526919225419};\\\", \\\"{x:1548,y:890,t:1526919225429};\\\", \\\"{x:1546,y:890,t:1526919225444};\\\", \\\"{x:1545,y:890,t:1526919225461};\\\", \\\"{x:1544,y:889,t:1526919225479};\\\", \\\"{x:1543,y:889,t:1526919225495};\\\", \\\"{x:1542,y:888,t:1526919225571};\\\", \\\"{x:1541,y:888,t:1526919225602};\\\", \\\"{x:1539,y:888,t:1526919226266};\\\", \\\"{x:1538,y:888,t:1526919226282};\\\", \\\"{x:1536,y:888,t:1526919226298};\\\", \\\"{x:1533,y:886,t:1526919226315};\\\", \\\"{x:1532,y:886,t:1526919226331};\\\", \\\"{x:1530,y:886,t:1526919226347};\\\", \\\"{x:1529,y:886,t:1526919226365};\\\", \\\"{x:1529,y:885,t:1526919226382};\\\", \\\"{x:1527,y:885,t:1526919226435};\\\", \\\"{x:1526,y:885,t:1526919228331};\\\", \\\"{x:1513,y:881,t:1526919235179};\\\", \\\"{x:1487,y:868,t:1526919235195};\\\", \\\"{x:1447,y:857,t:1526919235212};\\\", \\\"{x:1418,y:849,t:1526919235229};\\\", \\\"{x:1402,y:845,t:1526919235246};\\\", \\\"{x:1397,y:843,t:1526919235262};\\\", \\\"{x:1394,y:841,t:1526919235279};\\\", \\\"{x:1393,y:841,t:1526919235296};\\\", \\\"{x:1391,y:840,t:1526919235313};\\\", \\\"{x:1387,y:838,t:1526919235329};\\\", \\\"{x:1382,y:834,t:1526919235346};\\\", \\\"{x:1379,y:834,t:1526919235363};\\\", \\\"{x:1376,y:833,t:1526919235380};\\\", \\\"{x:1372,y:831,t:1526919235396};\\\", \\\"{x:1370,y:830,t:1526919235413};\\\", \\\"{x:1369,y:830,t:1526919235430};\\\", \\\"{x:1366,y:827,t:1526919235446};\\\", \\\"{x:1359,y:827,t:1526919235463};\\\", \\\"{x:1353,y:825,t:1526919235480};\\\", \\\"{x:1346,y:822,t:1526919235497};\\\", \\\"{x:1342,y:822,t:1526919235513};\\\", \\\"{x:1335,y:820,t:1526919235531};\\\", \\\"{x:1332,y:819,t:1526919235547};\\\", \\\"{x:1330,y:818,t:1526919235564};\\\", \\\"{x:1325,y:816,t:1526919235580};\\\", \\\"{x:1322,y:815,t:1526919235598};\\\", \\\"{x:1317,y:815,t:1526919235614};\\\", \\\"{x:1314,y:814,t:1526919235630};\\\", \\\"{x:1311,y:812,t:1526919235647};\\\", \\\"{x:1309,y:812,t:1526919235664};\\\", \\\"{x:1308,y:812,t:1526919235681};\\\", \\\"{x:1306,y:811,t:1526919235697};\\\", \\\"{x:1305,y:811,t:1526919235714};\\\", \\\"{x:1302,y:810,t:1526919235731};\\\", \\\"{x:1297,y:808,t:1526919235748};\\\", \\\"{x:1292,y:807,t:1526919235764};\\\", \\\"{x:1285,y:805,t:1526919235781};\\\", \\\"{x:1277,y:803,t:1526919235798};\\\", \\\"{x:1266,y:799,t:1526919235814};\\\", \\\"{x:1257,y:798,t:1526919235831};\\\", \\\"{x:1251,y:794,t:1526919235848};\\\", \\\"{x:1245,y:793,t:1526919235865};\\\", \\\"{x:1240,y:791,t:1526919235882};\\\", \\\"{x:1223,y:786,t:1526919235899};\\\", \\\"{x:1212,y:782,t:1526919235915};\\\", \\\"{x:1183,y:771,t:1526919235931};\\\", \\\"{x:1141,y:759,t:1526919235948};\\\", \\\"{x:1098,y:737,t:1526919235965};\\\", \\\"{x:1064,y:721,t:1526919235982};\\\", \\\"{x:1033,y:707,t:1526919235998};\\\", \\\"{x:1002,y:693,t:1526919236015};\\\", \\\"{x:978,y:687,t:1526919236032};\\\", \\\"{x:960,y:681,t:1526919236049};\\\", \\\"{x:944,y:677,t:1526919236065};\\\", \\\"{x:926,y:672,t:1526919236082};\\\", \\\"{x:920,y:669,t:1526919236099};\\\", \\\"{x:915,y:669,t:1526919236116};\\\", \\\"{x:908,y:668,t:1526919236132};\\\", \\\"{x:903,y:667,t:1526919236149};\\\", \\\"{x:899,y:667,t:1526919236166};\\\", \\\"{x:896,y:665,t:1526919236182};\\\", \\\"{x:892,y:665,t:1526919236199};\\\", \\\"{x:890,y:665,t:1526919236218};\\\", \\\"{x:888,y:665,t:1526919236233};\\\", \\\"{x:886,y:665,t:1526919236249};\\\", \\\"{x:880,y:664,t:1526919236267};\\\", \\\"{x:875,y:663,t:1526919236283};\\\", \\\"{x:868,y:662,t:1526919236299};\\\", \\\"{x:862,y:661,t:1526919236316};\\\", \\\"{x:857,y:661,t:1526919236333};\\\", \\\"{x:851,y:660,t:1526919236350};\\\", \\\"{x:848,y:659,t:1526919236366};\\\", \\\"{x:845,y:659,t:1526919236383};\\\", \\\"{x:842,y:658,t:1526919236400};\\\", \\\"{x:840,y:657,t:1526919236416};\\\", \\\"{x:839,y:657,t:1526919236442};\\\", \\\"{x:838,y:657,t:1526919236466};\\\", \\\"{x:837,y:657,t:1526919236483};\\\", \\\"{x:834,y:657,t:1526919236500};\\\", \\\"{x:833,y:656,t:1526919236517};\\\", \\\"{x:829,y:656,t:1526919236534};\\\", \\\"{x:826,y:654,t:1526919236550};\\\", \\\"{x:820,y:653,t:1526919236567};\\\", \\\"{x:815,y:653,t:1526919236584};\\\", \\\"{x:812,y:653,t:1526919236600};\\\", \\\"{x:807,y:652,t:1526919236617};\\\", \\\"{x:801,y:650,t:1526919236634};\\\", \\\"{x:798,y:650,t:1526919236650};\\\", \\\"{x:796,y:650,t:1526919236667};\\\", \\\"{x:795,y:650,t:1526919236684};\\\", \\\"{x:793,y:649,t:1526919236701};\\\", \\\"{x:791,y:649,t:1526919236718};\\\", \\\"{x:788,y:648,t:1526919236734};\\\", \\\"{x:784,y:648,t:1526919236751};\\\", \\\"{x:782,y:647,t:1526919236768};\\\", \\\"{x:780,y:647,t:1526919236784};\\\", \\\"{x:777,y:647,t:1526919236801};\\\", \\\"{x:775,y:646,t:1526919236818};\\\", \\\"{x:773,y:646,t:1526919236834};\\\", \\\"{x:772,y:646,t:1526919236851};\\\", \\\"{x:771,y:646,t:1526919236882};\\\", \\\"{x:769,y:646,t:1526919237738};\\\", \\\"{x:759,y:646,t:1526919237754};\\\", \\\"{x:735,y:641,t:1526919237770};\\\", \\\"{x:689,y:628,t:1526919237788};\\\", \\\"{x:626,y:610,t:1526919237805};\\\", \\\"{x:561,y:591,t:1526919237821};\\\", \\\"{x:522,y:580,t:1526919237835};\\\", \\\"{x:510,y:576,t:1526919237852};\\\", \\\"{x:508,y:575,t:1526919237869};\\\", \\\"{x:508,y:574,t:1526919237923};\\\", \\\"{x:507,y:574,t:1526919237935};\\\", \\\"{x:501,y:573,t:1526919237952};\\\", \\\"{x:499,y:572,t:1526919237969};\\\", \\\"{x:493,y:570,t:1526919237986};\\\", \\\"{x:480,y:566,t:1526919238002};\\\", \\\"{x:466,y:562,t:1526919238020};\\\", \\\"{x:449,y:559,t:1526919238035};\\\", \\\"{x:432,y:550,t:1526919238053};\\\", \\\"{x:417,y:548,t:1526919238070};\\\", \\\"{x:404,y:541,t:1526919238086};\\\", \\\"{x:399,y:540,t:1526919238102};\\\", \\\"{x:397,y:539,t:1526919238119};\\\", \\\"{x:395,y:539,t:1526919238136};\\\", \\\"{x:395,y:538,t:1526919238152};\\\", \\\"{x:393,y:537,t:1526919238170};\\\", \\\"{x:392,y:537,t:1526919238194};\\\", \\\"{x:390,y:537,t:1526919238226};\\\", \\\"{x:388,y:537,t:1526919238236};\\\", \\\"{x:380,y:537,t:1526919238252};\\\", \\\"{x:366,y:537,t:1526919238270};\\\", \\\"{x:350,y:537,t:1526919238286};\\\", \\\"{x:335,y:537,t:1526919238303};\\\", \\\"{x:320,y:537,t:1526919238319};\\\", \\\"{x:302,y:537,t:1526919238336};\\\", \\\"{x:281,y:537,t:1526919238353};\\\", \\\"{x:262,y:537,t:1526919238370};\\\", \\\"{x:236,y:537,t:1526919238386};\\\", \\\"{x:216,y:537,t:1526919238403};\\\", \\\"{x:202,y:536,t:1526919238419};\\\", \\\"{x:194,y:534,t:1526919238436};\\\", \\\"{x:187,y:534,t:1526919238453};\\\", \\\"{x:183,y:533,t:1526919238469};\\\", \\\"{x:178,y:532,t:1526919238486};\\\", \\\"{x:176,y:532,t:1526919238503};\\\", \\\"{x:173,y:532,t:1526919238519};\\\", \\\"{x:170,y:532,t:1526919238536};\\\", \\\"{x:169,y:532,t:1526919238553};\\\", \\\"{x:169,y:532,t:1526919238683};\\\", \\\"{x:168,y:533,t:1526919238850};\\\", \\\"{x:171,y:536,t:1526919238866};\\\", \\\"{x:174,y:537,t:1526919238882};\\\", \\\"{x:176,y:540,t:1526919238889};\\\", \\\"{x:177,y:540,t:1526919238903};\\\", \\\"{x:182,y:549,t:1526919238921};\\\", \\\"{x:191,y:563,t:1526919238937};\\\", \\\"{x:214,y:579,t:1526919238954};\\\", \\\"{x:240,y:600,t:1526919238971};\\\", \\\"{x:270,y:616,t:1526919238987};\\\", \\\"{x:318,y:640,t:1526919239004};\\\", \\\"{x:335,y:654,t:1526919239020};\\\", \\\"{x:350,y:663,t:1526919239040};\\\", \\\"{x:366,y:669,t:1526919239056};\\\", \\\"{x:375,y:674,t:1526919239074};\\\", \\\"{x:383,y:677,t:1526919239089};\\\", \\\"{x:389,y:679,t:1526919239106};\\\", \\\"{x:393,y:681,t:1526919239124};\\\", \\\"{x:402,y:682,t:1526919239140};\\\", \\\"{x:416,y:686,t:1526919239157};\\\", \\\"{x:444,y:693,t:1526919239174};\\\", \\\"{x:468,y:700,t:1526919239190};\\\", \\\"{x:496,y:708,t:1526919239206};\\\", \\\"{x:526,y:715,t:1526919239224};\\\", \\\"{x:547,y:723,t:1526919239240};\\\", \\\"{x:564,y:727,t:1526919239257};\\\", \\\"{x:571,y:731,t:1526919239274};\\\", \\\"{x:572,y:731,t:1526919239290};\\\", \\\"{x:573,y:733,t:1526919239358};\\\", \\\"{x:571,y:736,t:1526919239374};\\\", \\\"{x:565,y:738,t:1526919239390};\\\", \\\"{x:561,y:739,t:1526919239408};\\\", \\\"{x:556,y:739,t:1526919239424};\\\", \\\"{x:551,y:739,t:1526919239441};\\\", \\\"{x:549,y:739,t:1526919239457};\\\", \\\"{x:548,y:739,t:1526919239477};\\\", \\\"{x:547,y:739,t:1526919239493};\\\", \\\"{x:546,y:739,t:1526919239507};\\\", \\\"{x:545,y:738,t:1526919239524};\\\", \\\"{x:540,y:737,t:1526919239541};\\\", \\\"{x:534,y:734,t:1526919239557};\\\", \\\"{x:522,y:732,t:1526919239574};\\\", \\\"{x:518,y:731,t:1526919239591};\\\", \\\"{x:515,y:730,t:1526919239606};\\\", \\\"{x:514,y:730,t:1526919239623};\\\" ] }, { \\\"rt\\\": 8207, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 490116, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-02 PM-01 PM-B -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:730,t:1526919241550};\\\", \\\"{x:513,y:729,t:1526919241750};\\\", \\\"{x:512,y:729,t:1526919241765};\\\", \\\"{x:511,y:729,t:1526919243182};\\\", \\\"{x:511,y:728,t:1526919243254};\\\", \\\"{x:512,y:726,t:1526919243422};\\\", \\\"{x:514,y:725,t:1526919243430};\\\", \\\"{x:517,y:725,t:1526919243441};\\\", \\\"{x:524,y:723,t:1526919243458};\\\", \\\"{x:552,y:723,t:1526919243475};\\\", \\\"{x:592,y:723,t:1526919243491};\\\", \\\"{x:674,y:731,t:1526919243508};\\\", \\\"{x:759,y:750,t:1526919243525};\\\", \\\"{x:898,y:777,t:1526919243544};\\\", \\\"{x:986,y:798,t:1526919243561};\\\", \\\"{x:1072,y:823,t:1526919243577};\\\", \\\"{x:1167,y:840,t:1526919243594};\\\", \\\"{x:1261,y:862,t:1526919243611};\\\", \\\"{x:1346,y:883,t:1526919243627};\\\", \\\"{x:1424,y:907,t:1526919243644};\\\", \\\"{x:1490,y:922,t:1526919243661};\\\", \\\"{x:1545,y:937,t:1526919243677};\\\", \\\"{x:1612,y:955,t:1526919243694};\\\", \\\"{x:1638,y:962,t:1526919243711};\\\", \\\"{x:1659,y:967,t:1526919243727};\\\", \\\"{x:1674,y:971,t:1526919243744};\\\", \\\"{x:1684,y:974,t:1526919243761};\\\", \\\"{x:1699,y:979,t:1526919243777};\\\", \\\"{x:1712,y:988,t:1526919243794};\\\", \\\"{x:1719,y:992,t:1526919243811};\\\", \\\"{x:1728,y:996,t:1526919243827};\\\", \\\"{x:1730,y:997,t:1526919243844};\\\", \\\"{x:1731,y:997,t:1526919243861};\\\", \\\"{x:1732,y:998,t:1526919243877};\\\", \\\"{x:1728,y:1000,t:1526919243894};\\\", \\\"{x:1719,y:1001,t:1526919243911};\\\", \\\"{x:1702,y:1003,t:1526919243928};\\\", \\\"{x:1675,y:1003,t:1526919243944};\\\", \\\"{x:1648,y:1003,t:1526919243961};\\\", \\\"{x:1626,y:1002,t:1526919243978};\\\", \\\"{x:1611,y:999,t:1526919243994};\\\", \\\"{x:1591,y:998,t:1526919244011};\\\", \\\"{x:1575,y:997,t:1526919244028};\\\", \\\"{x:1565,y:997,t:1526919244044};\\\", \\\"{x:1554,y:997,t:1526919244061};\\\", \\\"{x:1537,y:994,t:1526919244077};\\\", \\\"{x:1524,y:992,t:1526919244094};\\\", \\\"{x:1506,y:991,t:1526919244111};\\\", \\\"{x:1484,y:987,t:1526919244128};\\\", \\\"{x:1465,y:982,t:1526919244144};\\\", \\\"{x:1447,y:980,t:1526919244161};\\\", \\\"{x:1439,y:979,t:1526919244178};\\\", \\\"{x:1432,y:976,t:1526919244194};\\\", \\\"{x:1423,y:974,t:1526919244211};\\\", \\\"{x:1412,y:972,t:1526919244228};\\\", \\\"{x:1403,y:969,t:1526919244244};\\\", \\\"{x:1392,y:968,t:1526919244261};\\\", \\\"{x:1377,y:968,t:1526919244278};\\\", \\\"{x:1362,y:965,t:1526919244295};\\\", \\\"{x:1355,y:964,t:1526919244311};\\\", \\\"{x:1353,y:963,t:1526919244328};\\\", \\\"{x:1352,y:963,t:1526919244358};\\\", \\\"{x:1351,y:963,t:1526919244374};\\\", \\\"{x:1349,y:962,t:1526919244422};\\\", \\\"{x:1349,y:961,t:1526919244438};\\\", \\\"{x:1348,y:961,t:1526919244446};\\\", \\\"{x:1347,y:960,t:1526919244718};\\\", \\\"{x:1347,y:959,t:1526919244728};\\\", \\\"{x:1347,y:957,t:1526919244745};\\\", \\\"{x:1348,y:955,t:1526919244762};\\\", \\\"{x:1348,y:952,t:1526919244778};\\\", \\\"{x:1348,y:948,t:1526919244795};\\\", \\\"{x:1348,y:944,t:1526919244812};\\\", \\\"{x:1349,y:940,t:1526919244828};\\\", \\\"{x:1351,y:936,t:1526919244845};\\\", \\\"{x:1351,y:933,t:1526919244862};\\\", \\\"{x:1351,y:931,t:1526919244878};\\\", \\\"{x:1351,y:927,t:1526919244895};\\\", \\\"{x:1351,y:923,t:1526919244912};\\\", \\\"{x:1351,y:919,t:1526919244928};\\\", \\\"{x:1351,y:916,t:1526919244946};\\\", \\\"{x:1351,y:910,t:1526919244962};\\\", \\\"{x:1351,y:903,t:1526919244978};\\\", \\\"{x:1351,y:891,t:1526919244995};\\\", \\\"{x:1351,y:881,t:1526919245012};\\\", \\\"{x:1351,y:866,t:1526919245029};\\\", \\\"{x:1351,y:847,t:1526919245045};\\\", \\\"{x:1351,y:821,t:1526919245062};\\\", \\\"{x:1351,y:810,t:1526919245078};\\\", \\\"{x:1351,y:800,t:1526919245095};\\\", \\\"{x:1349,y:790,t:1526919245113};\\\", \\\"{x:1347,y:782,t:1526919245128};\\\", \\\"{x:1347,y:775,t:1526919245145};\\\", \\\"{x:1346,y:772,t:1526919245162};\\\", \\\"{x:1346,y:769,t:1526919245178};\\\", \\\"{x:1346,y:768,t:1526919245196};\\\", \\\"{x:1346,y:766,t:1526919245212};\\\", \\\"{x:1346,y:764,t:1526919245229};\\\", \\\"{x:1346,y:763,t:1526919245245};\\\", \\\"{x:1346,y:760,t:1526919245261};\\\", \\\"{x:1346,y:758,t:1526919245279};\\\", \\\"{x:1346,y:756,t:1526919245295};\\\", \\\"{x:1346,y:752,t:1526919245312};\\\", \\\"{x:1346,y:749,t:1526919245329};\\\", \\\"{x:1346,y:745,t:1526919245345};\\\", \\\"{x:1346,y:742,t:1526919245363};\\\", \\\"{x:1346,y:738,t:1526919245379};\\\", \\\"{x:1346,y:736,t:1526919245395};\\\", \\\"{x:1345,y:732,t:1526919245412};\\\", \\\"{x:1345,y:730,t:1526919245429};\\\", \\\"{x:1345,y:728,t:1526919245445};\\\", \\\"{x:1345,y:725,t:1526919245462};\\\", \\\"{x:1344,y:722,t:1526919245479};\\\", \\\"{x:1344,y:721,t:1526919245495};\\\", \\\"{x:1344,y:720,t:1526919245512};\\\", \\\"{x:1344,y:718,t:1526919245529};\\\", \\\"{x:1344,y:716,t:1526919245545};\\\", \\\"{x:1344,y:715,t:1526919245566};\\\", \\\"{x:1344,y:714,t:1526919245579};\\\", \\\"{x:1344,y:713,t:1526919245595};\\\", \\\"{x:1344,y:712,t:1526919245612};\\\", \\\"{x:1344,y:711,t:1526919245629};\\\", \\\"{x:1344,y:708,t:1526919245646};\\\", \\\"{x:1344,y:707,t:1526919245662};\\\", \\\"{x:1344,y:706,t:1526919245686};\\\", \\\"{x:1344,y:705,t:1526919245696};\\\", \\\"{x:1344,y:704,t:1526919245712};\\\", \\\"{x:1344,y:702,t:1526919245729};\\\", \\\"{x:1344,y:698,t:1526919245746};\\\", \\\"{x:1344,y:694,t:1526919245762};\\\", \\\"{x:1344,y:692,t:1526919245779};\\\", \\\"{x:1344,y:691,t:1526919245796};\\\", \\\"{x:1344,y:690,t:1526919245812};\\\", \\\"{x:1344,y:688,t:1526919245829};\\\", \\\"{x:1344,y:687,t:1526919246110};\\\", \\\"{x:1343,y:685,t:1526919246118};\\\", \\\"{x:1338,y:684,t:1526919246129};\\\", \\\"{x:1331,y:683,t:1526919246146};\\\", \\\"{x:1321,y:681,t:1526919246163};\\\", \\\"{x:1300,y:679,t:1526919246179};\\\", \\\"{x:1276,y:676,t:1526919246196};\\\", \\\"{x:1248,y:664,t:1526919246213};\\\", \\\"{x:1209,y:645,t:1526919246229};\\\", \\\"{x:1144,y:614,t:1526919246246};\\\", \\\"{x:1083,y:588,t:1526919246263};\\\", \\\"{x:1009,y:558,t:1526919246280};\\\", \\\"{x:926,y:535,t:1526919246296};\\\", \\\"{x:843,y:522,t:1526919246314};\\\", \\\"{x:759,y:507,t:1526919246330};\\\", \\\"{x:708,y:500,t:1526919246347};\\\", \\\"{x:682,y:500,t:1526919246363};\\\", \\\"{x:675,y:500,t:1526919246379};\\\", \\\"{x:674,y:500,t:1526919246413};\\\", \\\"{x:673,y:500,t:1526919246429};\\\", \\\"{x:666,y:500,t:1526919246446};\\\", \\\"{x:658,y:504,t:1526919246463};\\\", \\\"{x:653,y:505,t:1526919246480};\\\", \\\"{x:651,y:506,t:1526919246496};\\\", \\\"{x:648,y:509,t:1526919246513};\\\", \\\"{x:645,y:511,t:1526919246530};\\\", \\\"{x:641,y:512,t:1526919246546};\\\", \\\"{x:638,y:514,t:1526919246563};\\\", \\\"{x:637,y:514,t:1526919246581};\\\", \\\"{x:637,y:515,t:1526919246596};\\\", \\\"{x:635,y:515,t:1526919246613};\\\", \\\"{x:634,y:516,t:1526919246631};\\\", \\\"{x:632,y:518,t:1526919246647};\\\", \\\"{x:631,y:519,t:1526919246663};\\\", \\\"{x:630,y:521,t:1526919246680};\\\", \\\"{x:630,y:523,t:1526919246697};\\\", \\\"{x:630,y:527,t:1526919246714};\\\", \\\"{x:630,y:531,t:1526919246730};\\\", \\\"{x:630,y:534,t:1526919246747};\\\", \\\"{x:628,y:540,t:1526919246763};\\\", \\\"{x:623,y:544,t:1526919246781};\\\", \\\"{x:605,y:553,t:1526919246797};\\\", \\\"{x:562,y:562,t:1526919246814};\\\", \\\"{x:442,y:588,t:1526919246830};\\\", \\\"{x:369,y:600,t:1526919246846};\\\", \\\"{x:314,y:613,t:1526919246863};\\\", \\\"{x:292,y:617,t:1526919246880};\\\", \\\"{x:278,y:621,t:1526919246897};\\\", \\\"{x:274,y:623,t:1526919246913};\\\", \\\"{x:272,y:623,t:1526919246983};\\\", \\\"{x:270,y:623,t:1526919246998};\\\", \\\"{x:267,y:623,t:1526919247013};\\\", \\\"{x:253,y:620,t:1526919247030};\\\", \\\"{x:245,y:617,t:1526919247047};\\\", \\\"{x:237,y:609,t:1526919247063};\\\", \\\"{x:231,y:602,t:1526919247080};\\\", \\\"{x:220,y:591,t:1526919247099};\\\", \\\"{x:208,y:579,t:1526919247114};\\\", \\\"{x:193,y:570,t:1526919247130};\\\", \\\"{x:188,y:566,t:1526919247147};\\\", \\\"{x:186,y:565,t:1526919247163};\\\", \\\"{x:185,y:564,t:1526919247414};\\\", \\\"{x:183,y:561,t:1526919247431};\\\", \\\"{x:181,y:557,t:1526919247447};\\\", \\\"{x:178,y:550,t:1526919247465};\\\", \\\"{x:178,y:549,t:1526919247509};\\\", \\\"{x:179,y:549,t:1526919247974};\\\", \\\"{x:189,y:549,t:1526919247982};\\\", \\\"{x:203,y:549,t:1526919247998};\\\", \\\"{x:254,y:549,t:1526919248015};\\\", \\\"{x:322,y:553,t:1526919248032};\\\", \\\"{x:380,y:558,t:1526919248049};\\\", \\\"{x:419,y:562,t:1526919248064};\\\", \\\"{x:443,y:564,t:1526919248082};\\\", \\\"{x:456,y:564,t:1526919248097};\\\", \\\"{x:467,y:564,t:1526919248114};\\\", \\\"{x:477,y:564,t:1526919248131};\\\", \\\"{x:485,y:564,t:1526919248148};\\\", \\\"{x:494,y:564,t:1526919248164};\\\", \\\"{x:509,y:564,t:1526919248182};\\\", \\\"{x:536,y:564,t:1526919248198};\\\", \\\"{x:560,y:564,t:1526919248214};\\\", \\\"{x:580,y:564,t:1526919248231};\\\", \\\"{x:592,y:564,t:1526919248248};\\\", \\\"{x:604,y:564,t:1526919248264};\\\", \\\"{x:617,y:564,t:1526919248281};\\\", \\\"{x:631,y:564,t:1526919248298};\\\", \\\"{x:646,y:561,t:1526919248314};\\\", \\\"{x:664,y:559,t:1526919248331};\\\", \\\"{x:681,y:559,t:1526919248348};\\\", \\\"{x:702,y:559,t:1526919248365};\\\", \\\"{x:733,y:559,t:1526919248382};\\\", \\\"{x:782,y:559,t:1526919248397};\\\", \\\"{x:803,y:559,t:1526919248414};\\\", \\\"{x:814,y:556,t:1526919248431};\\\", \\\"{x:816,y:556,t:1526919248448};\\\", \\\"{x:818,y:554,t:1526919248465};\\\", \\\"{x:822,y:552,t:1526919248481};\\\", \\\"{x:823,y:550,t:1526919248498};\\\", \\\"{x:825,y:549,t:1526919248515};\\\", \\\"{x:829,y:546,t:1526919248531};\\\", \\\"{x:830,y:543,t:1526919248549};\\\", \\\"{x:835,y:538,t:1526919248565};\\\", \\\"{x:840,y:531,t:1526919248581};\\\", \\\"{x:844,y:523,t:1526919248598};\\\", \\\"{x:845,y:520,t:1526919248615};\\\", \\\"{x:845,y:515,t:1526919248632};\\\", \\\"{x:844,y:512,t:1526919248648};\\\", \\\"{x:843,y:510,t:1526919248669};\\\", \\\"{x:843,y:509,t:1526919248681};\\\", \\\"{x:843,y:508,t:1526919248698};\\\", \\\"{x:841,y:506,t:1526919248715};\\\", \\\"{x:841,y:505,t:1526919248731};\\\", \\\"{x:840,y:503,t:1526919248748};\\\", \\\"{x:821,y:510,t:1526919249015};\\\", \\\"{x:780,y:534,t:1526919249032};\\\", \\\"{x:719,y:562,t:1526919249048};\\\", \\\"{x:673,y:587,t:1526919249066};\\\", \\\"{x:624,y:616,t:1526919249082};\\\", \\\"{x:594,y:641,t:1526919249099};\\\", \\\"{x:582,y:649,t:1526919249116};\\\", \\\"{x:577,y:657,t:1526919249132};\\\", \\\"{x:575,y:666,t:1526919249148};\\\", \\\"{x:572,y:676,t:1526919249165};\\\", \\\"{x:562,y:697,t:1526919249182};\\\", \\\"{x:558,y:705,t:1526919249198};\\\", \\\"{x:552,y:713,t:1526919249216};\\\", \\\"{x:550,y:719,t:1526919249232};\\\", \\\"{x:549,y:721,t:1526919249248};\\\", \\\"{x:549,y:723,t:1526919249265};\\\", \\\"{x:549,y:725,t:1526919249302};\\\", \\\"{x:549,y:726,t:1526919249325};\\\", \\\"{x:549,y:728,t:1526919249334};\\\", \\\"{x:549,y:729,t:1526919249348};\\\", \\\"{x:548,y:731,t:1526919249365};\\\", \\\"{x:547,y:733,t:1526919249382};\\\", \\\"{x:547,y:732,t:1526919250421};\\\", \\\"{x:547,y:731,t:1526919250478};\\\", \\\"{x:548,y:731,t:1526919250525};\\\", \\\"{x:548,y:730,t:1526919250574};\\\", \\\"{x:548,y:729,t:1526919250637};\\\", \\\"{x:549,y:729,t:1526919250725};\\\", \\\"{x:549,y:728,t:1526919250733};\\\", \\\"{x:550,y:728,t:1526919250774};\\\", \\\"{x:550,y:727,t:1526919250870};\\\", \\\"{x:551,y:727,t:1526919250893};\\\" ] }, { \\\"rt\\\": 10505, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 502214, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -B -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:724,t:1526919251734};\\\", \\\"{x:554,y:711,t:1526919251751};\\\", \\\"{x:558,y:695,t:1526919251773};\\\", \\\"{x:559,y:680,t:1526919251785};\\\", \\\"{x:559,y:664,t:1526919251801};\\\", \\\"{x:559,y:651,t:1526919251818};\\\", \\\"{x:556,y:637,t:1526919251834};\\\", \\\"{x:548,y:625,t:1526919251851};\\\", \\\"{x:541,y:611,t:1526919251867};\\\", \\\"{x:535,y:598,t:1526919251884};\\\", \\\"{x:525,y:578,t:1526919251901};\\\", \\\"{x:508,y:551,t:1526919251918};\\\", \\\"{x:502,y:543,t:1526919251934};\\\", \\\"{x:499,y:539,t:1526919251952};\\\", \\\"{x:496,y:534,t:1526919251968};\\\", \\\"{x:494,y:531,t:1526919251984};\\\", \\\"{x:494,y:530,t:1526919252001};\\\", \\\"{x:493,y:530,t:1526919252070};\\\", \\\"{x:493,y:529,t:1526919252085};\\\", \\\"{x:496,y:527,t:1526919252102};\\\", \\\"{x:501,y:523,t:1526919252118};\\\", \\\"{x:512,y:513,t:1526919252134};\\\", \\\"{x:526,y:505,t:1526919252151};\\\", \\\"{x:540,y:496,t:1526919252167};\\\", \\\"{x:547,y:487,t:1526919252185};\\\", \\\"{x:561,y:482,t:1526919252201};\\\", \\\"{x:574,y:475,t:1526919252217};\\\", \\\"{x:580,y:473,t:1526919252235};\\\", \\\"{x:587,y:471,t:1526919252252};\\\", \\\"{x:601,y:467,t:1526919252268};\\\", \\\"{x:614,y:464,t:1526919252284};\\\", \\\"{x:626,y:464,t:1526919252302};\\\", \\\"{x:648,y:464,t:1526919252318};\\\", \\\"{x:676,y:472,t:1526919252335};\\\", \\\"{x:719,y:486,t:1526919252351};\\\", \\\"{x:771,y:505,t:1526919252369};\\\", \\\"{x:848,y:539,t:1526919252385};\\\", \\\"{x:936,y:572,t:1526919252402};\\\", \\\"{x:1021,y:607,t:1526919252418};\\\", \\\"{x:1109,y:644,t:1526919252434};\\\", \\\"{x:1190,y:673,t:1526919252451};\\\", \\\"{x:1253,y:696,t:1526919252468};\\\", \\\"{x:1300,y:718,t:1526919252484};\\\", \\\"{x:1372,y:742,t:1526919252501};\\\", \\\"{x:1412,y:757,t:1526919252518};\\\", \\\"{x:1435,y:767,t:1526919252536};\\\", \\\"{x:1450,y:772,t:1526919252552};\\\", \\\"{x:1455,y:775,t:1526919252569};\\\", \\\"{x:1455,y:774,t:1526919252703};\\\", \\\"{x:1448,y:766,t:1526919252718};\\\", \\\"{x:1433,y:755,t:1526919252736};\\\", \\\"{x:1417,y:740,t:1526919252753};\\\", \\\"{x:1396,y:722,t:1526919252769};\\\", \\\"{x:1375,y:705,t:1526919252785};\\\", \\\"{x:1360,y:692,t:1526919252803};\\\", \\\"{x:1349,y:682,t:1526919252819};\\\", \\\"{x:1344,y:678,t:1526919252835};\\\", \\\"{x:1340,y:676,t:1526919252854};\\\", \\\"{x:1339,y:674,t:1526919252868};\\\", \\\"{x:1336,y:672,t:1526919252885};\\\", \\\"{x:1335,y:671,t:1526919252902};\\\", \\\"{x:1334,y:671,t:1526919253013};\\\", \\\"{x:1334,y:673,t:1526919253021};\\\", \\\"{x:1334,y:675,t:1526919253035};\\\", \\\"{x:1336,y:680,t:1526919253053};\\\", \\\"{x:1340,y:687,t:1526919253069};\\\", \\\"{x:1341,y:689,t:1526919253086};\\\", \\\"{x:1343,y:691,t:1526919253102};\\\", \\\"{x:1344,y:692,t:1526919253120};\\\", \\\"{x:1344,y:693,t:1526919253137};\\\", \\\"{x:1344,y:694,t:1526919253152};\\\", \\\"{x:1344,y:696,t:1526919253169};\\\", \\\"{x:1344,y:697,t:1526919253186};\\\", \\\"{x:1346,y:699,t:1526919253203};\\\", \\\"{x:1346,y:701,t:1526919253219};\\\", \\\"{x:1346,y:702,t:1526919253237};\\\", \\\"{x:1346,y:703,t:1526919253270};\\\", \\\"{x:1346,y:705,t:1526919253286};\\\", \\\"{x:1346,y:708,t:1526919253302};\\\", \\\"{x:1346,y:713,t:1526919253319};\\\", \\\"{x:1347,y:716,t:1526919253336};\\\", \\\"{x:1348,y:717,t:1526919253353};\\\", \\\"{x:1348,y:719,t:1526919253370};\\\", \\\"{x:1349,y:720,t:1526919253386};\\\", \\\"{x:1350,y:723,t:1526919253403};\\\", \\\"{x:1350,y:727,t:1526919253419};\\\", \\\"{x:1350,y:729,t:1526919253436};\\\", \\\"{x:1350,y:730,t:1526919253453};\\\", \\\"{x:1350,y:733,t:1526919253469};\\\", \\\"{x:1350,y:736,t:1526919253487};\\\", \\\"{x:1350,y:739,t:1526919253503};\\\", \\\"{x:1351,y:740,t:1526919253520};\\\", \\\"{x:1351,y:741,t:1526919253537};\\\", \\\"{x:1351,y:742,t:1526919253553};\\\", \\\"{x:1351,y:743,t:1526919253571};\\\", \\\"{x:1351,y:745,t:1526919253587};\\\", \\\"{x:1351,y:748,t:1526919253604};\\\", \\\"{x:1351,y:749,t:1526919253621};\\\", \\\"{x:1352,y:750,t:1526919253637};\\\", \\\"{x:1352,y:751,t:1526919253654};\\\", \\\"{x:1352,y:752,t:1526919253693};\\\", \\\"{x:1352,y:754,t:1526919253726};\\\", \\\"{x:1352,y:755,t:1526919253829};\\\", \\\"{x:1352,y:756,t:1526919253837};\\\", \\\"{x:1352,y:757,t:1526919253853};\\\", \\\"{x:1352,y:758,t:1526919253871};\\\", \\\"{x:1352,y:759,t:1526919253888};\\\", \\\"{x:1352,y:760,t:1526919253903};\\\", \\\"{x:1352,y:762,t:1526919253920};\\\", \\\"{x:1352,y:764,t:1526919253989};\\\", \\\"{x:1352,y:766,t:1526919254014};\\\", \\\"{x:1352,y:767,t:1526919254022};\\\", \\\"{x:1352,y:768,t:1526919254038};\\\", \\\"{x:1351,y:768,t:1526919254414};\\\", \\\"{x:1351,y:769,t:1526919254430};\\\", \\\"{x:1350,y:769,t:1526919254494};\\\", \\\"{x:1350,y:770,t:1526919254998};\\\", \\\"{x:1350,y:771,t:1526919255029};\\\", \\\"{x:1350,y:772,t:1526919255102};\\\", \\\"{x:1350,y:773,t:1526919255118};\\\", \\\"{x:1350,y:774,t:1526919255183};\\\", \\\"{x:1350,y:775,t:1526919255191};\\\", \\\"{x:1350,y:776,t:1526919255206};\\\", \\\"{x:1350,y:777,t:1526919255230};\\\", \\\"{x:1350,y:778,t:1526919255255};\\\", \\\"{x:1350,y:779,t:1526919255286};\\\", \\\"{x:1350,y:780,t:1526919255414};\\\", \\\"{x:1350,y:781,t:1526919255454};\\\", \\\"{x:1350,y:782,t:1526919255902};\\\", \\\"{x:1350,y:784,t:1526919255910};\\\", \\\"{x:1350,y:785,t:1526919255924};\\\", \\\"{x:1350,y:789,t:1526919255940};\\\", \\\"{x:1350,y:792,t:1526919255958};\\\", \\\"{x:1350,y:794,t:1526919255973};\\\", \\\"{x:1351,y:796,t:1526919255991};\\\", \\\"{x:1351,y:800,t:1526919256008};\\\", \\\"{x:1351,y:803,t:1526919256023};\\\", \\\"{x:1351,y:809,t:1526919256040};\\\", \\\"{x:1354,y:815,t:1526919256058};\\\", \\\"{x:1354,y:820,t:1526919256075};\\\", \\\"{x:1354,y:824,t:1526919256090};\\\", \\\"{x:1354,y:828,t:1526919256107};\\\", \\\"{x:1355,y:832,t:1526919256124};\\\", \\\"{x:1355,y:834,t:1526919256140};\\\", \\\"{x:1355,y:840,t:1526919256158};\\\", \\\"{x:1355,y:846,t:1526919256175};\\\", \\\"{x:1355,y:851,t:1526919256190};\\\", \\\"{x:1355,y:857,t:1526919256207};\\\", \\\"{x:1355,y:861,t:1526919256225};\\\", \\\"{x:1355,y:863,t:1526919256241};\\\", \\\"{x:1355,y:867,t:1526919256258};\\\", \\\"{x:1355,y:870,t:1526919256274};\\\", \\\"{x:1355,y:874,t:1526919256292};\\\", \\\"{x:1355,y:875,t:1526919256307};\\\", \\\"{x:1356,y:879,t:1526919256325};\\\", \\\"{x:1357,y:881,t:1526919256341};\\\", \\\"{x:1357,y:882,t:1526919256357};\\\", \\\"{x:1358,y:887,t:1526919256375};\\\", \\\"{x:1358,y:889,t:1526919256392};\\\", \\\"{x:1359,y:895,t:1526919256407};\\\", \\\"{x:1361,y:900,t:1526919256424};\\\", \\\"{x:1361,y:902,t:1526919256442};\\\", \\\"{x:1361,y:904,t:1526919256458};\\\", \\\"{x:1361,y:908,t:1526919256475};\\\", \\\"{x:1361,y:913,t:1526919256491};\\\", \\\"{x:1361,y:916,t:1526919256509};\\\", \\\"{x:1362,y:920,t:1526919256524};\\\", \\\"{x:1363,y:925,t:1526919256541};\\\", \\\"{x:1363,y:926,t:1526919256557};\\\", \\\"{x:1363,y:928,t:1526919256575};\\\", \\\"{x:1364,y:928,t:1526919256591};\\\", \\\"{x:1364,y:930,t:1526919256609};\\\", \\\"{x:1364,y:931,t:1526919256630};\\\", \\\"{x:1364,y:933,t:1526919256653};\\\", \\\"{x:1364,y:934,t:1526919256670};\\\", \\\"{x:1364,y:936,t:1526919256702};\\\", \\\"{x:1364,y:937,t:1526919256718};\\\", \\\"{x:1365,y:937,t:1526919256725};\\\", \\\"{x:1365,y:939,t:1526919256742};\\\", \\\"{x:1365,y:940,t:1526919256759};\\\", \\\"{x:1365,y:942,t:1526919256775};\\\", \\\"{x:1366,y:943,t:1526919256791};\\\", \\\"{x:1366,y:945,t:1526919256809};\\\", \\\"{x:1366,y:946,t:1526919256826};\\\", \\\"{x:1366,y:949,t:1526919256841};\\\", \\\"{x:1366,y:951,t:1526919256858};\\\", \\\"{x:1366,y:952,t:1526919256876};\\\", \\\"{x:1367,y:954,t:1526919256891};\\\", \\\"{x:1367,y:955,t:1526919256909};\\\", \\\"{x:1367,y:958,t:1526919256926};\\\", \\\"{x:1367,y:959,t:1526919256942};\\\", \\\"{x:1367,y:962,t:1526919256959};\\\", \\\"{x:1367,y:964,t:1526919256976};\\\", \\\"{x:1367,y:965,t:1526919256998};\\\", \\\"{x:1367,y:967,t:1526919257022};\\\", \\\"{x:1367,y:968,t:1526919257037};\\\", \\\"{x:1367,y:970,t:1526919257070};\\\", \\\"{x:1367,y:971,t:1526919257126};\\\", \\\"{x:1368,y:971,t:1526919257182};\\\", \\\"{x:1368,y:973,t:1526919257222};\\\", \\\"{x:1368,y:974,t:1526919257270};\\\", \\\"{x:1368,y:975,t:1526919257302};\\\", \\\"{x:1368,y:976,t:1526919257309};\\\", \\\"{x:1368,y:977,t:1526919257349};\\\", \\\"{x:1368,y:978,t:1526919257382};\\\", \\\"{x:1369,y:978,t:1526919257398};\\\", \\\"{x:1369,y:979,t:1526919257974};\\\", \\\"{x:1370,y:979,t:1526919258334};\\\", \\\"{x:1370,y:977,t:1526919258349};\\\", \\\"{x:1370,y:976,t:1526919258373};\\\", \\\"{x:1370,y:975,t:1526919258381};\\\", \\\"{x:1370,y:974,t:1526919258437};\\\", \\\"{x:1370,y:973,t:1526919258470};\\\", \\\"{x:1370,y:972,t:1526919258493};\\\", \\\"{x:1370,y:971,t:1526919258501};\\\", \\\"{x:1370,y:970,t:1526919258512};\\\", \\\"{x:1368,y:968,t:1526919258528};\\\", \\\"{x:1368,y:967,t:1526919258544};\\\", \\\"{x:1368,y:965,t:1526919258573};\\\", \\\"{x:1368,y:964,t:1526919258590};\\\", \\\"{x:1367,y:963,t:1526919258613};\\\", \\\"{x:1367,y:962,t:1526919258628};\\\", \\\"{x:1366,y:961,t:1526919258645};\\\", \\\"{x:1366,y:959,t:1526919258669};\\\", \\\"{x:1365,y:957,t:1526919258686};\\\", \\\"{x:1365,y:956,t:1526919258701};\\\", \\\"{x:1365,y:954,t:1526919258717};\\\", \\\"{x:1364,y:952,t:1526919258729};\\\", \\\"{x:1363,y:950,t:1526919258744};\\\", \\\"{x:1361,y:944,t:1526919258761};\\\", \\\"{x:1361,y:939,t:1526919258779};\\\", \\\"{x:1360,y:932,t:1526919258795};\\\", \\\"{x:1357,y:923,t:1526919258812};\\\", \\\"{x:1356,y:912,t:1526919258828};\\\", \\\"{x:1352,y:893,t:1526919258845};\\\", \\\"{x:1351,y:882,t:1526919258861};\\\", \\\"{x:1350,y:861,t:1526919258878};\\\", \\\"{x:1344,y:834,t:1526919258895};\\\", \\\"{x:1339,y:810,t:1526919258911};\\\", \\\"{x:1337,y:795,t:1526919258928};\\\", \\\"{x:1335,y:783,t:1526919258946};\\\", \\\"{x:1334,y:775,t:1526919258961};\\\", \\\"{x:1334,y:763,t:1526919258979};\\\", \\\"{x:1334,y:751,t:1526919258996};\\\", \\\"{x:1331,y:742,t:1526919259012};\\\", \\\"{x:1330,y:732,t:1526919259028};\\\", \\\"{x:1330,y:719,t:1526919259045};\\\", \\\"{x:1330,y:715,t:1526919259063};\\\", \\\"{x:1330,y:711,t:1526919259079};\\\", \\\"{x:1330,y:708,t:1526919259096};\\\", \\\"{x:1328,y:704,t:1526919259113};\\\", \\\"{x:1328,y:703,t:1526919259129};\\\", \\\"{x:1327,y:702,t:1526919259145};\\\", \\\"{x:1327,y:701,t:1526919259162};\\\", \\\"{x:1327,y:700,t:1526919259179};\\\", \\\"{x:1325,y:698,t:1526919259196};\\\", \\\"{x:1325,y:697,t:1526919259212};\\\", \\\"{x:1322,y:695,t:1526919259229};\\\", \\\"{x:1314,y:691,t:1526919259245};\\\", \\\"{x:1299,y:688,t:1526919259262};\\\", \\\"{x:1272,y:678,t:1526919259279};\\\", \\\"{x:1225,y:666,t:1526919259295};\\\", \\\"{x:1169,y:647,t:1526919259312};\\\", \\\"{x:1094,y:625,t:1526919259330};\\\", \\\"{x:1025,y:598,t:1526919259345};\\\", \\\"{x:958,y:575,t:1526919259363};\\\", \\\"{x:896,y:556,t:1526919259379};\\\", \\\"{x:840,y:546,t:1526919259396};\\\", \\\"{x:784,y:538,t:1526919259412};\\\", \\\"{x:703,y:532,t:1526919259430};\\\", \\\"{x:641,y:531,t:1526919259457};\\\", \\\"{x:599,y:531,t:1526919259473};\\\", \\\"{x:562,y:531,t:1526919259491};\\\", \\\"{x:532,y:531,t:1526919259508};\\\", \\\"{x:494,y:535,t:1526919259524};\\\", \\\"{x:471,y:537,t:1526919259540};\\\", \\\"{x:439,y:543,t:1526919259557};\\\", \\\"{x:417,y:544,t:1526919259573};\\\", \\\"{x:400,y:545,t:1526919259591};\\\", \\\"{x:381,y:546,t:1526919259608};\\\", \\\"{x:367,y:547,t:1526919259624};\\\", \\\"{x:361,y:547,t:1526919259640};\\\", \\\"{x:356,y:547,t:1526919259658};\\\", \\\"{x:352,y:547,t:1526919259673};\\\", \\\"{x:342,y:549,t:1526919259690};\\\", \\\"{x:332,y:550,t:1526919259707};\\\", \\\"{x:327,y:550,t:1526919259723};\\\", \\\"{x:322,y:550,t:1526919259741};\\\", \\\"{x:311,y:552,t:1526919259757};\\\", \\\"{x:300,y:554,t:1526919259774};\\\", \\\"{x:280,y:557,t:1526919259791};\\\", \\\"{x:257,y:560,t:1526919259808};\\\", \\\"{x:243,y:560,t:1526919259823};\\\", \\\"{x:241,y:560,t:1526919259840};\\\", \\\"{x:240,y:561,t:1526919259885};\\\", \\\"{x:239,y:561,t:1526919259894};\\\", \\\"{x:237,y:563,t:1526919259908};\\\", \\\"{x:236,y:564,t:1526919259925};\\\", \\\"{x:236,y:565,t:1526919259941};\\\", \\\"{x:234,y:565,t:1526919260005};\\\", \\\"{x:230,y:565,t:1526919260013};\\\", \\\"{x:226,y:565,t:1526919260025};\\\", \\\"{x:216,y:562,t:1526919260041};\\\", \\\"{x:206,y:556,t:1526919260057};\\\", \\\"{x:203,y:554,t:1526919260075};\\\", \\\"{x:200,y:552,t:1526919260091};\\\", \\\"{x:198,y:550,t:1526919260107};\\\", \\\"{x:197,y:550,t:1526919260125};\\\", \\\"{x:196,y:550,t:1526919260158};\\\", \\\"{x:194,y:549,t:1526919260175};\\\", \\\"{x:193,y:548,t:1526919260190};\\\", \\\"{x:192,y:547,t:1526919260207};\\\", \\\"{x:190,y:547,t:1526919260225};\\\", \\\"{x:190,y:546,t:1526919260269};\\\", \\\"{x:191,y:550,t:1526919260926};\\\", \\\"{x:218,y:584,t:1526919260942};\\\", \\\"{x:251,y:620,t:1526919260959};\\\", \\\"{x:292,y:665,t:1526919260975};\\\", \\\"{x:331,y:699,t:1526919260992};\\\", \\\"{x:364,y:726,t:1526919261008};\\\", \\\"{x:385,y:741,t:1526919261025};\\\", \\\"{x:402,y:750,t:1526919261041};\\\", \\\"{x:410,y:752,t:1526919261058};\\\", \\\"{x:416,y:754,t:1526919261074};\\\", \\\"{x:417,y:754,t:1526919261092};\\\", \\\"{x:420,y:755,t:1526919261108};\\\", \\\"{x:425,y:758,t:1526919261125};\\\", \\\"{x:433,y:760,t:1526919261141};\\\", \\\"{x:439,y:763,t:1526919261158};\\\", \\\"{x:448,y:765,t:1526919261175};\\\", \\\"{x:452,y:766,t:1526919261191};\\\", \\\"{x:455,y:766,t:1526919261209};\\\", \\\"{x:456,y:766,t:1526919261262};\\\", \\\"{x:459,y:766,t:1526919261301};\\\", \\\"{x:460,y:766,t:1526919261309};\\\", \\\"{x:463,y:766,t:1526919261325};\\\", \\\"{x:467,y:764,t:1526919261342};\\\", \\\"{x:471,y:762,t:1526919261359};\\\", \\\"{x:476,y:761,t:1526919261376};\\\", \\\"{x:483,y:756,t:1526919261391};\\\", \\\"{x:492,y:753,t:1526919261409};\\\", \\\"{x:496,y:750,t:1526919261425};\\\", \\\"{x:498,y:749,t:1526919261442};\\\", \\\"{x:498,y:748,t:1526919261459};\\\", \\\"{x:499,y:748,t:1526919261475};\\\", \\\"{x:500,y:747,t:1526919261493};\\\", \\\"{x:501,y:747,t:1526919261509};\\\" ] }, { \\\"rt\\\": 46260, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 549687, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 3.5, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"P\\\", \\\"L\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -09 AM-09 AM-10 AM-10 AM-11 AM-09 AM-08 AM-09 AM-11 AM-11 AM-12 PM-02 PM-03 PM-04 PM-04 PM-02 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:746,t:1526919263565};\\\", \\\"{x:502,y:742,t:1526919263576};\\\", \\\"{x:504,y:726,t:1526919263597};\\\", \\\"{x:506,y:706,t:1526919263609};\\\", \\\"{x:509,y:682,t:1526919263626};\\\", \\\"{x:511,y:662,t:1526919263644};\\\", \\\"{x:511,y:646,t:1526919263661};\\\", \\\"{x:505,y:622,t:1526919263678};\\\", \\\"{x:504,y:610,t:1526919263694};\\\", \\\"{x:500,y:597,t:1526919263711};\\\", \\\"{x:496,y:586,t:1526919263728};\\\", \\\"{x:496,y:578,t:1526919263743};\\\", \\\"{x:496,y:571,t:1526919263761};\\\", \\\"{x:494,y:566,t:1526919263778};\\\", \\\"{x:492,y:562,t:1526919263794};\\\", \\\"{x:492,y:554,t:1526919263811};\\\", \\\"{x:491,y:547,t:1526919263828};\\\", \\\"{x:490,y:542,t:1526919263844};\\\", \\\"{x:490,y:539,t:1526919263861};\\\", \\\"{x:489,y:538,t:1526919263877};\\\", \\\"{x:489,y:537,t:1526919263893};\\\", \\\"{x:489,y:536,t:1526919263933};\\\", \\\"{x:493,y:534,t:1526919263944};\\\", \\\"{x:507,y:526,t:1526919263961};\\\", \\\"{x:522,y:520,t:1526919263978};\\\", \\\"{x:532,y:514,t:1526919263994};\\\", \\\"{x:545,y:506,t:1526919264011};\\\", \\\"{x:559,y:501,t:1526919264027};\\\", \\\"{x:577,y:497,t:1526919264043};\\\", \\\"{x:599,y:494,t:1526919264061};\\\", \\\"{x:655,y:490,t:1526919264078};\\\", \\\"{x:705,y:490,t:1526919264095};\\\", \\\"{x:739,y:490,t:1526919264111};\\\", \\\"{x:778,y:490,t:1526919264127};\\\", \\\"{x:810,y:495,t:1526919264144};\\\", \\\"{x:850,y:507,t:1526919264161};\\\", \\\"{x:884,y:525,t:1526919264178};\\\", \\\"{x:923,y:552,t:1526919264195};\\\", \\\"{x:957,y:576,t:1526919264211};\\\", \\\"{x:993,y:604,t:1526919264228};\\\", \\\"{x:1027,y:622,t:1526919264244};\\\", \\\"{x:1063,y:643,t:1526919264260};\\\", \\\"{x:1110,y:666,t:1526919264277};\\\", \\\"{x:1136,y:678,t:1526919264295};\\\", \\\"{x:1154,y:688,t:1526919264311};\\\", \\\"{x:1178,y:697,t:1526919264328};\\\", \\\"{x:1198,y:706,t:1526919264345};\\\", \\\"{x:1221,y:713,t:1526919264361};\\\", \\\"{x:1255,y:723,t:1526919264377};\\\", \\\"{x:1289,y:734,t:1526919264395};\\\", \\\"{x:1326,y:746,t:1526919264411};\\\", \\\"{x:1358,y:756,t:1526919264428};\\\", \\\"{x:1388,y:763,t:1526919264444};\\\", \\\"{x:1414,y:770,t:1526919264460};\\\", \\\"{x:1444,y:777,t:1526919264478};\\\", \\\"{x:1461,y:782,t:1526919264494};\\\", \\\"{x:1476,y:787,t:1526919264511};\\\", \\\"{x:1486,y:788,t:1526919264528};\\\", \\\"{x:1496,y:791,t:1526919264544};\\\", \\\"{x:1506,y:792,t:1526919264561};\\\", \\\"{x:1515,y:795,t:1526919264578};\\\", \\\"{x:1527,y:798,t:1526919264594};\\\", \\\"{x:1533,y:799,t:1526919264611};\\\", \\\"{x:1535,y:799,t:1526919264628};\\\", \\\"{x:1536,y:799,t:1526919264644};\\\", \\\"{x:1537,y:798,t:1526919264677};\\\", \\\"{x:1538,y:797,t:1526919264694};\\\", \\\"{x:1538,y:792,t:1526919264711};\\\", \\\"{x:1538,y:787,t:1526919264728};\\\", \\\"{x:1538,y:783,t:1526919264744};\\\", \\\"{x:1538,y:780,t:1526919264761};\\\", \\\"{x:1536,y:777,t:1526919264778};\\\", \\\"{x:1535,y:776,t:1526919264794};\\\", \\\"{x:1531,y:774,t:1526919264811};\\\", \\\"{x:1527,y:773,t:1526919264828};\\\", \\\"{x:1521,y:772,t:1526919264843};\\\", \\\"{x:1509,y:771,t:1526919264861};\\\", \\\"{x:1493,y:770,t:1526919264877};\\\", \\\"{x:1479,y:766,t:1526919264894};\\\", \\\"{x:1469,y:763,t:1526919264910};\\\", \\\"{x:1459,y:759,t:1526919264928};\\\", \\\"{x:1453,y:758,t:1526919264943};\\\", \\\"{x:1451,y:758,t:1526919264961};\\\", \\\"{x:1448,y:758,t:1526919264978};\\\", \\\"{x:1447,y:758,t:1526919265013};\\\", \\\"{x:1445,y:758,t:1526919265038};\\\", \\\"{x:1444,y:758,t:1526919265053};\\\", \\\"{x:1443,y:758,t:1526919265061};\\\", \\\"{x:1440,y:758,t:1526919265078};\\\", \\\"{x:1437,y:759,t:1526919265094};\\\", \\\"{x:1433,y:761,t:1526919265111};\\\", \\\"{x:1431,y:763,t:1526919265128};\\\", \\\"{x:1428,y:764,t:1526919265144};\\\", \\\"{x:1422,y:768,t:1526919265161};\\\", \\\"{x:1415,y:772,t:1526919265178};\\\", \\\"{x:1409,y:777,t:1526919265194};\\\", \\\"{x:1399,y:784,t:1526919265211};\\\", \\\"{x:1395,y:787,t:1526919265227};\\\", \\\"{x:1391,y:792,t:1526919265244};\\\", \\\"{x:1389,y:795,t:1526919265260};\\\", \\\"{x:1388,y:799,t:1526919265277};\\\", \\\"{x:1385,y:804,t:1526919265294};\\\", \\\"{x:1381,y:809,t:1526919265311};\\\", \\\"{x:1379,y:812,t:1526919265327};\\\", \\\"{x:1378,y:816,t:1526919265344};\\\", \\\"{x:1377,y:818,t:1526919265361};\\\", \\\"{x:1376,y:818,t:1526919265377};\\\", \\\"{x:1375,y:820,t:1526919265394};\\\", \\\"{x:1375,y:821,t:1526919265411};\\\", \\\"{x:1375,y:822,t:1526919265428};\\\", \\\"{x:1374,y:823,t:1526919265444};\\\", \\\"{x:1374,y:824,t:1526919265461};\\\", \\\"{x:1374,y:825,t:1526919265789};\\\", \\\"{x:1374,y:826,t:1526919265805};\\\", \\\"{x:1374,y:827,t:1526919265821};\\\", \\\"{x:1374,y:828,t:1526919265845};\\\", \\\"{x:1374,y:829,t:1526919265861};\\\", \\\"{x:1374,y:830,t:1526919265878};\\\", \\\"{x:1374,y:831,t:1526919265901};\\\", \\\"{x:1374,y:833,t:1526919265926};\\\", \\\"{x:1374,y:834,t:1526919265957};\\\", \\\"{x:1375,y:836,t:1526919265964};\\\", \\\"{x:1375,y:837,t:1526919266005};\\\", \\\"{x:1376,y:839,t:1526919266013};\\\", \\\"{x:1376,y:840,t:1526919266037};\\\", \\\"{x:1376,y:842,t:1526919266070};\\\", \\\"{x:1377,y:843,t:1526919266086};\\\", \\\"{x:1377,y:844,t:1526919266118};\\\", \\\"{x:1377,y:845,t:1526919266133};\\\", \\\"{x:1378,y:846,t:1526919266157};\\\", \\\"{x:1378,y:847,t:1526919266189};\\\", \\\"{x:1378,y:848,t:1526919266237};\\\", \\\"{x:1379,y:849,t:1526919266261};\\\", \\\"{x:1379,y:850,t:1526919266349};\\\", \\\"{x:1379,y:852,t:1526919266373};\\\", \\\"{x:1379,y:853,t:1526919267053};\\\", \\\"{x:1380,y:855,t:1526919267061};\\\", \\\"{x:1380,y:856,t:1526919267101};\\\", \\\"{x:1381,y:857,t:1526919267111};\\\", \\\"{x:1381,y:858,t:1526919267166};\\\", \\\"{x:1382,y:858,t:1526919267181};\\\", \\\"{x:1382,y:859,t:1526919267213};\\\", \\\"{x:1382,y:860,t:1526919267230};\\\", \\\"{x:1382,y:861,t:1526919267317};\\\", \\\"{x:1383,y:863,t:1526919267422};\\\", \\\"{x:1383,y:864,t:1526919267501};\\\", \\\"{x:1383,y:865,t:1526919267557};\\\", \\\"{x:1384,y:866,t:1526919267565};\\\", \\\"{x:1384,y:867,t:1526919267614};\\\", \\\"{x:1384,y:868,t:1526919267646};\\\", \\\"{x:1384,y:869,t:1526919267734};\\\", \\\"{x:1384,y:870,t:1526919267789};\\\", \\\"{x:1385,y:870,t:1526919267797};\\\", \\\"{x:1385,y:871,t:1526919268221};\\\", \\\"{x:1388,y:871,t:1526919268229};\\\", \\\"{x:1392,y:871,t:1526919268244};\\\", \\\"{x:1410,y:871,t:1526919268259};\\\", \\\"{x:1439,y:869,t:1526919268276};\\\", \\\"{x:1458,y:858,t:1526919268293};\\\", \\\"{x:1483,y:841,t:1526919268309};\\\", \\\"{x:1499,y:829,t:1526919268327};\\\", \\\"{x:1517,y:819,t:1526919268344};\\\", \\\"{x:1527,y:811,t:1526919268360};\\\", \\\"{x:1533,y:802,t:1526919268376};\\\", \\\"{x:1535,y:796,t:1526919268394};\\\", \\\"{x:1537,y:785,t:1526919268410};\\\", \\\"{x:1537,y:774,t:1526919268426};\\\", \\\"{x:1539,y:761,t:1526919268444};\\\", \\\"{x:1541,y:752,t:1526919268460};\\\", \\\"{x:1542,y:747,t:1526919268477};\\\", \\\"{x:1542,y:746,t:1526919268494};\\\", \\\"{x:1542,y:742,t:1526919268510};\\\", \\\"{x:1542,y:736,t:1526919268526};\\\", \\\"{x:1542,y:731,t:1526919268542};\\\", \\\"{x:1543,y:725,t:1526919268559};\\\", \\\"{x:1544,y:719,t:1526919268577};\\\", \\\"{x:1546,y:716,t:1526919268593};\\\", \\\"{x:1547,y:712,t:1526919268610};\\\", \\\"{x:1548,y:708,t:1526919268627};\\\", \\\"{x:1550,y:705,t:1526919268643};\\\", \\\"{x:1553,y:701,t:1526919268660};\\\", \\\"{x:1554,y:699,t:1526919268677};\\\", \\\"{x:1555,y:697,t:1526919268693};\\\", \\\"{x:1558,y:692,t:1526919268710};\\\", \\\"{x:1563,y:688,t:1526919268726};\\\", \\\"{x:1565,y:686,t:1526919268743};\\\", \\\"{x:1567,y:686,t:1526919268759};\\\", \\\"{x:1568,y:685,t:1526919268777};\\\", \\\"{x:1569,y:684,t:1526919268792};\\\", \\\"{x:1570,y:684,t:1526919268810};\\\", \\\"{x:1572,y:684,t:1526919268827};\\\", \\\"{x:1574,y:684,t:1526919268843};\\\", \\\"{x:1577,y:684,t:1526919268860};\\\", \\\"{x:1580,y:684,t:1526919268877};\\\", \\\"{x:1583,y:684,t:1526919268893};\\\", \\\"{x:1586,y:684,t:1526919268917};\\\", \\\"{x:1587,y:685,t:1526919268932};\\\", \\\"{x:1588,y:685,t:1526919268965};\\\", \\\"{x:1589,y:686,t:1526919268977};\\\", \\\"{x:1590,y:686,t:1526919268992};\\\", \\\"{x:1590,y:687,t:1526919269009};\\\", \\\"{x:1591,y:688,t:1526919269027};\\\", \\\"{x:1593,y:689,t:1526919269043};\\\", \\\"{x:1593,y:690,t:1526919269060};\\\", \\\"{x:1594,y:691,t:1526919269077};\\\", \\\"{x:1594,y:692,t:1526919269101};\\\", \\\"{x:1595,y:693,t:1526919269110};\\\", \\\"{x:1595,y:694,t:1526919269261};\\\", \\\"{x:1595,y:695,t:1526919269309};\\\", \\\"{x:1595,y:696,t:1526919269325};\\\", \\\"{x:1595,y:697,t:1526919269373};\\\", \\\"{x:1595,y:698,t:1526919269405};\\\", \\\"{x:1595,y:699,t:1526919269429};\\\", \\\"{x:1594,y:699,t:1526919269443};\\\", \\\"{x:1594,y:700,t:1526919269460};\\\", \\\"{x:1594,y:701,t:1526919269502};\\\", \\\"{x:1595,y:702,t:1526919269997};\\\", \\\"{x:1596,y:702,t:1526919270013};\\\", \\\"{x:1598,y:702,t:1526919270037};\\\", \\\"{x:1599,y:702,t:1526919270181};\\\", \\\"{x:1599,y:701,t:1526919270222};\\\", \\\"{x:1600,y:700,t:1526919270230};\\\", \\\"{x:1601,y:699,t:1526919270243};\\\", \\\"{x:1602,y:696,t:1526919270260};\\\", \\\"{x:1603,y:695,t:1526919270276};\\\", \\\"{x:1605,y:690,t:1526919270293};\\\", \\\"{x:1606,y:688,t:1526919270309};\\\", \\\"{x:1607,y:685,t:1526919270326};\\\", \\\"{x:1608,y:682,t:1526919270342};\\\", \\\"{x:1608,y:681,t:1526919270360};\\\", \\\"{x:1608,y:679,t:1526919270376};\\\", \\\"{x:1608,y:678,t:1526919270397};\\\", \\\"{x:1608,y:677,t:1526919270414};\\\", \\\"{x:1608,y:676,t:1526919270426};\\\", \\\"{x:1608,y:675,t:1526919270445};\\\", \\\"{x:1608,y:674,t:1526919270461};\\\", \\\"{x:1608,y:673,t:1526919270476};\\\", \\\"{x:1608,y:672,t:1526919270493};\\\", \\\"{x:1608,y:671,t:1526919270509};\\\", \\\"{x:1608,y:670,t:1526919270525};\\\", \\\"{x:1609,y:671,t:1526919271621};\\\", \\\"{x:1609,y:672,t:1526919271645};\\\", \\\"{x:1609,y:673,t:1526919271685};\\\", \\\"{x:1610,y:674,t:1526919271693};\\\", \\\"{x:1610,y:675,t:1526919271725};\\\", \\\"{x:1611,y:676,t:1526919271733};\\\", \\\"{x:1611,y:677,t:1526919271743};\\\", \\\"{x:1612,y:679,t:1526919271766};\\\", \\\"{x:1612,y:680,t:1526919271845};\\\", \\\"{x:1612,y:681,t:1526919271861};\\\", \\\"{x:1613,y:682,t:1526919271876};\\\", \\\"{x:1613,y:683,t:1526919271909};\\\", \\\"{x:1613,y:684,t:1526919271926};\\\", \\\"{x:1613,y:685,t:1526919271973};\\\", \\\"{x:1614,y:685,t:1526919271989};\\\", \\\"{x:1614,y:686,t:1526919271998};\\\", \\\"{x:1614,y:687,t:1526919272037};\\\", \\\"{x:1614,y:688,t:1526919272062};\\\", \\\"{x:1614,y:689,t:1526919272206};\\\", \\\"{x:1613,y:689,t:1526919274630};\\\", \\\"{x:1612,y:689,t:1526919274661};\\\", \\\"{x:1612,y:688,t:1526919274675};\\\", \\\"{x:1611,y:688,t:1526919274692};\\\", \\\"{x:1610,y:688,t:1526919274765};\\\", \\\"{x:1608,y:688,t:1526919274781};\\\", \\\"{x:1604,y:690,t:1526919274797};\\\", \\\"{x:1599,y:693,t:1526919274809};\\\", \\\"{x:1589,y:701,t:1526919274825};\\\", \\\"{x:1577,y:712,t:1526919274842};\\\", \\\"{x:1570,y:717,t:1526919274859};\\\", \\\"{x:1564,y:723,t:1526919274875};\\\", \\\"{x:1556,y:730,t:1526919274892};\\\", \\\"{x:1538,y:743,t:1526919274909};\\\", \\\"{x:1521,y:753,t:1526919274925};\\\", \\\"{x:1499,y:766,t:1526919274942};\\\", \\\"{x:1478,y:779,t:1526919274959};\\\", \\\"{x:1458,y:787,t:1526919274975};\\\", \\\"{x:1446,y:793,t:1526919274992};\\\", \\\"{x:1438,y:797,t:1526919275008};\\\", \\\"{x:1429,y:803,t:1526919275025};\\\", \\\"{x:1417,y:813,t:1526919275042};\\\", \\\"{x:1397,y:827,t:1526919275058};\\\", \\\"{x:1371,y:840,t:1526919275075};\\\", \\\"{x:1340,y:853,t:1526919275092};\\\", \\\"{x:1304,y:869,t:1526919275108};\\\", \\\"{x:1265,y:894,t:1526919275124};\\\", \\\"{x:1240,y:911,t:1526919275142};\\\", \\\"{x:1208,y:931,t:1526919275158};\\\", \\\"{x:1185,y:948,t:1526919275175};\\\", \\\"{x:1158,y:967,t:1526919275192};\\\", \\\"{x:1134,y:982,t:1526919275209};\\\", \\\"{x:1115,y:995,t:1526919275225};\\\", \\\"{x:1100,y:1004,t:1526919275242};\\\", \\\"{x:1092,y:1011,t:1526919275258};\\\", \\\"{x:1085,y:1017,t:1526919275275};\\\", \\\"{x:1083,y:1022,t:1526919275292};\\\", \\\"{x:1082,y:1022,t:1526919275308};\\\", \\\"{x:1080,y:1023,t:1526919275325};\\\", \\\"{x:1076,y:1024,t:1526919275342};\\\", \\\"{x:1073,y:1024,t:1526919275358};\\\", \\\"{x:1072,y:1024,t:1526919275375};\\\", \\\"{x:1071,y:1023,t:1526919275413};\\\", \\\"{x:1071,y:1022,t:1526919275425};\\\", \\\"{x:1071,y:1018,t:1526919275442};\\\", \\\"{x:1073,y:1014,t:1526919275458};\\\", \\\"{x:1076,y:1008,t:1526919275475};\\\", \\\"{x:1078,y:1006,t:1526919275492};\\\", \\\"{x:1082,y:1002,t:1526919275508};\\\", \\\"{x:1084,y:1001,t:1526919275526};\\\", \\\"{x:1085,y:1001,t:1526919275542};\\\", \\\"{x:1087,y:1000,t:1526919275558};\\\", \\\"{x:1096,y:999,t:1526919275575};\\\", \\\"{x:1107,y:995,t:1526919275592};\\\", \\\"{x:1124,y:993,t:1526919275608};\\\", \\\"{x:1140,y:991,t:1526919275625};\\\", \\\"{x:1151,y:991,t:1526919275642};\\\", \\\"{x:1155,y:990,t:1526919275659};\\\", \\\"{x:1156,y:990,t:1526919275717};\\\", \\\"{x:1156,y:988,t:1526919275756};\\\", \\\"{x:1156,y:987,t:1526919275845};\\\", \\\"{x:1156,y:986,t:1526919275893};\\\", \\\"{x:1156,y:985,t:1526919275908};\\\", \\\"{x:1161,y:983,t:1526919275925};\\\", \\\"{x:1165,y:983,t:1526919275942};\\\", \\\"{x:1179,y:980,t:1526919275959};\\\", \\\"{x:1195,y:980,t:1526919275975};\\\", \\\"{x:1212,y:980,t:1526919275992};\\\", \\\"{x:1224,y:980,t:1526919276008};\\\", \\\"{x:1227,y:980,t:1526919276025};\\\", \\\"{x:1226,y:979,t:1526919276253};\\\", \\\"{x:1225,y:979,t:1526919276261};\\\", \\\"{x:1224,y:979,t:1526919276275};\\\", \\\"{x:1221,y:976,t:1526919276292};\\\", \\\"{x:1216,y:976,t:1526919276308};\\\", \\\"{x:1211,y:975,t:1526919276325};\\\", \\\"{x:1208,y:975,t:1526919276342};\\\", \\\"{x:1207,y:974,t:1526919276358};\\\", \\\"{x:1205,y:973,t:1526919276375};\\\", \\\"{x:1204,y:973,t:1526919276397};\\\", \\\"{x:1202,y:972,t:1526919276413};\\\", \\\"{x:1201,y:972,t:1526919276444};\\\", \\\"{x:1200,y:972,t:1526919276458};\\\", \\\"{x:1199,y:972,t:1526919276685};\\\", \\\"{x:1197,y:970,t:1526919276709};\\\", \\\"{x:1195,y:970,t:1526919276725};\\\", \\\"{x:1191,y:970,t:1526919276742};\\\", \\\"{x:1189,y:970,t:1526919276758};\\\", \\\"{x:1188,y:969,t:1526919276775};\\\", \\\"{x:1189,y:969,t:1526919276981};\\\", \\\"{x:1191,y:969,t:1526919276991};\\\", \\\"{x:1198,y:970,t:1526919277008};\\\", \\\"{x:1205,y:971,t:1526919277025};\\\", \\\"{x:1212,y:971,t:1526919277041};\\\", \\\"{x:1218,y:974,t:1526919277058};\\\", \\\"{x:1220,y:974,t:1526919277075};\\\", \\\"{x:1222,y:974,t:1526919277157};\\\", \\\"{x:1224,y:974,t:1526919277189};\\\", \\\"{x:1226,y:974,t:1526919277197};\\\", \\\"{x:1227,y:974,t:1526919277261};\\\", \\\"{x:1228,y:974,t:1526919277293};\\\", \\\"{x:1229,y:974,t:1526919277317};\\\", \\\"{x:1231,y:974,t:1526919277565};\\\", \\\"{x:1232,y:974,t:1526919277574};\\\", \\\"{x:1234,y:974,t:1526919277591};\\\", \\\"{x:1241,y:974,t:1526919277608};\\\", \\\"{x:1245,y:974,t:1526919277624};\\\", \\\"{x:1247,y:974,t:1526919277641};\\\", \\\"{x:1250,y:974,t:1526919277659};\\\", \\\"{x:1251,y:974,t:1526919277693};\\\", \\\"{x:1253,y:973,t:1526919277717};\\\", \\\"{x:1254,y:973,t:1526919277740};\\\", \\\"{x:1256,y:973,t:1526919277749};\\\", \\\"{x:1258,y:973,t:1526919277764};\\\", \\\"{x:1261,y:972,t:1526919277774};\\\", \\\"{x:1262,y:971,t:1526919277791};\\\", \\\"{x:1263,y:971,t:1526919277808};\\\", \\\"{x:1265,y:971,t:1526919277824};\\\", \\\"{x:1266,y:971,t:1526919277841};\\\", \\\"{x:1267,y:971,t:1526919277858};\\\", \\\"{x:1268,y:971,t:1526919277874};\\\", \\\"{x:1270,y:970,t:1526919277891};\\\", \\\"{x:1271,y:970,t:1526919277909};\\\", \\\"{x:1272,y:970,t:1526919277923};\\\", \\\"{x:1273,y:970,t:1526919277941};\\\", \\\"{x:1275,y:969,t:1526919277958};\\\", \\\"{x:1276,y:969,t:1526919277974};\\\", \\\"{x:1278,y:969,t:1526919278197};\\\", \\\"{x:1279,y:969,t:1526919278213};\\\", \\\"{x:1281,y:969,t:1526919278245};\\\", \\\"{x:1283,y:969,t:1526919278469};\\\", \\\"{x:1281,y:968,t:1526919278492};\\\", \\\"{x:1277,y:968,t:1526919278508};\\\", \\\"{x:1262,y:968,t:1526919278524};\\\", \\\"{x:1243,y:967,t:1526919278541};\\\", \\\"{x:1230,y:967,t:1526919278558};\\\", \\\"{x:1220,y:967,t:1526919278574};\\\", \\\"{x:1215,y:967,t:1526919278591};\\\", \\\"{x:1211,y:967,t:1526919278608};\\\", \\\"{x:1208,y:968,t:1526919278624};\\\", \\\"{x:1201,y:968,t:1526919278641};\\\", \\\"{x:1193,y:969,t:1526919278658};\\\", \\\"{x:1184,y:969,t:1526919278674};\\\", \\\"{x:1175,y:969,t:1526919278691};\\\", \\\"{x:1167,y:969,t:1526919278708};\\\", \\\"{x:1160,y:969,t:1526919278724};\\\", \\\"{x:1138,y:969,t:1526919278740};\\\", \\\"{x:1112,y:969,t:1526919278758};\\\", \\\"{x:1091,y:969,t:1526919278774};\\\", \\\"{x:1074,y:969,t:1526919278791};\\\", \\\"{x:1067,y:969,t:1526919278808};\\\", \\\"{x:1066,y:970,t:1526919278956};\\\", \\\"{x:1066,y:971,t:1526919278996};\\\", \\\"{x:1070,y:972,t:1526919279012};\\\", \\\"{x:1075,y:972,t:1526919279024};\\\", \\\"{x:1092,y:972,t:1526919279041};\\\", \\\"{x:1106,y:975,t:1526919279057};\\\", \\\"{x:1115,y:977,t:1526919279074};\\\", \\\"{x:1118,y:979,t:1526919279091};\\\", \\\"{x:1117,y:978,t:1526919279301};\\\", \\\"{x:1116,y:978,t:1526919279341};\\\", \\\"{x:1115,y:977,t:1526919279357};\\\", \\\"{x:1115,y:976,t:1526919279421};\\\", \\\"{x:1115,y:975,t:1526919279429};\\\", \\\"{x:1115,y:974,t:1526919279461};\\\", \\\"{x:1116,y:974,t:1526919279525};\\\", \\\"{x:1117,y:974,t:1526919279541};\\\", \\\"{x:1120,y:974,t:1526919279557};\\\", \\\"{x:1121,y:974,t:1526919279574};\\\", \\\"{x:1124,y:973,t:1526919279591};\\\", \\\"{x:1127,y:972,t:1526919279607};\\\", \\\"{x:1130,y:972,t:1526919279624};\\\", \\\"{x:1131,y:972,t:1526919279653};\\\", \\\"{x:1133,y:972,t:1526919279661};\\\", \\\"{x:1134,y:972,t:1526919279676};\\\", \\\"{x:1135,y:972,t:1526919279692};\\\", \\\"{x:1136,y:972,t:1526919279707};\\\", \\\"{x:1137,y:972,t:1526919279724};\\\", \\\"{x:1138,y:972,t:1526919279741};\\\", \\\"{x:1138,y:971,t:1526919279852};\\\", \\\"{x:1139,y:971,t:1526919279925};\\\", \\\"{x:1142,y:971,t:1526919279940};\\\", \\\"{x:1146,y:971,t:1526919279957};\\\", \\\"{x:1152,y:971,t:1526919279974};\\\", \\\"{x:1155,y:971,t:1526919279991};\\\", \\\"{x:1158,y:972,t:1526919280008};\\\", \\\"{x:1159,y:972,t:1526919280069};\\\", \\\"{x:1159,y:973,t:1526919280149};\\\", \\\"{x:1160,y:973,t:1526919280165};\\\", \\\"{x:1161,y:973,t:1526919280182};\\\", \\\"{x:1162,y:973,t:1526919280191};\\\", \\\"{x:1163,y:973,t:1526919280208};\\\", \\\"{x:1165,y:973,t:1526919280224};\\\", \\\"{x:1166,y:973,t:1526919280246};\\\", \\\"{x:1167,y:972,t:1526919280262};\\\", \\\"{x:1169,y:972,t:1526919280274};\\\", \\\"{x:1174,y:970,t:1526919280290};\\\", \\\"{x:1178,y:970,t:1526919280307};\\\", \\\"{x:1180,y:970,t:1526919280324};\\\", \\\"{x:1182,y:969,t:1526919280341};\\\", \\\"{x:1183,y:969,t:1526919280389};\\\", \\\"{x:1184,y:969,t:1526919280397};\\\", \\\"{x:1184,y:968,t:1526919280413};\\\", \\\"{x:1186,y:968,t:1526919280669};\\\", \\\"{x:1187,y:968,t:1526919280676};\\\", \\\"{x:1189,y:968,t:1526919280690};\\\", \\\"{x:1191,y:968,t:1526919280707};\\\", \\\"{x:1193,y:968,t:1526919280724};\\\", \\\"{x:1196,y:968,t:1526919280740};\\\", \\\"{x:1197,y:968,t:1526919280757};\\\", \\\"{x:1198,y:968,t:1526919280775};\\\", \\\"{x:1199,y:968,t:1526919280791};\\\", \\\"{x:1200,y:968,t:1526919280820};\\\", \\\"{x:1201,y:968,t:1526919280941};\\\", \\\"{x:1202,y:968,t:1526919280956};\\\", \\\"{x:1203,y:968,t:1526919281005};\\\", \\\"{x:1204,y:968,t:1526919281012};\\\", \\\"{x:1205,y:967,t:1526919281024};\\\", \\\"{x:1206,y:967,t:1526919281040};\\\", \\\"{x:1208,y:967,t:1526919281057};\\\", \\\"{x:1209,y:967,t:1526919281149};\\\", \\\"{x:1210,y:967,t:1526919281181};\\\", \\\"{x:1211,y:967,t:1526919281190};\\\", \\\"{x:1212,y:967,t:1526919281213};\\\", \\\"{x:1213,y:967,t:1526919281245};\\\", \\\"{x:1214,y:967,t:1526919281261};\\\", \\\"{x:1215,y:967,t:1526919281293};\\\", \\\"{x:1217,y:967,t:1526919281309};\\\", \\\"{x:1218,y:967,t:1526919281324};\\\", \\\"{x:1220,y:967,t:1526919281356};\\\", \\\"{x:1221,y:967,t:1526919281375};\\\", \\\"{x:1224,y:967,t:1526919281390};\\\", \\\"{x:1229,y:967,t:1526919281407};\\\", \\\"{x:1241,y:968,t:1526919281424};\\\", \\\"{x:1254,y:971,t:1526919281440};\\\", \\\"{x:1262,y:972,t:1526919281458};\\\", \\\"{x:1265,y:973,t:1526919281473};\\\", \\\"{x:1264,y:973,t:1526919281749};\\\", \\\"{x:1262,y:973,t:1526919281756};\\\", \\\"{x:1261,y:973,t:1526919281774};\\\", \\\"{x:1259,y:973,t:1526919281791};\\\", \\\"{x:1258,y:973,t:1526919281808};\\\", \\\"{x:1257,y:973,t:1526919281829};\\\", \\\"{x:1259,y:973,t:1526919282109};\\\", \\\"{x:1261,y:972,t:1526919282124};\\\", \\\"{x:1266,y:972,t:1526919282140};\\\", \\\"{x:1272,y:972,t:1526919282157};\\\", \\\"{x:1274,y:972,t:1526919282173};\\\", \\\"{x:1275,y:972,t:1526919282190};\\\", \\\"{x:1276,y:972,t:1526919282207};\\\", \\\"{x:1277,y:972,t:1526919282245};\\\", \\\"{x:1278,y:972,t:1526919282277};\\\", \\\"{x:1279,y:972,t:1526919282325};\\\", \\\"{x:1282,y:972,t:1526919282477};\\\", \\\"{x:1286,y:972,t:1526919282491};\\\", \\\"{x:1300,y:972,t:1526919282508};\\\", \\\"{x:1313,y:974,t:1526919282524};\\\", \\\"{x:1319,y:975,t:1526919282540};\\\", \\\"{x:1320,y:975,t:1526919282557};\\\", \\\"{x:1321,y:975,t:1526919282829};\\\", \\\"{x:1322,y:973,t:1526919282869};\\\", \\\"{x:1323,y:972,t:1526919282973};\\\", \\\"{x:1324,y:972,t:1526919283045};\\\", \\\"{x:1325,y:971,t:1526919283056};\\\", \\\"{x:1326,y:971,t:1526919283074};\\\", \\\"{x:1329,y:971,t:1526919283091};\\\", \\\"{x:1330,y:971,t:1526919283125};\\\", \\\"{x:1332,y:971,t:1526919283141};\\\", \\\"{x:1333,y:971,t:1526919283173};\\\", \\\"{x:1334,y:971,t:1526919283212};\\\", \\\"{x:1335,y:971,t:1526919283253};\\\", \\\"{x:1336,y:971,t:1526919283269};\\\", \\\"{x:1337,y:971,t:1526919283285};\\\", \\\"{x:1338,y:971,t:1526919283341};\\\", \\\"{x:1339,y:971,t:1526919283357};\\\", \\\"{x:1343,y:970,t:1526919283373};\\\", \\\"{x:1344,y:970,t:1526919283391};\\\", \\\"{x:1347,y:970,t:1526919283654};\\\", \\\"{x:1351,y:970,t:1526919283661};\\\", \\\"{x:1355,y:970,t:1526919283673};\\\", \\\"{x:1364,y:970,t:1526919283691};\\\", \\\"{x:1377,y:972,t:1526919283708};\\\", \\\"{x:1379,y:973,t:1526919283724};\\\", \\\"{x:1380,y:973,t:1526919283766};\\\", \\\"{x:1380,y:972,t:1526919283926};\\\", \\\"{x:1380,y:971,t:1526919283940};\\\", \\\"{x:1379,y:969,t:1526919283956};\\\", \\\"{x:1379,y:968,t:1526919283974};\\\", \\\"{x:1378,y:967,t:1526919283990};\\\", \\\"{x:1379,y:966,t:1526919284302};\\\", \\\"{x:1380,y:966,t:1526919284318};\\\", \\\"{x:1382,y:966,t:1526919284349};\\\", \\\"{x:1383,y:966,t:1526919284374};\\\", \\\"{x:1386,y:966,t:1526919284390};\\\", \\\"{x:1390,y:966,t:1526919284407};\\\", \\\"{x:1392,y:966,t:1526919284424};\\\", \\\"{x:1393,y:966,t:1526919284440};\\\", \\\"{x:1394,y:967,t:1526919284457};\\\", \\\"{x:1394,y:968,t:1526919284692};\\\", \\\"{x:1395,y:968,t:1526919284708};\\\", \\\"{x:1396,y:968,t:1526919284725};\\\", \\\"{x:1398,y:968,t:1526919284740};\\\", \\\"{x:1400,y:968,t:1526919284757};\\\", \\\"{x:1401,y:968,t:1526919284773};\\\", \\\"{x:1402,y:968,t:1526919284789};\\\", \\\"{x:1403,y:968,t:1526919284980};\\\", \\\"{x:1405,y:968,t:1526919284989};\\\", \\\"{x:1406,y:968,t:1526919285006};\\\", \\\"{x:1407,y:968,t:1526919285023};\\\", \\\"{x:1409,y:968,t:1526919285040};\\\", \\\"{x:1410,y:968,t:1526919285092};\\\", \\\"{x:1411,y:968,t:1526919285109};\\\", \\\"{x:1412,y:968,t:1526919285132};\\\", \\\"{x:1414,y:968,t:1526919285140};\\\", \\\"{x:1415,y:968,t:1526919285156};\\\", \\\"{x:1419,y:968,t:1526919285173};\\\", \\\"{x:1420,y:968,t:1526919285189};\\\", \\\"{x:1421,y:968,t:1526919285207};\\\", \\\"{x:1424,y:967,t:1526919285236};\\\", \\\"{x:1425,y:967,t:1526919285252};\\\", \\\"{x:1426,y:967,t:1526919285260};\\\", \\\"{x:1428,y:967,t:1526919285273};\\\", \\\"{x:1431,y:967,t:1526919285289};\\\", \\\"{x:1435,y:967,t:1526919285307};\\\", \\\"{x:1438,y:967,t:1526919285741};\\\", \\\"{x:1441,y:968,t:1526919285757};\\\", \\\"{x:1443,y:968,t:1526919285772};\\\", \\\"{x:1447,y:968,t:1526919285790};\\\", \\\"{x:1449,y:968,t:1526919285807};\\\", \\\"{x:1450,y:968,t:1526919285823};\\\", \\\"{x:1451,y:969,t:1526919285840};\\\", \\\"{x:1452,y:969,t:1526919285857};\\\", \\\"{x:1453,y:969,t:1526919285893};\\\", \\\"{x:1454,y:969,t:1526919285918};\\\", \\\"{x:1455,y:970,t:1526919285934};\\\", \\\"{x:1456,y:970,t:1526919285950};\\\", \\\"{x:1457,y:970,t:1526919285957};\\\", \\\"{x:1460,y:970,t:1526919285973};\\\", \\\"{x:1464,y:971,t:1526919285989};\\\", \\\"{x:1470,y:972,t:1526919286007};\\\", \\\"{x:1475,y:974,t:1526919286023};\\\", \\\"{x:1481,y:977,t:1526919286040};\\\", \\\"{x:1483,y:977,t:1526919286057};\\\", \\\"{x:1486,y:977,t:1526919286478};\\\", \\\"{x:1487,y:977,t:1526919286490};\\\", \\\"{x:1490,y:977,t:1526919286506};\\\", \\\"{x:1491,y:977,t:1526919286523};\\\", \\\"{x:1494,y:977,t:1526919286540};\\\", \\\"{x:1496,y:975,t:1526919286557};\\\", \\\"{x:1498,y:975,t:1526919286573};\\\", \\\"{x:1499,y:975,t:1526919286590};\\\", \\\"{x:1501,y:974,t:1526919286605};\\\", \\\"{x:1502,y:974,t:1526919286629};\\\", \\\"{x:1502,y:973,t:1526919286653};\\\", \\\"{x:1504,y:972,t:1526919286669};\\\", \\\"{x:1505,y:971,t:1526919286693};\\\", \\\"{x:1506,y:971,t:1526919286705};\\\", \\\"{x:1508,y:969,t:1526919286723};\\\", \\\"{x:1510,y:969,t:1526919286739};\\\", \\\"{x:1511,y:968,t:1526919286756};\\\", \\\"{x:1513,y:967,t:1526919286773};\\\", \\\"{x:1514,y:968,t:1526919287141};\\\", \\\"{x:1514,y:969,t:1526919287164};\\\", \\\"{x:1515,y:971,t:1526919287188};\\\", \\\"{x:1516,y:972,t:1526919287212};\\\", \\\"{x:1517,y:972,t:1526919287252};\\\", \\\"{x:1518,y:972,t:1526919287285};\\\", \\\"{x:1519,y:973,t:1526919287293};\\\", \\\"{x:1520,y:973,t:1526919287305};\\\", \\\"{x:1525,y:975,t:1526919287323};\\\", \\\"{x:1528,y:976,t:1526919287340};\\\", \\\"{x:1530,y:976,t:1526919287356};\\\", \\\"{x:1531,y:976,t:1526919287388};\\\", \\\"{x:1532,y:976,t:1526919287429};\\\", \\\"{x:1533,y:976,t:1526919287452};\\\", \\\"{x:1534,y:976,t:1526919287469};\\\", \\\"{x:1535,y:976,t:1526919287477};\\\", \\\"{x:1536,y:976,t:1526919287489};\\\", \\\"{x:1537,y:976,t:1526919287506};\\\", \\\"{x:1538,y:976,t:1526919287522};\\\", \\\"{x:1539,y:976,t:1526919287564};\\\", \\\"{x:1540,y:976,t:1526919287581};\\\", \\\"{x:1541,y:975,t:1526919287589};\\\", \\\"{x:1542,y:974,t:1526919287620};\\\", \\\"{x:1543,y:974,t:1526919287629};\\\", \\\"{x:1545,y:973,t:1526919287693};\\\", \\\"{x:1546,y:973,t:1526919287717};\\\", \\\"{x:1547,y:973,t:1526919287725};\\\", \\\"{x:1547,y:972,t:1526919287739};\\\", \\\"{x:1548,y:972,t:1526919287756};\\\", \\\"{x:1549,y:971,t:1526919287973};\\\", \\\"{x:1549,y:970,t:1526919287997};\\\", \\\"{x:1549,y:969,t:1526919288021};\\\", \\\"{x:1550,y:967,t:1526919288076};\\\", \\\"{x:1552,y:965,t:1526919288092};\\\", \\\"{x:1553,y:965,t:1526919288109};\\\", \\\"{x:1554,y:965,t:1526919288122};\\\", \\\"{x:1556,y:964,t:1526919288138};\\\", \\\"{x:1559,y:963,t:1526919288155};\\\", \\\"{x:1563,y:963,t:1526919288173};\\\", \\\"{x:1564,y:963,t:1526919288189};\\\", \\\"{x:1565,y:963,t:1526919288205};\\\", \\\"{x:1566,y:963,t:1526919288373};\\\", \\\"{x:1567,y:963,t:1526919288388};\\\", \\\"{x:1569,y:963,t:1526919288405};\\\", \\\"{x:1571,y:962,t:1526919288423};\\\", \\\"{x:1572,y:962,t:1526919288468};\\\", \\\"{x:1573,y:962,t:1526919288501};\\\", \\\"{x:1574,y:962,t:1526919288516};\\\", \\\"{x:1575,y:962,t:1526919288621};\\\", \\\"{x:1576,y:962,t:1526919289213};\\\", \\\"{x:1578,y:962,t:1526919289222};\\\", \\\"{x:1579,y:962,t:1526919289245};\\\", \\\"{x:1581,y:962,t:1526919289276};\\\", \\\"{x:1583,y:962,t:1526919289309};\\\", \\\"{x:1584,y:962,t:1526919289333};\\\", \\\"{x:1585,y:962,t:1526919289381};\\\", \\\"{x:1586,y:962,t:1526919289397};\\\", \\\"{x:1587,y:963,t:1526919289405};\\\", \\\"{x:1588,y:964,t:1526919289453};\\\", \\\"{x:1589,y:964,t:1526919289477};\\\", \\\"{x:1590,y:964,t:1526919289489};\\\", \\\"{x:1592,y:964,t:1526919289506};\\\", \\\"{x:1594,y:965,t:1526919289521};\\\", \\\"{x:1596,y:966,t:1526919289539};\\\", \\\"{x:1597,y:966,t:1526919289556};\\\", \\\"{x:1601,y:967,t:1526919289572};\\\", \\\"{x:1602,y:967,t:1526919289597};\\\", \\\"{x:1603,y:967,t:1526919289605};\\\", \\\"{x:1603,y:968,t:1526919289622};\\\", \\\"{x:1604,y:968,t:1526919289645};\\\", \\\"{x:1604,y:969,t:1526919289662};\\\", \\\"{x:1605,y:969,t:1526919290365};\\\", \\\"{x:1606,y:969,t:1526919290397};\\\", \\\"{x:1607,y:969,t:1526919290420};\\\", \\\"{x:1609,y:969,t:1526919290565};\\\", \\\"{x:1610,y:969,t:1526919290605};\\\", \\\"{x:1611,y:968,t:1526919290621};\\\", \\\"{x:1612,y:968,t:1526919290639};\\\", \\\"{x:1613,y:968,t:1526919290655};\\\", \\\"{x:1615,y:968,t:1526919290672};\\\", \\\"{x:1616,y:968,t:1526919290688};\\\", \\\"{x:1618,y:967,t:1526919290705};\\\", \\\"{x:1620,y:966,t:1526919290748};\\\", \\\"{x:1621,y:966,t:1526919290765};\\\", \\\"{x:1621,y:965,t:1526919290772};\\\", \\\"{x:1622,y:965,t:1526919290788};\\\", \\\"{x:1623,y:965,t:1526919290805};\\\", \\\"{x:1624,y:964,t:1526919290845};\\\", \\\"{x:1626,y:963,t:1526919290861};\\\", \\\"{x:1627,y:963,t:1526919290872};\\\", \\\"{x:1631,y:962,t:1526919290888};\\\", \\\"{x:1632,y:962,t:1526919290905};\\\", \\\"{x:1633,y:961,t:1526919290921};\\\", \\\"{x:1634,y:961,t:1526919290938};\\\", \\\"{x:1635,y:961,t:1526919290956};\\\", \\\"{x:1636,y:961,t:1526919290973};\\\", \\\"{x:1638,y:961,t:1526919290988};\\\", \\\"{x:1639,y:959,t:1526919291005};\\\", \\\"{x:1640,y:959,t:1526919291028};\\\", \\\"{x:1634,y:960,t:1526919291549};\\\", \\\"{x:1627,y:963,t:1526919291556};\\\", \\\"{x:1618,y:970,t:1526919291572};\\\", \\\"{x:1565,y:991,t:1526919291588};\\\", \\\"{x:1545,y:997,t:1526919291604};\\\", \\\"{x:1541,y:997,t:1526919291621};\\\", \\\"{x:1540,y:996,t:1526919291661};\\\", \\\"{x:1539,y:996,t:1526919291671};\\\", \\\"{x:1534,y:995,t:1526919291689};\\\", \\\"{x:1521,y:990,t:1526919291704};\\\", \\\"{x:1503,y:986,t:1526919291721};\\\", \\\"{x:1485,y:983,t:1526919291739};\\\", \\\"{x:1475,y:980,t:1526919291754};\\\", \\\"{x:1458,y:977,t:1526919291772};\\\", \\\"{x:1429,y:972,t:1526919291789};\\\", \\\"{x:1410,y:967,t:1526919291805};\\\", \\\"{x:1388,y:958,t:1526919291821};\\\", \\\"{x:1352,y:940,t:1526919291839};\\\", \\\"{x:1306,y:923,t:1526919291855};\\\", \\\"{x:1255,y:908,t:1526919291871};\\\", \\\"{x:1214,y:891,t:1526919291888};\\\", \\\"{x:1169,y:870,t:1526919291905};\\\", \\\"{x:1130,y:843,t:1526919291921};\\\", \\\"{x:1067,y:807,t:1526919291938};\\\", \\\"{x:992,y:769,t:1526919291955};\\\", \\\"{x:898,y:728,t:1526919291972};\\\", \\\"{x:798,y:685,t:1526919291988};\\\", \\\"{x:648,y:622,t:1526919292004};\\\", \\\"{x:558,y:587,t:1526919292022};\\\", \\\"{x:476,y:554,t:1526919292038};\\\", \\\"{x:442,y:542,t:1526919292051};\\\", \\\"{x:384,y:516,t:1526919292069};\\\", \\\"{x:330,y:500,t:1526919292083};\\\", \\\"{x:249,y:476,t:1526919292101};\\\", \\\"{x:222,y:470,t:1526919292118};\\\", \\\"{x:199,y:463,t:1526919292134};\\\", \\\"{x:173,y:461,t:1526919292151};\\\", \\\"{x:158,y:458,t:1526919292168};\\\", \\\"{x:151,y:457,t:1526919292183};\\\", \\\"{x:148,y:456,t:1526919292201};\\\", \\\"{x:147,y:456,t:1526919292221};\\\", \\\"{x:145,y:456,t:1526919292236};\\\", \\\"{x:143,y:456,t:1526919292250};\\\", \\\"{x:141,y:456,t:1526919292268};\\\", \\\"{x:139,y:457,t:1526919292283};\\\", \\\"{x:137,y:469,t:1526919292301};\\\", \\\"{x:139,y:482,t:1526919292317};\\\", \\\"{x:151,y:499,t:1526919292335};\\\", \\\"{x:170,y:513,t:1526919292351};\\\", \\\"{x:192,y:527,t:1526919292368};\\\", \\\"{x:220,y:539,t:1526919292385};\\\", \\\"{x:250,y:553,t:1526919292401};\\\", \\\"{x:275,y:564,t:1526919292418};\\\", \\\"{x:294,y:573,t:1526919292435};\\\", \\\"{x:306,y:580,t:1526919292451};\\\", \\\"{x:320,y:588,t:1526919292468};\\\", \\\"{x:342,y:600,t:1526919292484};\\\", \\\"{x:357,y:609,t:1526919292501};\\\", \\\"{x:370,y:615,t:1526919292518};\\\", \\\"{x:385,y:621,t:1526919292534};\\\", \\\"{x:394,y:624,t:1526919292551};\\\", \\\"{x:397,y:624,t:1526919292567};\\\", \\\"{x:397,y:625,t:1526919292584};\\\", \\\"{x:398,y:625,t:1526919295261};\\\", \\\"{x:398,y:624,t:1526919295325};\\\", \\\"{x:398,y:622,t:1526919295445};\\\", \\\"{x:398,y:621,t:1526919295494};\\\", \\\"{x:398,y:619,t:1526919295541};\\\", \\\"{x:398,y:618,t:1526919295876};\\\", \\\"{x:397,y:618,t:1526919295909};\\\", \\\"{x:397,y:617,t:1526919296085};\\\", \\\"{x:400,y:615,t:1526919296093};\\\", \\\"{x:402,y:614,t:1526919296104};\\\", \\\"{x:407,y:611,t:1526919296121};\\\", \\\"{x:412,y:610,t:1526919296137};\\\", \\\"{x:431,y:606,t:1526919296154};\\\", \\\"{x:449,y:604,t:1526919296171};\\\", \\\"{x:464,y:603,t:1526919296186};\\\", \\\"{x:473,y:601,t:1526919296204};\\\", \\\"{x:478,y:600,t:1526919296221};\\\", \\\"{x:485,y:599,t:1526919296237};\\\", \\\"{x:494,y:596,t:1526919296253};\\\", \\\"{x:509,y:596,t:1526919296271};\\\", \\\"{x:538,y:596,t:1526919296288};\\\", \\\"{x:591,y:596,t:1526919296304};\\\", \\\"{x:671,y:596,t:1526919296320};\\\", \\\"{x:727,y:596,t:1526919296338};\\\", \\\"{x:760,y:591,t:1526919296354};\\\", \\\"{x:774,y:586,t:1526919296371};\\\", \\\"{x:778,y:582,t:1526919296388};\\\", \\\"{x:779,y:573,t:1526919296404};\\\", \\\"{x:782,y:559,t:1526919296421};\\\", \\\"{x:787,y:549,t:1526919296438};\\\", \\\"{x:790,y:543,t:1526919296454};\\\", \\\"{x:796,y:537,t:1526919296471};\\\", \\\"{x:797,y:535,t:1526919296488};\\\", \\\"{x:797,y:534,t:1526919296516};\\\", \\\"{x:798,y:534,t:1526919296524};\\\", \\\"{x:798,y:533,t:1526919296549};\\\", \\\"{x:799,y:532,t:1526919296556};\\\", \\\"{x:800,y:531,t:1526919296570};\\\", \\\"{x:802,y:530,t:1526919296588};\\\", \\\"{x:803,y:530,t:1526919296605};\\\", \\\"{x:805,y:530,t:1526919296628};\\\", \\\"{x:808,y:530,t:1526919296638};\\\", \\\"{x:810,y:530,t:1526919296655};\\\", \\\"{x:814,y:532,t:1526919296670};\\\", \\\"{x:816,y:533,t:1526919296688};\\\", \\\"{x:816,y:537,t:1526919296705};\\\", \\\"{x:816,y:541,t:1526919296721};\\\", \\\"{x:807,y:549,t:1526919296738};\\\", \\\"{x:795,y:555,t:1526919296755};\\\", \\\"{x:778,y:559,t:1526919296771};\\\", \\\"{x:754,y:566,t:1526919296788};\\\", \\\"{x:718,y:570,t:1526919296804};\\\", \\\"{x:684,y:570,t:1526919296820};\\\", \\\"{x:661,y:570,t:1526919296838};\\\", \\\"{x:640,y:570,t:1526919296855};\\\", \\\"{x:627,y:570,t:1526919296871};\\\", \\\"{x:624,y:570,t:1526919296887};\\\", \\\"{x:622,y:570,t:1526919296905};\\\", \\\"{x:618,y:570,t:1526919296932};\\\", \\\"{x:615,y:570,t:1526919296940};\\\", \\\"{x:608,y:570,t:1526919296955};\\\", \\\"{x:591,y:570,t:1526919296972};\\\", \\\"{x:573,y:570,t:1526919296987};\\\", \\\"{x:541,y:570,t:1526919297005};\\\", \\\"{x:523,y:570,t:1526919297022};\\\", \\\"{x:507,y:570,t:1526919297038};\\\", \\\"{x:492,y:570,t:1526919297056};\\\", \\\"{x:478,y:570,t:1526919297071};\\\", \\\"{x:461,y:570,t:1526919297088};\\\", \\\"{x:452,y:570,t:1526919297105};\\\", \\\"{x:438,y:570,t:1526919297121};\\\", \\\"{x:427,y:570,t:1526919297138};\\\", \\\"{x:412,y:573,t:1526919297155};\\\", \\\"{x:402,y:574,t:1526919297172};\\\", \\\"{x:398,y:575,t:1526919297188};\\\", \\\"{x:398,y:576,t:1526919297236};\\\", \\\"{x:396,y:577,t:1526919297244};\\\", \\\"{x:396,y:578,t:1526919297255};\\\", \\\"{x:395,y:579,t:1526919297272};\\\", \\\"{x:395,y:580,t:1526919297287};\\\", \\\"{x:395,y:581,t:1526919297308};\\\", \\\"{x:395,y:583,t:1526919297322};\\\", \\\"{x:395,y:584,t:1526919297337};\\\", \\\"{x:395,y:587,t:1526919297354};\\\", \\\"{x:396,y:590,t:1526919297372};\\\", \\\"{x:396,y:593,t:1526919297388};\\\", \\\"{x:396,y:596,t:1526919297405};\\\", \\\"{x:396,y:599,t:1526919297422};\\\", \\\"{x:387,y:606,t:1526919297439};\\\", \\\"{x:372,y:615,t:1526919297455};\\\", \\\"{x:361,y:623,t:1526919297472};\\\", \\\"{x:331,y:631,t:1526919297489};\\\", \\\"{x:287,y:636,t:1526919297505};\\\", \\\"{x:263,y:640,t:1526919297522};\\\", \\\"{x:241,y:643,t:1526919297539};\\\", \\\"{x:232,y:645,t:1526919297555};\\\", \\\"{x:234,y:645,t:1526919297637};\\\", \\\"{x:241,y:644,t:1526919297644};\\\", \\\"{x:249,y:642,t:1526919297655};\\\", \\\"{x:270,y:635,t:1526919297672};\\\", \\\"{x:286,y:629,t:1526919297689};\\\", \\\"{x:288,y:628,t:1526919297705};\\\", \\\"{x:288,y:627,t:1526919297725};\\\", \\\"{x:288,y:626,t:1526919297740};\\\", \\\"{x:288,y:625,t:1526919297755};\\\", \\\"{x:286,y:625,t:1526919297772};\\\", \\\"{x:276,y:624,t:1526919297788};\\\", \\\"{x:263,y:621,t:1526919297807};\\\", \\\"{x:242,y:620,t:1526919297822};\\\", \\\"{x:225,y:618,t:1526919297839};\\\", \\\"{x:211,y:616,t:1526919297856};\\\", \\\"{x:205,y:615,t:1526919297872};\\\", \\\"{x:204,y:615,t:1526919297889};\\\", \\\"{x:203,y:615,t:1526919297906};\\\", \\\"{x:201,y:615,t:1526919297922};\\\", \\\"{x:201,y:614,t:1526919297939};\\\", \\\"{x:199,y:614,t:1526919297956};\\\", \\\"{x:197,y:613,t:1526919297972};\\\", \\\"{x:196,y:612,t:1526919298020};\\\", \\\"{x:195,y:612,t:1526919298036};\\\", \\\"{x:194,y:612,t:1526919298060};\\\", \\\"{x:194,y:613,t:1526919299103};\\\", \\\"{x:195,y:613,t:1526919299120};\\\", \\\"{x:196,y:613,t:1526919299144};\\\", \\\"{x:198,y:614,t:1526919299160};\\\", \\\"{x:200,y:615,t:1526919299183};\\\", \\\"{x:202,y:615,t:1526919299193};\\\", \\\"{x:207,y:617,t:1526919299210};\\\", \\\"{x:215,y:618,t:1526919299226};\\\", \\\"{x:217,y:618,t:1526919299243};\\\", \\\"{x:217,y:619,t:1526919299260};\\\", \\\"{x:218,y:619,t:1526919299432};\\\", \\\"{x:213,y:619,t:1526919299448};\\\", \\\"{x:206,y:619,t:1526919299461};\\\", \\\"{x:191,y:619,t:1526919299476};\\\", \\\"{x:183,y:619,t:1526919299494};\\\", \\\"{x:181,y:619,t:1526919299510};\\\", \\\"{x:181,y:618,t:1526919300176};\\\", \\\"{x:182,y:618,t:1526919300184};\\\", \\\"{x:187,y:618,t:1526919300194};\\\", \\\"{x:204,y:619,t:1526919300210};\\\", \\\"{x:227,y:620,t:1526919300227};\\\", \\\"{x:254,y:621,t:1526919300244};\\\", \\\"{x:284,y:621,t:1526919300262};\\\", \\\"{x:320,y:621,t:1526919300277};\\\", \\\"{x:341,y:620,t:1526919300294};\\\", \\\"{x:368,y:617,t:1526919300311};\\\", \\\"{x:384,y:612,t:1526919300327};\\\", \\\"{x:397,y:607,t:1526919300345};\\\", \\\"{x:404,y:604,t:1526919300361};\\\", \\\"{x:411,y:602,t:1526919300377};\\\", \\\"{x:415,y:600,t:1526919300395};\\\", \\\"{x:426,y:597,t:1526919300412};\\\", \\\"{x:437,y:595,t:1526919300428};\\\", \\\"{x:449,y:594,t:1526919300444};\\\", \\\"{x:462,y:592,t:1526919300462};\\\", \\\"{x:472,y:591,t:1526919300477};\\\", \\\"{x:479,y:590,t:1526919300494};\\\", \\\"{x:483,y:590,t:1526919300511};\\\", \\\"{x:483,y:589,t:1526919300592};\\\", \\\"{x:483,y:587,t:1526919300599};\\\", \\\"{x:480,y:586,t:1526919300611};\\\", \\\"{x:473,y:585,t:1526919300627};\\\", \\\"{x:463,y:584,t:1526919300644};\\\", \\\"{x:455,y:584,t:1526919300661};\\\", \\\"{x:448,y:585,t:1526919300677};\\\", \\\"{x:441,y:589,t:1526919300694};\\\", \\\"{x:434,y:593,t:1526919300711};\\\", \\\"{x:428,y:596,t:1526919300728};\\\", \\\"{x:423,y:599,t:1526919300744};\\\", \\\"{x:418,y:603,t:1526919300762};\\\", \\\"{x:413,y:607,t:1526919300779};\\\", \\\"{x:409,y:609,t:1526919300794};\\\", \\\"{x:407,y:609,t:1526919300811};\\\", \\\"{x:406,y:609,t:1526919300828};\\\", \\\"{x:403,y:611,t:1526919300845};\\\", \\\"{x:402,y:611,t:1526919300861};\\\", \\\"{x:399,y:611,t:1526919300878};\\\", \\\"{x:396,y:611,t:1526919300894};\\\", \\\"{x:395,y:611,t:1526919300911};\\\", \\\"{x:394,y:611,t:1526919301304};\\\", \\\"{x:394,y:611,t:1526919301363};\\\", \\\"{x:395,y:611,t:1526919302751};\\\", \\\"{x:398,y:611,t:1526919302762};\\\", \\\"{x:403,y:611,t:1526919302779};\\\", \\\"{x:409,y:610,t:1526919302796};\\\", \\\"{x:415,y:607,t:1526919302812};\\\", \\\"{x:420,y:606,t:1526919302830};\\\", \\\"{x:423,y:605,t:1526919302846};\\\", \\\"{x:427,y:603,t:1526919302862};\\\", \\\"{x:434,y:602,t:1526919302879};\\\", \\\"{x:455,y:598,t:1526919302896};\\\", \\\"{x:469,y:594,t:1526919302913};\\\", \\\"{x:486,y:592,t:1526919302930};\\\", \\\"{x:499,y:588,t:1526919302947};\\\", \\\"{x:513,y:583,t:1526919302963};\\\", \\\"{x:534,y:572,t:1526919302979};\\\", \\\"{x:561,y:562,t:1526919302997};\\\", \\\"{x:581,y:556,t:1526919303013};\\\", \\\"{x:592,y:555,t:1526919303029};\\\", \\\"{x:594,y:554,t:1526919303046};\\\", \\\"{x:597,y:554,t:1526919303087};\\\", \\\"{x:601,y:560,t:1526919303096};\\\", \\\"{x:607,y:572,t:1526919303114};\\\", \\\"{x:613,y:586,t:1526919303130};\\\", \\\"{x:618,y:600,t:1526919303147};\\\", \\\"{x:619,y:605,t:1526919303163};\\\", \\\"{x:619,y:609,t:1526919303179};\\\", \\\"{x:619,y:612,t:1526919303196};\\\", \\\"{x:619,y:613,t:1526919303232};\\\", \\\"{x:619,y:615,t:1526919303263};\\\", \\\"{x:617,y:617,t:1526919306727};\\\", \\\"{x:613,y:621,t:1526919306736};\\\", \\\"{x:608,y:625,t:1526919306750};\\\", \\\"{x:603,y:628,t:1526919306767};\\\", \\\"{x:601,y:629,t:1526919306783};\\\", \\\"{x:600,y:630,t:1526919306799};\\\", \\\"{x:599,y:631,t:1526919306817};\\\", \\\"{x:598,y:632,t:1526919306840};\\\", \\\"{x:597,y:632,t:1526919306849};\\\", \\\"{x:596,y:633,t:1526919306871};\\\", \\\"{x:595,y:634,t:1526919306943};\\\", \\\"{x:595,y:635,t:1526919306952};\\\", \\\"{x:594,y:635,t:1526919307007};\\\", \\\"{x:592,y:636,t:1526919307056};\\\", \\\"{x:591,y:637,t:1526919307066};\\\", \\\"{x:591,y:638,t:1526919307088};\\\", \\\"{x:590,y:638,t:1526919307112};\\\", \\\"{x:590,y:639,t:1526919307128};\\\", \\\"{x:589,y:639,t:1526919307151};\\\", \\\"{x:588,y:640,t:1526919307166};\\\", \\\"{x:588,y:641,t:1526919307208};\\\", \\\"{x:587,y:642,t:1526919307231};\\\", \\\"{x:587,y:643,t:1526919307255};\\\", \\\"{x:586,y:644,t:1526919307279};\\\", \\\"{x:585,y:644,t:1526919307319};\\\", \\\"{x:585,y:645,t:1526919307375};\\\", \\\"{x:585,y:646,t:1526919307455};\\\", \\\"{x:584,y:646,t:1526919307479};\\\", \\\"{x:584,y:647,t:1526919307712};\\\", \\\"{x:583,y:647,t:1526919307728};\\\", \\\"{x:583,y:648,t:1526919307744};\\\", \\\"{x:583,y:649,t:1526919307856};\\\", \\\"{x:581,y:650,t:1526919307968};\\\", \\\"{x:581,y:652,t:1526919308023};\\\", \\\"{x:580,y:653,t:1526919308039};\\\", \\\"{x:579,y:653,t:1526919308079};\\\", \\\"{x:579,y:655,t:1526919308095};\\\", \\\"{x:579,y:656,t:1526919308103};\\\", \\\"{x:579,y:657,t:1526919308117};\\\", \\\"{x:578,y:659,t:1526919308133};\\\", \\\"{x:578,y:662,t:1526919308150};\\\", \\\"{x:578,y:666,t:1526919308168};\\\", \\\"{x:578,y:669,t:1526919308184};\\\", \\\"{x:578,y:672,t:1526919308200};\\\", \\\"{x:578,y:676,t:1526919308217};\\\", \\\"{x:579,y:680,t:1526919308235};\\\", \\\"{x:579,y:683,t:1526919308251};\\\", \\\"{x:580,y:688,t:1526919308267};\\\", \\\"{x:581,y:693,t:1526919308284};\\\", \\\"{x:581,y:698,t:1526919308300};\\\", \\\"{x:582,y:702,t:1526919308318};\\\", \\\"{x:582,y:709,t:1526919308334};\\\", \\\"{x:582,y:715,t:1526919308350};\\\", \\\"{x:583,y:720,t:1526919308368};\\\", \\\"{x:584,y:721,t:1526919308384};\\\", \\\"{x:584,y:722,t:1526919308400};\\\", \\\"{x:584,y:723,t:1526919308418};\\\", \\\"{x:585,y:724,t:1526919308448};\\\", \\\"{x:586,y:724,t:1526919308456};\\\", \\\"{x:584,y:725,t:1526919308655};\\\", \\\"{x:582,y:725,t:1526919308672};\\\", \\\"{x:580,y:725,t:1526919308684};\\\", \\\"{x:576,y:727,t:1526919308702};\\\", \\\"{x:573,y:727,t:1526919308717};\\\", \\\"{x:569,y:728,t:1526919308734};\\\", \\\"{x:561,y:731,t:1526919308752};\\\", \\\"{x:557,y:731,t:1526919308768};\\\", \\\"{x:553,y:731,t:1526919308785};\\\", \\\"{x:551,y:732,t:1526919308802};\\\", \\\"{x:548,y:732,t:1526919308818};\\\", \\\"{x:546,y:733,t:1526919308834};\\\", \\\"{x:546,y:734,t:1526919308852};\\\", \\\"{x:545,y:734,t:1526919308867};\\\" ] }, { \\\"rt\\\": 12378, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 563303, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-01 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:734,t:1526919311543};\\\", \\\"{x:557,y:734,t:1526919311554};\\\", \\\"{x:583,y:734,t:1526919311570};\\\", \\\"{x:615,y:737,t:1526919311586};\\\", \\\"{x:650,y:747,t:1526919311604};\\\", \\\"{x:700,y:762,t:1526919311619};\\\", \\\"{x:749,y:772,t:1526919311637};\\\", \\\"{x:796,y:785,t:1526919311654};\\\", \\\"{x:830,y:795,t:1526919311671};\\\", \\\"{x:856,y:803,t:1526919311687};\\\", \\\"{x:893,y:816,t:1526919311703};\\\", \\\"{x:915,y:822,t:1526919311720};\\\", \\\"{x:936,y:831,t:1526919311737};\\\", \\\"{x:947,y:837,t:1526919311753};\\\", \\\"{x:968,y:843,t:1526919311771};\\\", \\\"{x:991,y:851,t:1526919311786};\\\", \\\"{x:1009,y:860,t:1526919311804};\\\", \\\"{x:1030,y:866,t:1526919311821};\\\", \\\"{x:1049,y:872,t:1526919311836};\\\", \\\"{x:1063,y:878,t:1526919311853};\\\", \\\"{x:1083,y:886,t:1526919311871};\\\", \\\"{x:1107,y:893,t:1526919311886};\\\", \\\"{x:1146,y:905,t:1526919311903};\\\", \\\"{x:1174,y:915,t:1526919311921};\\\", \\\"{x:1200,y:925,t:1526919311936};\\\", \\\"{x:1223,y:930,t:1526919311954};\\\", \\\"{x:1246,y:939,t:1526919311971};\\\", \\\"{x:1268,y:945,t:1526919311986};\\\", \\\"{x:1289,y:952,t:1526919312003};\\\", \\\"{x:1305,y:957,t:1526919312020};\\\", \\\"{x:1321,y:962,t:1526919312036};\\\", \\\"{x:1334,y:966,t:1526919312054};\\\", \\\"{x:1351,y:971,t:1526919312070};\\\", \\\"{x:1370,y:976,t:1526919312088};\\\", \\\"{x:1384,y:978,t:1526919312103};\\\", \\\"{x:1398,y:981,t:1526919312121};\\\", \\\"{x:1414,y:984,t:1526919312138};\\\", \\\"{x:1428,y:988,t:1526919312154};\\\", \\\"{x:1441,y:991,t:1526919312170};\\\", \\\"{x:1457,y:993,t:1526919312187};\\\", \\\"{x:1469,y:994,t:1526919312203};\\\", \\\"{x:1480,y:994,t:1526919312221};\\\", \\\"{x:1489,y:994,t:1526919312238};\\\", \\\"{x:1500,y:995,t:1526919312253};\\\", \\\"{x:1512,y:996,t:1526919312270};\\\", \\\"{x:1535,y:996,t:1526919312287};\\\", \\\"{x:1543,y:996,t:1526919312304};\\\", \\\"{x:1548,y:996,t:1526919312321};\\\", \\\"{x:1550,y:996,t:1526919312338};\\\", \\\"{x:1554,y:996,t:1526919312354};\\\", \\\"{x:1558,y:994,t:1526919312370};\\\", \\\"{x:1566,y:992,t:1526919312388};\\\", \\\"{x:1573,y:990,t:1526919312403};\\\", \\\"{x:1580,y:987,t:1526919312421};\\\", \\\"{x:1584,y:984,t:1526919312438};\\\", \\\"{x:1585,y:983,t:1526919312454};\\\", \\\"{x:1587,y:982,t:1526919312472};\\\", \\\"{x:1589,y:980,t:1526919312487};\\\", \\\"{x:1591,y:976,t:1526919312504};\\\", \\\"{x:1591,y:973,t:1526919312520};\\\", \\\"{x:1592,y:970,t:1526919312537};\\\", \\\"{x:1593,y:965,t:1526919312555};\\\", \\\"{x:1595,y:959,t:1526919312570};\\\", \\\"{x:1595,y:954,t:1526919312587};\\\", \\\"{x:1595,y:950,t:1526919312604};\\\", \\\"{x:1595,y:947,t:1526919312621};\\\", \\\"{x:1595,y:942,t:1526919312638};\\\", \\\"{x:1595,y:938,t:1526919312655};\\\", \\\"{x:1592,y:932,t:1526919312670};\\\", \\\"{x:1589,y:927,t:1526919312688};\\\", \\\"{x:1587,y:923,t:1526919312704};\\\", \\\"{x:1587,y:921,t:1526919312721};\\\", \\\"{x:1586,y:918,t:1526919312738};\\\", \\\"{x:1586,y:916,t:1526919312755};\\\", \\\"{x:1584,y:915,t:1526919312771};\\\", \\\"{x:1584,y:914,t:1526919312787};\\\", \\\"{x:1582,y:911,t:1526919312804};\\\", \\\"{x:1581,y:909,t:1526919312820};\\\", \\\"{x:1580,y:907,t:1526919312838};\\\", \\\"{x:1578,y:904,t:1526919312854};\\\", \\\"{x:1577,y:904,t:1526919312871};\\\", \\\"{x:1576,y:903,t:1526919312887};\\\", \\\"{x:1575,y:902,t:1526919312905};\\\", \\\"{x:1574,y:901,t:1526919312936};\\\", \\\"{x:1574,y:900,t:1526919312959};\\\", \\\"{x:1573,y:900,t:1526919312971};\\\", \\\"{x:1572,y:899,t:1526919312987};\\\", \\\"{x:1571,y:899,t:1526919313048};\\\", \\\"{x:1571,y:898,t:1526919313080};\\\", \\\"{x:1569,y:898,t:1526919313183};\\\", \\\"{x:1567,y:898,t:1526919313199};\\\", \\\"{x:1564,y:898,t:1526919313207};\\\", \\\"{x:1562,y:899,t:1526919313222};\\\", \\\"{x:1553,y:903,t:1526919313238};\\\", \\\"{x:1546,y:906,t:1526919313254};\\\", \\\"{x:1538,y:910,t:1526919313271};\\\", \\\"{x:1535,y:912,t:1526919313287};\\\", \\\"{x:1532,y:914,t:1526919313304};\\\", \\\"{x:1529,y:916,t:1526919313322};\\\", \\\"{x:1526,y:918,t:1526919313338};\\\", \\\"{x:1524,y:922,t:1526919313355};\\\", \\\"{x:1520,y:925,t:1526919313372};\\\", \\\"{x:1515,y:929,t:1526919313387};\\\", \\\"{x:1513,y:930,t:1526919313405};\\\", \\\"{x:1510,y:933,t:1526919313422};\\\", \\\"{x:1509,y:934,t:1526919313439};\\\", \\\"{x:1506,y:937,t:1526919313455};\\\", \\\"{x:1498,y:944,t:1526919313471};\\\", \\\"{x:1491,y:949,t:1526919313488};\\\", \\\"{x:1484,y:952,t:1526919313505};\\\", \\\"{x:1481,y:954,t:1526919313521};\\\", \\\"{x:1479,y:955,t:1526919313539};\\\", \\\"{x:1479,y:956,t:1526919313555};\\\", \\\"{x:1478,y:956,t:1526919313600};\\\", \\\"{x:1478,y:957,t:1526919313711};\\\", \\\"{x:1478,y:959,t:1526919313722};\\\", \\\"{x:1484,y:961,t:1526919313739};\\\", \\\"{x:1486,y:963,t:1526919313755};\\\", \\\"{x:1490,y:964,t:1526919313772};\\\", \\\"{x:1494,y:965,t:1526919313788};\\\", \\\"{x:1502,y:967,t:1526919313804};\\\", \\\"{x:1514,y:969,t:1526919313822};\\\", \\\"{x:1527,y:971,t:1526919313839};\\\", \\\"{x:1534,y:971,t:1526919313855};\\\", \\\"{x:1535,y:971,t:1526919313887};\\\", \\\"{x:1536,y:971,t:1526919313911};\\\", \\\"{x:1537,y:969,t:1526919313927};\\\", \\\"{x:1538,y:968,t:1526919313943};\\\", \\\"{x:1538,y:967,t:1526919313959};\\\", \\\"{x:1538,y:966,t:1526919313975};\\\", \\\"{x:1538,y:965,t:1526919314023};\\\", \\\"{x:1538,y:964,t:1526919314223};\\\", \\\"{x:1538,y:962,t:1526919314239};\\\", \\\"{x:1538,y:958,t:1526919314255};\\\", \\\"{x:1537,y:955,t:1526919314272};\\\", \\\"{x:1537,y:951,t:1526919314289};\\\", \\\"{x:1536,y:948,t:1526919314306};\\\", \\\"{x:1534,y:945,t:1526919314323};\\\", \\\"{x:1534,y:943,t:1526919314338};\\\", \\\"{x:1534,y:941,t:1526919314356};\\\", \\\"{x:1534,y:938,t:1526919314373};\\\", \\\"{x:1534,y:935,t:1526919314389};\\\", \\\"{x:1533,y:933,t:1526919314405};\\\", \\\"{x:1533,y:929,t:1526919314423};\\\", \\\"{x:1534,y:927,t:1526919314439};\\\", \\\"{x:1534,y:923,t:1526919314455};\\\", \\\"{x:1535,y:918,t:1526919314473};\\\", \\\"{x:1535,y:914,t:1526919314488};\\\", \\\"{x:1536,y:908,t:1526919314505};\\\", \\\"{x:1537,y:902,t:1526919314522};\\\", \\\"{x:1537,y:897,t:1526919314538};\\\", \\\"{x:1538,y:895,t:1526919314556};\\\", \\\"{x:1539,y:890,t:1526919314573};\\\", \\\"{x:1541,y:883,t:1526919314589};\\\", \\\"{x:1541,y:879,t:1526919314606};\\\", \\\"{x:1541,y:875,t:1526919314623};\\\", \\\"{x:1542,y:869,t:1526919314639};\\\", \\\"{x:1542,y:863,t:1526919314656};\\\", \\\"{x:1542,y:859,t:1526919314673};\\\", \\\"{x:1542,y:854,t:1526919314688};\\\", \\\"{x:1542,y:848,t:1526919314705};\\\", \\\"{x:1542,y:842,t:1526919314722};\\\", \\\"{x:1542,y:835,t:1526919314740};\\\", \\\"{x:1540,y:831,t:1526919314756};\\\", \\\"{x:1539,y:827,t:1526919314772};\\\", \\\"{x:1538,y:823,t:1526919314790};\\\", \\\"{x:1538,y:818,t:1526919314805};\\\", \\\"{x:1538,y:814,t:1526919314822};\\\", \\\"{x:1538,y:809,t:1526919314840};\\\", \\\"{x:1538,y:805,t:1526919314856};\\\", \\\"{x:1538,y:803,t:1526919314873};\\\", \\\"{x:1538,y:800,t:1526919314890};\\\", \\\"{x:1538,y:797,t:1526919314906};\\\", \\\"{x:1538,y:796,t:1526919314923};\\\", \\\"{x:1538,y:793,t:1526919314939};\\\", \\\"{x:1538,y:791,t:1526919314956};\\\", \\\"{x:1538,y:789,t:1526919314973};\\\", \\\"{x:1538,y:787,t:1526919314990};\\\", \\\"{x:1538,y:786,t:1526919315006};\\\", \\\"{x:1538,y:784,t:1526919315023};\\\", \\\"{x:1538,y:783,t:1526919315039};\\\", \\\"{x:1538,y:782,t:1526919315063};\\\", \\\"{x:1538,y:781,t:1526919315073};\\\", \\\"{x:1538,y:780,t:1526919315096};\\\", \\\"{x:1538,y:779,t:1526919315111};\\\", \\\"{x:1539,y:777,t:1526919315136};\\\", \\\"{x:1539,y:776,t:1526919315191};\\\", \\\"{x:1539,y:775,t:1526919315207};\\\", \\\"{x:1539,y:774,t:1526919315223};\\\", \\\"{x:1541,y:773,t:1526919315240};\\\", \\\"{x:1541,y:772,t:1526919315257};\\\", \\\"{x:1541,y:771,t:1526919315273};\\\", \\\"{x:1542,y:769,t:1526919315289};\\\", \\\"{x:1542,y:768,t:1526919315307};\\\", \\\"{x:1542,y:766,t:1526919315323};\\\", \\\"{x:1543,y:764,t:1526919315339};\\\", \\\"{x:1543,y:761,t:1526919315357};\\\", \\\"{x:1543,y:759,t:1526919315372};\\\", \\\"{x:1543,y:756,t:1526919315390};\\\", \\\"{x:1543,y:754,t:1526919315406};\\\", \\\"{x:1543,y:753,t:1526919315423};\\\", \\\"{x:1543,y:750,t:1526919315439};\\\", \\\"{x:1543,y:746,t:1526919315457};\\\", \\\"{x:1543,y:743,t:1526919315472};\\\", \\\"{x:1543,y:741,t:1526919315489};\\\", \\\"{x:1543,y:740,t:1526919315506};\\\", \\\"{x:1543,y:739,t:1526919315523};\\\", \\\"{x:1543,y:736,t:1526919315540};\\\", \\\"{x:1543,y:733,t:1526919315557};\\\", \\\"{x:1543,y:729,t:1526919315572};\\\", \\\"{x:1543,y:727,t:1526919315590};\\\", \\\"{x:1543,y:723,t:1526919315607};\\\", \\\"{x:1543,y:721,t:1526919315623};\\\", \\\"{x:1543,y:719,t:1526919315640};\\\", \\\"{x:1543,y:715,t:1526919315657};\\\", \\\"{x:1543,y:712,t:1526919315674};\\\", \\\"{x:1543,y:708,t:1526919315690};\\\", \\\"{x:1543,y:704,t:1526919315707};\\\", \\\"{x:1543,y:701,t:1526919315724};\\\", \\\"{x:1543,y:698,t:1526919315740};\\\", \\\"{x:1543,y:696,t:1526919315757};\\\", \\\"{x:1542,y:694,t:1526919315773};\\\", \\\"{x:1541,y:692,t:1526919315790};\\\", \\\"{x:1540,y:688,t:1526919315807};\\\", \\\"{x:1539,y:686,t:1526919315823};\\\", \\\"{x:1537,y:684,t:1526919315840};\\\", \\\"{x:1537,y:685,t:1526919316168};\\\", \\\"{x:1536,y:687,t:1526919316183};\\\", \\\"{x:1536,y:688,t:1526919316191};\\\", \\\"{x:1536,y:689,t:1526919316207};\\\", \\\"{x:1535,y:691,t:1526919316223};\\\", \\\"{x:1535,y:694,t:1526919316263};\\\", \\\"{x:1535,y:695,t:1526919316288};\\\", \\\"{x:1535,y:697,t:1526919316295};\\\", \\\"{x:1535,y:698,t:1526919316312};\\\", \\\"{x:1535,y:699,t:1526919316327};\\\", \\\"{x:1535,y:700,t:1526919316341};\\\", \\\"{x:1536,y:700,t:1526919316357};\\\", \\\"{x:1536,y:701,t:1526919316374};\\\", \\\"{x:1536,y:702,t:1526919316391};\\\", \\\"{x:1536,y:704,t:1526919316407};\\\", \\\"{x:1537,y:707,t:1526919316424};\\\", \\\"{x:1537,y:709,t:1526919316440};\\\", \\\"{x:1537,y:710,t:1526919316457};\\\", \\\"{x:1538,y:712,t:1526919316474};\\\", \\\"{x:1538,y:713,t:1526919316491};\\\", \\\"{x:1538,y:715,t:1526919316507};\\\", \\\"{x:1539,y:718,t:1526919316524};\\\", \\\"{x:1539,y:719,t:1526919316541};\\\", \\\"{x:1539,y:722,t:1526919316558};\\\", \\\"{x:1539,y:723,t:1526919316574};\\\", \\\"{x:1540,y:726,t:1526919316591};\\\", \\\"{x:1541,y:729,t:1526919316608};\\\", \\\"{x:1541,y:734,t:1526919316624};\\\", \\\"{x:1541,y:738,t:1526919316640};\\\", \\\"{x:1542,y:742,t:1526919316658};\\\", \\\"{x:1543,y:748,t:1526919316674};\\\", \\\"{x:1544,y:753,t:1526919316690};\\\", \\\"{x:1544,y:757,t:1526919316708};\\\", \\\"{x:1544,y:760,t:1526919316724};\\\", \\\"{x:1544,y:761,t:1526919316741};\\\", \\\"{x:1544,y:763,t:1526919316758};\\\", \\\"{x:1545,y:764,t:1526919316773};\\\", \\\"{x:1545,y:765,t:1526919316791};\\\", \\\"{x:1545,y:766,t:1526919316856};\\\", \\\"{x:1545,y:767,t:1526919316871};\\\", \\\"{x:1545,y:768,t:1526919316895};\\\", \\\"{x:1545,y:769,t:1526919316919};\\\", \\\"{x:1545,y:770,t:1526919316927};\\\", \\\"{x:1545,y:771,t:1526919316967};\\\", \\\"{x:1545,y:772,t:1526919316975};\\\", \\\"{x:1545,y:773,t:1526919317023};\\\", \\\"{x:1542,y:774,t:1526919317479};\\\", \\\"{x:1541,y:775,t:1526919317492};\\\", \\\"{x:1540,y:775,t:1526919317519};\\\", \\\"{x:1538,y:777,t:1526919317696};\\\", \\\"{x:1538,y:778,t:1526919317708};\\\", \\\"{x:1538,y:783,t:1526919317725};\\\", \\\"{x:1538,y:788,t:1526919317742};\\\", \\\"{x:1538,y:791,t:1526919317759};\\\", \\\"{x:1538,y:796,t:1526919317774};\\\", \\\"{x:1538,y:801,t:1526919317792};\\\", \\\"{x:1538,y:807,t:1526919317809};\\\", \\\"{x:1540,y:814,t:1526919317825};\\\", \\\"{x:1542,y:822,t:1526919317841};\\\", \\\"{x:1542,y:827,t:1526919317859};\\\", \\\"{x:1544,y:835,t:1526919317875};\\\", \\\"{x:1547,y:845,t:1526919317891};\\\", \\\"{x:1548,y:854,t:1526919317909};\\\", \\\"{x:1549,y:864,t:1526919317925};\\\", \\\"{x:1552,y:877,t:1526919317942};\\\", \\\"{x:1553,y:887,t:1526919317959};\\\", \\\"{x:1553,y:898,t:1526919317975};\\\", \\\"{x:1556,y:908,t:1526919317991};\\\", \\\"{x:1556,y:913,t:1526919318009};\\\", \\\"{x:1556,y:916,t:1526919318025};\\\", \\\"{x:1556,y:918,t:1526919318042};\\\", \\\"{x:1556,y:921,t:1526919318059};\\\", \\\"{x:1556,y:923,t:1526919318075};\\\", \\\"{x:1556,y:925,t:1526919318092};\\\", \\\"{x:1556,y:926,t:1526919318109};\\\", \\\"{x:1556,y:927,t:1526919318124};\\\", \\\"{x:1556,y:928,t:1526919318142};\\\", \\\"{x:1556,y:923,t:1526919318279};\\\", \\\"{x:1554,y:913,t:1526919318292};\\\", \\\"{x:1549,y:892,t:1526919318309};\\\", \\\"{x:1538,y:868,t:1526919318326};\\\", \\\"{x:1527,y:851,t:1526919318341};\\\", \\\"{x:1521,y:835,t:1526919318359};\\\", \\\"{x:1513,y:816,t:1526919318375};\\\", \\\"{x:1510,y:807,t:1526919318392};\\\", \\\"{x:1507,y:799,t:1526919318408};\\\", \\\"{x:1505,y:790,t:1526919318425};\\\", \\\"{x:1504,y:785,t:1526919318441};\\\", \\\"{x:1502,y:781,t:1526919318459};\\\", \\\"{x:1502,y:780,t:1526919318476};\\\", \\\"{x:1502,y:779,t:1526919318492};\\\", \\\"{x:1501,y:778,t:1526919318509};\\\", \\\"{x:1500,y:776,t:1526919318599};\\\", \\\"{x:1498,y:776,t:1526919318609};\\\", \\\"{x:1479,y:770,t:1526919318625};\\\", \\\"{x:1449,y:767,t:1526919318643};\\\", \\\"{x:1388,y:758,t:1526919318658};\\\", \\\"{x:1326,y:747,t:1526919318675};\\\", \\\"{x:1259,y:738,t:1526919318693};\\\", \\\"{x:1208,y:735,t:1526919318709};\\\", \\\"{x:1187,y:729,t:1526919318726};\\\", \\\"{x:1162,y:728,t:1526919318743};\\\", \\\"{x:1137,y:724,t:1526919318759};\\\", \\\"{x:1109,y:721,t:1526919318776};\\\", \\\"{x:1096,y:720,t:1526919318793};\\\", \\\"{x:1075,y:719,t:1526919318809};\\\", \\\"{x:1053,y:718,t:1526919318826};\\\", \\\"{x:1034,y:718,t:1526919318843};\\\", \\\"{x:1004,y:718,t:1526919318859};\\\", \\\"{x:976,y:718,t:1526919318876};\\\", \\\"{x:947,y:718,t:1526919318893};\\\", \\\"{x:927,y:718,t:1526919318909};\\\", \\\"{x:904,y:718,t:1526919318926};\\\", \\\"{x:892,y:718,t:1526919318942};\\\", \\\"{x:876,y:718,t:1526919318959};\\\", \\\"{x:841,y:718,t:1526919318975};\\\", \\\"{x:815,y:718,t:1526919318993};\\\", \\\"{x:782,y:718,t:1526919319009};\\\", \\\"{x:743,y:713,t:1526919319026};\\\", \\\"{x:711,y:713,t:1526919319043};\\\", \\\"{x:684,y:713,t:1526919319059};\\\", \\\"{x:665,y:713,t:1526919319076};\\\", \\\"{x:656,y:713,t:1526919319092};\\\", \\\"{x:655,y:713,t:1526919319110};\\\", \\\"{x:650,y:713,t:1526919319408};\\\", \\\"{x:644,y:713,t:1526919319415};\\\", \\\"{x:638,y:712,t:1526919319426};\\\", \\\"{x:623,y:708,t:1526919319443};\\\", \\\"{x:612,y:708,t:1526919319460};\\\", \\\"{x:609,y:707,t:1526919319476};\\\", \\\"{x:608,y:706,t:1526919319493};\\\", \\\"{x:607,y:705,t:1526919319560};\\\", \\\"{x:605,y:705,t:1526919319576};\\\", \\\"{x:602,y:705,t:1526919319593};\\\", \\\"{x:600,y:704,t:1526919319610};\\\", \\\"{x:598,y:703,t:1526919319627};\\\", \\\"{x:596,y:701,t:1526919320727};\\\", \\\"{x:591,y:697,t:1526919320744};\\\", \\\"{x:586,y:691,t:1526919320761};\\\", \\\"{x:577,y:684,t:1526919320777};\\\", \\\"{x:570,y:678,t:1526919320794};\\\", \\\"{x:564,y:670,t:1526919320811};\\\", \\\"{x:556,y:660,t:1526919320827};\\\", \\\"{x:542,y:653,t:1526919320844};\\\", \\\"{x:527,y:642,t:1526919320861};\\\", \\\"{x:519,y:633,t:1526919320878};\\\", \\\"{x:511,y:628,t:1526919320895};\\\", \\\"{x:503,y:623,t:1526919320911};\\\", \\\"{x:492,y:616,t:1526919320928};\\\", \\\"{x:485,y:615,t:1526919320944};\\\", \\\"{x:477,y:611,t:1526919320961};\\\", \\\"{x:468,y:607,t:1526919320977};\\\", \\\"{x:455,y:603,t:1526919320993};\\\", \\\"{x:450,y:602,t:1526919321011};\\\", \\\"{x:448,y:600,t:1526919321028};\\\", \\\"{x:446,y:599,t:1526919321044};\\\", \\\"{x:452,y:599,t:1526919321191};\\\", \\\"{x:465,y:598,t:1526919321199};\\\", \\\"{x:484,y:598,t:1526919321211};\\\", \\\"{x:534,y:598,t:1526919321228};\\\", \\\"{x:598,y:598,t:1526919321245};\\\", \\\"{x:662,y:598,t:1526919321261};\\\", \\\"{x:699,y:593,t:1526919321278};\\\", \\\"{x:720,y:588,t:1526919321295};\\\", \\\"{x:721,y:587,t:1526919321311};\\\", \\\"{x:724,y:584,t:1526919321329};\\\", \\\"{x:728,y:579,t:1526919321345};\\\", \\\"{x:734,y:572,t:1526919321362};\\\", \\\"{x:746,y:564,t:1526919321378};\\\", \\\"{x:752,y:561,t:1526919321396};\\\", \\\"{x:756,y:558,t:1526919321413};\\\", \\\"{x:760,y:557,t:1526919321428};\\\", \\\"{x:764,y:557,t:1526919321445};\\\", \\\"{x:767,y:556,t:1526919321462};\\\", \\\"{x:772,y:556,t:1526919321478};\\\", \\\"{x:795,y:563,t:1526919321496};\\\", \\\"{x:810,y:566,t:1526919321512};\\\", \\\"{x:822,y:570,t:1526919321528};\\\", \\\"{x:829,y:573,t:1526919321546};\\\", \\\"{x:831,y:574,t:1526919321562};\\\", \\\"{x:835,y:576,t:1526919321578};\\\", \\\"{x:837,y:578,t:1526919321595};\\\", \\\"{x:841,y:581,t:1526919321612};\\\", \\\"{x:843,y:584,t:1526919321628};\\\", \\\"{x:841,y:588,t:1526919322095};\\\", \\\"{x:811,y:600,t:1526919322112};\\\", \\\"{x:766,y:614,t:1526919322130};\\\", \\\"{x:718,y:629,t:1526919322145};\\\", \\\"{x:688,y:641,t:1526919322163};\\\", \\\"{x:665,y:652,t:1526919322179};\\\", \\\"{x:650,y:658,t:1526919322196};\\\", \\\"{x:640,y:665,t:1526919322212};\\\", \\\"{x:631,y:674,t:1526919322229};\\\", \\\"{x:625,y:681,t:1526919322246};\\\", \\\"{x:616,y:688,t:1526919322262};\\\", \\\"{x:599,y:697,t:1526919322279};\\\", \\\"{x:592,y:701,t:1526919322296};\\\", \\\"{x:591,y:702,t:1526919322312};\\\", \\\"{x:590,y:702,t:1526919322431};\\\", \\\"{x:585,y:702,t:1526919322446};\\\", \\\"{x:576,y:707,t:1526919322462};\\\", \\\"{x:558,y:716,t:1526919322479};\\\", \\\"{x:548,y:719,t:1526919322496};\\\", \\\"{x:539,y:720,t:1526919322513};\\\", \\\"{x:536,y:721,t:1526919322529};\\\" ] }, { \\\"rt\\\": 18845, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 583464, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": null, \\\"axis\\\": null, \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:720,t:1526919340439};\\\", \\\"{x:519,y:713,t:1526919340447};\\\", \\\"{x:506,y:706,t:1526919340460};\\\", \\\"{x:470,y:684,t:1526919340477};\\\", \\\"{x:436,y:667,t:1526919340494};\\\", \\\"{x:415,y:650,t:1526919340512};\\\", \\\"{x:415,y:649,t:1526919340527};\\\", \\\"{x:415,y:648,t:1526919340647};\\\", \\\"{x:416,y:647,t:1526919340663};\\\", \\\"{x:416,y:646,t:1526919340679};\\\", \\\"{x:416,y:645,t:1526919340691};\\\", \\\"{x:419,y:641,t:1526919340706};\\\", \\\"{x:419,y:633,t:1526919340728};\\\", \\\"{x:419,y:628,t:1526919340744};\\\", \\\"{x:419,y:624,t:1526919340761};\\\", \\\"{x:415,y:616,t:1526919340778};\\\", \\\"{x:413,y:613,t:1526919340795};\\\", \\\"{x:412,y:612,t:1526919340811};\\\", \\\"{x:411,y:612,t:1526919341039};\\\", \\\"{x:410,y:610,t:1526919341047};\\\", \\\"{x:409,y:609,t:1526919341061};\\\", \\\"{x:407,y:607,t:1526919341078};\\\", \\\"{x:403,y:602,t:1526919341096};\\\", \\\"{x:403,y:600,t:1526919341111};\\\", \\\"{x:402,y:599,t:1526919341143};\\\", \\\"{x:403,y:600,t:1526919341559};\\\", \\\"{x:405,y:607,t:1526919341568};\\\", \\\"{x:407,y:613,t:1526919341580};\\\", \\\"{x:415,y:624,t:1526919341595};\\\", \\\"{x:420,y:631,t:1526919341612};\\\", \\\"{x:424,y:636,t:1526919341629};\\\", \\\"{x:427,y:643,t:1526919341645};\\\", \\\"{x:431,y:648,t:1526919341662};\\\", \\\"{x:440,y:659,t:1526919341679};\\\", \\\"{x:446,y:667,t:1526919341695};\\\", \\\"{x:456,y:681,t:1526919341712};\\\", \\\"{x:464,y:691,t:1526919341729};\\\", \\\"{x:472,y:698,t:1526919341745};\\\", \\\"{x:477,y:705,t:1526919341763};\\\", \\\"{x:481,y:710,t:1526919341779};\\\", \\\"{x:485,y:716,t:1526919341795};\\\", \\\"{x:491,y:723,t:1526919341812};\\\", \\\"{x:499,y:731,t:1526919341828};\\\", \\\"{x:506,y:739,t:1526919341845};\\\", \\\"{x:510,y:746,t:1526919341862};\\\", \\\"{x:517,y:750,t:1526919341879};\\\", \\\"{x:519,y:752,t:1526919341895};\\\", \\\"{x:521,y:754,t:1526919341912};\\\", \\\"{x:522,y:755,t:1526919341929};\\\", \\\"{x:523,y:758,t:1526919341945};\\\", \\\"{x:524,y:759,t:1526919341962};\\\", \\\"{x:525,y:760,t:1526919341979};\\\", \\\"{x:526,y:762,t:1526919341995};\\\", \\\"{x:528,y:764,t:1526919342012};\\\", \\\"{x:530,y:766,t:1526919342029};\\\", \\\"{x:532,y:768,t:1526919342046};\\\", \\\"{x:533,y:769,t:1526919342063};\\\", \\\"{x:534,y:770,t:1526919342079};\\\", \\\"{x:534,y:769,t:1526919342575};\\\", \\\"{x:534,y:768,t:1526919342584};\\\", \\\"{x:534,y:767,t:1526919342596};\\\", \\\"{x:533,y:765,t:1526919342613};\\\", \\\"{x:533,y:764,t:1526919342639};\\\" ] }, { \\\"rt\\\": 49446, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 634098, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"B and F shifts end\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 11154, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"mexico\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 646258, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\" }, { \\\"rt\\\": 12039, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 659308, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\" }, { \\\"rt\\\": 55149, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 715780, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"9D6O3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"alpha\\\", \\\"condition\\\": \\\"3\\\" } ]\",\"parentNode\":{\"id\":2658}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"9D6O3\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2410,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2415,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2416,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2417,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2418,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2424,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2426,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2428,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2430,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2432,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2436,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2437,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2438,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2444,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2445,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2446,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2448,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2449,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2450,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2452,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2456,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2457,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2458,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2467,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2468,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2469,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2470,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2471,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2472,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2475,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2476,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2478,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2480,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2481,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2482,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2483},{\"nodeType\":3,\"id\":2484,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2485,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2486,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2487,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2488,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 139, dom: 888, initialDom: 1045",
  "javascriptErrors": []
}