var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dcf2947d4ce5ccb72d27c7ea69ade48f",
  "created": "2018-05-15T17:05:29.5543702-07:00",
  "lastActivity": "2018-05-15T17:05:39.9701505-07:00",
  "pageViews": [
    {
      "id": "05152919a70cc034363aaf50ebbb65a79c4f7ebd",
      "startTime": "2018-05-15T17:05:29.5744476-07:00",
      "endTime": "2018-05-15T17:05:39.9701505-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 10581,
      "engagementTime": 10479,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10581,
  "engagementTime": 10479,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JZWPZ",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1db74e1067254a5010f63f2af0143258",
  "gdpr": false
}