var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "03bdc0487287fcba2b8a12c9e3ba3cd6",
  "created": "2018-05-22T14:16:41.732404-07:00",
  "lastActivity": "2018-05-22T14:17:32.807661-07:00",
  "pageViews": [
    {
      "id": "052242592348f2dcadc997ffb0be2959c17dd4c6",
      "startTime": "2018-05-22T14:16:41.8705786-07:00",
      "endTime": "2018-05-22T14:17:32.807661-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 50994,
      "engagementTime": 50894,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 50994,
  "engagementTime": 50894,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JSK2P",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5a339a147e07782021a16ece1325a8d4",
  "gdpr": false
}