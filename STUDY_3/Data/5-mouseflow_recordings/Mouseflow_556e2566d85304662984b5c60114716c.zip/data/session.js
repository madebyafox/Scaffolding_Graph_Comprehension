var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "556e2566d85304662984b5c60114716c",
  "created": "2018-05-24T12:10:03.3646405-07:00",
  "lastActivity": "2018-05-24T12:10:25.64876-07:00",
  "pageViews": [
    {
      "id": "05240325025398d72b8a3ac4b60b84382774c101",
      "startTime": "2018-05-24T12:10:03.41076-07:00",
      "endTime": "2018-05-24T12:10:25.64876-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 22238,
      "engagementTime": 16137,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22238,
  "engagementTime": 16137,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=3Z8ZL",
    "CONDITION=113",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "019a030ed3e2383f6ede12fbc18b150d",
  "gdpr": false
}