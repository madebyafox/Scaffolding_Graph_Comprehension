var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f55c39507a8c8ed0cab6077269bfa8fb",
  "created": "2018-05-22T16:08:09.1342552-07:00",
  "lastActivity": "2018-05-22T16:09:03.205208-07:00",
  "pageViews": [
    {
      "id": "052209775ea0887556fa4dac81336e1fa1902b5e",
      "startTime": "2018-05-22T16:08:09.232208-07:00",
      "endTime": "2018-05-22T16:09:03.205208-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 53973,
      "engagementTime": 51427,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 53973,
  "engagementTime": 51427,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=0QG7J",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1900a7ffdc304ac63d963ed1766f3d82",
  "gdpr": false
}