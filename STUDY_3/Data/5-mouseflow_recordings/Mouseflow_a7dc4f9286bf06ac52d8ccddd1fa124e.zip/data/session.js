var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a7dc4f9286bf06ac52d8ccddd1fa124e",
  "created": "2018-06-01T11:14:51.6300191-07:00",
  "lastActivity": "2018-06-01T11:16:37.6180191-07:00",
  "pageViews": [
    {
      "id": "06015107afa84481da2c3709c5f118d71a4c5baf",
      "startTime": "2018-06-01T11:14:51.6300191-07:00",
      "endTime": "2018-06-01T11:16:37.6180191-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 105988,
      "engagementTime": 92775,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 105988,
  "engagementTime": 92775,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.46",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=JPN18",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "96823804b129a1243e8ec46ec99f629e",
  "gdpr": false
}