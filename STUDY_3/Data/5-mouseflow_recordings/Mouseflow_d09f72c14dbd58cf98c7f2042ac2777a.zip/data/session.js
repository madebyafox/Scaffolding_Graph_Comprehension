var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d09f72c14dbd58cf98c7f2042ac2777a",
  "created": "2018-05-21T12:22:17.524943-07:00",
  "lastActivity": "2018-05-21T12:23:21.095943-07:00",
  "pageViews": [
    {
      "id": "052117990011f27f6e3971f04ad8d7f7ab370012",
      "startTime": "2018-05-21T12:22:17.524943-07:00",
      "endTime": "2018-05-21T12:23:21.095943-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 63571,
      "engagementTime": 63325,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 63571,
  "engagementTime": 63325,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=X9PTQ",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d00d1e359a3163c1dba36e94cfbe811c",
  "gdpr": false
}