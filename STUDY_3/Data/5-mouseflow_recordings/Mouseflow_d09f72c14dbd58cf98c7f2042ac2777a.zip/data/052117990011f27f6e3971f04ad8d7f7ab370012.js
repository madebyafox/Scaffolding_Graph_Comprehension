var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052117990011f27f6e3971f04ad8d7f7ab370012"] = {
  "startTime": "2018-05-21T19:22:17.524943Z",
  "websitePageUrl": "/16",
  "visitTime": 63571,
  "engagementTime": 63325,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "d09f72c14dbd58cf98c7f2042ac2777a",
    "created": "2018-05-21T19:22:17.524943+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=X9PTQ",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "d00d1e359a3163c1dba36e94cfbe811c",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d09f72c14dbd58cf98c7f2042ac2777a/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 104,
      "e": 104,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 104,
      "e": 104,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 2,
      "x": 69,
      "y": 1114
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 2100,
      "y": 61269,
      "ta": "> div.stimulus"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 48,
      "y": 1065
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 243,
      "y": 855
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 33262,
      "y": 42046,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 434,
      "y": 735
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 464,
      "y": 701
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 461,
      "y": 659
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 40906,
      "y": 36063,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2586,
      "e": 2586,
      "ty": 6,
      "x": 429,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 429,
      "y": 603
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 408,
      "y": 576
    },
    {
      "t": 2752,
      "e": 2752,
      "ty": 41,
      "x": 34162,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 399,
      "y": 565
    },
    {
      "t": 2902,
      "e": 2902,
      "ty": 2,
      "x": 398,
      "y": 564
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 33824,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3211,
      "e": 3211,
      "ty": 3,
      "x": 398,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3213,
      "e": 3213,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3362,
      "e": 3362,
      "ty": 4,
      "x": 33824,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3363,
      "e": 3363,
      "ty": 5,
      "x": 398,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7232,
      "e": 7232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7255,
      "e": 7255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 7256,
      "e": 7256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7358,
      "e": 7358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "b"
    },
    {
      "t": 7374,
      "e": 7374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "b"
    },
    {
      "t": 7527,
      "e": 7527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 7528,
      "e": 7528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7631,
      "e": 7631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "bY"
    },
    {
      "t": 7727,
      "e": 7727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7727,
      "e": 7727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7814,
      "e": 7814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "bY "
    },
    {
      "t": 8023,
      "e": 8023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 8024,
      "e": 8024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8094,
      "e": 8094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "bY L"
    },
    {
      "t": 8199,
      "e": 8199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8199,
      "e": 8199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8254,
      "e": 8254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 8270,
      "e": 8270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8270,
      "e": 8270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8374,
      "e": 8374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 8886,
      "e": 8886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8927,
      "e": 8927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "bY LO"
    },
    {
      "t": 9007,
      "e": 9007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9135,
      "e": 9135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "bY L"
    },
    {
      "t": 9231,
      "e": 9231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9263,
      "e": 9263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "bY "
    },
    {
      "t": 9342,
      "e": 9342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9367,
      "e": 9367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "bY"
    },
    {
      "t": 9438,
      "e": 9438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9487,
      "e": 9487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "b"
    },
    {
      "t": 9575,
      "e": 9575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9622,
      "e": 9622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9702,
      "e": 9702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 9807,
      "e": 9807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10207,
      "e": 10207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10255,
      "e": 10255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 10255,
      "e": 10255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10359,
      "e": 10359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 10359,
      "e": 10359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 10479,
      "e": 10479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 10480,
      "e": 10480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10558,
      "e": 10558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By"
    },
    {
      "t": 10646,
      "e": 10646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10647,
      "e": 10647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10727,
      "e": 10727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By "
    },
    {
      "t": 10879,
      "e": 10879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 10879,
      "e": 10879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10942,
      "e": 10942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By l"
    },
    {
      "t": 11047,
      "e": 11047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11047,
      "e": 11047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11110,
      "e": 11110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 11167,
      "e": 11167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11168,
      "e": 11168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11263,
      "e": 11263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 11303,
      "e": 11303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 11303,
      "e": 11303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11367,
      "e": 11367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 11439,
      "e": 11439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11440,
      "e": 11440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11510,
      "e": 11510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 11559,
      "e": 11559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11559,
      "e": 11559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11614,
      "e": 11614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 11615,
      "e": 11615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11622,
      "e": 11622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ng"
    },
    {
      "t": 11687,
      "e": 11687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11687,
      "e": 11687,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11718,
      "e": 11718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11767,
      "e": 11767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11767,
      "e": 11767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11775,
      "e": 11775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11838,
      "e": 11838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11911,
      "e": 11911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11911,
      "e": 11911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11999,
      "e": 11999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12031,
      "e": 12031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12032,
      "e": 12032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12111,
      "e": 12111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12159,
      "e": 12159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12159,
      "e": 12159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12230,
      "e": 12230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12230,
      "e": 12230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12238,
      "e": 12238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 12302,
      "e": 12302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12310,
      "e": 12310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12311,
      "e": 12311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12367,
      "e": 12367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12367,
      "e": 12367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12382,
      "e": 12382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 12462,
      "e": 12462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13124,
      "e": 13124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13285,
      "e": 13285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 13285,
      "e": 13285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13288,
      "e": 13288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 13288,
      "e": 13288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13364,
      "e": 13364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||XC"
    },
    {
      "t": 13364,
      "e": 13364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13404,
      "e": 13404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13885,
      "e": 13885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13915,
      "e": 13915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X"
    },
    {
      "t": 14316,
      "e": 14316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14317,
      "e": 14317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14395,
      "e": 14395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14765,
      "e": 14765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14765,
      "e": 14765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14844,
      "e": 14844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15029,
      "e": 15029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 15029,
      "e": 15029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15100,
      "e": 15100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 15123,
      "e": 15123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15124,
      "e": 15124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15171,
      "e": 15171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15468,
      "e": 15468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15507,
      "e": 15507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X ac"
    },
    {
      "t": 15628,
      "e": 15628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15660,
      "e": 15660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X a"
    },
    {
      "t": 15800,
      "e": 15800,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X a"
    },
    {
      "t": 15988,
      "e": 15988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 15989,
      "e": 15989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16099,
      "e": 16099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 16163,
      "e": 16163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16164,
      "e": 16164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16261,
      "e": 16261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16269,
      "e": 16269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16269,
      "e": 16269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16364,
      "e": 16364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16436,
      "e": 16436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16436,
      "e": 16436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16499,
      "e": 16499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16596,
      "e": 16596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16597,
      "e": 16597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16651,
      "e": 16651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 16652,
      "e": 16652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16668,
      "e": 16668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 16748,
      "e": 16748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16764,
      "e": 16764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16765,
      "e": 16765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16836,
      "e": 16836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16877,
      "e": 16877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16877,
      "e": 16877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16940,
      "e": 16940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16948,
      "e": 16948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16949,
      "e": 16949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17003,
      "e": 17003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17003,
      "e": 17003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17011,
      "e": 17011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 17068,
      "e": 17068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17091,
      "e": 17091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17092,
      "e": 17092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17164,
      "e": 17164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 17164,
      "e": 17164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17172,
      "e": 17172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| g"
    },
    {
      "t": 17244,
      "e": 17244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17325,
      "e": 17325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17325,
      "e": 17325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17412,
      "e": 17412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17413,
      "e": 17413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17428,
      "e": 17413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 17508,
      "e": 17493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17516,
      "e": 17501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17517,
      "e": 17502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17596,
      "e": 17581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 17684,
      "e": 17669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17685,
      "e": 17670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17757,
      "e": 17742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17836,
      "e": 17821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17837,
      "e": 17822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17893,
      "e": 17878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18001,
      "e": 17986,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X axis of the graph "
    },
    {
      "t": 22541,
      "e": 22526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22652,
      "e": 22637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X axis of the graph"
    },
    {
      "t": 23599,
      "e": 23584,
      "ty": 2,
      "x": 356,
      "y": 546
    },
    {
      "t": 23600,
      "e": 23585,
      "ty": 7,
      "x": 244,
      "y": 497,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23699,
      "e": 23684,
      "ty": 2,
      "x": 8,
      "y": 432
    },
    {
      "t": 23748,
      "e": 23733,
      "ty": 41,
      "x": 0,
      "y": 24430,
      "ta": "html"
    },
    {
      "t": 23799,
      "e": 23784,
      "ty": 2,
      "x": 20,
      "y": 455
    },
    {
      "t": 23834,
      "e": 23819,
      "ty": 6,
      "x": 155,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23867,
      "e": 23852,
      "ty": 7,
      "x": 324,
      "y": 624,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23885,
      "e": 23870,
      "ty": 6,
      "x": 406,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 23898,
      "e": 23883,
      "ty": 2,
      "x": 406,
      "y": 678
    },
    {
      "t": 23901,
      "e": 23886,
      "ty": 7,
      "x": 483,
      "y": 721,
      "ta": "#strategyButton"
    },
    {
      "t": 23999,
      "e": 23984,
      "ty": 2,
      "x": 560,
      "y": 780
    },
    {
      "t": 24000,
      "e": 23985,
      "ty": 41,
      "x": 52035,
      "y": 42766,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 24099,
      "e": 24084,
      "ty": 2,
      "x": 564,
      "y": 780
    },
    {
      "t": 24199,
      "e": 24184,
      "ty": 2,
      "x": 393,
      "y": 627
    },
    {
      "t": 24249,
      "e": 24234,
      "ty": 41,
      "x": 30452,
      "y": 64294,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 24299,
      "e": 24284,
      "ty": 2,
      "x": 365,
      "y": 619
    },
    {
      "t": 24399,
      "e": 24384,
      "ty": 2,
      "x": 354,
      "y": 626
    },
    {
      "t": 24470,
      "e": 24455,
      "ty": 6,
      "x": 361,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 24498,
      "e": 24483,
      "ty": 2,
      "x": 362,
      "y": 656
    },
    {
      "t": 24498,
      "e": 24483,
      "ty": 41,
      "x": 12782,
      "y": 2439,
      "ta": "#strategyButton"
    },
    {
      "t": 24598,
      "e": 24583,
      "ty": 2,
      "x": 366,
      "y": 662
    },
    {
      "t": 24698,
      "e": 24683,
      "ty": 2,
      "x": 373,
      "y": 672
    },
    {
      "t": 24748,
      "e": 24733,
      "ty": 41,
      "x": 19336,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 24798,
      "e": 24783,
      "ty": 2,
      "x": 374,
      "y": 673
    },
    {
      "t": 25712,
      "e": 25697,
      "ty": 3,
      "x": 374,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 25712,
      "e": 25697,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the X axis of the graph"
    },
    {
      "t": 25712,
      "e": 25697,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25712,
      "e": 25697,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 25864,
      "e": 25849,
      "ty": 4,
      "x": 19336,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 25876,
      "e": 25861,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 25877,
      "e": 25862,
      "ty": 5,
      "x": 374,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 25882,
      "e": 25867,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 26699,
      "e": 26684,
      "ty": 2,
      "x": 356,
      "y": 699
    },
    {
      "t": 26749,
      "e": 26734,
      "ty": 41,
      "x": 9160,
      "y": 43376,
      "ta": "html > body"
    },
    {
      "t": 26799,
      "e": 26784,
      "ty": 2,
      "x": 256,
      "y": 821
    },
    {
      "t": 26883,
      "e": 26868,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 26899,
      "e": 26884,
      "ty": 2,
      "x": 256,
      "y": 822
    },
    {
      "t": 26999,
      "e": 26984,
      "ty": 41,
      "x": 8540,
      "y": 45093,
      "ta": "html > body"
    },
    {
      "t": 27699,
      "e": 27684,
      "ty": 2,
      "x": 297,
      "y": 794
    },
    {
      "t": 27749,
      "e": 27734,
      "ty": 41,
      "x": 22901,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 27788,
      "e": 27773,
      "ty": 6,
      "x": 941,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 27799,
      "e": 27784,
      "ty": 2,
      "x": 941,
      "y": 699
    },
    {
      "t": 27899,
      "e": 27884,
      "ty": 2,
      "x": 968,
      "y": 682
    },
    {
      "t": 27904,
      "e": 27889,
      "ty": 7,
      "x": 968,
      "y": 669,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 27920,
      "e": 27905,
      "ty": 6,
      "x": 964,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27937,
      "e": 27922,
      "ty": 7,
      "x": 960,
      "y": 629,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27998,
      "e": 27983,
      "ty": 2,
      "x": 941,
      "y": 577
    },
    {
      "t": 27998,
      "e": 27983,
      "ty": 41,
      "x": 28766,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 28004,
      "e": 27989,
      "ty": 6,
      "x": 934,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28054,
      "e": 28039,
      "ty": 7,
      "x": 916,
      "y": 550,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28099,
      "e": 28084,
      "ty": 2,
      "x": 909,
      "y": 544
    },
    {
      "t": 28199,
      "e": 28184,
      "ty": 2,
      "x": 898,
      "y": 541
    },
    {
      "t": 28249,
      "e": 28234,
      "ty": 41,
      "x": 18816,
      "y": 40871,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 28271,
      "e": 28256,
      "ty": 6,
      "x": 895,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28299,
      "e": 28284,
      "ty": 2,
      "x": 895,
      "y": 559
    },
    {
      "t": 28399,
      "e": 28384,
      "ty": 2,
      "x": 895,
      "y": 563
    },
    {
      "t": 28416,
      "e": 28401,
      "ty": 3,
      "x": 895,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28416,
      "e": 28401,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28499,
      "e": 28484,
      "ty": 41,
      "x": 18816,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28544,
      "e": 28529,
      "ty": 4,
      "x": 18816,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28544,
      "e": 28529,
      "ty": 5,
      "x": 895,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28899,
      "e": 28884,
      "ty": 2,
      "x": 895,
      "y": 564
    },
    {
      "t": 28999,
      "e": 28984,
      "ty": 2,
      "x": 891,
      "y": 570
    },
    {
      "t": 29000,
      "e": 28985,
      "ty": 41,
      "x": 17951,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29099,
      "e": 29084,
      "ty": 2,
      "x": 889,
      "y": 572
    },
    {
      "t": 29199,
      "e": 29184,
      "ty": 2,
      "x": 887,
      "y": 573
    },
    {
      "t": 29232,
      "e": 29217,
      "ty": 7,
      "x": 886,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29248,
      "e": 29233,
      "ty": 41,
      "x": 16654,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 29253,
      "e": 29238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 29253,
      "e": 29238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29299,
      "e": 29284,
      "ty": 2,
      "x": 884,
      "y": 578
    },
    {
      "t": 29341,
      "e": 29326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 29499,
      "e": 29484,
      "ty": 41,
      "x": 16437,
      "y": 62011,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 29699,
      "e": 29684,
      "ty": 2,
      "x": 877,
      "y": 580
    },
    {
      "t": 29749,
      "e": 29734,
      "ty": 41,
      "x": 14923,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 29773,
      "e": 29758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 29773,
      "e": 29758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29868,
      "e": 29853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 29999,
      "e": 29984,
      "ty": 2,
      "x": 891,
      "y": 624
    },
    {
      "t": 29999,
      "e": 29984,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30001,
      "e": 29986,
      "ty": 41,
      "x": 17951,
      "y": 53832,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 30055,
      "e": 30040,
      "ty": 6,
      "x": 898,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30099,
      "e": 30084,
      "ty": 2,
      "x": 898,
      "y": 652
    },
    {
      "t": 30199,
      "e": 30184,
      "ty": 2,
      "x": 898,
      "y": 660
    },
    {
      "t": 30249,
      "e": 30234,
      "ty": 41,
      "x": 19465,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30299,
      "e": 30284,
      "ty": 2,
      "x": 894,
      "y": 661
    },
    {
      "t": 30399,
      "e": 30384,
      "ty": 2,
      "x": 892,
      "y": 657
    },
    {
      "t": 30400,
      "e": 30385,
      "ty": 3,
      "x": 892,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30401,
      "e": 30386,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 30402,
      "e": 30387,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 30403,
      "e": 30388,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30498,
      "e": 30483,
      "ty": 41,
      "x": 18168,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30535,
      "e": 30520,
      "ty": 4,
      "x": 18168,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30536,
      "e": 30521,
      "ty": 5,
      "x": 892,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31668,
      "e": 31653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 31836,
      "e": 31821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 31837,
      "e": 31822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31907,
      "e": 31892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 31947,
      "e": 31932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 32076,
      "e": 32061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 32077,
      "e": 32062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32171,
      "e": 32156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 32284,
      "e": 32269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 32284,
      "e": 32269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32339,
      "e": 32324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 32339,
      "e": 32324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32347,
      "e": 32332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 32419,
      "e": 32404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 32779,
      "e": 32764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 32780,
      "e": 32765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32851,
      "e": 32836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 32931,
      "e": 32916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 32932,
      "e": 32917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33020,
      "e": 33005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 33020,
      "e": 33005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33036,
      "e": 33021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 33116,
      "e": 33101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 33196,
      "e": 33181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 33204,
      "e": 33189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 33205,
      "e": 33190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33307,
      "e": 33292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 33331,
      "e": 33316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 33388,
      "e": 33373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 33388,
      "e": 33373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33476,
      "e": 33461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 33508,
      "e": 33493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 33509,
      "e": 33494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33669,
      "e": 33654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 33716,
      "e": 33701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 33717,
      "e": 33702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33796,
      "e": 33781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 33892,
      "e": 33877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 33893,
      "e": 33878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33947,
      "e": 33932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 34052,
      "e": 34037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 34052,
      "e": 34037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34164,
      "e": 34149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 34480,
      "e": 34465,
      "ty": 7,
      "x": 863,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34499,
      "e": 34484,
      "ty": 2,
      "x": 831,
      "y": 630
    },
    {
      "t": 34499,
      "e": 34484,
      "ty": 41,
      "x": 4974,
      "y": 33119,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 34598,
      "e": 34583,
      "ty": 2,
      "x": 783,
      "y": 580
    },
    {
      "t": 34610,
      "e": 34595,
      "ty": 6,
      "x": 810,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34692,
      "e": 34677,
      "ty": 7,
      "x": 845,
      "y": 581,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34698,
      "e": 34683,
      "ty": 2,
      "x": 845,
      "y": 581
    },
    {
      "t": 34749,
      "e": 34734,
      "ty": 41,
      "x": 16870,
      "y": 63194,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 34761,
      "e": 34746,
      "ty": 6,
      "x": 909,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34799,
      "e": 34784,
      "ty": 2,
      "x": 924,
      "y": 667
    },
    {
      "t": 34809,
      "e": 34794,
      "ty": 7,
      "x": 927,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34827,
      "e": 34812,
      "ty": 6,
      "x": 933,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34898,
      "e": 34883,
      "ty": 2,
      "x": 957,
      "y": 706
    },
    {
      "t": 34999,
      "e": 34984,
      "ty": 41,
      "x": 31479,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35099,
      "e": 35084,
      "ty": 2,
      "x": 958,
      "y": 706
    },
    {
      "t": 35198,
      "e": 35183,
      "ty": 2,
      "x": 959,
      "y": 701
    },
    {
      "t": 35241,
      "e": 35226,
      "ty": 3,
      "x": 959,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35241,
      "e": 35226,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 35245,
      "e": 35230,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35246,
      "e": 35231,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35248,
      "e": 35233,
      "ty": 41,
      "x": 32509,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35392,
      "e": 35377,
      "ty": 4,
      "x": 32509,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35393,
      "e": 35378,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35393,
      "e": 35378,
      "ty": 5,
      "x": 959,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 35393,
      "e": 35378,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 35698,
      "e": 35683,
      "ty": 2,
      "x": 927,
      "y": 710
    },
    {
      "t": 35748,
      "e": 35733,
      "ty": 41,
      "x": 29134,
      "y": 39442,
      "ta": "html > body"
    },
    {
      "t": 35799,
      "e": 35784,
      "ty": 2,
      "x": 782,
      "y": 721
    },
    {
      "t": 35898,
      "e": 35883,
      "ty": 2,
      "x": 760,
      "y": 721
    },
    {
      "t": 35998,
      "e": 35983,
      "ty": 41,
      "x": 25897,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 36099,
      "e": 36084,
      "ty": 2,
      "x": 757,
      "y": 721
    },
    {
      "t": 36198,
      "e": 36183,
      "ty": 2,
      "x": 751,
      "y": 716
    },
    {
      "t": 36249,
      "e": 36234,
      "ty": 41,
      "x": 25449,
      "y": 39221,
      "ta": "html > body"
    },
    {
      "t": 36298,
      "e": 36283,
      "ty": 2,
      "x": 718,
      "y": 738
    },
    {
      "t": 36413,
      "e": 36398,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 36419,
      "e": 36404,
      "ty": 2,
      "x": 508,
      "y": 949
    },
    {
      "t": 36498,
      "e": 36483,
      "ty": 2,
      "x": 492,
      "y": 975
    },
    {
      "t": 36498,
      "e": 36483,
      "ty": 41,
      "x": 16667,
      "y": 53569,
      "ta": "html > body"
    },
    {
      "t": 36698,
      "e": 36683,
      "ty": 2,
      "x": 493,
      "y": 974
    },
    {
      "t": 36748,
      "e": 36733,
      "ty": 41,
      "x": 16805,
      "y": 53015,
      "ta": "html > body"
    },
    {
      "t": 36799,
      "e": 36784,
      "ty": 2,
      "x": 497,
      "y": 960
    },
    {
      "t": 36902,
      "e": 36887,
      "ty": 2,
      "x": 499,
      "y": 955
    },
    {
      "t": 36998,
      "e": 36983,
      "ty": 2,
      "x": 499,
      "y": 954
    },
    {
      "t": 36998,
      "e": 36983,
      "ty": 41,
      "x": 16908,
      "y": 52405,
      "ta": "html > body"
    },
    {
      "t": 37598,
      "e": 37583,
      "ty": 2,
      "x": 605,
      "y": 517
    },
    {
      "t": 37699,
      "e": 37684,
      "ty": 2,
      "x": 859,
      "y": 16
    },
    {
      "t": 37748,
      "e": 37733,
      "ty": 41,
      "x": 32302,
      "y": 443,
      "ta": "html > body"
    },
    {
      "t": 37798,
      "e": 37783,
      "ty": 2,
      "x": 965,
      "y": 16
    },
    {
      "t": 37898,
      "e": 37883,
      "ty": 2,
      "x": 986,
      "y": 70
    },
    {
      "t": 37998,
      "e": 37983,
      "ty": 2,
      "x": 961,
      "y": 151
    },
    {
      "t": 37999,
      "e": 37984,
      "ty": 41,
      "x": 32819,
      "y": 7921,
      "ta": "html > body"
    },
    {
      "t": 38099,
      "e": 38084,
      "ty": 2,
      "x": 932,
      "y": 173
    },
    {
      "t": 38198,
      "e": 38183,
      "ty": 2,
      "x": 882,
      "y": 207
    },
    {
      "t": 38249,
      "e": 38234,
      "ty": 41,
      "x": 10579,
      "y": 17005,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 38298,
      "e": 38283,
      "ty": 2,
      "x": 851,
      "y": 234
    },
    {
      "t": 38398,
      "e": 38383,
      "ty": 2,
      "x": 848,
      "y": 237
    },
    {
      "t": 38498,
      "e": 38483,
      "ty": 2,
      "x": 845,
      "y": 237
    },
    {
      "t": 38499,
      "e": 38484,
      "ty": 41,
      "x": 19307,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 38598,
      "e": 38583,
      "ty": 2,
      "x": 842,
      "y": 237
    },
    {
      "t": 38698,
      "e": 38683,
      "ty": 2,
      "x": 839,
      "y": 254
    },
    {
      "t": 38731,
      "e": 38685,
      "ty": 6,
      "x": 838,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 38749,
      "e": 38703,
      "ty": 41,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 38798,
      "e": 38752,
      "ty": 2,
      "x": 837,
      "y": 268
    },
    {
      "t": 38898,
      "e": 38852,
      "ty": 2,
      "x": 837,
      "y": 269
    },
    {
      "t": 38964,
      "e": 38918,
      "ty": 7,
      "x": 837,
      "y": 273,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 38998,
      "e": 38952,
      "ty": 2,
      "x": 837,
      "y": 278
    },
    {
      "t": 38998,
      "e": 38952,
      "ty": 41,
      "x": 3697,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 39063,
      "e": 39017,
      "ty": 6,
      "x": 837,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 39098,
      "e": 39052,
      "ty": 2,
      "x": 837,
      "y": 288
    },
    {
      "t": 39127,
      "e": 39081,
      "ty": 7,
      "x": 837,
      "y": 286,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 39180,
      "e": 39134,
      "ty": 6,
      "x": 837,
      "y": 268,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 39198,
      "e": 39152,
      "ty": 2,
      "x": 837,
      "y": 263
    },
    {
      "t": 39230,
      "e": 39184,
      "ty": 7,
      "x": 838,
      "y": 258,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 39248,
      "e": 39202,
      "ty": 41,
      "x": 3934,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 39298,
      "e": 39252,
      "ty": 2,
      "x": 838,
      "y": 249
    },
    {
      "t": 39397,
      "e": 39351,
      "ty": 6,
      "x": 838,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 39398,
      "e": 39352,
      "ty": 2,
      "x": 838,
      "y": 244
    },
    {
      "t": 39499,
      "e": 39453,
      "ty": 2,
      "x": 838,
      "y": 240
    },
    {
      "t": 39499,
      "e": 39453,
      "ty": 41,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 39577,
      "e": 39531,
      "ty": 3,
      "x": 838,
      "y": 240,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 39578,
      "e": 39532,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 39711,
      "e": 39665,
      "ty": 4,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 39711,
      "e": 39665,
      "ty": 5,
      "x": 838,
      "y": 240,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 39713,
      "e": 39667,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 39798,
      "e": 39752,
      "ty": 2,
      "x": 838,
      "y": 242
    },
    {
      "t": 39809,
      "e": 39763,
      "ty": 7,
      "x": 838,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 39864,
      "e": 39818,
      "ty": 6,
      "x": 838,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 39896,
      "e": 39850,
      "ty": 7,
      "x": 840,
      "y": 269,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 39898,
      "e": 39852,
      "ty": 2,
      "x": 840,
      "y": 269
    },
    {
      "t": 39999,
      "e": 39953,
      "ty": 2,
      "x": 843,
      "y": 294
    },
    {
      "t": 39999,
      "e": 39953,
      "ty": 41,
      "x": 6762,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 40098,
      "e": 40052,
      "ty": 2,
      "x": 844,
      "y": 314
    },
    {
      "t": 40198,
      "e": 40152,
      "ty": 2,
      "x": 842,
      "y": 320
    },
    {
      "t": 40249,
      "e": 40203,
      "ty": 41,
      "x": 20428,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 40299,
      "e": 40253,
      "ty": 2,
      "x": 841,
      "y": 320
    },
    {
      "t": 40320,
      "e": 40274,
      "ty": 6,
      "x": 839,
      "y": 320,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 40377,
      "e": 40331,
      "ty": 3,
      "x": 839,
      "y": 320,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 40380,
      "e": 40334,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 40381,
      "e": 40335,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 40398,
      "e": 40352,
      "ty": 2,
      "x": 839,
      "y": 320
    },
    {
      "t": 40498,
      "e": 40452,
      "ty": 2,
      "x": 838,
      "y": 320
    },
    {
      "t": 40499,
      "e": 40453,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 40527,
      "e": 40481,
      "ty": 4,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 40527,
      "e": 40481,
      "ty": 5,
      "x": 838,
      "y": 320,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 40528,
      "e": 40482,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 40698,
      "e": 40652,
      "ty": 2,
      "x": 838,
      "y": 325
    },
    {
      "t": 40728,
      "e": 40682,
      "ty": 7,
      "x": 838,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 40749,
      "e": 40703,
      "ty": 41,
      "x": 17450,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 40799,
      "e": 40753,
      "ty": 2,
      "x": 844,
      "y": 335
    },
    {
      "t": 40898,
      "e": 40852,
      "ty": 2,
      "x": 850,
      "y": 339
    },
    {
      "t": 40998,
      "e": 40952,
      "ty": 2,
      "x": 851,
      "y": 295
    },
    {
      "t": 40999,
      "e": 40953,
      "ty": 41,
      "x": 9269,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 41099,
      "e": 41053,
      "ty": 2,
      "x": 851,
      "y": 263
    },
    {
      "t": 41200,
      "e": 41154,
      "ty": 2,
      "x": 846,
      "y": 247
    },
    {
      "t": 41249,
      "e": 41203,
      "ty": 41,
      "x": 15213,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 41265,
      "e": 41219,
      "ty": 6,
      "x": 838,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 41298,
      "e": 41252,
      "ty": 2,
      "x": 838,
      "y": 232
    },
    {
      "t": 41321,
      "e": 41275,
      "ty": 7,
      "x": 837,
      "y": 230,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 41399,
      "e": 41353,
      "ty": 2,
      "x": 836,
      "y": 228
    },
    {
      "t": 41499,
      "e": 41453,
      "ty": 41,
      "x": 3459,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 41548,
      "e": 41502,
      "ty": 6,
      "x": 836,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 41582,
      "e": 41536,
      "ty": 7,
      "x": 838,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 41598,
      "e": 41552,
      "ty": 2,
      "x": 842,
      "y": 257
    },
    {
      "t": 41698,
      "e": 41652,
      "ty": 2,
      "x": 867,
      "y": 350
    },
    {
      "t": 41749,
      "e": 41653,
      "ty": 41,
      "x": 11766,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 41799,
      "e": 41703,
      "ty": 2,
      "x": 872,
      "y": 367
    },
    {
      "t": 41898,
      "e": 41802,
      "ty": 2,
      "x": 863,
      "y": 341
    },
    {
      "t": 41998,
      "e": 41902,
      "ty": 2,
      "x": 845,
      "y": 268
    },
    {
      "t": 41998,
      "e": 41902,
      "ty": 41,
      "x": 17957,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 42098,
      "e": 42002,
      "ty": 2,
      "x": 846,
      "y": 274
    },
    {
      "t": 42198,
      "e": 42102,
      "ty": 2,
      "x": 862,
      "y": 378
    },
    {
      "t": 42249,
      "e": 42153,
      "ty": 41,
      "x": 47500,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 42298,
      "e": 42202,
      "ty": 2,
      "x": 861,
      "y": 431
    },
    {
      "t": 42398,
      "e": 42302,
      "ty": 2,
      "x": 861,
      "y": 432
    },
    {
      "t": 42498,
      "e": 42402,
      "ty": 2,
      "x": 850,
      "y": 448
    },
    {
      "t": 42499,
      "e": 42403,
      "ty": 41,
      "x": 22826,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 42599,
      "e": 42503,
      "ty": 2,
      "x": 848,
      "y": 451
    },
    {
      "t": 42749,
      "e": 42653,
      "ty": 41,
      "x": 21229,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 42799,
      "e": 42703,
      "ty": 2,
      "x": 854,
      "y": 408
    },
    {
      "t": 42898,
      "e": 42802,
      "ty": 2,
      "x": 850,
      "y": 318
    },
    {
      "t": 42998,
      "e": 42902,
      "ty": 2,
      "x": 841,
      "y": 252
    },
    {
      "t": 42998,
      "e": 42902,
      "ty": 41,
      "x": 4646,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 42999,
      "e": 42903,
      "ty": 6,
      "x": 838,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43098,
      "e": 43002,
      "ty": 2,
      "x": 837,
      "y": 235
    },
    {
      "t": 43249,
      "e": 43153,
      "ty": 41,
      "x": 53325,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43366,
      "e": 43270,
      "ty": 7,
      "x": 834,
      "y": 252,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43398,
      "e": 43302,
      "ty": 2,
      "x": 833,
      "y": 258
    },
    {
      "t": 43499,
      "e": 43403,
      "ty": 2,
      "x": 826,
      "y": 423
    },
    {
      "t": 43499,
      "e": 43403,
      "ty": 41,
      "x": 5359,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 43517,
      "e": 43421,
      "ty": 6,
      "x": 826,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 43583,
      "e": 43487,
      "ty": 7,
      "x": 826,
      "y": 430,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 43599,
      "e": 43503,
      "ty": 2,
      "x": 826,
      "y": 430
    },
    {
      "t": 43599,
      "e": 43503,
      "ty": 6,
      "x": 826,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 43616,
      "e": 43520,
      "ty": 7,
      "x": 826,
      "y": 388,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 43667,
      "e": 43571,
      "ty": 6,
      "x": 826,
      "y": 300,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 43682,
      "e": 43586,
      "ty": 7,
      "x": 831,
      "y": 281,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 43698,
      "e": 43602,
      "ty": 2,
      "x": 831,
      "y": 281
    },
    {
      "t": 43700,
      "e": 43604,
      "ty": 6,
      "x": 836,
      "y": 272,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 43717,
      "e": 43621,
      "ty": 7,
      "x": 840,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 43748,
      "e": 43652,
      "ty": 41,
      "x": 15672,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 43799,
      "e": 43703,
      "ty": 2,
      "x": 844,
      "y": 255
    },
    {
      "t": 43898,
      "e": 43802,
      "ty": 2,
      "x": 845,
      "y": 253
    },
    {
      "t": 43998,
      "e": 43902,
      "ty": 41,
      "x": 5595,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 44098,
      "e": 44002,
      "ty": 2,
      "x": 843,
      "y": 241
    },
    {
      "t": 44199,
      "e": 44103,
      "ty": 2,
      "x": 842,
      "y": 240
    },
    {
      "t": 44200,
      "e": 44104,
      "ty": 3,
      "x": 842,
      "y": 240,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 44201,
      "e": 44105,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 44248,
      "e": 44152,
      "ty": 41,
      "x": 16850,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 44312,
      "e": 44216,
      "ty": 4,
      "x": 16850,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 44313,
      "e": 44217,
      "ty": 5,
      "x": 842,
      "y": 240,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 44313,
      "e": 44217,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44314,
      "e": 44218,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 44584,
      "e": 44488,
      "ty": 6,
      "x": 839,
      "y": 264,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 44598,
      "e": 44502,
      "ty": 2,
      "x": 839,
      "y": 264
    },
    {
      "t": 44617,
      "e": 44521,
      "ty": 7,
      "x": 840,
      "y": 279,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 44698,
      "e": 44602,
      "ty": 2,
      "x": 859,
      "y": 313
    },
    {
      "t": 44748,
      "e": 44652,
      "ty": 41,
      "x": 12478,
      "y": 14272,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 44798,
      "e": 44702,
      "ty": 2,
      "x": 878,
      "y": 383
    },
    {
      "t": 44898,
      "e": 44802,
      "ty": 2,
      "x": 882,
      "y": 403
    },
    {
      "t": 44999,
      "e": 44903,
      "ty": 2,
      "x": 882,
      "y": 407
    },
    {
      "t": 44999,
      "e": 44903,
      "ty": 41,
      "x": 14376,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 45098,
      "e": 45002,
      "ty": 2,
      "x": 882,
      "y": 414
    },
    {
      "t": 45199,
      "e": 45103,
      "ty": 2,
      "x": 880,
      "y": 416
    },
    {
      "t": 45249,
      "e": 45153,
      "ty": 41,
      "x": 13902,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 45298,
      "e": 45202,
      "ty": 2,
      "x": 880,
      "y": 423
    },
    {
      "t": 45399,
      "e": 45303,
      "ty": 2,
      "x": 878,
      "y": 432
    },
    {
      "t": 45498,
      "e": 45402,
      "ty": 2,
      "x": 872,
      "y": 447
    },
    {
      "t": 45499,
      "e": 45403,
      "ty": 41,
      "x": 40399,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 45599,
      "e": 45503,
      "ty": 2,
      "x": 858,
      "y": 477
    },
    {
      "t": 45699,
      "e": 45603,
      "ty": 2,
      "x": 857,
      "y": 477
    },
    {
      "t": 45750,
      "e": 45604,
      "ty": 41,
      "x": 35492,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 45798,
      "e": 45652,
      "ty": 2,
      "x": 851,
      "y": 444
    },
    {
      "t": 45898,
      "e": 45752,
      "ty": 2,
      "x": 851,
      "y": 427
    },
    {
      "t": 45998,
      "e": 45852,
      "ty": 2,
      "x": 851,
      "y": 418
    },
    {
      "t": 45999,
      "e": 45853,
      "ty": 41,
      "x": 34623,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46099,
      "e": 45953,
      "ty": 2,
      "x": 852,
      "y": 414
    },
    {
      "t": 46248,
      "e": 46102,
      "ty": 3,
      "x": 852,
      "y": 414,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46249,
      "e": 46103,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46252,
      "e": 46106,
      "ty": 41,
      "x": 35794,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46375,
      "e": 46229,
      "ty": 4,
      "x": 35794,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46375,
      "e": 46229,
      "ty": 5,
      "x": 852,
      "y": 414,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46375,
      "e": 46229,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 46376,
      "e": 46230,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 46598,
      "e": 46452,
      "ty": 2,
      "x": 852,
      "y": 417
    },
    {
      "t": 46699,
      "e": 46553,
      "ty": 2,
      "x": 874,
      "y": 477
    },
    {
      "t": 46749,
      "e": 46603,
      "ty": 41,
      "x": 52576,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 46798,
      "e": 46652,
      "ty": 2,
      "x": 882,
      "y": 523
    },
    {
      "t": 46898,
      "e": 46752,
      "ty": 2,
      "x": 882,
      "y": 571
    },
    {
      "t": 46999,
      "e": 46853,
      "ty": 2,
      "x": 866,
      "y": 643
    },
    {
      "t": 46999,
      "e": 46853,
      "ty": 41,
      "x": 10579,
      "y": 7582,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 47099,
      "e": 46953,
      "ty": 2,
      "x": 864,
      "y": 654
    },
    {
      "t": 47199,
      "e": 47053,
      "ty": 2,
      "x": 918,
      "y": 678
    },
    {
      "t": 47249,
      "e": 47103,
      "ty": 41,
      "x": 27542,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 47299,
      "e": 47153,
      "ty": 2,
      "x": 944,
      "y": 680
    },
    {
      "t": 47398,
      "e": 47252,
      "ty": 2,
      "x": 974,
      "y": 678
    },
    {
      "t": 47499,
      "e": 47353,
      "ty": 2,
      "x": 977,
      "y": 692
    },
    {
      "t": 47499,
      "e": 47353,
      "ty": 41,
      "x": 36922,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 47598,
      "e": 47452,
      "ty": 2,
      "x": 966,
      "y": 709
    },
    {
      "t": 47699,
      "e": 47553,
      "ty": 2,
      "x": 952,
      "y": 731
    },
    {
      "t": 47748,
      "e": 47602,
      "ty": 41,
      "x": 31769,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 47798,
      "e": 47652,
      "ty": 2,
      "x": 948,
      "y": 729
    },
    {
      "t": 47899,
      "e": 47753,
      "ty": 2,
      "x": 933,
      "y": 673
    },
    {
      "t": 47998,
      "e": 47852,
      "ty": 2,
      "x": 932,
      "y": 658
    },
    {
      "t": 47998,
      "e": 47852,
      "ty": 41,
      "x": 26242,
      "y": 11644,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 48099,
      "e": 47953,
      "ty": 2,
      "x": 937,
      "y": 657
    },
    {
      "t": 48199,
      "e": 48053,
      "ty": 2,
      "x": 946,
      "y": 667
    },
    {
      "t": 48249,
      "e": 48103,
      "ty": 41,
      "x": 33449,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 48298,
      "e": 48152,
      "ty": 2,
      "x": 945,
      "y": 691
    },
    {
      "t": 48399,
      "e": 48253,
      "ty": 2,
      "x": 943,
      "y": 700
    },
    {
      "t": 48498,
      "e": 48352,
      "ty": 2,
      "x": 939,
      "y": 707
    },
    {
      "t": 48498,
      "e": 48352,
      "ty": 41,
      "x": 29627,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 48760,
      "e": 48614,
      "ty": 3,
      "x": 939,
      "y": 707,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 48761,
      "e": 48615,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 48871,
      "e": 48725,
      "ty": 4,
      "x": 29627,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 48871,
      "e": 48725,
      "ty": 5,
      "x": 939,
      "y": 707,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 48872,
      "e": 48726,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48872,
      "e": 48726,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 49099,
      "e": 48953,
      "ty": 2,
      "x": 938,
      "y": 708
    },
    {
      "t": 49199,
      "e": 49053,
      "ty": 2,
      "x": 901,
      "y": 762
    },
    {
      "t": 49249,
      "e": 49053,
      "ty": 41,
      "x": 35592,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 49298,
      "e": 49102,
      "ty": 2,
      "x": 860,
      "y": 811
    },
    {
      "t": 49399,
      "e": 49203,
      "ty": 2,
      "x": 842,
      "y": 819
    },
    {
      "t": 49498,
      "e": 49302,
      "ty": 2,
      "x": 848,
      "y": 827
    },
    {
      "t": 49499,
      "e": 49303,
      "ty": 41,
      "x": 6307,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 49599,
      "e": 49403,
      "ty": 2,
      "x": 953,
      "y": 852
    },
    {
      "t": 49699,
      "e": 49503,
      "ty": 2,
      "x": 1009,
      "y": 871
    },
    {
      "t": 49749,
      "e": 49553,
      "ty": 41,
      "x": 49026,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 49799,
      "e": 49603,
      "ty": 2,
      "x": 1030,
      "y": 881
    },
    {
      "t": 49899,
      "e": 49703,
      "ty": 2,
      "x": 1022,
      "y": 891
    },
    {
      "t": 49998,
      "e": 49802,
      "ty": 2,
      "x": 1011,
      "y": 903
    },
    {
      "t": 50000,
      "e": 49804,
      "ty": 41,
      "x": 44991,
      "y": 14115,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 50498,
      "e": 50302,
      "ty": 2,
      "x": 1007,
      "y": 935
    },
    {
      "t": 50499,
      "e": 50303,
      "ty": 41,
      "x": 44042,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 50598,
      "e": 50402,
      "ty": 2,
      "x": 964,
      "y": 1012
    },
    {
      "t": 50607,
      "e": 50411,
      "ty": 6,
      "x": 954,
      "y": 1019,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 50699,
      "e": 50503,
      "ty": 2,
      "x": 915,
      "y": 1019
    },
    {
      "t": 50723,
      "e": 50527,
      "ty": 7,
      "x": 865,
      "y": 996,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 50749,
      "e": 50553,
      "ty": 41,
      "x": 27377,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 50798,
      "e": 50602,
      "ty": 2,
      "x": 834,
      "y": 974
    },
    {
      "t": 50822,
      "e": 50626,
      "ty": 6,
      "x": 834,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 50872,
      "e": 50676,
      "ty": 7,
      "x": 842,
      "y": 950,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 50898,
      "e": 50702,
      "ty": 2,
      "x": 843,
      "y": 945
    },
    {
      "t": 50999,
      "e": 50803,
      "ty": 2,
      "x": 846,
      "y": 936
    },
    {
      "t": 51000,
      "e": 50804,
      "ty": 41,
      "x": 26845,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 51099,
      "e": 50903,
      "ty": 2,
      "x": 846,
      "y": 938
    },
    {
      "t": 51199,
      "e": 51003,
      "ty": 2,
      "x": 846,
      "y": 944
    },
    {
      "t": 51249,
      "e": 51053,
      "ty": 41,
      "x": 26845,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 51299,
      "e": 51103,
      "ty": 2,
      "x": 846,
      "y": 945
    },
    {
      "t": 51399,
      "e": 51203,
      "ty": 2,
      "x": 846,
      "y": 950
    },
    {
      "t": 51499,
      "e": 51303,
      "ty": 2,
      "x": 846,
      "y": 953
    },
    {
      "t": 51500,
      "e": 51304,
      "ty": 41,
      "x": 19881,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51624,
      "e": 51428,
      "ty": 3,
      "x": 846,
      "y": 953,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51625,
      "e": 51429,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51815,
      "e": 51619,
      "ty": 4,
      "x": 19881,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51816,
      "e": 51620,
      "ty": 5,
      "x": 846,
      "y": 953,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51817,
      "e": 51621,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 51819,
      "e": 51623,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 51899,
      "e": 51703,
      "ty": 2,
      "x": 846,
      "y": 960
    },
    {
      "t": 51998,
      "e": 51802,
      "ty": 2,
      "x": 846,
      "y": 963
    },
    {
      "t": 51999,
      "e": 51803,
      "ty": 41,
      "x": 19881,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 52098,
      "e": 51902,
      "ty": 2,
      "x": 846,
      "y": 967
    },
    {
      "t": 52198,
      "e": 52002,
      "ty": 2,
      "x": 847,
      "y": 971
    },
    {
      "t": 52249,
      "e": 52053,
      "ty": 41,
      "x": 20690,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 52299,
      "e": 52103,
      "ty": 2,
      "x": 849,
      "y": 972
    },
    {
      "t": 52399,
      "e": 52203,
      "ty": 2,
      "x": 852,
      "y": 972
    },
    {
      "t": 52498,
      "e": 52302,
      "ty": 2,
      "x": 854,
      "y": 971
    },
    {
      "t": 52499,
      "e": 52303,
      "ty": 41,
      "x": 26353,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 52599,
      "e": 52403,
      "ty": 2,
      "x": 858,
      "y": 967
    },
    {
      "t": 52699,
      "e": 52503,
      "ty": 2,
      "x": 862,
      "y": 951
    },
    {
      "t": 52749,
      "e": 52553,
      "ty": 41,
      "x": 49782,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 52799,
      "e": 52603,
      "ty": 2,
      "x": 869,
      "y": 914
    },
    {
      "t": 52899,
      "e": 52703,
      "ty": 2,
      "x": 869,
      "y": 906
    },
    {
      "t": 53000,
      "e": 52804,
      "ty": 41,
      "x": 11291,
      "y": 15627,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 53099,
      "e": 52903,
      "ty": 2,
      "x": 886,
      "y": 923
    },
    {
      "t": 53199,
      "e": 53003,
      "ty": 2,
      "x": 909,
      "y": 958
    },
    {
      "t": 53250,
      "e": 53004,
      "ty": 41,
      "x": 21021,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 53298,
      "e": 53052,
      "ty": 2,
      "x": 910,
      "y": 986
    },
    {
      "t": 53399,
      "e": 53153,
      "ty": 2,
      "x": 901,
      "y": 1002
    },
    {
      "t": 53408,
      "e": 53162,
      "ty": 6,
      "x": 895,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 53499,
      "e": 53253,
      "ty": 2,
      "x": 883,
      "y": 1015
    },
    {
      "t": 53499,
      "e": 53253,
      "ty": 41,
      "x": 27613,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 53598,
      "e": 53352,
      "ty": 2,
      "x": 883,
      "y": 1016
    },
    {
      "t": 53749,
      "e": 53503,
      "ty": 41,
      "x": 27613,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 53798,
      "e": 53552,
      "ty": 2,
      "x": 899,
      "y": 1023
    },
    {
      "t": 53899,
      "e": 53653,
      "ty": 2,
      "x": 932,
      "y": 1030
    },
    {
      "t": 53999,
      "e": 53753,
      "ty": 2,
      "x": 933,
      "y": 1031
    },
    {
      "t": 53999,
      "e": 53753,
      "ty": 41,
      "x": 53383,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54099,
      "e": 53853,
      "ty": 2,
      "x": 916,
      "y": 1035
    },
    {
      "t": 54199,
      "e": 53953,
      "ty": 2,
      "x": 905,
      "y": 1031
    },
    {
      "t": 54249,
      "e": 54003,
      "ty": 41,
      "x": 38436,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54299,
      "e": 54053,
      "ty": 2,
      "x": 903,
      "y": 1020
    },
    {
      "t": 54399,
      "e": 54153,
      "ty": 2,
      "x": 903,
      "y": 1018
    },
    {
      "t": 54465,
      "e": 54219,
      "ty": 3,
      "x": 903,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54466,
      "e": 54220,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 54466,
      "e": 54220,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54499,
      "e": 54253,
      "ty": 41,
      "x": 37921,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54616,
      "e": 54370,
      "ty": 4,
      "x": 37921,
      "y": 25816,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54617,
      "e": 54371,
      "ty": 5,
      "x": 903,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54624,
      "e": 54378,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54625,
      "e": 54379,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 54629,
      "e": 54383,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 55299,
      "e": 55053,
      "ty": 2,
      "x": 911,
      "y": 1002
    },
    {
      "t": 55399,
      "e": 55153,
      "ty": 2,
      "x": 971,
      "y": 919
    },
    {
      "t": 55499,
      "e": 55253,
      "ty": 2,
      "x": 1054,
      "y": 856
    },
    {
      "t": 55499,
      "e": 55253,
      "ty": 41,
      "x": 36021,
      "y": 46976,
      "ta": "html > body"
    },
    {
      "t": 55598,
      "e": 55352,
      "ty": 2,
      "x": 1155,
      "y": 805
    },
    {
      "t": 55699,
      "e": 55453,
      "ty": 2,
      "x": 1182,
      "y": 798
    },
    {
      "t": 55725,
      "e": 55479,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 55749,
      "e": 55503,
      "ty": 41,
      "x": 43713,
      "y": 53668,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 55799,
      "e": 55553,
      "ty": 2,
      "x": 1183,
      "y": 797
    },
    {
      "t": 56000,
      "e": 55754,
      "ty": 41,
      "x": 43763,
      "y": 53552,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 56399,
      "e": 56153,
      "ty": 2,
      "x": 1185,
      "y": 823
    },
    {
      "t": 56498,
      "e": 56252,
      "ty": 2,
      "x": 1167,
      "y": 900
    },
    {
      "t": 56499,
      "e": 56253,
      "ty": 41,
      "x": 42975,
      "y": 64401,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 56598,
      "e": 56352,
      "ty": 2,
      "x": 1133,
      "y": 951
    },
    {
      "t": 56698,
      "e": 56452,
      "ty": 2,
      "x": 1001,
      "y": 1012
    },
    {
      "t": 56748,
      "e": 56502,
      "ty": 41,
      "x": 32201,
      "y": 63063,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 56799,
      "e": 56553,
      "ty": 2,
      "x": 937,
      "y": 1042
    },
    {
      "t": 56898,
      "e": 56652,
      "ty": 2,
      "x": 934,
      "y": 1047
    },
    {
      "t": 56994,
      "e": 56748,
      "ty": 6,
      "x": 942,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 56998,
      "e": 56752,
      "ty": 2,
      "x": 942,
      "y": 1076
    },
    {
      "t": 56999,
      "e": 56753,
      "ty": 41,
      "x": 17749,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 57098,
      "e": 56852,
      "ty": 2,
      "x": 947,
      "y": 1086
    },
    {
      "t": 57198,
      "e": 56952,
      "ty": 2,
      "x": 954,
      "y": 1102
    },
    {
      "t": 57249,
      "e": 57003,
      "ty": 41,
      "x": 24302,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 59998,
      "e": 59752,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60151,
      "e": 59905,
      "ty": 3,
      "x": 954,
      "y": 1102,
      "ta": "#start"
    },
    {
      "t": 60152,
      "e": 59906,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 60327,
      "e": 60081,
      "ty": 4,
      "x": 24302,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 60328,
      "e": 60082,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 60328,
      "e": 60082,
      "ty": 5,
      "x": 954,
      "y": 1102,
      "ta": "#start"
    },
    {
      "t": 60329,
      "e": 60083,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 60899,
      "e": 60653,
      "ty": 2,
      "x": 686,
      "y": 958
    },
    {
      "t": 60999,
      "e": 60753,
      "ty": 2,
      "x": 300,
      "y": 681
    },
    {
      "t": 60999,
      "e": 60753,
      "ty": 41,
      "x": 10055,
      "y": 37282,
      "ta": "html > body"
    },
    {
      "t": 61098,
      "e": 60852,
      "ty": 2,
      "x": 350,
      "y": 509
    },
    {
      "t": 61199,
      "e": 60953,
      "ty": 2,
      "x": 604,
      "y": 405
    },
    {
      "t": 61249,
      "e": 61003,
      "ty": 41,
      "x": 21592,
      "y": 21272,
      "ta": "html > body"
    },
    {
      "t": 61298,
      "e": 61052,
      "ty": 2,
      "x": 637,
      "y": 390
    },
    {
      "t": 61370,
      "e": 61124,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 62614,
      "e": 62368,
      "ty": 2,
      "x": 1012,
      "y": 356
    },
    {
      "t": 62614,
      "e": 62368,
      "ty": 41,
      "x": 34265,
      "y": 32731,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 62699,
      "e": 62453,
      "ty": 2,
      "x": 1017,
      "y": 356
    },
    {
      "t": 62748,
      "e": 62502,
      "ty": 41,
      "x": 34408,
      "y": 32730,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 62798,
      "e": 62552,
      "ty": 2,
      "x": 1015,
      "y": 340
    },
    {
      "t": 62898,
      "e": 62652,
      "ty": 2,
      "x": 913,
      "y": 274
    },
    {
      "t": 62998,
      "e": 62752,
      "ty": 2,
      "x": 902,
      "y": 264
    },
    {
      "t": 62999,
      "e": 62753,
      "ty": 41,
      "x": 31126,
      "y": 32717,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 63571,
      "e": 63325,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 143409, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 143411, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 4640, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 149385, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 16233, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 166623, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 23155, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 190858, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 9000, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 200861, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 27462, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 229707, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-11 AM-A -A -C -I -I -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:984,y:1042,t:1526929853181};\\\", \\\"{x:1009,y:1049,t:1526929853191};\\\", \\\"{x:1089,y:1085,t:1526929853209};\\\", \\\"{x:1156,y:1116,t:1526929853226};\\\", \\\"{x:1197,y:1132,t:1526929853241};\\\", \\\"{x:1217,y:1140,t:1526929853258};\\\", \\\"{x:1224,y:1141,t:1526929853276};\\\", \\\"{x:1226,y:1141,t:1526929853292};\\\", \\\"{x:1225,y:1141,t:1526929853828};\\\", \\\"{x:1219,y:1139,t:1526929853842};\\\", \\\"{x:1199,y:1134,t:1526929853859};\\\", \\\"{x:1172,y:1127,t:1526929853876};\\\", \\\"{x:1133,y:1109,t:1526929853892};\\\", \\\"{x:1113,y:1098,t:1526929853908};\\\", \\\"{x:1096,y:1088,t:1526929853925};\\\", \\\"{x:1080,y:1079,t:1526929853942};\\\", \\\"{x:1066,y:1069,t:1526929853959};\\\", \\\"{x:1051,y:1055,t:1526929853975};\\\", \\\"{x:1034,y:1038,t:1526929853993};\\\", \\\"{x:1020,y:1020,t:1526929854010};\\\", \\\"{x:1009,y:1004,t:1526929854026};\\\", \\\"{x:1001,y:988,t:1526929854042};\\\", \\\"{x:993,y:973,t:1526929854060};\\\", \\\"{x:987,y:958,t:1526929854076};\\\", \\\"{x:978,y:936,t:1526929854093};\\\", \\\"{x:974,y:922,t:1526929854110};\\\", \\\"{x:970,y:908,t:1526929854126};\\\", \\\"{x:966,y:893,t:1526929854142};\\\", \\\"{x:962,y:881,t:1526929854160};\\\", \\\"{x:961,y:874,t:1526929854175};\\\", \\\"{x:960,y:868,t:1526929854192};\\\", \\\"{x:960,y:863,t:1526929854210};\\\", \\\"{x:960,y:859,t:1526929854226};\\\", \\\"{x:960,y:855,t:1526929854242};\\\", \\\"{x:960,y:848,t:1526929854260};\\\", \\\"{x:962,y:839,t:1526929854276};\\\", \\\"{x:972,y:826,t:1526929854293};\\\", \\\"{x:979,y:820,t:1526929854309};\\\", \\\"{x:988,y:813,t:1526929854326};\\\", \\\"{x:996,y:809,t:1526929854342};\\\", \\\"{x:1004,y:803,t:1526929854359};\\\", \\\"{x:1012,y:799,t:1526929854376};\\\", \\\"{x:1019,y:794,t:1526929854392};\\\", \\\"{x:1026,y:791,t:1526929854409};\\\", \\\"{x:1030,y:789,t:1526929854426};\\\", \\\"{x:1033,y:788,t:1526929854443};\\\", \\\"{x:1034,y:787,t:1526929854460};\\\", \\\"{x:1035,y:786,t:1526929854573};\\\", \\\"{x:1035,y:785,t:1526929854580};\\\", \\\"{x:1035,y:783,t:1526929854593};\\\", \\\"{x:1035,y:778,t:1526929854610};\\\", \\\"{x:1028,y:769,t:1526929854627};\\\", \\\"{x:1012,y:757,t:1526929854642};\\\", \\\"{x:988,y:740,t:1526929854659};\\\", \\\"{x:925,y:704,t:1526929854676};\\\", \\\"{x:865,y:678,t:1526929854692};\\\", \\\"{x:782,y:646,t:1526929854710};\\\", \\\"{x:703,y:616,t:1526929854727};\\\", \\\"{x:620,y:577,t:1526929854742};\\\", \\\"{x:540,y:541,t:1526929854759};\\\", \\\"{x:468,y:509,t:1526929854777};\\\", \\\"{x:410,y:485,t:1526929854793};\\\", \\\"{x:371,y:464,t:1526929854809};\\\", \\\"{x:349,y:455,t:1526929854827};\\\", \\\"{x:338,y:449,t:1526929854844};\\\", \\\"{x:336,y:448,t:1526929854860};\\\", \\\"{x:335,y:448,t:1526929854932};\\\", \\\"{x:335,y:447,t:1526929854943};\\\", \\\"{x:344,y:445,t:1526929854959};\\\", \\\"{x:366,y:441,t:1526929854977};\\\", \\\"{x:393,y:438,t:1526929854994};\\\", \\\"{x:431,y:433,t:1526929855011};\\\", \\\"{x:482,y:432,t:1526929855026};\\\", \\\"{x:535,y:432,t:1526929855044};\\\", \\\"{x:599,y:432,t:1526929855060};\\\", \\\"{x:665,y:440,t:1526929855076};\\\", \\\"{x:687,y:446,t:1526929855094};\\\", \\\"{x:706,y:451,t:1526929855110};\\\", \\\"{x:721,y:456,t:1526929855127};\\\", \\\"{x:733,y:459,t:1526929855144};\\\", \\\"{x:743,y:462,t:1526929855161};\\\", \\\"{x:759,y:464,t:1526929855177};\\\", \\\"{x:780,y:469,t:1526929855193};\\\", \\\"{x:805,y:476,t:1526929855211};\\\", \\\"{x:837,y:484,t:1526929855227};\\\", \\\"{x:864,y:492,t:1526929855244};\\\", \\\"{x:919,y:505,t:1526929855260};\\\", \\\"{x:955,y:510,t:1526929855277};\\\", \\\"{x:986,y:514,t:1526929855294};\\\", \\\"{x:1010,y:519,t:1526929855311};\\\", \\\"{x:1032,y:522,t:1526929855327};\\\", \\\"{x:1051,y:527,t:1526929855344};\\\", \\\"{x:1064,y:529,t:1526929855361};\\\", \\\"{x:1080,y:532,t:1526929855378};\\\", \\\"{x:1095,y:535,t:1526929855393};\\\", \\\"{x:1105,y:535,t:1526929855411};\\\", \\\"{x:1112,y:537,t:1526929855428};\\\", \\\"{x:1116,y:538,t:1526929855444};\\\", \\\"{x:1125,y:539,t:1526929855460};\\\", \\\"{x:1131,y:539,t:1526929855478};\\\", \\\"{x:1134,y:539,t:1526929855494};\\\", \\\"{x:1135,y:539,t:1526929855511};\\\", \\\"{x:1136,y:541,t:1526929855660};\\\", \\\"{x:1136,y:542,t:1526929855692};\\\", \\\"{x:1136,y:544,t:1526929855700};\\\", \\\"{x:1136,y:545,t:1526929855711};\\\", \\\"{x:1133,y:548,t:1526929855728};\\\", \\\"{x:1130,y:552,t:1526929855745};\\\", \\\"{x:1127,y:553,t:1526929855761};\\\", \\\"{x:1123,y:557,t:1526929855777};\\\", \\\"{x:1121,y:559,t:1526929855794};\\\", \\\"{x:1118,y:562,t:1526929855811};\\\", \\\"{x:1117,y:564,t:1526929855828};\\\", \\\"{x:1115,y:569,t:1526929855844};\\\", \\\"{x:1113,y:571,t:1526929855860};\\\", \\\"{x:1113,y:573,t:1526929855878};\\\", \\\"{x:1111,y:576,t:1526929855894};\\\", \\\"{x:1110,y:578,t:1526929855910};\\\", \\\"{x:1110,y:579,t:1526929855928};\\\", \\\"{x:1109,y:582,t:1526929855944};\\\", \\\"{x:1109,y:583,t:1526929855961};\\\", \\\"{x:1109,y:585,t:1526929855977};\\\", \\\"{x:1107,y:588,t:1526929855994};\\\", \\\"{x:1107,y:590,t:1526929856011};\\\", \\\"{x:1106,y:592,t:1526929856028};\\\", \\\"{x:1105,y:596,t:1526929856045};\\\", \\\"{x:1105,y:598,t:1526929856062};\\\", \\\"{x:1105,y:603,t:1526929856077};\\\", \\\"{x:1104,y:607,t:1526929856095};\\\", \\\"{x:1102,y:612,t:1526929856112};\\\", \\\"{x:1102,y:618,t:1526929856128};\\\", \\\"{x:1102,y:626,t:1526929856144};\\\", \\\"{x:1102,y:636,t:1526929856162};\\\", \\\"{x:1099,y:649,t:1526929856177};\\\", \\\"{x:1099,y:663,t:1526929856194};\\\", \\\"{x:1099,y:681,t:1526929856212};\\\", \\\"{x:1099,y:697,t:1526929856227};\\\", \\\"{x:1099,y:720,t:1526929856244};\\\", \\\"{x:1099,y:735,t:1526929856261};\\\", \\\"{x:1099,y:752,t:1526929856278};\\\", \\\"{x:1099,y:767,t:1526929856295};\\\", \\\"{x:1099,y:781,t:1526929856312};\\\", \\\"{x:1099,y:795,t:1526929856328};\\\", \\\"{x:1099,y:807,t:1526929856344};\\\", \\\"{x:1099,y:821,t:1526929856362};\\\", \\\"{x:1099,y:831,t:1526929856377};\\\", \\\"{x:1099,y:837,t:1526929856395};\\\", \\\"{x:1099,y:841,t:1526929856411};\\\", \\\"{x:1099,y:848,t:1526929856428};\\\", \\\"{x:1099,y:851,t:1526929856445};\\\", \\\"{x:1099,y:854,t:1526929856462};\\\", \\\"{x:1100,y:857,t:1526929856478};\\\", \\\"{x:1100,y:861,t:1526929856494};\\\", \\\"{x:1101,y:864,t:1526929856512};\\\", \\\"{x:1102,y:866,t:1526929856528};\\\", \\\"{x:1102,y:869,t:1526929856544};\\\", \\\"{x:1106,y:876,t:1526929856562};\\\", \\\"{x:1108,y:881,t:1526929856578};\\\", \\\"{x:1111,y:886,t:1526929856594};\\\", \\\"{x:1115,y:893,t:1526929856612};\\\", \\\"{x:1118,y:902,t:1526929856628};\\\", \\\"{x:1120,y:907,t:1526929856644};\\\", \\\"{x:1123,y:913,t:1526929856661};\\\", \\\"{x:1125,y:918,t:1526929856679};\\\", \\\"{x:1128,y:922,t:1526929856694};\\\", \\\"{x:1132,y:930,t:1526929856711};\\\", \\\"{x:1139,y:941,t:1526929856729};\\\", \\\"{x:1147,y:950,t:1526929856745};\\\", \\\"{x:1154,y:958,t:1526929856762};\\\", \\\"{x:1166,y:970,t:1526929856779};\\\", \\\"{x:1180,y:981,t:1526929856795};\\\", \\\"{x:1192,y:988,t:1526929856812};\\\", \\\"{x:1209,y:997,t:1526929856828};\\\", \\\"{x:1221,y:1002,t:1526929856846};\\\", \\\"{x:1234,y:1006,t:1526929856862};\\\", \\\"{x:1244,y:1008,t:1526929856879};\\\", \\\"{x:1258,y:1011,t:1526929856896};\\\", \\\"{x:1269,y:1011,t:1526929856912};\\\", \\\"{x:1278,y:1013,t:1526929856929};\\\", \\\"{x:1283,y:1013,t:1526929856946};\\\", \\\"{x:1285,y:1013,t:1526929856962};\\\", \\\"{x:1286,y:1013,t:1526929856979};\\\", \\\"{x:1287,y:1013,t:1526929857013};\\\", \\\"{x:1288,y:1013,t:1526929857029};\\\", \\\"{x:1291,y:1011,t:1526929857047};\\\", \\\"{x:1293,y:1007,t:1526929857062};\\\", \\\"{x:1296,y:1002,t:1526929857079};\\\", \\\"{x:1296,y:997,t:1526929857096};\\\", \\\"{x:1298,y:990,t:1526929857112};\\\", \\\"{x:1299,y:986,t:1526929857129};\\\", \\\"{x:1299,y:985,t:1526929857146};\\\", \\\"{x:1299,y:983,t:1526929857163};\\\", \\\"{x:1299,y:982,t:1526929857179};\\\", \\\"{x:1299,y:981,t:1526929857196};\\\", \\\"{x:1299,y:979,t:1526929857212};\\\", \\\"{x:1299,y:978,t:1526929857244};\\\", \\\"{x:1299,y:977,t:1526929857260};\\\", \\\"{x:1298,y:976,t:1526929857268};\\\", \\\"{x:1297,y:976,t:1526929857300};\\\", \\\"{x:1296,y:975,t:1526929857317};\\\", \\\"{x:1295,y:975,t:1526929857445};\\\", \\\"{x:1294,y:975,t:1526929857510};\\\", \\\"{x:1293,y:975,t:1526929857524};\\\", \\\"{x:1292,y:975,t:1526929857533};\\\", \\\"{x:1292,y:977,t:1526929857546};\\\", \\\"{x:1290,y:979,t:1526929857563};\\\", \\\"{x:1288,y:981,t:1526929857580};\\\", \\\"{x:1288,y:983,t:1526929857595};\\\", \\\"{x:1287,y:984,t:1526929857613};\\\", \\\"{x:1287,y:983,t:1526929857813};\\\", \\\"{x:1287,y:981,t:1526929857829};\\\", \\\"{x:1287,y:980,t:1526929857845};\\\", \\\"{x:1287,y:979,t:1526929857863};\\\", \\\"{x:1287,y:978,t:1526929857884};\\\", \\\"{x:1287,y:977,t:1526929857932};\\\", \\\"{x:1286,y:976,t:1526929857956};\\\", \\\"{x:1286,y:975,t:1526929857988};\\\", \\\"{x:1286,y:974,t:1526929858004};\\\", \\\"{x:1286,y:973,t:1526929858020};\\\", \\\"{x:1285,y:973,t:1526929858030};\\\", \\\"{x:1284,y:972,t:1526929858060};\\\", \\\"{x:1284,y:971,t:1526929858076};\\\", \\\"{x:1284,y:970,t:1526929858093};\\\", \\\"{x:1284,y:969,t:1526929858101};\\\", \\\"{x:1283,y:968,t:1526929858113};\\\", \\\"{x:1283,y:966,t:1526929858130};\\\", \\\"{x:1283,y:965,t:1526929858147};\\\", \\\"{x:1283,y:964,t:1526929858163};\\\", \\\"{x:1282,y:962,t:1526929858181};\\\", \\\"{x:1282,y:960,t:1526929858196};\\\", \\\"{x:1282,y:959,t:1526929858215};\\\", \\\"{x:1282,y:958,t:1526929858230};\\\", \\\"{x:1282,y:957,t:1526929858247};\\\", \\\"{x:1281,y:955,t:1526929858700};\\\", \\\"{x:1281,y:954,t:1526929858714};\\\", \\\"{x:1281,y:952,t:1526929858788};\\\", \\\"{x:1280,y:951,t:1526929858820};\\\", \\\"{x:1280,y:952,t:1526929859732};\\\", \\\"{x:1280,y:954,t:1526929859748};\\\", \\\"{x:1280,y:957,t:1526929859765};\\\", \\\"{x:1280,y:958,t:1526929859782};\\\", \\\"{x:1280,y:960,t:1526929859798};\\\", \\\"{x:1280,y:962,t:1526929859814};\\\", \\\"{x:1280,y:963,t:1526929859832};\\\", \\\"{x:1280,y:964,t:1526929859924};\\\", \\\"{x:1280,y:965,t:1526929860108};\\\", \\\"{x:1280,y:964,t:1526929860132};\\\", \\\"{x:1280,y:957,t:1526929860148};\\\", \\\"{x:1280,y:951,t:1526929860165};\\\", \\\"{x:1280,y:940,t:1526929860182};\\\", \\\"{x:1280,y:930,t:1526929860199};\\\", \\\"{x:1278,y:919,t:1526929860215};\\\", \\\"{x:1275,y:907,t:1526929860232};\\\", \\\"{x:1273,y:894,t:1526929860249};\\\", \\\"{x:1269,y:880,t:1526929860265};\\\", \\\"{x:1268,y:870,t:1526929860282};\\\", \\\"{x:1265,y:858,t:1526929860299};\\\", \\\"{x:1264,y:848,t:1526929860315};\\\", \\\"{x:1264,y:839,t:1526929860332};\\\", \\\"{x:1263,y:832,t:1526929860349};\\\", \\\"{x:1261,y:829,t:1526929860366};\\\", \\\"{x:1261,y:826,t:1526929860382};\\\", \\\"{x:1261,y:824,t:1526929860399};\\\", \\\"{x:1261,y:823,t:1526929860416};\\\", \\\"{x:1261,y:821,t:1526929860432};\\\", \\\"{x:1260,y:820,t:1526929860448};\\\", \\\"{x:1260,y:819,t:1526929860477};\\\", \\\"{x:1261,y:819,t:1526929860908};\\\", \\\"{x:1262,y:820,t:1526929860957};\\\", \\\"{x:1264,y:821,t:1526929860988};\\\", \\\"{x:1264,y:822,t:1526929861028};\\\", \\\"{x:1265,y:823,t:1526929861052};\\\", \\\"{x:1265,y:824,t:1526929861076};\\\", \\\"{x:1266,y:825,t:1526929861107};\\\", \\\"{x:1267,y:826,t:1526929861236};\\\", \\\"{x:1267,y:827,t:1526929861309};\\\", \\\"{x:1268,y:828,t:1526929861332};\\\", \\\"{x:1268,y:829,t:1526929861380};\\\", \\\"{x:1269,y:829,t:1526929861444};\\\", \\\"{x:1270,y:830,t:1526929861460};\\\", \\\"{x:1271,y:832,t:1526929861516};\\\", \\\"{x:1272,y:832,t:1526929861533};\\\", \\\"{x:1273,y:832,t:1526929861550};\\\", \\\"{x:1274,y:833,t:1526929861572};\\\", \\\"{x:1275,y:834,t:1526929861588};\\\", \\\"{x:1276,y:834,t:1526929861612};\\\", \\\"{x:1277,y:834,t:1526929861653};\\\", \\\"{x:1278,y:834,t:1526929861667};\\\", \\\"{x:1279,y:834,t:1526929861789};\\\", \\\"{x:1280,y:834,t:1526929861813};\\\", \\\"{x:1281,y:834,t:1526929861820};\\\", \\\"{x:1282,y:834,t:1526929861834};\\\", \\\"{x:1283,y:834,t:1526929861860};\\\", \\\"{x:1284,y:834,t:1526929861868};\\\", \\\"{x:1285,y:834,t:1526929861884};\\\", \\\"{x:1288,y:834,t:1526929861901};\\\", \\\"{x:1287,y:834,t:1526929862276};\\\", \\\"{x:1286,y:834,t:1526929862299};\\\", \\\"{x:1286,y:835,t:1526929862324};\\\", \\\"{x:1285,y:835,t:1526929862348};\\\", \\\"{x:1284,y:835,t:1526929862364};\\\", \\\"{x:1283,y:835,t:1526929862380};\\\", \\\"{x:1282,y:835,t:1526929862400};\\\", \\\"{x:1281,y:835,t:1526929862436};\\\", \\\"{x:1280,y:836,t:1526929862452};\\\", \\\"{x:1279,y:836,t:1526929862917};\\\", \\\"{x:1272,y:836,t:1526929863876};\\\", \\\"{x:1259,y:833,t:1526929863886};\\\", \\\"{x:1211,y:820,t:1526929863902};\\\", \\\"{x:1120,y:795,t:1526929863919};\\\", \\\"{x:1006,y:762,t:1526929863936};\\\", \\\"{x:865,y:721,t:1526929863952};\\\", \\\"{x:699,y:665,t:1526929863969};\\\", \\\"{x:550,y:607,t:1526929863986};\\\", \\\"{x:400,y:554,t:1526929864002};\\\", \\\"{x:293,y:513,t:1526929864014};\\\", \\\"{x:221,y:478,t:1526929864031};\\\", \\\"{x:176,y:458,t:1526929864047};\\\", \\\"{x:160,y:448,t:1526929864067};\\\", \\\"{x:156,y:447,t:1526929864084};\\\", \\\"{x:156,y:445,t:1526929864101};\\\", \\\"{x:155,y:445,t:1526929864117};\\\", \\\"{x:153,y:441,t:1526929864134};\\\", \\\"{x:152,y:440,t:1526929864151};\\\", \\\"{x:152,y:439,t:1526929864167};\\\", \\\"{x:151,y:438,t:1526929864184};\\\", \\\"{x:150,y:438,t:1526929864201};\\\", \\\"{x:151,y:438,t:1526929864244};\\\", \\\"{x:154,y:438,t:1526929864252};\\\", \\\"{x:158,y:438,t:1526929864268};\\\", \\\"{x:176,y:441,t:1526929864284};\\\", \\\"{x:201,y:451,t:1526929864301};\\\", \\\"{x:240,y:465,t:1526929864317};\\\", \\\"{x:276,y:480,t:1526929864334};\\\", \\\"{x:314,y:496,t:1526929864351};\\\", \\\"{x:352,y:510,t:1526929864368};\\\", \\\"{x:377,y:520,t:1526929864384};\\\", \\\"{x:399,y:528,t:1526929864401};\\\", \\\"{x:408,y:534,t:1526929864418};\\\", \\\"{x:413,y:536,t:1526929864435};\\\", \\\"{x:413,y:537,t:1526929864453};\\\", \\\"{x:414,y:538,t:1526929864468};\\\", \\\"{x:415,y:539,t:1526929864484};\\\", \\\"{x:417,y:542,t:1526929864501};\\\", \\\"{x:419,y:545,t:1526929864518};\\\", \\\"{x:421,y:547,t:1526929864534};\\\", \\\"{x:422,y:548,t:1526929864551};\\\", \\\"{x:421,y:548,t:1526929864676};\\\", \\\"{x:420,y:548,t:1526929864684};\\\", \\\"{x:417,y:547,t:1526929864701};\\\", \\\"{x:416,y:547,t:1526929864718};\\\", \\\"{x:415,y:545,t:1526929864734};\\\", \\\"{x:412,y:545,t:1526929864751};\\\", \\\"{x:410,y:544,t:1526929864767};\\\", \\\"{x:409,y:543,t:1526929864785};\\\", \\\"{x:406,y:542,t:1526929864800};\\\", \\\"{x:405,y:541,t:1526929864818};\\\", \\\"{x:403,y:540,t:1526929864835};\\\", \\\"{x:402,y:540,t:1526929864851};\\\", \\\"{x:400,y:538,t:1526929864868};\\\", \\\"{x:399,y:538,t:1526929864884};\\\", \\\"{x:396,y:538,t:1526929864901};\\\", \\\"{x:395,y:537,t:1526929864918};\\\", \\\"{x:393,y:536,t:1526929864936};\\\", \\\"{x:392,y:535,t:1526929864951};\\\", \\\"{x:391,y:535,t:1526929864969};\\\", \\\"{x:390,y:534,t:1526929864988};\\\", \\\"{x:389,y:534,t:1526929865020};\\\", \\\"{x:388,y:533,t:1526929865035};\\\", \\\"{x:387,y:532,t:1526929865068};\\\", \\\"{x:385,y:532,t:1526929865118};\\\", \\\"{x:392,y:535,t:1526929865909};\\\", \\\"{x:399,y:539,t:1526929865919};\\\", \\\"{x:415,y:550,t:1526929865936};\\\", \\\"{x:437,y:561,t:1526929865952};\\\", \\\"{x:462,y:577,t:1526929865970};\\\", \\\"{x:492,y:591,t:1526929865985};\\\", \\\"{x:518,y:604,t:1526929866002};\\\", \\\"{x:560,y:624,t:1526929866019};\\\", \\\"{x:600,y:644,t:1526929866035};\\\", \\\"{x:666,y:676,t:1526929866052};\\\", \\\"{x:717,y:703,t:1526929866068};\\\", \\\"{x:775,y:728,t:1526929866086};\\\", \\\"{x:818,y:749,t:1526929866102};\\\", \\\"{x:864,y:768,t:1526929866119};\\\", \\\"{x:905,y:782,t:1526929866136};\\\", \\\"{x:938,y:797,t:1526929866151};\\\", \\\"{x:962,y:809,t:1526929866169};\\\", \\\"{x:983,y:819,t:1526929866186};\\\", \\\"{x:1003,y:828,t:1526929866202};\\\", \\\"{x:1019,y:833,t:1526929866218};\\\", \\\"{x:1032,y:836,t:1526929866235};\\\", \\\"{x:1056,y:841,t:1526929866252};\\\", \\\"{x:1074,y:844,t:1526929866269};\\\", \\\"{x:1104,y:847,t:1526929866285};\\\", \\\"{x:1143,y:854,t:1526929866302};\\\", \\\"{x:1185,y:860,t:1526929866319};\\\", \\\"{x:1223,y:864,t:1526929866335};\\\", \\\"{x:1248,y:865,t:1526929866352};\\\", \\\"{x:1263,y:865,t:1526929866370};\\\", \\\"{x:1267,y:865,t:1526929866385};\\\", \\\"{x:1270,y:865,t:1526929866402};\\\", \\\"{x:1271,y:865,t:1526929866420};\\\", \\\"{x:1271,y:864,t:1526929866452};\\\", \\\"{x:1272,y:864,t:1526929866485};\\\", \\\"{x:1272,y:863,t:1526929866732};\\\", \\\"{x:1272,y:862,t:1526929866741};\\\", \\\"{x:1272,y:861,t:1526929866756};\\\", \\\"{x:1271,y:859,t:1526929866772};\\\", \\\"{x:1271,y:857,t:1526929866788};\\\", \\\"{x:1270,y:857,t:1526929866803};\\\", \\\"{x:1269,y:855,t:1526929866820};\\\", \\\"{x:1268,y:854,t:1526929866836};\\\", \\\"{x:1268,y:852,t:1526929866852};\\\", \\\"{x:1267,y:851,t:1526929866869};\\\", \\\"{x:1267,y:850,t:1526929866886};\\\", \\\"{x:1267,y:849,t:1526929866903};\\\", \\\"{x:1267,y:848,t:1526929866920};\\\", \\\"{x:1266,y:846,t:1526929866936};\\\", \\\"{x:1266,y:845,t:1526929866965};\\\", \\\"{x:1266,y:844,t:1526929866972};\\\", \\\"{x:1266,y:843,t:1526929866989};\\\", \\\"{x:1266,y:842,t:1526929867021};\\\", \\\"{x:1265,y:842,t:1526929867036};\\\", \\\"{x:1265,y:841,t:1526929867053};\\\", \\\"{x:1265,y:840,t:1526929867149};\\\", \\\"{x:1265,y:839,t:1526929867206};\\\", \\\"{x:1265,y:838,t:1526929867245};\\\", \\\"{x:1265,y:837,t:1526929867308};\\\", \\\"{x:1265,y:836,t:1526929867324};\\\", \\\"{x:1265,y:835,t:1526929867348};\\\", \\\"{x:1265,y:834,t:1526929867388};\\\", \\\"{x:1265,y:832,t:1526929867412};\\\", \\\"{x:1265,y:831,t:1526929867428};\\\", \\\"{x:1265,y:829,t:1526929867444};\\\", \\\"{x:1266,y:828,t:1526929867452};\\\", \\\"{x:1266,y:827,t:1526929867469};\\\", \\\"{x:1266,y:826,t:1526929867486};\\\", \\\"{x:1266,y:825,t:1526929867502};\\\", \\\"{x:1266,y:823,t:1526929867519};\\\", \\\"{x:1267,y:822,t:1526929867536};\\\", \\\"{x:1268,y:818,t:1526929867553};\\\", \\\"{x:1268,y:816,t:1526929867571};\\\", \\\"{x:1268,y:815,t:1526929867587};\\\", \\\"{x:1268,y:814,t:1526929867602};\\\", \\\"{x:1268,y:811,t:1526929867619};\\\", \\\"{x:1268,y:806,t:1526929867636};\\\", \\\"{x:1268,y:802,t:1526929867652};\\\", \\\"{x:1270,y:796,t:1526929867669};\\\", \\\"{x:1270,y:794,t:1526929867687};\\\", \\\"{x:1271,y:790,t:1526929867703};\\\", \\\"{x:1272,y:788,t:1526929867719};\\\", \\\"{x:1273,y:784,t:1526929867736};\\\", \\\"{x:1273,y:783,t:1526929867752};\\\", \\\"{x:1274,y:782,t:1526929867769};\\\", \\\"{x:1274,y:780,t:1526929867787};\\\", \\\"{x:1274,y:777,t:1526929867803};\\\", \\\"{x:1275,y:775,t:1526929867819};\\\", \\\"{x:1275,y:771,t:1526929867836};\\\", \\\"{x:1275,y:768,t:1526929867852};\\\", \\\"{x:1275,y:764,t:1526929867870};\\\", \\\"{x:1275,y:760,t:1526929867887};\\\", \\\"{x:1275,y:758,t:1526929867903};\\\", \\\"{x:1275,y:754,t:1526929867920};\\\", \\\"{x:1275,y:752,t:1526929867937};\\\", \\\"{x:1275,y:748,t:1526929867953};\\\", \\\"{x:1275,y:746,t:1526929867970};\\\", \\\"{x:1275,y:743,t:1526929867987};\\\", \\\"{x:1275,y:740,t:1526929868002};\\\", \\\"{x:1275,y:735,t:1526929868019};\\\", \\\"{x:1275,y:729,t:1526929868036};\\\", \\\"{x:1275,y:726,t:1526929868052};\\\", \\\"{x:1275,y:720,t:1526929868069};\\\", \\\"{x:1277,y:716,t:1526929868086};\\\", \\\"{x:1278,y:712,t:1526929868102};\\\", \\\"{x:1278,y:711,t:1526929868119};\\\", \\\"{x:1278,y:708,t:1526929868136};\\\", \\\"{x:1279,y:706,t:1526929868152};\\\", \\\"{x:1279,y:705,t:1526929868169};\\\", \\\"{x:1280,y:703,t:1526929868186};\\\", \\\"{x:1280,y:702,t:1526929868268};\\\", \\\"{x:1280,y:701,t:1526929868283};\\\", \\\"{x:1280,y:700,t:1526929868308};\\\", \\\"{x:1280,y:697,t:1526929869333};\\\", \\\"{x:1280,y:696,t:1526929869341};\\\", \\\"{x:1280,y:693,t:1526929869354};\\\", \\\"{x:1280,y:688,t:1526929869369};\\\", \\\"{x:1279,y:683,t:1526929869386};\\\", \\\"{x:1277,y:676,t:1526929869403};\\\", \\\"{x:1274,y:668,t:1526929869419};\\\", \\\"{x:1272,y:658,t:1526929869436};\\\", \\\"{x:1270,y:653,t:1526929869454};\\\", \\\"{x:1269,y:648,t:1526929869469};\\\", \\\"{x:1267,y:644,t:1526929869486};\\\", \\\"{x:1267,y:639,t:1526929869503};\\\", \\\"{x:1266,y:633,t:1526929869519};\\\", \\\"{x:1264,y:628,t:1526929869537};\\\", \\\"{x:1263,y:620,t:1526929869554};\\\", \\\"{x:1260,y:612,t:1526929869569};\\\", \\\"{x:1259,y:609,t:1526929869586};\\\", \\\"{x:1257,y:604,t:1526929869604};\\\", \\\"{x:1257,y:600,t:1526929869619};\\\", \\\"{x:1255,y:593,t:1526929869636};\\\", \\\"{x:1254,y:588,t:1526929869654};\\\", \\\"{x:1254,y:586,t:1526929869669};\\\", \\\"{x:1254,y:584,t:1526929869686};\\\", \\\"{x:1254,y:583,t:1526929869703};\\\", \\\"{x:1253,y:582,t:1526929869720};\\\", \\\"{x:1253,y:581,t:1526929869736};\\\", \\\"{x:1253,y:580,t:1526929869764};\\\", \\\"{x:1253,y:579,t:1526929869796};\\\", \\\"{x:1253,y:578,t:1526929869819};\\\", \\\"{x:1254,y:578,t:1526929869836};\\\", \\\"{x:1255,y:576,t:1526929869860};\\\", \\\"{x:1256,y:576,t:1526929869869};\\\", \\\"{x:1258,y:576,t:1526929869886};\\\", \\\"{x:1259,y:575,t:1526929869903};\\\", \\\"{x:1259,y:572,t:1526929870309};\\\", \\\"{x:1259,y:570,t:1526929870320};\\\", \\\"{x:1259,y:559,t:1526929870337};\\\", \\\"{x:1257,y:551,t:1526929870354};\\\", \\\"{x:1255,y:546,t:1526929870370};\\\", \\\"{x:1253,y:538,t:1526929870386};\\\", \\\"{x:1253,y:534,t:1526929870403};\\\", \\\"{x:1251,y:527,t:1526929870419};\\\", \\\"{x:1251,y:523,t:1526929870436};\\\", \\\"{x:1251,y:520,t:1526929870453};\\\", \\\"{x:1251,y:518,t:1526929870470};\\\", \\\"{x:1251,y:516,t:1526929870486};\\\", \\\"{x:1251,y:512,t:1526929870503};\\\", \\\"{x:1251,y:511,t:1526929870520};\\\", \\\"{x:1251,y:509,t:1526929870536};\\\", \\\"{x:1251,y:506,t:1526929870553};\\\", \\\"{x:1251,y:505,t:1526929870580};\\\", \\\"{x:1251,y:504,t:1526929870588};\\\", \\\"{x:1251,y:503,t:1526929870603};\\\", \\\"{x:1251,y:502,t:1526929870620};\\\", \\\"{x:1251,y:501,t:1526929870636};\\\", \\\"{x:1251,y:500,t:1526929870653};\\\", \\\"{x:1251,y:498,t:1526929870670};\\\", \\\"{x:1251,y:497,t:1526929870687};\\\", \\\"{x:1251,y:495,t:1526929870703};\\\", \\\"{x:1251,y:494,t:1526929870720};\\\", \\\"{x:1251,y:493,t:1526929870737};\\\", \\\"{x:1251,y:492,t:1526929870754};\\\", \\\"{x:1251,y:491,t:1526929870771};\\\", \\\"{x:1251,y:490,t:1526929870789};\\\", \\\"{x:1251,y:489,t:1526929870804};\\\", \\\"{x:1251,y:488,t:1526929870828};\\\", \\\"{x:1251,y:487,t:1526929870885};\\\", \\\"{x:1252,y:487,t:1526929870892};\\\", \\\"{x:1252,y:486,t:1526929870916};\\\", \\\"{x:1252,y:485,t:1526929870989};\\\", \\\"{x:1254,y:485,t:1526929871245};\\\", \\\"{x:1254,y:486,t:1526929871268};\\\", \\\"{x:1256,y:486,t:1526929871284};\\\", \\\"{x:1257,y:487,t:1526929871300};\\\", \\\"{x:1258,y:487,t:1526929871324};\\\", \\\"{x:1258,y:488,t:1526929871336};\\\", \\\"{x:1259,y:489,t:1526929871354};\\\", \\\"{x:1259,y:490,t:1526929871370};\\\", \\\"{x:1260,y:490,t:1526929871386};\\\", \\\"{x:1261,y:491,t:1526929871403};\\\", \\\"{x:1261,y:492,t:1526929871436};\\\", \\\"{x:1261,y:494,t:1526929872149};\\\", \\\"{x:1263,y:497,t:1526929872157};\\\", \\\"{x:1263,y:501,t:1526929872173};\\\", \\\"{x:1263,y:502,t:1526929872187};\\\", \\\"{x:1264,y:509,t:1526929872204};\\\", \\\"{x:1265,y:518,t:1526929872220};\\\", \\\"{x:1267,y:524,t:1526929872237};\\\", \\\"{x:1268,y:533,t:1526929872253};\\\", \\\"{x:1269,y:543,t:1526929872270};\\\", \\\"{x:1272,y:556,t:1526929872286};\\\", \\\"{x:1273,y:568,t:1526929872303};\\\", \\\"{x:1278,y:584,t:1526929872321};\\\", \\\"{x:1284,y:598,t:1526929872336};\\\", \\\"{x:1290,y:612,t:1526929872353};\\\", \\\"{x:1299,y:625,t:1526929872371};\\\", \\\"{x:1303,y:633,t:1526929872387};\\\", \\\"{x:1308,y:642,t:1526929872404};\\\", \\\"{x:1316,y:658,t:1526929872420};\\\", \\\"{x:1319,y:664,t:1526929872437};\\\", \\\"{x:1323,y:671,t:1526929872453};\\\", \\\"{x:1326,y:677,t:1526929872471};\\\", \\\"{x:1327,y:683,t:1526929872487};\\\", \\\"{x:1329,y:689,t:1526929872504};\\\", \\\"{x:1331,y:694,t:1526929872521};\\\", \\\"{x:1333,y:703,t:1526929872538};\\\", \\\"{x:1334,y:711,t:1526929872553};\\\", \\\"{x:1336,y:714,t:1526929872571};\\\", \\\"{x:1336,y:719,t:1526929872587};\\\", \\\"{x:1337,y:726,t:1526929872604};\\\", \\\"{x:1338,y:733,t:1526929872620};\\\", \\\"{x:1338,y:742,t:1526929872637};\\\", \\\"{x:1338,y:749,t:1526929872653};\\\", \\\"{x:1338,y:757,t:1526929872670};\\\", \\\"{x:1338,y:763,t:1526929872687};\\\", \\\"{x:1338,y:771,t:1526929872703};\\\", \\\"{x:1338,y:780,t:1526929872721};\\\", \\\"{x:1338,y:788,t:1526929872737};\\\", \\\"{x:1337,y:796,t:1526929872753};\\\", \\\"{x:1336,y:801,t:1526929872771};\\\", \\\"{x:1333,y:806,t:1526929872788};\\\", \\\"{x:1333,y:807,t:1526929872804};\\\", \\\"{x:1333,y:811,t:1526929872820};\\\", \\\"{x:1332,y:815,t:1526929872837};\\\", \\\"{x:1332,y:816,t:1526929872853};\\\", \\\"{x:1332,y:818,t:1526929872870};\\\", \\\"{x:1332,y:820,t:1526929872887};\\\", \\\"{x:1332,y:822,t:1526929872904};\\\", \\\"{x:1332,y:823,t:1526929872921};\\\", \\\"{x:1332,y:824,t:1526929872938};\\\", \\\"{x:1332,y:826,t:1526929872953};\\\", \\\"{x:1332,y:827,t:1526929873204};\\\", \\\"{x:1333,y:827,t:1526929873236};\\\", \\\"{x:1334,y:827,t:1526929873252};\\\", \\\"{x:1335,y:826,t:1526929873268};\\\", \\\"{x:1336,y:826,t:1526929873693};\\\", \\\"{x:1336,y:825,t:1526929873705};\\\", \\\"{x:1336,y:822,t:1526929873722};\\\", \\\"{x:1335,y:816,t:1526929873738};\\\", \\\"{x:1331,y:804,t:1526929873753};\\\", \\\"{x:1326,y:784,t:1526929873770};\\\", \\\"{x:1319,y:763,t:1526929873787};\\\", \\\"{x:1313,y:747,t:1526929873803};\\\", \\\"{x:1308,y:726,t:1526929873821};\\\", \\\"{x:1305,y:713,t:1526929873837};\\\", \\\"{x:1303,y:701,t:1526929873853};\\\", \\\"{x:1301,y:692,t:1526929873870};\\\", \\\"{x:1299,y:680,t:1526929873887};\\\", \\\"{x:1294,y:665,t:1526929873904};\\\", \\\"{x:1289,y:652,t:1526929873921};\\\", \\\"{x:1285,y:640,t:1526929873937};\\\", \\\"{x:1279,y:626,t:1526929873953};\\\", \\\"{x:1278,y:618,t:1526929873971};\\\", \\\"{x:1276,y:610,t:1526929873988};\\\", \\\"{x:1276,y:604,t:1526929874004};\\\", \\\"{x:1275,y:591,t:1526929874020};\\\", \\\"{x:1275,y:579,t:1526929874037};\\\", \\\"{x:1275,y:572,t:1526929874054};\\\", \\\"{x:1277,y:563,t:1526929874071};\\\", \\\"{x:1278,y:556,t:1526929874087};\\\", \\\"{x:1279,y:549,t:1526929874104};\\\", \\\"{x:1281,y:543,t:1526929874120};\\\", \\\"{x:1282,y:541,t:1526929874138};\\\", \\\"{x:1283,y:536,t:1526929874153};\\\", \\\"{x:1284,y:534,t:1526929874171};\\\", \\\"{x:1284,y:531,t:1526929874187};\\\", \\\"{x:1284,y:528,t:1526929874204};\\\", \\\"{x:1287,y:523,t:1526929874221};\\\", \\\"{x:1290,y:520,t:1526929874238};\\\", \\\"{x:1295,y:512,t:1526929874253};\\\", \\\"{x:1297,y:508,t:1526929874271};\\\", \\\"{x:1299,y:504,t:1526929874287};\\\", \\\"{x:1303,y:497,t:1526929874303};\\\", \\\"{x:1306,y:493,t:1526929874321};\\\", \\\"{x:1307,y:492,t:1526929874337};\\\", \\\"{x:1308,y:490,t:1526929874353};\\\", \\\"{x:1308,y:489,t:1526929874437};\\\", \\\"{x:1309,y:487,t:1526929874444};\\\", \\\"{x:1310,y:486,t:1526929874453};\\\", \\\"{x:1312,y:483,t:1526929874470};\\\", \\\"{x:1313,y:481,t:1526929874487};\\\", \\\"{x:1315,y:479,t:1526929874504};\\\", \\\"{x:1316,y:479,t:1526929874524};\\\", \\\"{x:1316,y:478,t:1526929874537};\\\", \\\"{x:1317,y:478,t:1526929874580};\\\", \\\"{x:1318,y:477,t:1526929874588};\\\", \\\"{x:1320,y:477,t:1526929874603};\\\", \\\"{x:1321,y:476,t:1526929874627};\\\", \\\"{x:1322,y:476,t:1526929874700};\\\", \\\"{x:1323,y:476,t:1526929874804};\\\", \\\"{x:1324,y:476,t:1526929874821};\\\", \\\"{x:1325,y:475,t:1526929874838};\\\", \\\"{x:1326,y:475,t:1526929875724};\\\", \\\"{x:1326,y:477,t:1526929875739};\\\", \\\"{x:1326,y:480,t:1526929875754};\\\", \\\"{x:1324,y:484,t:1526929875770};\\\", \\\"{x:1322,y:491,t:1526929875787};\\\", \\\"{x:1320,y:496,t:1526929875804};\\\", \\\"{x:1319,y:498,t:1526929875820};\\\", \\\"{x:1318,y:501,t:1526929875837};\\\", \\\"{x:1318,y:502,t:1526929875861};\\\", \\\"{x:1318,y:503,t:1526929875876};\\\", \\\"{x:1318,y:505,t:1526929875888};\\\", \\\"{x:1318,y:507,t:1526929875904};\\\", \\\"{x:1318,y:511,t:1526929875920};\\\", \\\"{x:1318,y:515,t:1526929875938};\\\", \\\"{x:1318,y:519,t:1526929875955};\\\", \\\"{x:1318,y:523,t:1526929875971};\\\", \\\"{x:1319,y:529,t:1526929875988};\\\", \\\"{x:1322,y:542,t:1526929876004};\\\", \\\"{x:1324,y:548,t:1526929876021};\\\", \\\"{x:1326,y:554,t:1526929876038};\\\", \\\"{x:1327,y:558,t:1526929876055};\\\", \\\"{x:1329,y:564,t:1526929876070};\\\", \\\"{x:1330,y:569,t:1526929876088};\\\", \\\"{x:1332,y:578,t:1526929876105};\\\", \\\"{x:1333,y:588,t:1526929876120};\\\", \\\"{x:1336,y:598,t:1526929876137};\\\", \\\"{x:1338,y:607,t:1526929876155};\\\", \\\"{x:1338,y:614,t:1526929876170};\\\", \\\"{x:1339,y:620,t:1526929876187};\\\", \\\"{x:1339,y:627,t:1526929876204};\\\", \\\"{x:1339,y:638,t:1526929876221};\\\", \\\"{x:1339,y:648,t:1526929876237};\\\", \\\"{x:1339,y:661,t:1526929876255};\\\", \\\"{x:1339,y:674,t:1526929876271};\\\", \\\"{x:1339,y:684,t:1526929876288};\\\", \\\"{x:1339,y:691,t:1526929876305};\\\", \\\"{x:1339,y:699,t:1526929876322};\\\", \\\"{x:1339,y:707,t:1526929876338};\\\", \\\"{x:1339,y:719,t:1526929876354};\\\", \\\"{x:1339,y:731,t:1526929876370};\\\", \\\"{x:1335,y:745,t:1526929876387};\\\", \\\"{x:1334,y:765,t:1526929876404};\\\", \\\"{x:1333,y:775,t:1526929876421};\\\", \\\"{x:1331,y:784,t:1526929876437};\\\", \\\"{x:1330,y:791,t:1526929876455};\\\", \\\"{x:1330,y:798,t:1526929876471};\\\", \\\"{x:1329,y:807,t:1526929876487};\\\", \\\"{x:1328,y:817,t:1526929876505};\\\", \\\"{x:1325,y:827,t:1526929876520};\\\", \\\"{x:1324,y:839,t:1526929876538};\\\", \\\"{x:1323,y:845,t:1526929876554};\\\", \\\"{x:1322,y:852,t:1526929876571};\\\", \\\"{x:1321,y:860,t:1526929876587};\\\", \\\"{x:1319,y:870,t:1526929876604};\\\", \\\"{x:1317,y:883,t:1526929876621};\\\", \\\"{x:1316,y:894,t:1526929876637};\\\", \\\"{x:1313,y:907,t:1526929876654};\\\", \\\"{x:1312,y:912,t:1526929876670};\\\", \\\"{x:1311,y:920,t:1526929876687};\\\", \\\"{x:1310,y:926,t:1526929876704};\\\", \\\"{x:1310,y:928,t:1526929876722};\\\", \\\"{x:1310,y:931,t:1526929876737};\\\", \\\"{x:1310,y:933,t:1526929876754};\\\", \\\"{x:1310,y:935,t:1526929876772};\\\", \\\"{x:1310,y:937,t:1526929876788};\\\", \\\"{x:1310,y:940,t:1526929876805};\\\", \\\"{x:1310,y:942,t:1526929876821};\\\", \\\"{x:1310,y:944,t:1526929876837};\\\", \\\"{x:1310,y:946,t:1526929876855};\\\", \\\"{x:1310,y:949,t:1526929876871};\\\", \\\"{x:1310,y:951,t:1526929876888};\\\", \\\"{x:1310,y:954,t:1526929876904};\\\", \\\"{x:1311,y:958,t:1526929876922};\\\", \\\"{x:1311,y:961,t:1526929876938};\\\", \\\"{x:1311,y:963,t:1526929876955};\\\", \\\"{x:1311,y:964,t:1526929876972};\\\", \\\"{x:1311,y:965,t:1526929876987};\\\", \\\"{x:1312,y:965,t:1526929877004};\\\", \\\"{x:1312,y:967,t:1526929877021};\\\", \\\"{x:1313,y:969,t:1526929877037};\\\", \\\"{x:1313,y:970,t:1526929877060};\\\", \\\"{x:1313,y:971,t:1526929877572};\\\", \\\"{x:1312,y:972,t:1526929877587};\\\", \\\"{x:1310,y:973,t:1526929877605};\\\", \\\"{x:1309,y:974,t:1526929877622};\\\", \\\"{x:1307,y:974,t:1526929877638};\\\", \\\"{x:1306,y:974,t:1526929877654};\\\", \\\"{x:1305,y:975,t:1526929877672};\\\", \\\"{x:1304,y:975,t:1526929877724};\\\", \\\"{x:1302,y:975,t:1526929877748};\\\", \\\"{x:1300,y:975,t:1526929877765};\\\", \\\"{x:1298,y:976,t:1526929877772};\\\", \\\"{x:1296,y:976,t:1526929877788};\\\", \\\"{x:1295,y:976,t:1526929877804};\\\", \\\"{x:1292,y:976,t:1526929877822};\\\", \\\"{x:1289,y:976,t:1526929877838};\\\", \\\"{x:1288,y:976,t:1526929877861};\\\", \\\"{x:1287,y:976,t:1526929877877};\\\", \\\"{x:1286,y:976,t:1526929877888};\\\", \\\"{x:1285,y:976,t:1526929877909};\\\", \\\"{x:1284,y:976,t:1526929877922};\\\", \\\"{x:1282,y:976,t:1526929877940};\\\", \\\"{x:1281,y:975,t:1526929878101};\\\", \\\"{x:1281,y:974,t:1526929878117};\\\", \\\"{x:1280,y:974,t:1526929878124};\\\", \\\"{x:1279,y:973,t:1526929878140};\\\", \\\"{x:1279,y:971,t:1526929878157};\\\", \\\"{x:1279,y:970,t:1526929878181};\\\", \\\"{x:1279,y:969,t:1526929878197};\\\", \\\"{x:1279,y:968,t:1526929878207};\\\", \\\"{x:1279,y:966,t:1526929878236};\\\", \\\"{x:1279,y:965,t:1526929878259};\\\", \\\"{x:1279,y:964,t:1526929878284};\\\", \\\"{x:1279,y:963,t:1526929878308};\\\", \\\"{x:1279,y:962,t:1526929878322};\\\", \\\"{x:1279,y:961,t:1526929878340};\\\", \\\"{x:1279,y:960,t:1526929878355};\\\", \\\"{x:1279,y:958,t:1526929878371};\\\", \\\"{x:1278,y:955,t:1526929878388};\\\", \\\"{x:1277,y:952,t:1526929878405};\\\", \\\"{x:1275,y:947,t:1526929878422};\\\", \\\"{x:1271,y:940,t:1526929878438};\\\", \\\"{x:1265,y:932,t:1526929878456};\\\", \\\"{x:1257,y:925,t:1526929878472};\\\", \\\"{x:1244,y:916,t:1526929878488};\\\", \\\"{x:1236,y:912,t:1526929878505};\\\", \\\"{x:1227,y:908,t:1526929878522};\\\", \\\"{x:1220,y:906,t:1526929878538};\\\", \\\"{x:1213,y:902,t:1526929878555};\\\", \\\"{x:1200,y:901,t:1526929878572};\\\", \\\"{x:1186,y:896,t:1526929878588};\\\", \\\"{x:1169,y:892,t:1526929878605};\\\", \\\"{x:1151,y:890,t:1526929878622};\\\", \\\"{x:1130,y:888,t:1526929878638};\\\", \\\"{x:1110,y:887,t:1526929878655};\\\", \\\"{x:1089,y:886,t:1526929878672};\\\", \\\"{x:1066,y:881,t:1526929878687};\\\", \\\"{x:1041,y:879,t:1526929878704};\\\", \\\"{x:1001,y:867,t:1526929878722};\\\", \\\"{x:954,y:853,t:1526929878738};\\\", \\\"{x:884,y:833,t:1526929878755};\\\", \\\"{x:762,y:798,t:1526929878772};\\\", \\\"{x:688,y:770,t:1526929878788};\\\", \\\"{x:625,y:746,t:1526929878805};\\\", \\\"{x:574,y:726,t:1526929878822};\\\", \\\"{x:537,y:714,t:1526929878839};\\\", \\\"{x:513,y:706,t:1526929878855};\\\", \\\"{x:491,y:698,t:1526929878872};\\\", \\\"{x:475,y:695,t:1526929878888};\\\", \\\"{x:457,y:691,t:1526929878913};\\\", \\\"{x:446,y:688,t:1526929878929};\\\", \\\"{x:439,y:688,t:1526929878946};\\\", \\\"{x:438,y:687,t:1526929878963};\\\", \\\"{x:436,y:687,t:1526929878979};\\\", \\\"{x:436,y:688,t:1526929879061};\\\", \\\"{x:436,y:690,t:1526929879069};\\\", \\\"{x:439,y:693,t:1526929879080};\\\", \\\"{x:443,y:697,t:1526929879096};\\\", \\\"{x:453,y:704,t:1526929879114};\\\", \\\"{x:465,y:712,t:1526929879130};\\\", \\\"{x:484,y:722,t:1526929879146};\\\", \\\"{x:503,y:728,t:1526929879162};\\\", \\\"{x:528,y:736,t:1526929879180};\\\", \\\"{x:533,y:737,t:1526929879196};\\\", \\\"{x:536,y:737,t:1526929879213};\\\", \\\"{x:537,y:737,t:1526929879429};\\\", \\\"{x:537,y:736,t:1526929879453};\\\", \\\"{x:537,y:734,t:1526929879478};\\\", \\\"{x:537,y:733,t:1526929879497};\\\", \\\"{x:535,y:732,t:1526929879513};\\\", \\\"{x:534,y:732,t:1526929879529};\\\", \\\"{x:532,y:731,t:1526929879546};\\\", \\\"{x:530,y:730,t:1526929879563};\\\", \\\"{x:529,y:728,t:1526929879579};\\\", \\\"{x:527,y:726,t:1526929879596};\\\", \\\"{x:526,y:726,t:1526929879613};\\\", \\\"{x:525,y:725,t:1526929879629};\\\", \\\"{x:526,y:725,t:1526929880612};\\\", \\\"{x:527,y:725,t:1526929880788};\\\", \\\"{x:529,y:725,t:1526929880805};\\\", \\\"{x:530,y:725,t:1526929880814};\\\", \\\"{x:534,y:726,t:1526929880831};\\\", \\\"{x:536,y:726,t:1526929880848};\\\", \\\"{x:539,y:727,t:1526929880865};\\\", \\\"{x:540,y:727,t:1526929880940};\\\", \\\"{x:543,y:728,t:1526929880947};\\\", \\\"{x:544,y:728,t:1526929880965};\\\", \\\"{x:546,y:728,t:1526929880980};\\\", \\\"{x:547,y:728,t:1526929881027};\\\", \\\"{x:549,y:729,t:1526929881036};\\\", \\\"{x:551,y:730,t:1526929881101};\\\", \\\"{x:552,y:730,t:1526929881132};\\\", \\\"{x:553,y:730,t:1526929881155};\\\" ] }, { \\\"rt\\\": 11604, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 242576, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -E -E -D -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:732,t:1526929881302};\\\", \\\"{x:561,y:734,t:1526929881315};\\\", \\\"{x:566,y:736,t:1526929881330};\\\", \\\"{x:575,y:742,t:1526929881348};\\\", \\\"{x:585,y:751,t:1526929881364};\\\", \\\"{x:601,y:762,t:1526929881392};\\\", \\\"{x:605,y:766,t:1526929881398};\\\", \\\"{x:612,y:774,t:1526929881414};\\\", \\\"{x:620,y:782,t:1526929881431};\\\", \\\"{x:626,y:793,t:1526929881447};\\\", \\\"{x:632,y:806,t:1526929881465};\\\", \\\"{x:638,y:820,t:1526929881482};\\\", \\\"{x:646,y:840,t:1526929881498};\\\", \\\"{x:650,y:854,t:1526929881515};\\\", \\\"{x:655,y:871,t:1526929881532};\\\", \\\"{x:656,y:877,t:1526929881547};\\\", \\\"{x:656,y:880,t:1526929881565};\\\", \\\"{x:657,y:882,t:1526929881581};\\\", \\\"{x:657,y:883,t:1526929881599};\\\", \\\"{x:657,y:884,t:1526929881636};\\\", \\\"{x:654,y:877,t:1526929882604};\\\", \\\"{x:648,y:865,t:1526929882616};\\\", \\\"{x:637,y:839,t:1526929882633};\\\", \\\"{x:621,y:813,t:1526929882649};\\\", \\\"{x:604,y:784,t:1526929882666};\\\", \\\"{x:582,y:755,t:1526929882684};\\\", \\\"{x:572,y:742,t:1526929882699};\\\", \\\"{x:563,y:728,t:1526929882717};\\\", \\\"{x:556,y:714,t:1526929882734};\\\", \\\"{x:547,y:700,t:1526929882749};\\\", \\\"{x:539,y:686,t:1526929882765};\\\", \\\"{x:530,y:671,t:1526929882782};\\\", \\\"{x:523,y:652,t:1526929882799};\\\", \\\"{x:516,y:627,t:1526929882816};\\\", \\\"{x:506,y:596,t:1526929882834};\\\", \\\"{x:499,y:566,t:1526929882850};\\\", \\\"{x:494,y:534,t:1526929882867};\\\", \\\"{x:489,y:506,t:1526929882883};\\\", \\\"{x:488,y:488,t:1526929882899};\\\", \\\"{x:489,y:465,t:1526929882915};\\\", \\\"{x:496,y:450,t:1526929882933};\\\", \\\"{x:505,y:436,t:1526929882949};\\\", \\\"{x:517,y:425,t:1526929882966};\\\", \\\"{x:530,y:416,t:1526929882982};\\\", \\\"{x:544,y:406,t:1526929882999};\\\", \\\"{x:554,y:402,t:1526929883016};\\\", \\\"{x:564,y:398,t:1526929883033};\\\", \\\"{x:574,y:396,t:1526929883049};\\\", \\\"{x:583,y:395,t:1526929883066};\\\", \\\"{x:590,y:395,t:1526929883083};\\\", \\\"{x:595,y:395,t:1526929883100};\\\", \\\"{x:598,y:395,t:1526929883115};\\\", \\\"{x:600,y:396,t:1526929883133};\\\", \\\"{x:604,y:398,t:1526929883150};\\\", \\\"{x:608,y:401,t:1526929883166};\\\", \\\"{x:611,y:404,t:1526929883183};\\\", \\\"{x:613,y:410,t:1526929883200};\\\", \\\"{x:614,y:415,t:1526929883215};\\\", \\\"{x:615,y:423,t:1526929883233};\\\", \\\"{x:614,y:431,t:1526929883250};\\\", \\\"{x:610,y:438,t:1526929883266};\\\", \\\"{x:604,y:448,t:1526929883284};\\\", \\\"{x:590,y:462,t:1526929883301};\\\", \\\"{x:578,y:472,t:1526929883317};\\\", \\\"{x:568,y:480,t:1526929883333};\\\", \\\"{x:558,y:487,t:1526929883351};\\\", \\\"{x:549,y:491,t:1526929883367};\\\", \\\"{x:541,y:496,t:1526929883383};\\\", \\\"{x:535,y:496,t:1526929883400};\\\", \\\"{x:529,y:499,t:1526929883417};\\\", \\\"{x:525,y:499,t:1526929883433};\\\", \\\"{x:524,y:499,t:1526929883450};\\\", \\\"{x:521,y:499,t:1526929883468};\\\", \\\"{x:519,y:499,t:1526929883483};\\\", \\\"{x:515,y:499,t:1526929883500};\\\", \\\"{x:511,y:499,t:1526929883516};\\\", \\\"{x:507,y:499,t:1526929883533};\\\", \\\"{x:501,y:499,t:1526929883549};\\\", \\\"{x:492,y:497,t:1526929883567};\\\", \\\"{x:485,y:494,t:1526929883582};\\\", \\\"{x:482,y:494,t:1526929883600};\\\", \\\"{x:480,y:492,t:1526929883616};\\\", \\\"{x:479,y:492,t:1526929883634};\\\", \\\"{x:478,y:492,t:1526929883649};\\\", \\\"{x:478,y:491,t:1526929883827};\\\", \\\"{x:478,y:490,t:1526929883836};\\\", \\\"{x:478,y:489,t:1526929883852};\\\", \\\"{x:479,y:488,t:1526929883867};\\\", \\\"{x:483,y:487,t:1526929883884};\\\", \\\"{x:485,y:486,t:1526929883900};\\\", \\\"{x:487,y:485,t:1526929883917};\\\", \\\"{x:488,y:485,t:1526929883933};\\\", \\\"{x:489,y:484,t:1526929883951};\\\", \\\"{x:493,y:483,t:1526929883966};\\\", \\\"{x:496,y:483,t:1526929883983};\\\", \\\"{x:497,y:483,t:1526929884001};\\\", \\\"{x:500,y:483,t:1526929884017};\\\", \\\"{x:504,y:481,t:1526929884034};\\\", \\\"{x:508,y:481,t:1526929884050};\\\", \\\"{x:510,y:481,t:1526929884067};\\\", \\\"{x:514,y:481,t:1526929884084};\\\", \\\"{x:516,y:481,t:1526929884100};\\\", \\\"{x:517,y:481,t:1526929884117};\\\", \\\"{x:519,y:481,t:1526929884133};\\\", \\\"{x:520,y:481,t:1526929884164};\\\", \\\"{x:520,y:480,t:1526929884179};\\\", \\\"{x:522,y:480,t:1526929884211};\\\", \\\"{x:523,y:480,t:1526929884227};\\\", \\\"{x:525,y:480,t:1526929884243};\\\", \\\"{x:526,y:480,t:1526929884268};\\\", \\\"{x:527,y:479,t:1526929884331};\\\", \\\"{x:528,y:479,t:1526929884340};\\\", \\\"{x:529,y:479,t:1526929884380};\\\", \\\"{x:530,y:478,t:1526929884396};\\\", \\\"{x:531,y:478,t:1526929884412};\\\", \\\"{x:532,y:477,t:1526929884436};\\\", \\\"{x:534,y:477,t:1526929884450};\\\", \\\"{x:538,y:477,t:1526929884468};\\\", \\\"{x:541,y:477,t:1526929884484};\\\", \\\"{x:546,y:477,t:1526929884500};\\\", \\\"{x:552,y:477,t:1526929884517};\\\", \\\"{x:557,y:477,t:1526929884533};\\\", \\\"{x:562,y:477,t:1526929884551};\\\", \\\"{x:571,y:479,t:1526929884567};\\\", \\\"{x:578,y:480,t:1526929884584};\\\", \\\"{x:585,y:480,t:1526929884600};\\\", \\\"{x:593,y:482,t:1526929884617};\\\", \\\"{x:602,y:483,t:1526929884635};\\\", \\\"{x:608,y:484,t:1526929884651};\\\", \\\"{x:614,y:485,t:1526929884667};\\\", \\\"{x:618,y:485,t:1526929884685};\\\", \\\"{x:622,y:486,t:1526929884701};\\\", \\\"{x:630,y:487,t:1526929884718};\\\", \\\"{x:645,y:490,t:1526929884735};\\\", \\\"{x:663,y:493,t:1526929884750};\\\", \\\"{x:693,y:500,t:1526929884767};\\\", \\\"{x:731,y:509,t:1526929884785};\\\", \\\"{x:778,y:521,t:1526929884801};\\\", \\\"{x:825,y:535,t:1526929884816};\\\", \\\"{x:873,y:548,t:1526929884832};\\\", \\\"{x:919,y:559,t:1526929884849};\\\", \\\"{x:967,y:575,t:1526929884867};\\\", \\\"{x:1047,y:602,t:1526929884884};\\\", \\\"{x:1094,y:615,t:1526929884901};\\\", \\\"{x:1142,y:630,t:1526929884918};\\\", \\\"{x:1183,y:642,t:1526929884934};\\\", \\\"{x:1212,y:650,t:1526929884951};\\\", \\\"{x:1249,y:661,t:1526929884967};\\\", \\\"{x:1269,y:667,t:1526929884984};\\\", \\\"{x:1295,y:674,t:1526929885001};\\\", \\\"{x:1321,y:682,t:1526929885017};\\\", \\\"{x:1347,y:689,t:1526929885033};\\\", \\\"{x:1370,y:696,t:1526929885050};\\\", \\\"{x:1405,y:705,t:1526929885068};\\\", \\\"{x:1423,y:712,t:1526929885084};\\\", \\\"{x:1442,y:717,t:1526929885100};\\\", \\\"{x:1457,y:721,t:1526929885118};\\\", \\\"{x:1467,y:726,t:1526929885135};\\\", \\\"{x:1470,y:726,t:1526929885151};\\\", \\\"{x:1475,y:728,t:1526929885168};\\\", \\\"{x:1475,y:729,t:1526929885185};\\\", \\\"{x:1477,y:731,t:1526929885201};\\\", \\\"{x:1479,y:732,t:1526929885218};\\\", \\\"{x:1485,y:734,t:1526929885235};\\\", \\\"{x:1487,y:736,t:1526929885250};\\\", \\\"{x:1489,y:737,t:1526929885268};\\\", \\\"{x:1490,y:738,t:1526929885315};\\\", \\\"{x:1490,y:739,t:1526929885323};\\\", \\\"{x:1488,y:739,t:1526929885372};\\\", \\\"{x:1485,y:739,t:1526929885385};\\\", \\\"{x:1480,y:739,t:1526929885402};\\\", \\\"{x:1472,y:738,t:1526929885417};\\\", \\\"{x:1456,y:730,t:1526929885434};\\\", \\\"{x:1428,y:714,t:1526929885451};\\\", \\\"{x:1411,y:701,t:1526929885468};\\\", \\\"{x:1404,y:695,t:1526929885485};\\\", \\\"{x:1398,y:688,t:1526929885502};\\\", \\\"{x:1390,y:677,t:1526929885518};\\\", \\\"{x:1383,y:666,t:1526929885535};\\\", \\\"{x:1377,y:653,t:1526929885552};\\\", \\\"{x:1372,y:642,t:1526929885568};\\\", \\\"{x:1364,y:632,t:1526929885585};\\\", \\\"{x:1360,y:623,t:1526929885601};\\\", \\\"{x:1359,y:615,t:1526929885619};\\\", \\\"{x:1354,y:606,t:1526929885635};\\\", \\\"{x:1349,y:595,t:1526929885652};\\\", \\\"{x:1346,y:585,t:1526929885669};\\\", \\\"{x:1342,y:580,t:1526929885686};\\\", \\\"{x:1342,y:574,t:1526929885702};\\\", \\\"{x:1341,y:570,t:1526929885719};\\\", \\\"{x:1340,y:568,t:1526929885736};\\\", \\\"{x:1339,y:565,t:1526929885752};\\\", \\\"{x:1339,y:563,t:1526929885769};\\\", \\\"{x:1339,y:558,t:1526929885785};\\\", \\\"{x:1339,y:556,t:1526929885801};\\\", \\\"{x:1340,y:553,t:1526929885819};\\\", \\\"{x:1344,y:548,t:1526929885836};\\\", \\\"{x:1347,y:545,t:1526929885851};\\\", \\\"{x:1350,y:543,t:1526929885869};\\\", \\\"{x:1355,y:540,t:1526929885886};\\\", \\\"{x:1364,y:536,t:1526929885902};\\\", \\\"{x:1374,y:534,t:1526929885919};\\\", \\\"{x:1384,y:530,t:1526929885936};\\\", \\\"{x:1392,y:529,t:1526929885952};\\\", \\\"{x:1398,y:527,t:1526929885969};\\\", \\\"{x:1400,y:527,t:1526929885986};\\\", \\\"{x:1402,y:528,t:1526929886002};\\\", \\\"{x:1403,y:531,t:1526929886019};\\\", \\\"{x:1405,y:537,t:1526929886036};\\\", \\\"{x:1405,y:547,t:1526929886053};\\\", \\\"{x:1405,y:556,t:1526929886069};\\\", \\\"{x:1405,y:565,t:1526929886087};\\\", \\\"{x:1405,y:573,t:1526929886103};\\\", \\\"{x:1405,y:582,t:1526929886119};\\\", \\\"{x:1403,y:595,t:1526929886136};\\\", \\\"{x:1399,y:606,t:1526929886153};\\\", \\\"{x:1393,y:620,t:1526929886169};\\\", \\\"{x:1388,y:639,t:1526929886186};\\\", \\\"{x:1383,y:655,t:1526929886203};\\\", \\\"{x:1380,y:668,t:1526929886219};\\\", \\\"{x:1376,y:687,t:1526929886236};\\\", \\\"{x:1376,y:695,t:1526929886253};\\\", \\\"{x:1374,y:706,t:1526929886269};\\\", \\\"{x:1374,y:714,t:1526929886286};\\\", \\\"{x:1374,y:728,t:1526929886303};\\\", \\\"{x:1375,y:737,t:1526929886319};\\\", \\\"{x:1378,y:743,t:1526929886336};\\\", \\\"{x:1381,y:747,t:1526929886353};\\\", \\\"{x:1386,y:751,t:1526929886371};\\\", \\\"{x:1393,y:754,t:1526929886386};\\\", \\\"{x:1404,y:757,t:1526929886403};\\\", \\\"{x:1442,y:769,t:1526929886420};\\\", \\\"{x:1477,y:778,t:1526929886436};\\\", \\\"{x:1508,y:785,t:1526929886453};\\\", \\\"{x:1542,y:789,t:1526929886470};\\\", \\\"{x:1570,y:789,t:1526929886486};\\\", \\\"{x:1601,y:789,t:1526929886503};\\\", \\\"{x:1630,y:789,t:1526929886521};\\\", \\\"{x:1654,y:789,t:1526929886537};\\\", \\\"{x:1675,y:789,t:1526929886553};\\\", \\\"{x:1689,y:783,t:1526929886570};\\\", \\\"{x:1699,y:775,t:1526929886587};\\\", \\\"{x:1711,y:770,t:1526929886603};\\\", \\\"{x:1722,y:764,t:1526929886620};\\\", \\\"{x:1727,y:760,t:1526929886637};\\\", \\\"{x:1730,y:756,t:1526929886652};\\\", \\\"{x:1732,y:754,t:1526929886670};\\\", \\\"{x:1734,y:746,t:1526929886687};\\\", \\\"{x:1734,y:741,t:1526929886703};\\\", \\\"{x:1734,y:733,t:1526929886720};\\\", \\\"{x:1733,y:726,t:1526929886737};\\\", \\\"{x:1730,y:718,t:1526929886754};\\\", \\\"{x:1724,y:710,t:1526929886770};\\\", \\\"{x:1718,y:701,t:1526929886787};\\\", \\\"{x:1701,y:682,t:1526929886803};\\\", \\\"{x:1688,y:670,t:1526929886819};\\\", \\\"{x:1678,y:661,t:1526929886837};\\\", \\\"{x:1671,y:654,t:1526929886854};\\\", \\\"{x:1664,y:647,t:1526929886870};\\\", \\\"{x:1658,y:640,t:1526929886887};\\\", \\\"{x:1651,y:632,t:1526929886904};\\\", \\\"{x:1644,y:627,t:1526929886920};\\\", \\\"{x:1640,y:622,t:1526929886937};\\\", \\\"{x:1635,y:616,t:1526929886953};\\\", \\\"{x:1633,y:614,t:1526929886971};\\\", \\\"{x:1630,y:609,t:1526929886986};\\\", \\\"{x:1626,y:604,t:1526929887003};\\\", \\\"{x:1623,y:597,t:1526929887021};\\\", \\\"{x:1622,y:594,t:1526929887037};\\\", \\\"{x:1618,y:587,t:1526929887054};\\\", \\\"{x:1615,y:580,t:1526929887071};\\\", \\\"{x:1613,y:571,t:1526929887086};\\\", \\\"{x:1611,y:562,t:1526929887105};\\\", \\\"{x:1610,y:548,t:1526929887121};\\\", \\\"{x:1608,y:531,t:1526929887136};\\\", \\\"{x:1608,y:513,t:1526929887154};\\\", \\\"{x:1609,y:494,t:1526929887170};\\\", \\\"{x:1611,y:464,t:1526929887187};\\\", \\\"{x:1614,y:446,t:1526929887204};\\\", \\\"{x:1618,y:431,t:1526929887221};\\\", \\\"{x:1623,y:417,t:1526929887238};\\\", \\\"{x:1624,y:411,t:1526929887254};\\\", \\\"{x:1627,y:406,t:1526929887271};\\\", \\\"{x:1627,y:402,t:1526929887288};\\\", \\\"{x:1627,y:401,t:1526929887388};\\\", \\\"{x:1627,y:400,t:1526929887524};\\\", \\\"{x:1626,y:400,t:1526929887538};\\\", \\\"{x:1626,y:404,t:1526929887555};\\\", \\\"{x:1625,y:409,t:1526929887571};\\\", \\\"{x:1623,y:416,t:1526929887588};\\\", \\\"{x:1623,y:420,t:1526929887604};\\\", \\\"{x:1624,y:428,t:1526929887621};\\\", \\\"{x:1627,y:433,t:1526929887637};\\\", \\\"{x:1629,y:442,t:1526929887655};\\\", \\\"{x:1631,y:450,t:1526929887671};\\\", \\\"{x:1632,y:457,t:1526929887687};\\\", \\\"{x:1635,y:463,t:1526929887705};\\\", \\\"{x:1635,y:470,t:1526929887721};\\\", \\\"{x:1637,y:476,t:1526929887738};\\\", \\\"{x:1639,y:481,t:1526929887755};\\\", \\\"{x:1641,y:490,t:1526929887771};\\\", \\\"{x:1644,y:497,t:1526929887788};\\\", \\\"{x:1644,y:502,t:1526929887804};\\\", \\\"{x:1645,y:507,t:1526929887822};\\\", \\\"{x:1645,y:514,t:1526929887837};\\\", \\\"{x:1647,y:521,t:1526929887855};\\\", \\\"{x:1646,y:530,t:1526929887871};\\\", \\\"{x:1645,y:537,t:1526929887888};\\\", \\\"{x:1643,y:542,t:1526929887905};\\\", \\\"{x:1642,y:548,t:1526929887922};\\\", \\\"{x:1640,y:554,t:1526929887939};\\\", \\\"{x:1639,y:558,t:1526929887955};\\\", \\\"{x:1636,y:568,t:1526929887972};\\\", \\\"{x:1634,y:573,t:1526929887989};\\\", \\\"{x:1634,y:577,t:1526929888005};\\\", \\\"{x:1632,y:582,t:1526929888022};\\\", \\\"{x:1631,y:583,t:1526929888039};\\\", \\\"{x:1630,y:586,t:1526929888055};\\\", \\\"{x:1629,y:587,t:1526929888072};\\\", \\\"{x:1628,y:588,t:1526929888091};\\\", \\\"{x:1628,y:589,t:1526929888156};\\\", \\\"{x:1627,y:589,t:1526929888180};\\\", \\\"{x:1627,y:588,t:1526929888189};\\\", \\\"{x:1625,y:587,t:1526929888206};\\\", \\\"{x:1622,y:585,t:1526929888222};\\\", \\\"{x:1621,y:584,t:1526929888239};\\\", \\\"{x:1619,y:581,t:1526929888256};\\\", \\\"{x:1618,y:577,t:1526929888271};\\\", \\\"{x:1617,y:576,t:1526929888288};\\\", \\\"{x:1616,y:574,t:1526929888306};\\\", \\\"{x:1615,y:572,t:1526929888322};\\\", \\\"{x:1615,y:570,t:1526929888339};\\\", \\\"{x:1614,y:570,t:1526929888356};\\\", \\\"{x:1614,y:569,t:1526929888379};\\\", \\\"{x:1613,y:569,t:1526929888389};\\\", \\\"{x:1613,y:568,t:1526929888406};\\\", \\\"{x:1613,y:567,t:1526929888443};\\\", \\\"{x:1612,y:567,t:1526929888708};\\\", \\\"{x:1610,y:567,t:1526929888723};\\\", \\\"{x:1596,y:569,t:1526929888740};\\\", \\\"{x:1572,y:571,t:1526929888756};\\\", \\\"{x:1511,y:574,t:1526929888773};\\\", \\\"{x:1414,y:577,t:1526929888790};\\\", \\\"{x:1292,y:590,t:1526929888806};\\\", \\\"{x:1147,y:600,t:1526929888823};\\\", \\\"{x:1009,y:615,t:1526929888840};\\\", \\\"{x:893,y:632,t:1526929888857};\\\", \\\"{x:804,y:645,t:1526929888872};\\\", \\\"{x:775,y:648,t:1526929888890};\\\", \\\"{x:758,y:651,t:1526929888907};\\\", \\\"{x:753,y:651,t:1526929888922};\\\", \\\"{x:748,y:652,t:1526929888939};\\\", \\\"{x:741,y:652,t:1526929888957};\\\", \\\"{x:719,y:651,t:1526929888973};\\\", \\\"{x:690,y:644,t:1526929888990};\\\", \\\"{x:635,y:632,t:1526929889007};\\\", \\\"{x:577,y:617,t:1526929889023};\\\", \\\"{x:544,y:610,t:1526929889034};\\\", \\\"{x:491,y:602,t:1526929889051};\\\", \\\"{x:447,y:597,t:1526929889071};\\\", \\\"{x:433,y:596,t:1526929889087};\\\", \\\"{x:429,y:594,t:1526929889104};\\\", \\\"{x:427,y:592,t:1526929889121};\\\", \\\"{x:425,y:591,t:1526929889136};\\\", \\\"{x:418,y:587,t:1526929889153};\\\", \\\"{x:402,y:578,t:1526929889172};\\\", \\\"{x:388,y:571,t:1526929889188};\\\", \\\"{x:364,y:558,t:1526929889204};\\\", \\\"{x:352,y:553,t:1526929889221};\\\", \\\"{x:339,y:550,t:1526929889237};\\\", \\\"{x:327,y:546,t:1526929889254};\\\", \\\"{x:316,y:545,t:1526929889271};\\\", \\\"{x:305,y:543,t:1526929889288};\\\", \\\"{x:292,y:543,t:1526929889304};\\\", \\\"{x:281,y:543,t:1526929889321};\\\", \\\"{x:269,y:543,t:1526929889337};\\\", \\\"{x:260,y:543,t:1526929889355};\\\", \\\"{x:248,y:543,t:1526929889371};\\\", \\\"{x:226,y:543,t:1526929889388};\\\", \\\"{x:216,y:543,t:1526929889405};\\\", \\\"{x:203,y:543,t:1526929889421};\\\", \\\"{x:192,y:543,t:1526929889437};\\\", \\\"{x:179,y:543,t:1526929889455};\\\", \\\"{x:167,y:543,t:1526929889472};\\\", \\\"{x:158,y:548,t:1526929889488};\\\", \\\"{x:153,y:551,t:1526929889506};\\\", \\\"{x:149,y:554,t:1526929889521};\\\", \\\"{x:147,y:557,t:1526929889538};\\\", \\\"{x:146,y:560,t:1526929889553};\\\", \\\"{x:146,y:565,t:1526929889570};\\\", \\\"{x:146,y:570,t:1526929889587};\\\", \\\"{x:146,y:574,t:1526929889604};\\\", \\\"{x:146,y:579,t:1526929889621};\\\", \\\"{x:149,y:585,t:1526929889638};\\\", \\\"{x:151,y:588,t:1526929889654};\\\", \\\"{x:156,y:591,t:1526929889670};\\\", \\\"{x:158,y:593,t:1526929889688};\\\", \\\"{x:163,y:595,t:1526929889704};\\\", \\\"{x:164,y:597,t:1526929889721};\\\", \\\"{x:166,y:599,t:1526929889738};\\\", \\\"{x:166,y:600,t:1526929889754};\\\", \\\"{x:166,y:602,t:1526929889774};\\\", \\\"{x:166,y:603,t:1526929889791};\\\", \\\"{x:166,y:605,t:1526929889807};\\\", \\\"{x:166,y:607,t:1526929889824};\\\", \\\"{x:166,y:608,t:1526929889841};\\\", \\\"{x:166,y:610,t:1526929889858};\\\", \\\"{x:166,y:613,t:1526929889875};\\\", \\\"{x:166,y:614,t:1526929889891};\\\", \\\"{x:166,y:616,t:1526929889911};\\\", \\\"{x:166,y:617,t:1526929889928};\\\", \\\"{x:166,y:618,t:1526929889941};\\\", \\\"{x:165,y:619,t:1526929889958};\\\", \\\"{x:165,y:621,t:1526929890056};\\\", \\\"{x:164,y:622,t:1526929890095};\\\", \\\"{x:164,y:623,t:1526929890111};\\\", \\\"{x:164,y:624,t:1526929890135};\\\", \\\"{x:164,y:625,t:1526929890151};\\\", \\\"{x:164,y:626,t:1526929890167};\\\", \\\"{x:164,y:627,t:1526929890183};\\\", \\\"{x:164,y:628,t:1526929890231};\\\", \\\"{x:165,y:630,t:1526929891744};\\\", \\\"{x:190,y:634,t:1526929891760};\\\", \\\"{x:233,y:644,t:1526929891777};\\\", \\\"{x:275,y:656,t:1526929891794};\\\", \\\"{x:318,y:665,t:1526929891809};\\\", \\\"{x:351,y:674,t:1526929891827};\\\", \\\"{x:371,y:679,t:1526929891844};\\\", \\\"{x:384,y:682,t:1526929891860};\\\", \\\"{x:392,y:682,t:1526929891876};\\\", \\\"{x:403,y:682,t:1526929891894};\\\", \\\"{x:418,y:682,t:1526929891909};\\\", \\\"{x:437,y:684,t:1526929891927};\\\", \\\"{x:470,y:685,t:1526929891943};\\\", \\\"{x:492,y:685,t:1526929891959};\\\", \\\"{x:511,y:685,t:1526929891977};\\\", \\\"{x:522,y:685,t:1526929891993};\\\", \\\"{x:529,y:685,t:1526929892010};\\\", \\\"{x:532,y:685,t:1526929892026};\\\", \\\"{x:536,y:685,t:1526929892043};\\\", \\\"{x:538,y:683,t:1526929892059};\\\", \\\"{x:540,y:682,t:1526929892077};\\\", \\\"{x:543,y:678,t:1526929892093};\\\", \\\"{x:543,y:675,t:1526929892110};\\\", \\\"{x:544,y:671,t:1526929892127};\\\", \\\"{x:544,y:662,t:1526929892143};\\\", \\\"{x:537,y:654,t:1526929892160};\\\", \\\"{x:528,y:650,t:1526929892178};\\\", \\\"{x:520,y:647,t:1526929892193};\\\", \\\"{x:514,y:646,t:1526929892210};\\\", \\\"{x:510,y:646,t:1526929892227};\\\", \\\"{x:508,y:646,t:1526929892244};\\\", \\\"{x:505,y:648,t:1526929892260};\\\", \\\"{x:504,y:651,t:1526929892278};\\\", \\\"{x:502,y:656,t:1526929892294};\\\", \\\"{x:502,y:661,t:1526929892310};\\\", \\\"{x:502,y:668,t:1526929892328};\\\", \\\"{x:502,y:679,t:1526929892343};\\\", \\\"{x:504,y:684,t:1526929892361};\\\", \\\"{x:507,y:690,t:1526929892377};\\\", \\\"{x:508,y:695,t:1526929892394};\\\", \\\"{x:510,y:700,t:1526929892411};\\\", \\\"{x:511,y:704,t:1526929892428};\\\", \\\"{x:512,y:710,t:1526929892443};\\\", \\\"{x:513,y:711,t:1526929892460};\\\", \\\"{x:514,y:712,t:1526929892476};\\\", \\\"{x:514,y:713,t:1526929892527};\\\", \\\"{x:514,y:714,t:1526929893143};\\\", \\\"{x:514,y:713,t:1526929893167};\\\", \\\"{x:513,y:713,t:1526929893182};\\\", \\\"{x:512,y:712,t:1526929893206};\\\", \\\"{x:511,y:711,t:1526929893215};\\\", \\\"{x:509,y:708,t:1526929893228};\\\", \\\"{x:501,y:704,t:1526929893244};\\\", \\\"{x:491,y:699,t:1526929893261};\\\", \\\"{x:477,y:693,t:1526929893277};\\\", \\\"{x:461,y:683,t:1526929893294};\\\", \\\"{x:458,y:680,t:1526929893310};\\\", \\\"{x:453,y:677,t:1526929893327};\\\", \\\"{x:450,y:675,t:1526929893345};\\\", \\\"{x:445,y:672,t:1526929893361};\\\", \\\"{x:439,y:669,t:1526929893377};\\\", \\\"{x:428,y:664,t:1526929893394};\\\", \\\"{x:420,y:662,t:1526929893411};\\\", \\\"{x:411,y:659,t:1526929893427};\\\", \\\"{x:406,y:656,t:1526929893444};\\\", \\\"{x:400,y:655,t:1526929893461};\\\", \\\"{x:397,y:653,t:1526929893477};\\\", \\\"{x:395,y:653,t:1526929893494};\\\", \\\"{x:394,y:653,t:1526929893519};\\\", \\\"{x:393,y:653,t:1526929893527};\\\", \\\"{x:391,y:653,t:1526929893544};\\\", \\\"{x:391,y:652,t:1526929893561};\\\", \\\"{x:390,y:652,t:1526929893577};\\\", \\\"{x:388,y:652,t:1526929893595};\\\", \\\"{x:387,y:652,t:1526929893611};\\\", \\\"{x:386,y:651,t:1526929893628};\\\", \\\"{x:385,y:651,t:1526929893644};\\\", \\\"{x:384,y:651,t:1526929893720};\\\", \\\"{x:383,y:651,t:1526929893776};\\\", \\\"{x:382,y:651,t:1526929893824};\\\", \\\"{x:381,y:651,t:1526929893864};\\\", \\\"{x:380,y:651,t:1526929893942};\\\" ] }, { \\\"rt\\\": 28660, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 272445, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -Z -C -C -A -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:377,y:651,t:1526929894115};\\\", \\\"{x:376,y:651,t:1526929894198};\\\", \\\"{x:375,y:652,t:1526929894230};\\\", \\\"{x:374,y:652,t:1526929894303};\\\", \\\"{x:374,y:653,t:1526929894335};\\\", \\\"{x:373,y:654,t:1526929894367};\\\", \\\"{x:373,y:655,t:1526929894391};\\\", \\\"{x:372,y:655,t:1526929894399};\\\", \\\"{x:371,y:656,t:1526929894438};\\\", \\\"{x:369,y:657,t:1526929895183};\\\", \\\"{x:365,y:657,t:1526929895196};\\\", \\\"{x:354,y:657,t:1526929895212};\\\", \\\"{x:338,y:652,t:1526929895229};\\\", \\\"{x:321,y:648,t:1526929895246};\\\", \\\"{x:302,y:642,t:1526929895262};\\\", \\\"{x:293,y:640,t:1526929895279};\\\", \\\"{x:289,y:638,t:1526929895296};\\\", \\\"{x:285,y:637,t:1526929895313};\\\", \\\"{x:282,y:637,t:1526929895329};\\\", \\\"{x:278,y:637,t:1526929895346};\\\", \\\"{x:271,y:636,t:1526929895364};\\\", \\\"{x:264,y:634,t:1526929895379};\\\", \\\"{x:259,y:633,t:1526929895396};\\\", \\\"{x:256,y:633,t:1526929895413};\\\", \\\"{x:253,y:630,t:1526929895429};\\\", \\\"{x:251,y:629,t:1526929895463};\\\", \\\"{x:250,y:629,t:1526929895559};\\\", \\\"{x:249,y:629,t:1526929895631};\\\", \\\"{x:249,y:628,t:1526929895645};\\\", \\\"{x:248,y:627,t:1526929895663};\\\", \\\"{x:248,y:624,t:1526929895680};\\\", \\\"{x:250,y:619,t:1526929895696};\\\", \\\"{x:258,y:611,t:1526929895713};\\\", \\\"{x:274,y:603,t:1526929895730};\\\", \\\"{x:294,y:592,t:1526929895746};\\\", \\\"{x:320,y:581,t:1526929895763};\\\", \\\"{x:350,y:569,t:1526929895780};\\\", \\\"{x:385,y:557,t:1526929895797};\\\", \\\"{x:431,y:540,t:1526929895813};\\\", \\\"{x:478,y:528,t:1526929895830};\\\", \\\"{x:531,y:512,t:1526929895847};\\\", \\\"{x:569,y:503,t:1526929895863};\\\", \\\"{x:598,y:497,t:1526929895880};\\\", \\\"{x:619,y:493,t:1526929895897};\\\", \\\"{x:626,y:493,t:1526929895913};\\\", \\\"{x:628,y:493,t:1526929895930};\\\", \\\"{x:629,y:493,t:1526929895947};\\\", \\\"{x:625,y:490,t:1526929896183};\\\", \\\"{x:623,y:488,t:1526929896198};\\\", \\\"{x:612,y:480,t:1526929896214};\\\", \\\"{x:598,y:472,t:1526929896231};\\\", \\\"{x:591,y:470,t:1526929896247};\\\", \\\"{x:587,y:469,t:1526929896264};\\\", \\\"{x:584,y:469,t:1526929896281};\\\", \\\"{x:583,y:469,t:1526929896303};\\\", \\\"{x:582,y:469,t:1526929896315};\\\", \\\"{x:584,y:470,t:1526929896408};\\\", \\\"{x:593,y:471,t:1526929896415};\\\", \\\"{x:619,y:474,t:1526929896432};\\\", \\\"{x:678,y:483,t:1526929896448};\\\", \\\"{x:767,y:496,t:1526929896465};\\\", \\\"{x:866,y:506,t:1526929896483};\\\", \\\"{x:985,y:506,t:1526929896499};\\\", \\\"{x:1080,y:508,t:1526929896513};\\\", \\\"{x:1177,y:508,t:1526929896530};\\\", \\\"{x:1266,y:508,t:1526929896547};\\\", \\\"{x:1346,y:500,t:1526929896564};\\\", \\\"{x:1419,y:487,t:1526929896580};\\\", \\\"{x:1470,y:478,t:1526929896597};\\\", \\\"{x:1516,y:468,t:1526929896614};\\\", \\\"{x:1562,y:446,t:1526929896631};\\\", \\\"{x:1585,y:432,t:1526929896647};\\\", \\\"{x:1603,y:420,t:1526929896663};\\\", \\\"{x:1613,y:411,t:1526929896681};\\\", \\\"{x:1618,y:405,t:1526929896698};\\\", \\\"{x:1619,y:404,t:1526929896714};\\\", \\\"{x:1616,y:404,t:1526929896808};\\\", \\\"{x:1610,y:408,t:1526929896815};\\\", \\\"{x:1601,y:414,t:1526929896831};\\\", \\\"{x:1589,y:420,t:1526929896847};\\\", \\\"{x:1572,y:429,t:1526929896864};\\\", \\\"{x:1552,y:440,t:1526929896881};\\\", \\\"{x:1529,y:455,t:1526929896897};\\\", \\\"{x:1499,y:479,t:1526929896914};\\\", \\\"{x:1465,y:501,t:1526929896931};\\\", \\\"{x:1436,y:524,t:1526929896947};\\\", \\\"{x:1416,y:543,t:1526929896963};\\\", \\\"{x:1398,y:559,t:1526929896980};\\\", \\\"{x:1385,y:571,t:1526929896998};\\\", \\\"{x:1373,y:585,t:1526929897014};\\\", \\\"{x:1359,y:603,t:1526929897031};\\\", \\\"{x:1352,y:614,t:1526929897047};\\\", \\\"{x:1345,y:627,t:1526929897064};\\\", \\\"{x:1339,y:637,t:1526929897081};\\\", \\\"{x:1332,y:652,t:1526929897098};\\\", \\\"{x:1325,y:664,t:1526929897114};\\\", \\\"{x:1324,y:672,t:1526929897131};\\\", \\\"{x:1323,y:678,t:1526929897148};\\\", \\\"{x:1323,y:683,t:1526929897164};\\\", \\\"{x:1323,y:688,t:1526929897181};\\\", \\\"{x:1323,y:696,t:1526929897198};\\\", \\\"{x:1323,y:713,t:1526929897215};\\\", \\\"{x:1324,y:722,t:1526929897231};\\\", \\\"{x:1329,y:730,t:1526929897248};\\\", \\\"{x:1330,y:736,t:1526929897265};\\\", \\\"{x:1334,y:744,t:1526929897281};\\\", \\\"{x:1338,y:753,t:1526929897298};\\\", \\\"{x:1339,y:761,t:1526929897315};\\\", \\\"{x:1342,y:771,t:1526929897332};\\\", \\\"{x:1343,y:782,t:1526929897348};\\\", \\\"{x:1345,y:802,t:1526929897366};\\\", \\\"{x:1348,y:817,t:1526929897382};\\\", \\\"{x:1349,y:826,t:1526929897399};\\\", \\\"{x:1350,y:839,t:1526929897416};\\\", \\\"{x:1350,y:843,t:1526929897432};\\\", \\\"{x:1350,y:847,t:1526929897448};\\\", \\\"{x:1350,y:850,t:1526929897466};\\\", \\\"{x:1350,y:852,t:1526929897482};\\\", \\\"{x:1350,y:856,t:1526929897498};\\\", \\\"{x:1350,y:857,t:1526929897515};\\\", \\\"{x:1350,y:859,t:1526929897535};\\\", \\\"{x:1350,y:860,t:1526929897550};\\\", \\\"{x:1349,y:864,t:1526929897565};\\\", \\\"{x:1348,y:865,t:1526929897582};\\\", \\\"{x:1348,y:867,t:1526929897598};\\\", \\\"{x:1348,y:869,t:1526929897615};\\\", \\\"{x:1347,y:870,t:1526929897632};\\\", \\\"{x:1347,y:872,t:1526929897648};\\\", \\\"{x:1346,y:875,t:1526929897665};\\\", \\\"{x:1345,y:877,t:1526929897681};\\\", \\\"{x:1344,y:882,t:1526929897698};\\\", \\\"{x:1344,y:886,t:1526929897715};\\\", \\\"{x:1342,y:891,t:1526929897732};\\\", \\\"{x:1341,y:895,t:1526929897748};\\\", \\\"{x:1341,y:901,t:1526929897765};\\\", \\\"{x:1339,y:911,t:1526929897781};\\\", \\\"{x:1338,y:921,t:1526929897798};\\\", \\\"{x:1338,y:933,t:1526929897814};\\\", \\\"{x:1337,y:938,t:1526929897832};\\\", \\\"{x:1337,y:940,t:1526929897847};\\\", \\\"{x:1337,y:944,t:1526929897865};\\\", \\\"{x:1337,y:946,t:1526929897882};\\\", \\\"{x:1337,y:948,t:1526929897898};\\\", \\\"{x:1337,y:953,t:1526929897915};\\\", \\\"{x:1336,y:956,t:1526929897932};\\\", \\\"{x:1336,y:958,t:1526929897949};\\\", \\\"{x:1336,y:961,t:1526929897964};\\\", \\\"{x:1336,y:963,t:1526929897981};\\\", \\\"{x:1336,y:964,t:1526929897999};\\\", \\\"{x:1337,y:964,t:1526929898095};\\\", \\\"{x:1338,y:964,t:1526929898111};\\\", \\\"{x:1339,y:964,t:1526929898119};\\\", \\\"{x:1340,y:964,t:1526929898135};\\\", \\\"{x:1341,y:963,t:1526929898149};\\\", \\\"{x:1342,y:963,t:1526929898164};\\\", \\\"{x:1343,y:963,t:1526929898191};\\\", \\\"{x:1343,y:961,t:1526929898199};\\\", \\\"{x:1343,y:956,t:1526929898215};\\\", \\\"{x:1343,y:950,t:1526929898232};\\\", \\\"{x:1343,y:946,t:1526929898249};\\\", \\\"{x:1343,y:942,t:1526929898265};\\\", \\\"{x:1343,y:939,t:1526929898282};\\\", \\\"{x:1341,y:931,t:1526929898299};\\\", \\\"{x:1338,y:922,t:1526929898316};\\\", \\\"{x:1334,y:911,t:1526929898332};\\\", \\\"{x:1329,y:902,t:1526929898349};\\\", \\\"{x:1325,y:898,t:1526929898366};\\\", \\\"{x:1324,y:896,t:1526929898382};\\\", \\\"{x:1322,y:892,t:1526929898399};\\\", \\\"{x:1320,y:890,t:1526929898416};\\\", \\\"{x:1317,y:884,t:1526929898432};\\\", \\\"{x:1307,y:869,t:1526929898449};\\\", \\\"{x:1297,y:855,t:1526929898465};\\\", \\\"{x:1282,y:846,t:1526929898481};\\\", \\\"{x:1267,y:837,t:1526929898499};\\\", \\\"{x:1255,y:833,t:1526929898516};\\\", \\\"{x:1246,y:830,t:1526929898532};\\\", \\\"{x:1235,y:825,t:1526929898549};\\\", \\\"{x:1226,y:822,t:1526929898566};\\\", \\\"{x:1214,y:820,t:1526929898582};\\\", \\\"{x:1204,y:820,t:1526929898599};\\\", \\\"{x:1200,y:820,t:1526929898616};\\\", \\\"{x:1199,y:820,t:1526929898632};\\\", \\\"{x:1198,y:820,t:1526929898649};\\\", \\\"{x:1198,y:821,t:1526929898687};\\\", \\\"{x:1198,y:822,t:1526929898703};\\\", \\\"{x:1198,y:824,t:1526929898716};\\\", \\\"{x:1197,y:827,t:1526929898733};\\\", \\\"{x:1197,y:832,t:1526929898748};\\\", \\\"{x:1198,y:833,t:1526929898766};\\\", \\\"{x:1201,y:836,t:1526929898783};\\\", \\\"{x:1203,y:838,t:1526929898798};\\\", \\\"{x:1205,y:840,t:1526929898816};\\\", \\\"{x:1207,y:841,t:1526929898839};\\\", \\\"{x:1208,y:841,t:1526929898863};\\\", \\\"{x:1208,y:842,t:1526929898871};\\\", \\\"{x:1210,y:842,t:1526929898887};\\\", \\\"{x:1211,y:842,t:1526929898911};\\\", \\\"{x:1213,y:842,t:1526929898943};\\\", \\\"{x:1214,y:842,t:1526929898959};\\\", \\\"{x:1214,y:841,t:1526929898983};\\\", \\\"{x:1215,y:841,t:1526929898999};\\\", \\\"{x:1216,y:840,t:1526929899015};\\\", \\\"{x:1217,y:840,t:1526929899033};\\\", \\\"{x:1220,y:836,t:1526929899050};\\\", \\\"{x:1221,y:835,t:1526929899067};\\\", \\\"{x:1223,y:834,t:1526929899083};\\\", \\\"{x:1223,y:833,t:1526929899103};\\\", \\\"{x:1223,y:832,t:1526929899119};\\\", \\\"{x:1224,y:831,t:1526929899133};\\\", \\\"{x:1223,y:831,t:1526929901039};\\\", \\\"{x:1223,y:832,t:1526929901103};\\\", \\\"{x:1222,y:832,t:1526929901159};\\\", \\\"{x:1221,y:832,t:1526929901223};\\\", \\\"{x:1220,y:832,t:1526929901279};\\\", \\\"{x:1219,y:833,t:1526929901354};\\\", \\\"{x:1218,y:833,t:1526929901479};\\\", \\\"{x:1217,y:834,t:1526929902312};\\\", \\\"{x:1215,y:834,t:1526929902576};\\\", \\\"{x:1214,y:834,t:1526929902672};\\\", \\\"{x:1214,y:833,t:1526929902943};\\\", \\\"{x:1214,y:832,t:1526929902975};\\\", \\\"{x:1214,y:831,t:1526929903152};\\\", \\\"{x:1214,y:830,t:1526929913616};\\\", \\\"{x:1214,y:829,t:1526929913639};\\\", \\\"{x:1214,y:828,t:1526929913783};\\\", \\\"{x:1215,y:828,t:1526929913822};\\\", \\\"{x:1215,y:829,t:1526929913839};\\\", \\\"{x:1216,y:830,t:1526929913854};\\\", \\\"{x:1217,y:832,t:1526929913863};\\\", \\\"{x:1218,y:834,t:1526929913881};\\\", \\\"{x:1219,y:835,t:1526929913897};\\\", \\\"{x:1221,y:836,t:1526929913914};\\\", \\\"{x:1225,y:839,t:1526929913930};\\\", \\\"{x:1232,y:843,t:1526929913947};\\\", \\\"{x:1239,y:846,t:1526929913965};\\\", \\\"{x:1246,y:849,t:1526929913981};\\\", \\\"{x:1256,y:852,t:1526929913997};\\\", \\\"{x:1262,y:853,t:1526929914014};\\\", \\\"{x:1264,y:853,t:1526929914030};\\\", \\\"{x:1265,y:853,t:1526929914048};\\\", \\\"{x:1268,y:853,t:1526929914064};\\\", \\\"{x:1271,y:853,t:1526929914080};\\\", \\\"{x:1275,y:852,t:1526929914097};\\\", \\\"{x:1276,y:851,t:1526929914115};\\\", \\\"{x:1279,y:850,t:1526929914131};\\\", \\\"{x:1280,y:848,t:1526929914148};\\\", \\\"{x:1281,y:847,t:1526929914165};\\\", \\\"{x:1281,y:845,t:1526929914181};\\\", \\\"{x:1282,y:844,t:1526929914198};\\\", \\\"{x:1282,y:843,t:1526929914214};\\\", \\\"{x:1282,y:842,t:1526929914230};\\\", \\\"{x:1282,y:841,t:1526929914248};\\\", \\\"{x:1282,y:840,t:1526929914264};\\\", \\\"{x:1282,y:839,t:1526929914282};\\\", \\\"{x:1282,y:838,t:1526929914297};\\\", \\\"{x:1282,y:837,t:1526929914315};\\\", \\\"{x:1282,y:836,t:1526929914332};\\\", \\\"{x:1282,y:835,t:1526929914348};\\\", \\\"{x:1282,y:834,t:1526929914365};\\\", \\\"{x:1282,y:833,t:1526929914383};\\\", \\\"{x:1282,y:832,t:1526929914406};\\\", \\\"{x:1282,y:831,t:1526929914430};\\\", \\\"{x:1282,y:830,t:1526929914438};\\\", \\\"{x:1282,y:831,t:1526929914727};\\\", \\\"{x:1282,y:832,t:1526929914734};\\\", \\\"{x:1282,y:833,t:1526929914749};\\\", \\\"{x:1282,y:838,t:1526929914764};\\\", \\\"{x:1282,y:843,t:1526929914781};\\\", \\\"{x:1283,y:846,t:1526929914799};\\\", \\\"{x:1285,y:849,t:1526929914815};\\\", \\\"{x:1292,y:853,t:1526929914831};\\\", \\\"{x:1300,y:856,t:1526929914848};\\\", \\\"{x:1309,y:858,t:1526929914865};\\\", \\\"{x:1319,y:859,t:1526929914882};\\\", \\\"{x:1327,y:860,t:1526929914899};\\\", \\\"{x:1335,y:860,t:1526929914915};\\\", \\\"{x:1338,y:860,t:1526929914931};\\\", \\\"{x:1343,y:860,t:1526929914948};\\\", \\\"{x:1344,y:860,t:1526929914965};\\\", \\\"{x:1346,y:858,t:1526929914981};\\\", \\\"{x:1349,y:855,t:1526929914998};\\\", \\\"{x:1350,y:853,t:1526929915015};\\\", \\\"{x:1350,y:851,t:1526929915031};\\\", \\\"{x:1352,y:849,t:1526929915049};\\\", \\\"{x:1352,y:847,t:1526929915065};\\\", \\\"{x:1352,y:843,t:1526929915081};\\\", \\\"{x:1352,y:841,t:1526929915098};\\\", \\\"{x:1352,y:840,t:1526929915116};\\\", \\\"{x:1352,y:838,t:1526929915131};\\\", \\\"{x:1352,y:837,t:1526929915149};\\\", \\\"{x:1352,y:836,t:1526929915167};\\\", \\\"{x:1352,y:835,t:1526929915183};\\\", \\\"{x:1351,y:834,t:1526929915207};\\\", \\\"{x:1350,y:833,t:1526929915295};\\\", \\\"{x:1350,y:832,t:1526929915447};\\\", \\\"{x:1350,y:831,t:1526929917744};\\\", \\\"{x:1349,y:830,t:1526929917758};\\\", \\\"{x:1349,y:829,t:1526929918070};\\\", \\\"{x:1349,y:828,t:1526929918103};\\\", \\\"{x:1349,y:827,t:1526929918126};\\\", \\\"{x:1348,y:826,t:1526929918135};\\\", \\\"{x:1347,y:826,t:1526929918151};\\\", \\\"{x:1347,y:825,t:1526929918591};\\\", \\\"{x:1346,y:824,t:1526929918606};\\\", \\\"{x:1346,y:825,t:1526929918783};\\\", \\\"{x:1344,y:826,t:1526929918790};\\\", \\\"{x:1344,y:828,t:1526929918807};\\\", \\\"{x:1344,y:829,t:1526929918819};\\\", \\\"{x:1344,y:831,t:1526929918836};\\\", \\\"{x:1344,y:833,t:1526929918853};\\\", \\\"{x:1343,y:837,t:1526929918869};\\\", \\\"{x:1343,y:842,t:1526929918886};\\\", \\\"{x:1343,y:847,t:1526929918902};\\\", \\\"{x:1343,y:850,t:1526929918919};\\\", \\\"{x:1343,y:856,t:1526929918936};\\\", \\\"{x:1343,y:860,t:1526929918953};\\\", \\\"{x:1343,y:864,t:1526929918969};\\\", \\\"{x:1343,y:867,t:1526929918986};\\\", \\\"{x:1343,y:870,t:1526929919004};\\\", \\\"{x:1343,y:871,t:1526929919019};\\\", \\\"{x:1343,y:873,t:1526929919036};\\\", \\\"{x:1343,y:875,t:1526929919053};\\\", \\\"{x:1343,y:877,t:1526929919069};\\\", \\\"{x:1343,y:880,t:1526929919087};\\\", \\\"{x:1344,y:882,t:1526929919104};\\\", \\\"{x:1345,y:884,t:1526929919119};\\\", \\\"{x:1346,y:887,t:1526929919136};\\\", \\\"{x:1346,y:889,t:1526929919153};\\\", \\\"{x:1348,y:891,t:1526929919170};\\\", \\\"{x:1348,y:894,t:1526929919186};\\\", \\\"{x:1350,y:896,t:1526929919203};\\\", \\\"{x:1350,y:897,t:1526929919220};\\\", \\\"{x:1351,y:899,t:1526929919236};\\\", \\\"{x:1351,y:900,t:1526929919253};\\\", \\\"{x:1354,y:903,t:1526929919271};\\\", \\\"{x:1354,y:904,t:1526929919286};\\\", \\\"{x:1355,y:906,t:1526929919304};\\\", \\\"{x:1349,y:906,t:1526929919400};\\\", \\\"{x:1330,y:904,t:1526929919408};\\\", \\\"{x:1301,y:899,t:1526929919420};\\\", \\\"{x:1195,y:881,t:1526929919437};\\\", \\\"{x:1062,y:844,t:1526929919453};\\\", \\\"{x:891,y:800,t:1526929919470};\\\", \\\"{x:695,y:739,t:1526929919486};\\\", \\\"{x:372,y:648,t:1526929919504};\\\", \\\"{x:202,y:612,t:1526929919521};\\\", \\\"{x:28,y:559,t:1526929919553};\\\", \\\"{x:24,y:557,t:1526929919566};\\\", \\\"{x:23,y:557,t:1526929919582};\\\", \\\"{x:23,y:556,t:1526929919614};\\\", \\\"{x:25,y:556,t:1526929919623};\\\", \\\"{x:30,y:556,t:1526929919633};\\\", \\\"{x:48,y:556,t:1526929919649};\\\", \\\"{x:83,y:558,t:1526929919665};\\\", \\\"{x:151,y:565,t:1526929919682};\\\", \\\"{x:236,y:572,t:1526929919699};\\\", \\\"{x:310,y:576,t:1526929919716};\\\", \\\"{x:350,y:577,t:1526929919732};\\\", \\\"{x:371,y:577,t:1526929919749};\\\", \\\"{x:376,y:577,t:1526929919766};\\\", \\\"{x:377,y:577,t:1526929919782};\\\", \\\"{x:378,y:577,t:1526929919799};\\\", \\\"{x:378,y:575,t:1526929919816};\\\", \\\"{x:372,y:573,t:1526929919832};\\\", \\\"{x:357,y:572,t:1526929919849};\\\", \\\"{x:333,y:572,t:1526929919865};\\\", \\\"{x:297,y:576,t:1526929919883};\\\", \\\"{x:256,y:586,t:1526929919899};\\\", \\\"{x:228,y:595,t:1526929919915};\\\", \\\"{x:213,y:606,t:1526929919932};\\\", \\\"{x:206,y:619,t:1526929919949};\\\", \\\"{x:203,y:632,t:1526929919966};\\\", \\\"{x:204,y:642,t:1526929919981};\\\", \\\"{x:220,y:656,t:1526929919998};\\\", \\\"{x:244,y:664,t:1526929920015};\\\", \\\"{x:303,y:673,t:1526929920033};\\\", \\\"{x:417,y:691,t:1526929920049};\\\", \\\"{x:558,y:696,t:1526929920066};\\\", \\\"{x:727,y:696,t:1526929920082};\\\", \\\"{x:900,y:686,t:1526929920098};\\\", \\\"{x:1046,y:670,t:1526929920115};\\\", \\\"{x:1160,y:665,t:1526929920133};\\\", \\\"{x:1207,y:659,t:1526929920150};\\\", \\\"{x:1219,y:659,t:1526929920165};\\\", \\\"{x:1217,y:658,t:1526929920223};\\\", \\\"{x:1207,y:654,t:1526929920233};\\\", \\\"{x:1182,y:651,t:1526929920250};\\\", \\\"{x:1140,y:641,t:1526929920266};\\\", \\\"{x:1074,y:624,t:1526929920283};\\\", \\\"{x:1002,y:606,t:1526929920300};\\\", \\\"{x:940,y:585,t:1526929920317};\\\", \\\"{x:878,y:563,t:1526929920334};\\\", \\\"{x:846,y:547,t:1526929920349};\\\", \\\"{x:828,y:536,t:1526929920366};\\\", \\\"{x:809,y:527,t:1526929920382};\\\", \\\"{x:801,y:526,t:1526929920400};\\\", \\\"{x:784,y:526,t:1526929920416};\\\", \\\"{x:757,y:526,t:1526929920432};\\\", \\\"{x:726,y:526,t:1526929920450};\\\", \\\"{x:696,y:526,t:1526929920466};\\\", \\\"{x:677,y:529,t:1526929920483};\\\", \\\"{x:665,y:534,t:1526929920499};\\\", \\\"{x:661,y:538,t:1526929920516};\\\", \\\"{x:659,y:542,t:1526929920533};\\\", \\\"{x:655,y:549,t:1526929920550};\\\", \\\"{x:651,y:555,t:1526929920565};\\\", \\\"{x:640,y:572,t:1526929920582};\\\", \\\"{x:626,y:587,t:1526929920600};\\\", \\\"{x:605,y:607,t:1526929920616};\\\", \\\"{x:583,y:625,t:1526929920633};\\\", \\\"{x:548,y:649,t:1526929920650};\\\", \\\"{x:501,y:680,t:1526929920667};\\\", \\\"{x:447,y:708,t:1526929920683};\\\", \\\"{x:388,y:740,t:1526929920700};\\\", \\\"{x:334,y:758,t:1526929920715};\\\", \\\"{x:296,y:766,t:1526929920733};\\\", \\\"{x:270,y:768,t:1526929920750};\\\", \\\"{x:249,y:763,t:1526929920766};\\\", \\\"{x:242,y:757,t:1526929920783};\\\", \\\"{x:236,y:749,t:1526929920800};\\\", \\\"{x:232,y:743,t:1526929920816};\\\", \\\"{x:227,y:733,t:1526929920832};\\\", \\\"{x:224,y:727,t:1526929920850};\\\", \\\"{x:222,y:718,t:1526929920866};\\\", \\\"{x:221,y:705,t:1526929920883};\\\", \\\"{x:221,y:692,t:1526929920900};\\\", \\\"{x:222,y:676,t:1526929920917};\\\", \\\"{x:229,y:660,t:1526929920932};\\\", \\\"{x:241,y:645,t:1526929920950};\\\", \\\"{x:254,y:629,t:1526929920966};\\\", \\\"{x:260,y:622,t:1526929920984};\\\", \\\"{x:260,y:621,t:1526929921000};\\\", \\\"{x:260,y:620,t:1526929921078};\\\", \\\"{x:254,y:620,t:1526929921087};\\\", \\\"{x:249,y:620,t:1526929921100};\\\", \\\"{x:232,y:624,t:1526929921116};\\\", \\\"{x:214,y:626,t:1526929921134};\\\", \\\"{x:186,y:631,t:1526929921151};\\\", \\\"{x:172,y:633,t:1526929921168};\\\", \\\"{x:166,y:634,t:1526929921184};\\\", \\\"{x:163,y:635,t:1526929921200};\\\", \\\"{x:159,y:636,t:1526929921216};\\\", \\\"{x:155,y:636,t:1526929921234};\\\", \\\"{x:153,y:638,t:1526929921250};\\\", \\\"{x:151,y:638,t:1526929921267};\\\", \\\"{x:150,y:638,t:1526929921303};\\\", \\\"{x:149,y:638,t:1526929921317};\\\", \\\"{x:147,y:632,t:1526929921334};\\\", \\\"{x:146,y:625,t:1526929921350};\\\", \\\"{x:145,y:614,t:1526929921368};\\\", \\\"{x:148,y:603,t:1526929921385};\\\", \\\"{x:152,y:593,t:1526929921400};\\\", \\\"{x:157,y:586,t:1526929921417};\\\", \\\"{x:160,y:581,t:1526929921435};\\\", \\\"{x:163,y:579,t:1526929921451};\\\", \\\"{x:163,y:577,t:1526929921466};\\\", \\\"{x:164,y:577,t:1526929921484};\\\", \\\"{x:164,y:575,t:1526929921679};\\\", \\\"{x:164,y:574,t:1526929921687};\\\", \\\"{x:164,y:573,t:1526929921701};\\\", \\\"{x:164,y:572,t:1526929921717};\\\", \\\"{x:164,y:571,t:1526929921734};\\\", \\\"{x:164,y:570,t:1526929921751};\\\", \\\"{x:164,y:569,t:1526929921783};\\\", \\\"{x:164,y:568,t:1526929921871};\\\", \\\"{x:166,y:568,t:1526929922118};\\\", \\\"{x:177,y:575,t:1526929922134};\\\", \\\"{x:206,y:588,t:1526929922151};\\\", \\\"{x:234,y:602,t:1526929922168};\\\", \\\"{x:276,y:621,t:1526929922184};\\\", \\\"{x:326,y:645,t:1526929922200};\\\", \\\"{x:387,y:670,t:1526929922218};\\\", \\\"{x:422,y:685,t:1526929922233};\\\", \\\"{x:443,y:698,t:1526929922251};\\\", \\\"{x:453,y:702,t:1526929922268};\\\", \\\"{x:456,y:703,t:1526929922284};\\\", \\\"{x:457,y:703,t:1526929922335};\\\", \\\"{x:460,y:706,t:1526929922350};\\\", \\\"{x:464,y:708,t:1526929922368};\\\", \\\"{x:466,y:710,t:1526929922384};\\\", \\\"{x:468,y:712,t:1526929922401};\\\", \\\"{x:468,y:713,t:1526929922418};\\\", \\\"{x:470,y:715,t:1526929922435};\\\", \\\"{x:470,y:716,t:1526929922451};\\\", \\\"{x:471,y:719,t:1526929922468};\\\", \\\"{x:472,y:720,t:1526929922485};\\\", \\\"{x:473,y:720,t:1526929922502};\\\", \\\"{x:473,y:721,t:1526929922527};\\\", \\\"{x:474,y:721,t:1526929922567};\\\", \\\"{x:475,y:721,t:1526929922591};\\\", \\\"{x:476,y:721,t:1526929922630};\\\", \\\"{x:477,y:722,t:1526929922774};\\\", \\\"{x:477,y:722,t:1526929922793};\\\" ] }, { \\\"rt\\\": 58061, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 331747, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-08 AM-09 AM-A -12 PM-02 PM-04 PM-E -01 PM-04 PM-02 PM-05 PM-05 PM-04 PM-04 PM-03 PM-03 PM-02 PM-02 PM-01 PM-12 PM-Z -Z -O -O -F -F -F -Z -01 PM-02 PM-03 PM-03 PM-02 PM-01 PM-12 PM-12 PM-Z -03 PM-03 PM-K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:721,t:1526929924214};\\\", \\\"{x:476,y:721,t:1526929924239};\\\", \\\"{x:475,y:721,t:1526929924254};\\\", \\\"{x:474,y:720,t:1526929924269};\\\", \\\"{x:473,y:720,t:1526929924286};\\\", \\\"{x:472,y:719,t:1526929924303};\\\", \\\"{x:471,y:718,t:1526929924326};\\\", \\\"{x:470,y:718,t:1526929924511};\\\", \\\"{x:469,y:718,t:1526929924526};\\\", \\\"{x:468,y:718,t:1526929924566};\\\", \\\"{x:467,y:718,t:1526929924590};\\\", \\\"{x:466,y:718,t:1526929924606};\\\", \\\"{x:464,y:718,t:1526929924630};\\\", \\\"{x:463,y:718,t:1526929924638};\\\", \\\"{x:461,y:718,t:1526929924654};\\\", \\\"{x:457,y:718,t:1526929924669};\\\", \\\"{x:449,y:718,t:1526929924686};\\\", \\\"{x:438,y:713,t:1526929924703};\\\", \\\"{x:428,y:710,t:1526929924719};\\\", \\\"{x:420,y:708,t:1526929924736};\\\", \\\"{x:416,y:706,t:1526929924753};\\\", \\\"{x:413,y:706,t:1526929924770};\\\", \\\"{x:407,y:706,t:1526929924785};\\\", \\\"{x:403,y:706,t:1526929924803};\\\", \\\"{x:401,y:706,t:1526929924820};\\\", \\\"{x:399,y:706,t:1526929924837};\\\", \\\"{x:396,y:706,t:1526929924853};\\\", \\\"{x:393,y:706,t:1526929924871};\\\", \\\"{x:390,y:706,t:1526929924887};\\\", \\\"{x:388,y:706,t:1526929924903};\\\", \\\"{x:386,y:705,t:1526929925480};\\\", \\\"{x:385,y:703,t:1526929925487};\\\", \\\"{x:380,y:697,t:1526929925504};\\\", \\\"{x:376,y:692,t:1526929925521};\\\", \\\"{x:370,y:685,t:1526929925537};\\\", \\\"{x:366,y:680,t:1526929925554};\\\", \\\"{x:358,y:675,t:1526929925572};\\\", \\\"{x:347,y:665,t:1526929925588};\\\", \\\"{x:333,y:655,t:1526929925605};\\\", \\\"{x:322,y:646,t:1526929925623};\\\", \\\"{x:313,y:639,t:1526929925637};\\\", \\\"{x:309,y:636,t:1526929925654};\\\", \\\"{x:306,y:634,t:1526929925670};\\\", \\\"{x:305,y:631,t:1526929925687};\\\", \\\"{x:303,y:629,t:1526929925703};\\\", \\\"{x:302,y:628,t:1526929925720};\\\", \\\"{x:301,y:627,t:1526929925737};\\\", \\\"{x:300,y:625,t:1526929925754};\\\", \\\"{x:300,y:626,t:1526929926087};\\\", \\\"{x:300,y:631,t:1526929926104};\\\", \\\"{x:302,y:633,t:1526929926122};\\\", \\\"{x:304,y:636,t:1526929926137};\\\", \\\"{x:309,y:638,t:1526929926154};\\\", \\\"{x:317,y:640,t:1526929926171};\\\", \\\"{x:331,y:643,t:1526929926187};\\\", \\\"{x:355,y:645,t:1526929926204};\\\", \\\"{x:401,y:652,t:1526929926221};\\\", \\\"{x:462,y:658,t:1526929926237};\\\", \\\"{x:560,y:660,t:1526929926254};\\\", \\\"{x:737,y:660,t:1526929926271};\\\", \\\"{x:860,y:666,t:1526929926287};\\\", \\\"{x:1003,y:679,t:1526929926304};\\\", \\\"{x:1155,y:701,t:1526929926320};\\\", \\\"{x:1303,y:731,t:1526929926337};\\\", \\\"{x:1430,y:763,t:1526929926354};\\\", \\\"{x:1542,y:788,t:1526929926371};\\\", \\\"{x:1622,y:812,t:1526929926388};\\\", \\\"{x:1673,y:828,t:1526929926404};\\\", \\\"{x:1717,y:838,t:1526929926421};\\\", \\\"{x:1754,y:850,t:1526929926437};\\\", \\\"{x:1778,y:862,t:1526929926454};\\\", \\\"{x:1806,y:873,t:1526929926471};\\\", \\\"{x:1819,y:880,t:1526929926488};\\\", \\\"{x:1833,y:888,t:1526929926504};\\\", \\\"{x:1844,y:897,t:1526929926521};\\\", \\\"{x:1855,y:906,t:1526929926538};\\\", \\\"{x:1859,y:911,t:1526929926554};\\\", \\\"{x:1862,y:920,t:1526929926571};\\\", \\\"{x:1864,y:928,t:1526929926588};\\\", \\\"{x:1865,y:937,t:1526929926604};\\\", \\\"{x:1865,y:944,t:1526929926621};\\\", \\\"{x:1865,y:952,t:1526929926638};\\\", \\\"{x:1865,y:958,t:1526929926654};\\\", \\\"{x:1862,y:967,t:1526929926671};\\\", \\\"{x:1857,y:975,t:1526929926688};\\\", \\\"{x:1848,y:984,t:1526929926704};\\\", \\\"{x:1838,y:995,t:1526929926721};\\\", \\\"{x:1818,y:1008,t:1526929926738};\\\", \\\"{x:1793,y:1022,t:1526929926754};\\\", \\\"{x:1764,y:1034,t:1526929926771};\\\", \\\"{x:1724,y:1049,t:1526929926788};\\\", \\\"{x:1670,y:1065,t:1526929926805};\\\", \\\"{x:1615,y:1073,t:1526929926821};\\\", \\\"{x:1558,y:1076,t:1526929926838};\\\", \\\"{x:1507,y:1078,t:1526929926854};\\\", \\\"{x:1472,y:1078,t:1526929926871};\\\", \\\"{x:1460,y:1078,t:1526929926888};\\\", \\\"{x:1452,y:1078,t:1526929926904};\\\", \\\"{x:1447,y:1075,t:1526929926921};\\\", \\\"{x:1438,y:1071,t:1526929926938};\\\", \\\"{x:1425,y:1067,t:1526929926955};\\\", \\\"{x:1413,y:1062,t:1526929926971};\\\", \\\"{x:1403,y:1060,t:1526929926988};\\\", \\\"{x:1394,y:1055,t:1526929927005};\\\", \\\"{x:1383,y:1050,t:1526929927021};\\\", \\\"{x:1376,y:1047,t:1526929927038};\\\", \\\"{x:1368,y:1042,t:1526929927055};\\\", \\\"{x:1366,y:1042,t:1526929927071};\\\", \\\"{x:1365,y:1041,t:1526929927159};\\\", \\\"{x:1365,y:1040,t:1526929927288};\\\", \\\"{x:1365,y:1039,t:1526929927306};\\\", \\\"{x:1365,y:1038,t:1526929927322};\\\", \\\"{x:1363,y:1035,t:1526929927486};\\\", \\\"{x:1361,y:1033,t:1526929927495};\\\", \\\"{x:1355,y:1029,t:1526929927505};\\\", \\\"{x:1346,y:1022,t:1526929927522};\\\", \\\"{x:1335,y:1014,t:1526929927538};\\\", \\\"{x:1325,y:1008,t:1526929927555};\\\", \\\"{x:1306,y:1002,t:1526929927572};\\\", \\\"{x:1293,y:997,t:1526929927588};\\\", \\\"{x:1284,y:994,t:1526929927605};\\\", \\\"{x:1277,y:991,t:1526929927622};\\\", \\\"{x:1267,y:988,t:1526929927638};\\\", \\\"{x:1249,y:982,t:1526929927655};\\\", \\\"{x:1239,y:978,t:1526929927672};\\\", \\\"{x:1228,y:973,t:1526929927688};\\\", \\\"{x:1217,y:968,t:1526929927705};\\\", \\\"{x:1211,y:966,t:1526929927721};\\\", \\\"{x:1207,y:964,t:1526929927738};\\\", \\\"{x:1203,y:963,t:1526929927755};\\\", \\\"{x:1201,y:962,t:1526929927772};\\\", \\\"{x:1200,y:962,t:1526929927789};\\\", \\\"{x:1199,y:962,t:1526929927805};\\\", \\\"{x:1192,y:959,t:1526929927822};\\\", \\\"{x:1188,y:957,t:1526929927839};\\\", \\\"{x:1180,y:954,t:1526929927855};\\\", \\\"{x:1174,y:950,t:1526929927872};\\\", \\\"{x:1164,y:946,t:1526929927889};\\\", \\\"{x:1155,y:943,t:1526929927905};\\\", \\\"{x:1143,y:938,t:1526929927922};\\\", \\\"{x:1132,y:933,t:1526929927939};\\\", \\\"{x:1116,y:926,t:1526929927955};\\\", \\\"{x:1103,y:921,t:1526929927972};\\\", \\\"{x:1091,y:916,t:1526929927989};\\\", \\\"{x:1081,y:914,t:1526929928005};\\\", \\\"{x:1069,y:910,t:1526929928023};\\\", \\\"{x:1065,y:909,t:1526929928038};\\\", \\\"{x:1068,y:909,t:1526929929375};\\\", \\\"{x:1072,y:909,t:1526929929390};\\\", \\\"{x:1082,y:912,t:1526929929406};\\\", \\\"{x:1108,y:920,t:1526929929423};\\\", \\\"{x:1128,y:926,t:1526929929440};\\\", \\\"{x:1150,y:933,t:1526929929456};\\\", \\\"{x:1175,y:939,t:1526929929473};\\\", \\\"{x:1200,y:945,t:1526929929490};\\\", \\\"{x:1224,y:952,t:1526929929506};\\\", \\\"{x:1242,y:954,t:1526929929523};\\\", \\\"{x:1260,y:957,t:1526929929541};\\\", \\\"{x:1274,y:959,t:1526929929557};\\\", \\\"{x:1285,y:959,t:1526929929573};\\\", \\\"{x:1299,y:959,t:1526929929590};\\\", \\\"{x:1316,y:959,t:1526929929607};\\\", \\\"{x:1327,y:959,t:1526929929623};\\\", \\\"{x:1335,y:959,t:1526929929640};\\\", \\\"{x:1343,y:958,t:1526929929657};\\\", \\\"{x:1350,y:955,t:1526929929673};\\\", \\\"{x:1354,y:952,t:1526929929690};\\\", \\\"{x:1359,y:949,t:1526929929707};\\\", \\\"{x:1366,y:937,t:1526929929723};\\\", \\\"{x:1376,y:924,t:1526929929740};\\\", \\\"{x:1380,y:917,t:1526929929756};\\\", \\\"{x:1385,y:910,t:1526929929773};\\\", \\\"{x:1388,y:905,t:1526929929790};\\\", \\\"{x:1391,y:900,t:1526929929807};\\\", \\\"{x:1392,y:898,t:1526929929823};\\\", \\\"{x:1392,y:897,t:1526929929840};\\\", \\\"{x:1391,y:897,t:1526929929974};\\\", \\\"{x:1389,y:897,t:1526929929990};\\\", \\\"{x:1381,y:899,t:1526929930007};\\\", \\\"{x:1375,y:900,t:1526929930023};\\\", \\\"{x:1371,y:903,t:1526929930040};\\\", \\\"{x:1363,y:907,t:1526929930057};\\\", \\\"{x:1355,y:913,t:1526929930073};\\\", \\\"{x:1350,y:917,t:1526929930090};\\\", \\\"{x:1343,y:925,t:1526929930107};\\\", \\\"{x:1339,y:930,t:1526929930124};\\\", \\\"{x:1335,y:935,t:1526929930140};\\\", \\\"{x:1330,y:939,t:1526929930157};\\\", \\\"{x:1327,y:944,t:1526929930173};\\\", \\\"{x:1324,y:947,t:1526929930190};\\\", \\\"{x:1321,y:951,t:1526929930207};\\\", \\\"{x:1319,y:956,t:1526929930223};\\\", \\\"{x:1318,y:957,t:1526929930240};\\\", \\\"{x:1317,y:959,t:1526929930258};\\\", \\\"{x:1317,y:960,t:1526929930274};\\\", \\\"{x:1315,y:962,t:1526929930291};\\\", \\\"{x:1315,y:963,t:1526929930310};\\\", \\\"{x:1315,y:964,t:1526929930326};\\\", \\\"{x:1314,y:965,t:1526929930340};\\\", \\\"{x:1314,y:966,t:1526929930358};\\\", \\\"{x:1313,y:966,t:1526929930374};\\\", \\\"{x:1312,y:967,t:1526929930390};\\\", \\\"{x:1312,y:968,t:1526929930446};\\\", \\\"{x:1311,y:968,t:1526929930470};\\\", \\\"{x:1311,y:969,t:1526929930502};\\\", \\\"{x:1310,y:969,t:1526929930519};\\\", \\\"{x:1308,y:969,t:1526929930534};\\\", \\\"{x:1306,y:970,t:1526929930543};\\\", \\\"{x:1304,y:970,t:1526929930557};\\\", \\\"{x:1300,y:970,t:1526929930574};\\\", \\\"{x:1296,y:970,t:1526929930590};\\\", \\\"{x:1289,y:970,t:1526929930606};\\\", \\\"{x:1285,y:970,t:1526929930624};\\\", \\\"{x:1278,y:970,t:1526929930640};\\\", \\\"{x:1274,y:970,t:1526929930657};\\\", \\\"{x:1269,y:970,t:1526929930674};\\\", \\\"{x:1263,y:970,t:1526929930691};\\\", \\\"{x:1258,y:969,t:1526929930707};\\\", \\\"{x:1250,y:967,t:1526929930724};\\\", \\\"{x:1244,y:966,t:1526929930741};\\\", \\\"{x:1242,y:966,t:1526929930757};\\\", \\\"{x:1238,y:965,t:1526929930774};\\\", \\\"{x:1237,y:965,t:1526929930791};\\\", \\\"{x:1236,y:965,t:1526929930807};\\\", \\\"{x:1235,y:965,t:1526929930903};\\\", \\\"{x:1233,y:965,t:1526929930919};\\\", \\\"{x:1232,y:965,t:1526929930927};\\\", \\\"{x:1231,y:965,t:1526929930942};\\\", \\\"{x:1229,y:965,t:1526929930957};\\\", \\\"{x:1225,y:965,t:1526929930975};\\\", \\\"{x:1216,y:963,t:1526929930991};\\\", \\\"{x:1213,y:963,t:1526929931007};\\\", \\\"{x:1211,y:963,t:1526929931024};\\\", \\\"{x:1208,y:963,t:1526929931041};\\\", \\\"{x:1207,y:963,t:1526929931063};\\\", \\\"{x:1206,y:963,t:1526929931074};\\\", \\\"{x:1205,y:963,t:1526929931091};\\\", \\\"{x:1204,y:963,t:1526929931107};\\\", \\\"{x:1203,y:963,t:1526929931124};\\\", \\\"{x:1203,y:964,t:1526929931142};\\\", \\\"{x:1202,y:964,t:1526929931157};\\\", \\\"{x:1201,y:964,t:1526929931182};\\\", \\\"{x:1200,y:965,t:1526929931222};\\\", \\\"{x:1199,y:965,t:1526929931262};\\\", \\\"{x:1198,y:966,t:1526929931274};\\\", \\\"{x:1195,y:966,t:1526929931291};\\\", \\\"{x:1193,y:966,t:1526929931308};\\\", \\\"{x:1188,y:966,t:1526929931325};\\\", \\\"{x:1183,y:966,t:1526929931341};\\\", \\\"{x:1170,y:965,t:1526929931358};\\\", \\\"{x:1162,y:964,t:1526929931374};\\\", \\\"{x:1155,y:963,t:1526929931391};\\\", \\\"{x:1152,y:962,t:1526929931408};\\\", \\\"{x:1151,y:962,t:1526929931446};\\\", \\\"{x:1150,y:962,t:1526929931470};\\\", \\\"{x:1149,y:962,t:1526929931479};\\\", \\\"{x:1148,y:962,t:1526929931494};\\\", \\\"{x:1147,y:962,t:1526929931508};\\\", \\\"{x:1146,y:962,t:1526929931524};\\\", \\\"{x:1142,y:962,t:1526929931541};\\\", \\\"{x:1135,y:963,t:1526929931558};\\\", \\\"{x:1131,y:963,t:1526929931574};\\\", \\\"{x:1129,y:963,t:1526929931591};\\\", \\\"{x:1125,y:964,t:1526929931609};\\\", \\\"{x:1121,y:965,t:1526929931625};\\\", \\\"{x:1118,y:966,t:1526929931641};\\\", \\\"{x:1116,y:966,t:1526929931658};\\\", \\\"{x:1112,y:966,t:1526929931675};\\\", \\\"{x:1107,y:968,t:1526929931691};\\\", \\\"{x:1103,y:969,t:1526929931708};\\\", \\\"{x:1099,y:970,t:1526929931725};\\\", \\\"{x:1087,y:973,t:1526929931742};\\\", \\\"{x:1069,y:978,t:1526929931758};\\\", \\\"{x:1060,y:981,t:1526929931775};\\\", \\\"{x:1055,y:984,t:1526929931792};\\\", \\\"{x:1052,y:985,t:1526929931808};\\\", \\\"{x:1050,y:987,t:1526929931825};\\\", \\\"{x:1049,y:987,t:1526929931841};\\\", \\\"{x:1048,y:987,t:1526929931858};\\\", \\\"{x:1048,y:988,t:1526929931875};\\\", \\\"{x:1047,y:989,t:1526929931910};\\\", \\\"{x:1047,y:990,t:1526929932054};\\\", \\\"{x:1048,y:990,t:1526929932062};\\\", \\\"{x:1050,y:991,t:1526929932075};\\\", \\\"{x:1053,y:991,t:1526929932091};\\\", \\\"{x:1057,y:991,t:1526929932107};\\\", \\\"{x:1060,y:991,t:1526929932125};\\\", \\\"{x:1063,y:991,t:1526929932142};\\\", \\\"{x:1065,y:991,t:1526929932158};\\\", \\\"{x:1066,y:991,t:1526929932190};\\\", \\\"{x:1068,y:991,t:1526929932206};\\\", \\\"{x:1069,y:991,t:1526929932214};\\\", \\\"{x:1070,y:991,t:1526929932225};\\\", \\\"{x:1072,y:991,t:1526929932242};\\\", \\\"{x:1075,y:991,t:1526929932258};\\\", \\\"{x:1077,y:991,t:1526929932275};\\\", \\\"{x:1079,y:991,t:1526929932292};\\\", \\\"{x:1082,y:991,t:1526929932308};\\\", \\\"{x:1084,y:991,t:1526929932325};\\\", \\\"{x:1089,y:991,t:1526929932342};\\\", \\\"{x:1093,y:991,t:1526929932358};\\\", \\\"{x:1099,y:991,t:1526929932375};\\\", \\\"{x:1104,y:991,t:1526929932392};\\\", \\\"{x:1110,y:991,t:1526929932409};\\\", \\\"{x:1115,y:989,t:1526929932426};\\\", \\\"{x:1124,y:989,t:1526929932442};\\\", \\\"{x:1131,y:988,t:1526929932459};\\\", \\\"{x:1134,y:988,t:1526929932475};\\\", \\\"{x:1136,y:986,t:1526929932493};\\\", \\\"{x:1138,y:985,t:1526929932509};\\\", \\\"{x:1139,y:984,t:1526929932551};\\\", \\\"{x:1140,y:983,t:1526929932567};\\\", \\\"{x:1142,y:981,t:1526929932583};\\\", \\\"{x:1143,y:980,t:1526929932639};\\\", \\\"{x:1145,y:978,t:1526929932990};\\\", \\\"{x:1146,y:977,t:1526929933014};\\\", \\\"{x:1146,y:976,t:1526929933025};\\\", \\\"{x:1148,y:975,t:1526929933043};\\\", \\\"{x:1149,y:973,t:1526929933059};\\\", \\\"{x:1151,y:971,t:1526929933076};\\\", \\\"{x:1151,y:969,t:1526929933093};\\\", \\\"{x:1152,y:966,t:1526929933109};\\\", \\\"{x:1152,y:962,t:1526929933127};\\\", \\\"{x:1152,y:957,t:1526929933142};\\\", \\\"{x:1152,y:949,t:1526929933159};\\\", \\\"{x:1152,y:943,t:1526929933176};\\\", \\\"{x:1152,y:939,t:1526929933192};\\\", \\\"{x:1152,y:935,t:1526929933209};\\\", \\\"{x:1152,y:932,t:1526929933226};\\\", \\\"{x:1151,y:930,t:1526929933242};\\\", \\\"{x:1151,y:927,t:1526929933259};\\\", \\\"{x:1151,y:923,t:1526929933276};\\\", \\\"{x:1151,y:918,t:1526929933292};\\\", \\\"{x:1151,y:911,t:1526929933310};\\\", \\\"{x:1151,y:899,t:1526929933326};\\\", \\\"{x:1151,y:895,t:1526929933342};\\\", \\\"{x:1152,y:887,t:1526929933359};\\\", \\\"{x:1155,y:879,t:1526929933376};\\\", \\\"{x:1157,y:873,t:1526929933392};\\\", \\\"{x:1157,y:869,t:1526929933409};\\\", \\\"{x:1160,y:860,t:1526929933426};\\\", \\\"{x:1161,y:852,t:1526929933442};\\\", \\\"{x:1161,y:847,t:1526929933460};\\\", \\\"{x:1164,y:843,t:1526929933476};\\\", \\\"{x:1165,y:841,t:1526929933493};\\\", \\\"{x:1166,y:837,t:1526929933510};\\\", \\\"{x:1168,y:832,t:1526929933526};\\\", \\\"{x:1170,y:827,t:1526929933542};\\\", \\\"{x:1171,y:825,t:1526929933560};\\\", \\\"{x:1171,y:824,t:1526929933577};\\\", \\\"{x:1173,y:822,t:1526929933593};\\\", \\\"{x:1175,y:820,t:1526929933609};\\\", \\\"{x:1179,y:816,t:1526929933626};\\\", \\\"{x:1182,y:814,t:1526929933643};\\\", \\\"{x:1185,y:813,t:1526929933659};\\\", \\\"{x:1193,y:810,t:1526929933676};\\\", \\\"{x:1198,y:809,t:1526929933693};\\\", \\\"{x:1205,y:809,t:1526929933709};\\\", \\\"{x:1212,y:809,t:1526929933726};\\\", \\\"{x:1215,y:809,t:1526929933743};\\\", \\\"{x:1219,y:809,t:1526929933759};\\\", \\\"{x:1222,y:809,t:1526929933776};\\\", \\\"{x:1226,y:809,t:1526929933793};\\\", \\\"{x:1231,y:809,t:1526929933810};\\\", \\\"{x:1240,y:812,t:1526929933827};\\\", \\\"{x:1247,y:814,t:1526929933843};\\\", \\\"{x:1255,y:818,t:1526929933859};\\\", \\\"{x:1261,y:820,t:1526929933877};\\\", \\\"{x:1265,y:824,t:1526929933894};\\\", \\\"{x:1268,y:825,t:1526929933909};\\\", \\\"{x:1270,y:826,t:1526929933927};\\\", \\\"{x:1272,y:827,t:1526929933943};\\\", \\\"{x:1274,y:829,t:1526929933959};\\\", \\\"{x:1275,y:831,t:1526929933977};\\\", \\\"{x:1277,y:832,t:1526929933994};\\\", \\\"{x:1279,y:835,t:1526929934009};\\\", \\\"{x:1280,y:838,t:1526929934027};\\\", \\\"{x:1282,y:843,t:1526929934043};\\\", \\\"{x:1285,y:847,t:1526929934059};\\\", \\\"{x:1286,y:852,t:1526929934077};\\\", \\\"{x:1289,y:859,t:1526929934093};\\\", \\\"{x:1295,y:872,t:1526929934111};\\\", \\\"{x:1301,y:882,t:1526929934127};\\\", \\\"{x:1306,y:890,t:1526929934143};\\\", \\\"{x:1313,y:900,t:1526929934160};\\\", \\\"{x:1318,y:907,t:1526929934176};\\\", \\\"{x:1327,y:917,t:1526929934193};\\\", \\\"{x:1334,y:925,t:1526929934211};\\\", \\\"{x:1339,y:932,t:1526929934226};\\\", \\\"{x:1344,y:938,t:1526929934243};\\\", \\\"{x:1345,y:941,t:1526929934260};\\\", \\\"{x:1348,y:945,t:1526929934276};\\\", \\\"{x:1350,y:949,t:1526929934294};\\\", \\\"{x:1353,y:954,t:1526929934311};\\\", \\\"{x:1355,y:957,t:1526929934326};\\\", \\\"{x:1356,y:960,t:1526929934343};\\\", \\\"{x:1358,y:962,t:1526929934360};\\\", \\\"{x:1360,y:964,t:1526929934376};\\\", \\\"{x:1362,y:969,t:1526929934393};\\\", \\\"{x:1367,y:973,t:1526929934411};\\\", \\\"{x:1371,y:978,t:1526929934426};\\\", \\\"{x:1377,y:983,t:1526929934444};\\\", \\\"{x:1382,y:986,t:1526929934460};\\\", \\\"{x:1386,y:988,t:1526929934477};\\\", \\\"{x:1390,y:991,t:1526929934494};\\\", \\\"{x:1393,y:991,t:1526929934511};\\\", \\\"{x:1395,y:992,t:1526929934526};\\\", \\\"{x:1398,y:992,t:1526929934543};\\\", \\\"{x:1401,y:992,t:1526929934560};\\\", \\\"{x:1407,y:992,t:1526929934577};\\\", \\\"{x:1413,y:992,t:1526929934593};\\\", \\\"{x:1419,y:992,t:1526929934610};\\\", \\\"{x:1425,y:992,t:1526929934628};\\\", \\\"{x:1430,y:991,t:1526929934643};\\\", \\\"{x:1433,y:990,t:1526929934660};\\\", \\\"{x:1437,y:989,t:1526929934677};\\\", \\\"{x:1443,y:987,t:1526929934694};\\\", \\\"{x:1451,y:986,t:1526929934710};\\\", \\\"{x:1460,y:985,t:1526929934727};\\\", \\\"{x:1468,y:984,t:1526929934744};\\\", \\\"{x:1476,y:984,t:1526929934760};\\\", \\\"{x:1482,y:984,t:1526929934777};\\\", \\\"{x:1487,y:984,t:1526929934793};\\\", \\\"{x:1491,y:984,t:1526929934811};\\\", \\\"{x:1499,y:984,t:1526929934827};\\\", \\\"{x:1510,y:984,t:1526929934844};\\\", \\\"{x:1527,y:986,t:1526929934860};\\\", \\\"{x:1555,y:990,t:1526929934877};\\\", \\\"{x:1584,y:993,t:1526929934893};\\\", \\\"{x:1618,y:999,t:1526929934910};\\\", \\\"{x:1640,y:1000,t:1526929934928};\\\", \\\"{x:1655,y:1001,t:1526929934943};\\\", \\\"{x:1662,y:1001,t:1526929934961};\\\", \\\"{x:1663,y:1001,t:1526929934977};\\\", \\\"{x:1664,y:1001,t:1526929934994};\\\", \\\"{x:1666,y:1001,t:1526929935011};\\\", \\\"{x:1668,y:1001,t:1526929935027};\\\", \\\"{x:1671,y:999,t:1526929935045};\\\", \\\"{x:1673,y:998,t:1526929935061};\\\", \\\"{x:1677,y:996,t:1526929935078};\\\", \\\"{x:1679,y:994,t:1526929935095};\\\", \\\"{x:1680,y:993,t:1526929935111};\\\", \\\"{x:1678,y:991,t:1526929935200};\\\", \\\"{x:1672,y:991,t:1526929935212};\\\", \\\"{x:1663,y:990,t:1526929935228};\\\", \\\"{x:1653,y:988,t:1526929935244};\\\", \\\"{x:1645,y:988,t:1526929935260};\\\", \\\"{x:1640,y:988,t:1526929935278};\\\", \\\"{x:1638,y:988,t:1526929935294};\\\", \\\"{x:1636,y:988,t:1526929935310};\\\", \\\"{x:1634,y:988,t:1526929935328};\\\", \\\"{x:1631,y:988,t:1526929935344};\\\", \\\"{x:1629,y:988,t:1526929935361};\\\", \\\"{x:1628,y:988,t:1526929935377};\\\", \\\"{x:1628,y:989,t:1526929935398};\\\", \\\"{x:1627,y:989,t:1526929935510};\\\", \\\"{x:1626,y:988,t:1526929935527};\\\", \\\"{x:1624,y:988,t:1526929935544};\\\", \\\"{x:1623,y:985,t:1526929935562};\\\", \\\"{x:1622,y:984,t:1526929935577};\\\", \\\"{x:1621,y:983,t:1526929935594};\\\", \\\"{x:1621,y:982,t:1526929935611};\\\", \\\"{x:1620,y:982,t:1526929935627};\\\", \\\"{x:1619,y:981,t:1526929935644};\\\", \\\"{x:1618,y:981,t:1526929935662};\\\", \\\"{x:1617,y:980,t:1526929935677};\\\", \\\"{x:1616,y:979,t:1526929935695};\\\", \\\"{x:1616,y:978,t:1526929935734};\\\", \\\"{x:1615,y:977,t:1526929935751};\\\", \\\"{x:1615,y:976,t:1526929935799};\\\", \\\"{x:1614,y:975,t:1526929935823};\\\", \\\"{x:1614,y:974,t:1526929935855};\\\", \\\"{x:1614,y:973,t:1526929935870};\\\", \\\"{x:1614,y:972,t:1526929935886};\\\", \\\"{x:1614,y:971,t:1526929935894};\\\", \\\"{x:1611,y:969,t:1526929935912};\\\", \\\"{x:1611,y:967,t:1526929935934};\\\", \\\"{x:1611,y:965,t:1526929935959};\\\", \\\"{x:1610,y:965,t:1526929935982};\\\", \\\"{x:1610,y:964,t:1526929935994};\\\", \\\"{x:1609,y:962,t:1526929936015};\\\", \\\"{x:1609,y:961,t:1526929936047};\\\", \\\"{x:1608,y:960,t:1526929936063};\\\", \\\"{x:1608,y:959,t:1526929936078};\\\", \\\"{x:1607,y:957,t:1526929936095};\\\", \\\"{x:1607,y:956,t:1526929936166};\\\", \\\"{x:1607,y:955,t:1526929936178};\\\", \\\"{x:1607,y:954,t:1526929936194};\\\", \\\"{x:1606,y:953,t:1526929936239};\\\", \\\"{x:1606,y:952,t:1526929936270};\\\", \\\"{x:1606,y:951,t:1526929936278};\\\", \\\"{x:1606,y:950,t:1526929936295};\\\", \\\"{x:1606,y:948,t:1526929936311};\\\", \\\"{x:1606,y:946,t:1526929936329};\\\", \\\"{x:1606,y:945,t:1526929936345};\\\", \\\"{x:1606,y:944,t:1526929936407};\\\", \\\"{x:1605,y:943,t:1526929936606};\\\", \\\"{x:1604,y:943,t:1526929936647};\\\", \\\"{x:1603,y:943,t:1526929936686};\\\", \\\"{x:1602,y:943,t:1526929936702};\\\", \\\"{x:1602,y:944,t:1526929937055};\\\", \\\"{x:1602,y:946,t:1526929937070};\\\", \\\"{x:1603,y:947,t:1526929937086};\\\", \\\"{x:1603,y:948,t:1526929937102};\\\", \\\"{x:1605,y:949,t:1526929937112};\\\", \\\"{x:1606,y:950,t:1526929937190};\\\", \\\"{x:1606,y:951,t:1526929937215};\\\", \\\"{x:1607,y:952,t:1526929937228};\\\", \\\"{x:1608,y:953,t:1526929937245};\\\", \\\"{x:1609,y:954,t:1526929937263};\\\", \\\"{x:1610,y:955,t:1526929937279};\\\", \\\"{x:1611,y:957,t:1526929937295};\\\", \\\"{x:1613,y:958,t:1526929937312};\\\", \\\"{x:1613,y:959,t:1526929937328};\\\", \\\"{x:1615,y:961,t:1526929937346};\\\", \\\"{x:1616,y:963,t:1526929937362};\\\", \\\"{x:1616,y:965,t:1526929937379};\\\", \\\"{x:1618,y:968,t:1526929937396};\\\", \\\"{x:1618,y:967,t:1526929937694};\\\", \\\"{x:1617,y:966,t:1526929937702};\\\", \\\"{x:1617,y:965,t:1526929937712};\\\", \\\"{x:1615,y:963,t:1526929937729};\\\", \\\"{x:1615,y:961,t:1526929937745};\\\", \\\"{x:1614,y:960,t:1526929937762};\\\", \\\"{x:1613,y:958,t:1526929937779};\\\", \\\"{x:1613,y:956,t:1526929937796};\\\", \\\"{x:1611,y:954,t:1526929937812};\\\", \\\"{x:1611,y:952,t:1526929937829};\\\", \\\"{x:1610,y:950,t:1526929937846};\\\", \\\"{x:1610,y:949,t:1526929937863};\\\", \\\"{x:1609,y:947,t:1526929937879};\\\", \\\"{x:1608,y:946,t:1526929937897};\\\", \\\"{x:1608,y:944,t:1526929937912};\\\", \\\"{x:1607,y:942,t:1526929937929};\\\", \\\"{x:1607,y:941,t:1526929937947};\\\", \\\"{x:1606,y:940,t:1526929937962};\\\", \\\"{x:1606,y:939,t:1526929937980};\\\", \\\"{x:1606,y:938,t:1526929937997};\\\", \\\"{x:1605,y:936,t:1526929938014};\\\", \\\"{x:1605,y:935,t:1526929938046};\\\", \\\"{x:1604,y:934,t:1526929938094};\\\", \\\"{x:1604,y:933,t:1526929938110};\\\", \\\"{x:1604,y:932,t:1526929938166};\\\", \\\"{x:1604,y:930,t:1526929938191};\\\", \\\"{x:1604,y:929,t:1526929938214};\\\", \\\"{x:1604,y:927,t:1526929938229};\\\", \\\"{x:1604,y:924,t:1526929938246};\\\", \\\"{x:1604,y:922,t:1526929938263};\\\", \\\"{x:1604,y:919,t:1526929938280};\\\", \\\"{x:1604,y:917,t:1526929938297};\\\", \\\"{x:1604,y:916,t:1526929938313};\\\", \\\"{x:1604,y:914,t:1526929938330};\\\", \\\"{x:1604,y:913,t:1526929938347};\\\", \\\"{x:1604,y:911,t:1526929938363};\\\", \\\"{x:1604,y:910,t:1526929938380};\\\", \\\"{x:1603,y:908,t:1526929938397};\\\", \\\"{x:1602,y:907,t:1526929938413};\\\", \\\"{x:1602,y:905,t:1526929938430};\\\", \\\"{x:1602,y:903,t:1526929938446};\\\", \\\"{x:1602,y:901,t:1526929938463};\\\", \\\"{x:1602,y:899,t:1526929938479};\\\", \\\"{x:1602,y:897,t:1526929938497};\\\", \\\"{x:1602,y:895,t:1526929938513};\\\", \\\"{x:1602,y:891,t:1526929938529};\\\", \\\"{x:1602,y:889,t:1526929938547};\\\", \\\"{x:1602,y:885,t:1526929938564};\\\", \\\"{x:1602,y:880,t:1526929938580};\\\", \\\"{x:1602,y:876,t:1526929938597};\\\", \\\"{x:1602,y:870,t:1526929938613};\\\", \\\"{x:1602,y:865,t:1526929938629};\\\", \\\"{x:1602,y:857,t:1526929938646};\\\", \\\"{x:1602,y:853,t:1526929938663};\\\", \\\"{x:1602,y:848,t:1526929938680};\\\", \\\"{x:1602,y:843,t:1526929938696};\\\", \\\"{x:1602,y:839,t:1526929938713};\\\", \\\"{x:1602,y:833,t:1526929938731};\\\", \\\"{x:1602,y:829,t:1526929938746};\\\", \\\"{x:1602,y:827,t:1526929938763};\\\", \\\"{x:1603,y:824,t:1526929938781};\\\", \\\"{x:1603,y:823,t:1526929938796};\\\", \\\"{x:1603,y:822,t:1526929938814};\\\", \\\"{x:1603,y:821,t:1526929938830};\\\", \\\"{x:1603,y:820,t:1526929938846};\\\", \\\"{x:1604,y:819,t:1526929938863};\\\", \\\"{x:1605,y:817,t:1526929938881};\\\", \\\"{x:1605,y:816,t:1526929938896};\\\", \\\"{x:1605,y:815,t:1526929938913};\\\", \\\"{x:1606,y:812,t:1526929938931};\\\", \\\"{x:1606,y:810,t:1526929938946};\\\", \\\"{x:1606,y:809,t:1526929938964};\\\", \\\"{x:1608,y:804,t:1526929938980};\\\", \\\"{x:1608,y:799,t:1526929938997};\\\", \\\"{x:1610,y:790,t:1526929939013};\\\", \\\"{x:1610,y:780,t:1526929939030};\\\", \\\"{x:1611,y:773,t:1526929939046};\\\", \\\"{x:1612,y:767,t:1526929939063};\\\", \\\"{x:1612,y:757,t:1526929939080};\\\", \\\"{x:1612,y:749,t:1526929939096};\\\", \\\"{x:1611,y:737,t:1526929939114};\\\", \\\"{x:1607,y:725,t:1526929939131};\\\", \\\"{x:1606,y:716,t:1526929939146};\\\", \\\"{x:1604,y:712,t:1526929939164};\\\", \\\"{x:1603,y:708,t:1526929939181};\\\", \\\"{x:1603,y:707,t:1526929939196};\\\", \\\"{x:1603,y:705,t:1526929939214};\\\", \\\"{x:1602,y:702,t:1526929939230};\\\", \\\"{x:1602,y:701,t:1526929939247};\\\", \\\"{x:1602,y:697,t:1526929939264};\\\", \\\"{x:1602,y:694,t:1526929939281};\\\", \\\"{x:1602,y:690,t:1526929939298};\\\", \\\"{x:1602,y:687,t:1526929939314};\\\", \\\"{x:1602,y:680,t:1526929939331};\\\", \\\"{x:1602,y:673,t:1526929939348};\\\", \\\"{x:1602,y:666,t:1526929939364};\\\", \\\"{x:1602,y:658,t:1526929939381};\\\", \\\"{x:1602,y:651,t:1526929939398};\\\", \\\"{x:1604,y:643,t:1526929939414};\\\", \\\"{x:1605,y:631,t:1526929939430};\\\", \\\"{x:1605,y:623,t:1526929939447};\\\", \\\"{x:1605,y:616,t:1526929939464};\\\", \\\"{x:1605,y:612,t:1526929939481};\\\", \\\"{x:1606,y:608,t:1526929939498};\\\", \\\"{x:1606,y:605,t:1526929939514};\\\", \\\"{x:1607,y:602,t:1526929939531};\\\", \\\"{x:1607,y:598,t:1526929939548};\\\", \\\"{x:1608,y:593,t:1526929939564};\\\", \\\"{x:1609,y:590,t:1526929939581};\\\", \\\"{x:1609,y:585,t:1526929939598};\\\", \\\"{x:1610,y:579,t:1526929939614};\\\", \\\"{x:1611,y:574,t:1526929939631};\\\", \\\"{x:1611,y:572,t:1526929939649};\\\", \\\"{x:1612,y:569,t:1526929939665};\\\", \\\"{x:1612,y:567,t:1526929939681};\\\", \\\"{x:1612,y:565,t:1526929939698};\\\", \\\"{x:1612,y:563,t:1526929939718};\\\", \\\"{x:1613,y:562,t:1526929939742};\\\", \\\"{x:1614,y:560,t:1526929939790};\\\", \\\"{x:1612,y:560,t:1526929941398};\\\", \\\"{x:1601,y:561,t:1526929941416};\\\", \\\"{x:1582,y:567,t:1526929941431};\\\", \\\"{x:1557,y:575,t:1526929941448};\\\", \\\"{x:1517,y:586,t:1526929941466};\\\", \\\"{x:1437,y:609,t:1526929941481};\\\", \\\"{x:1325,y:633,t:1526929941499};\\\", \\\"{x:1173,y:675,t:1526929941515};\\\", \\\"{x:991,y:720,t:1526929941531};\\\", \\\"{x:818,y:763,t:1526929941548};\\\", \\\"{x:642,y:808,t:1526929941566};\\\", \\\"{x:427,y:858,t:1526929941582};\\\", \\\"{x:336,y:885,t:1526929941598};\\\", \\\"{x:282,y:903,t:1526929941615};\\\", \\\"{x:255,y:908,t:1526929941632};\\\", \\\"{x:238,y:908,t:1526929941648};\\\", \\\"{x:228,y:909,t:1526929941665};\\\", \\\"{x:225,y:911,t:1526929941682};\\\", \\\"{x:221,y:911,t:1526929941698};\\\", \\\"{x:215,y:909,t:1526929941715};\\\", \\\"{x:204,y:902,t:1526929941732};\\\", \\\"{x:200,y:900,t:1526929941748};\\\", \\\"{x:197,y:893,t:1526929941765};\\\", \\\"{x:187,y:860,t:1526929941782};\\\", \\\"{x:181,y:833,t:1526929941798};\\\", \\\"{x:176,y:810,t:1526929941815};\\\", \\\"{x:172,y:790,t:1526929941832};\\\", \\\"{x:169,y:776,t:1526929941848};\\\", \\\"{x:164,y:760,t:1526929941865};\\\", \\\"{x:161,y:745,t:1526929941882};\\\", \\\"{x:160,y:729,t:1526929941898};\\\", \\\"{x:156,y:714,t:1526929941915};\\\", \\\"{x:156,y:700,t:1526929941933};\\\", \\\"{x:156,y:687,t:1526929941949};\\\", \\\"{x:156,y:678,t:1526929941966};\\\", \\\"{x:154,y:669,t:1526929941982};\\\", \\\"{x:153,y:665,t:1526929941999};\\\", \\\"{x:153,y:663,t:1526929942022};\\\", \\\"{x:152,y:661,t:1526929942038};\\\", \\\"{x:152,y:660,t:1526929942049};\\\", \\\"{x:152,y:656,t:1526929942066};\\\", \\\"{x:152,y:652,t:1526929942083};\\\", \\\"{x:152,y:649,t:1526929942100};\\\", \\\"{x:152,y:648,t:1526929942115};\\\", \\\"{x:152,y:646,t:1526929942132};\\\", \\\"{x:152,y:645,t:1526929942166};\\\", \\\"{x:152,y:643,t:1526929942238};\\\", \\\"{x:152,y:642,t:1526929942278};\\\", \\\"{x:152,y:641,t:1526929942814};\\\", \\\"{x:153,y:641,t:1526929942926};\\\", \\\"{x:154,y:641,t:1526929942942};\\\", \\\"{x:155,y:641,t:1526929942950};\\\", \\\"{x:156,y:641,t:1526929942974};\\\", \\\"{x:158,y:641,t:1526929942984};\\\", \\\"{x:162,y:642,t:1526929943001};\\\", \\\"{x:170,y:644,t:1526929943018};\\\", \\\"{x:184,y:650,t:1526929943034};\\\", \\\"{x:205,y:656,t:1526929943051};\\\", \\\"{x:241,y:668,t:1526929943067};\\\", \\\"{x:303,y:687,t:1526929943085};\\\", \\\"{x:392,y:712,t:1526929943100};\\\", \\\"{x:501,y:734,t:1526929943117};\\\", \\\"{x:683,y:778,t:1526929943135};\\\", \\\"{x:826,y:815,t:1526929943150};\\\", \\\"{x:977,y:848,t:1526929943167};\\\", \\\"{x:1103,y:880,t:1526929943185};\\\", \\\"{x:1227,y:907,t:1526929943201};\\\", \\\"{x:1331,y:933,t:1526929943217};\\\", \\\"{x:1400,y:951,t:1526929943234};\\\", \\\"{x:1432,y:958,t:1526929943251};\\\", \\\"{x:1454,y:963,t:1526929943268};\\\", \\\"{x:1467,y:965,t:1526929943284};\\\", \\\"{x:1471,y:965,t:1526929943300};\\\", \\\"{x:1472,y:965,t:1526929943318};\\\", \\\"{x:1471,y:965,t:1526929943568};\\\", \\\"{x:1470,y:966,t:1526929943599};\\\", \\\"{x:1469,y:967,t:1526929943631};\\\", \\\"{x:1468,y:967,t:1526929943663};\\\", \\\"{x:1467,y:967,t:1526929943704};\\\", \\\"{x:1466,y:967,t:1526929943718};\\\", \\\"{x:1460,y:968,t:1526929943734};\\\", \\\"{x:1454,y:969,t:1526929943751};\\\", \\\"{x:1445,y:970,t:1526929943768};\\\", \\\"{x:1436,y:970,t:1526929943784};\\\", \\\"{x:1426,y:970,t:1526929943802};\\\", \\\"{x:1420,y:970,t:1526929943818};\\\", \\\"{x:1416,y:970,t:1526929943834};\\\", \\\"{x:1415,y:970,t:1526929943852};\\\", \\\"{x:1414,y:970,t:1526929943887};\\\", \\\"{x:1413,y:970,t:1526929943919};\\\", \\\"{x:1412,y:970,t:1526929943935};\\\", \\\"{x:1410,y:970,t:1526929943959};\\\", \\\"{x:1413,y:969,t:1526929944102};\\\", \\\"{x:1423,y:966,t:1526929944118};\\\", \\\"{x:1438,y:965,t:1526929944134};\\\", \\\"{x:1452,y:964,t:1526929944151};\\\", \\\"{x:1464,y:961,t:1526929944169};\\\", \\\"{x:1479,y:960,t:1526929944185};\\\", \\\"{x:1493,y:956,t:1526929944202};\\\", \\\"{x:1507,y:956,t:1526929944218};\\\", \\\"{x:1518,y:956,t:1526929944234};\\\", \\\"{x:1530,y:956,t:1526929944251};\\\", \\\"{x:1544,y:956,t:1526929944269};\\\", \\\"{x:1559,y:956,t:1526929944284};\\\", \\\"{x:1570,y:956,t:1526929944301};\\\", \\\"{x:1589,y:958,t:1526929944318};\\\", \\\"{x:1598,y:961,t:1526929944334};\\\", \\\"{x:1602,y:962,t:1526929944351};\\\", \\\"{x:1603,y:962,t:1526929944368};\\\", \\\"{x:1603,y:963,t:1526929944385};\\\", \\\"{x:1604,y:963,t:1526929944414};\\\", \\\"{x:1605,y:964,t:1526929944446};\\\", \\\"{x:1605,y:965,t:1526929944478};\\\", \\\"{x:1605,y:966,t:1526929944485};\\\", \\\"{x:1605,y:967,t:1526929944502};\\\", \\\"{x:1604,y:972,t:1526929944518};\\\", \\\"{x:1601,y:975,t:1526929944535};\\\", \\\"{x:1593,y:978,t:1526929944551};\\\", \\\"{x:1582,y:983,t:1526929944569};\\\", \\\"{x:1572,y:986,t:1526929944586};\\\", \\\"{x:1559,y:989,t:1526929944601};\\\", \\\"{x:1550,y:990,t:1526929944618};\\\", \\\"{x:1540,y:994,t:1526929944636};\\\", \\\"{x:1530,y:997,t:1526929944652};\\\", \\\"{x:1522,y:998,t:1526929944668};\\\", \\\"{x:1513,y:1001,t:1526929944686};\\\", \\\"{x:1506,y:1003,t:1526929944702};\\\", \\\"{x:1498,y:1004,t:1526929944718};\\\", \\\"{x:1494,y:1005,t:1526929944736};\\\", \\\"{x:1491,y:1007,t:1526929944752};\\\", \\\"{x:1489,y:1007,t:1526929944768};\\\", \\\"{x:1487,y:1008,t:1526929944785};\\\", \\\"{x:1484,y:1008,t:1526929944802};\\\", \\\"{x:1482,y:1008,t:1526929944819};\\\", \\\"{x:1478,y:1009,t:1526929944836};\\\", \\\"{x:1477,y:1009,t:1526929944852};\\\", \\\"{x:1475,y:1009,t:1526929944893};\\\", \\\"{x:1474,y:1009,t:1526929944901};\\\", \\\"{x:1472,y:1010,t:1526929944919};\\\", \\\"{x:1471,y:1010,t:1526929944935};\\\", \\\"{x:1469,y:1010,t:1526929944953};\\\", \\\"{x:1468,y:1010,t:1526929944969};\\\", \\\"{x:1467,y:1010,t:1526929945038};\\\", \\\"{x:1466,y:1010,t:1526929945063};\\\", \\\"{x:1465,y:1010,t:1526929945086};\\\", \\\"{x:1463,y:1010,t:1526929945135};\\\", \\\"{x:1462,y:1010,t:1526929945167};\\\", \\\"{x:1460,y:1010,t:1526929945191};\\\", \\\"{x:1459,y:1010,t:1526929945247};\\\", \\\"{x:1458,y:1010,t:1526929945271};\\\", \\\"{x:1457,y:1010,t:1526929945303};\\\", \\\"{x:1456,y:1010,t:1526929945327};\\\", \\\"{x:1455,y:1010,t:1526929945400};\\\", \\\"{x:1454,y:1010,t:1526929945496};\\\", \\\"{x:1452,y:1010,t:1526929945574};\\\", \\\"{x:1450,y:1009,t:1526929945606};\\\", \\\"{x:1449,y:1009,t:1526929945622};\\\", \\\"{x:1446,y:1008,t:1526929945823};\\\", \\\"{x:1446,y:1007,t:1526929945838};\\\", \\\"{x:1446,y:1006,t:1526929945853};\\\", \\\"{x:1446,y:1004,t:1526929945870};\\\", \\\"{x:1446,y:1003,t:1526929945886};\\\", \\\"{x:1446,y:1001,t:1526929945903};\\\", \\\"{x:1446,y:999,t:1526929945920};\\\", \\\"{x:1446,y:997,t:1526929945937};\\\", \\\"{x:1447,y:996,t:1526929945952};\\\", \\\"{x:1447,y:994,t:1526929945969};\\\", \\\"{x:1449,y:993,t:1526929945990};\\\", \\\"{x:1449,y:992,t:1526929946030};\\\", \\\"{x:1450,y:991,t:1526929946038};\\\", \\\"{x:1452,y:990,t:1526929946062};\\\", \\\"{x:1453,y:988,t:1526929946086};\\\", \\\"{x:1454,y:988,t:1526929946102};\\\", \\\"{x:1455,y:987,t:1526929946118};\\\", \\\"{x:1456,y:987,t:1526929946142};\\\", \\\"{x:1458,y:986,t:1526929946152};\\\", \\\"{x:1458,y:985,t:1526929946170};\\\", \\\"{x:1459,y:985,t:1526929946187};\\\", \\\"{x:1461,y:984,t:1526929946202};\\\", \\\"{x:1463,y:982,t:1526929946220};\\\", \\\"{x:1465,y:982,t:1526929946236};\\\", \\\"{x:1468,y:979,t:1526929946253};\\\", \\\"{x:1471,y:977,t:1526929946270};\\\", \\\"{x:1474,y:974,t:1526929946287};\\\", \\\"{x:1481,y:967,t:1526929946303};\\\", \\\"{x:1485,y:962,t:1526929946320};\\\", \\\"{x:1487,y:956,t:1526929946336};\\\", \\\"{x:1488,y:951,t:1526929946353};\\\", \\\"{x:1489,y:948,t:1526929946370};\\\", \\\"{x:1491,y:945,t:1526929946387};\\\", \\\"{x:1491,y:940,t:1526929946403};\\\", \\\"{x:1491,y:936,t:1526929946420};\\\", \\\"{x:1491,y:932,t:1526929946436};\\\", \\\"{x:1493,y:929,t:1526929946454};\\\", \\\"{x:1493,y:926,t:1526929946470};\\\", \\\"{x:1494,y:921,t:1526929946486};\\\", \\\"{x:1495,y:917,t:1526929946504};\\\", \\\"{x:1495,y:916,t:1526929946535};\\\", \\\"{x:1495,y:914,t:1526929946559};\\\", \\\"{x:1495,y:913,t:1526929946570};\\\", \\\"{x:1495,y:912,t:1526929946586};\\\", \\\"{x:1491,y:912,t:1526929947142};\\\", \\\"{x:1488,y:912,t:1526929947153};\\\", \\\"{x:1482,y:912,t:1526929947170};\\\", \\\"{x:1477,y:913,t:1526929947187};\\\", \\\"{x:1474,y:915,t:1526929947203};\\\", \\\"{x:1470,y:917,t:1526929947220};\\\", \\\"{x:1468,y:917,t:1526929947238};\\\", \\\"{x:1467,y:918,t:1526929947254};\\\", \\\"{x:1466,y:919,t:1526929947302};\\\", \\\"{x:1466,y:920,t:1526929947334};\\\", \\\"{x:1466,y:922,t:1526929947390};\\\", \\\"{x:1466,y:924,t:1526929947406};\\\", \\\"{x:1473,y:925,t:1526929947420};\\\", \\\"{x:1489,y:928,t:1526929947438};\\\", \\\"{x:1535,y:935,t:1526929947454};\\\", \\\"{x:1568,y:939,t:1526929947471};\\\", \\\"{x:1622,y:939,t:1526929947487};\\\", \\\"{x:1655,y:939,t:1526929947504};\\\", \\\"{x:1677,y:939,t:1526929947520};\\\", \\\"{x:1688,y:939,t:1526929947538};\\\", \\\"{x:1692,y:940,t:1526929947553};\\\", \\\"{x:1693,y:941,t:1526929947670};\\\", \\\"{x:1693,y:942,t:1526929947685};\\\", \\\"{x:1694,y:943,t:1526929947694};\\\", \\\"{x:1695,y:943,t:1526929947705};\\\", \\\"{x:1697,y:949,t:1526929947720};\\\", \\\"{x:1699,y:953,t:1526929947737};\\\", \\\"{x:1700,y:958,t:1526929947755};\\\", \\\"{x:1700,y:961,t:1526929947771};\\\", \\\"{x:1702,y:965,t:1526929947788};\\\", \\\"{x:1702,y:967,t:1526929947804};\\\", \\\"{x:1702,y:971,t:1526929947821};\\\", \\\"{x:1702,y:974,t:1526929947838};\\\", \\\"{x:1702,y:975,t:1526929947854};\\\", \\\"{x:1702,y:977,t:1526929947870};\\\", \\\"{x:1702,y:978,t:1526929947887};\\\", \\\"{x:1701,y:980,t:1526929947905};\\\", \\\"{x:1700,y:981,t:1526929947921};\\\", \\\"{x:1700,y:982,t:1526929947937};\\\", \\\"{x:1699,y:983,t:1526929947955};\\\", \\\"{x:1698,y:984,t:1526929947971};\\\", \\\"{x:1697,y:984,t:1526929947990};\\\", \\\"{x:1696,y:984,t:1526929948038};\\\", \\\"{x:1694,y:984,t:1526929948134};\\\", \\\"{x:1693,y:984,t:1526929948262};\\\", \\\"{x:1692,y:985,t:1526929948287};\\\", \\\"{x:1691,y:985,t:1526929948294};\\\", \\\"{x:1690,y:986,t:1526929948318};\\\", \\\"{x:1689,y:987,t:1526929948358};\\\", \\\"{x:1688,y:988,t:1526929948390};\\\", \\\"{x:1687,y:988,t:1526929948414};\\\", \\\"{x:1686,y:988,t:1526929948582};\\\", \\\"{x:1686,y:987,t:1526929948606};\\\", \\\"{x:1684,y:986,t:1526929948622};\\\", \\\"{x:1683,y:985,t:1526929948726};\\\", \\\"{x:1683,y:984,t:1526929948751};\\\", \\\"{x:1682,y:983,t:1526929948758};\\\", \\\"{x:1681,y:983,t:1526929948790};\\\", \\\"{x:1680,y:982,t:1526929948830};\\\", \\\"{x:1679,y:981,t:1526929948838};\\\", \\\"{x:1677,y:981,t:1526929948854};\\\", \\\"{x:1673,y:981,t:1526929948872};\\\", \\\"{x:1666,y:981,t:1526929948889};\\\", \\\"{x:1659,y:979,t:1526929948905};\\\", \\\"{x:1652,y:979,t:1526929948922};\\\", \\\"{x:1648,y:979,t:1526929948939};\\\", \\\"{x:1647,y:979,t:1526929948955};\\\", \\\"{x:1645,y:979,t:1526929948974};\\\", \\\"{x:1644,y:979,t:1526929948990};\\\", \\\"{x:1643,y:979,t:1526929949006};\\\", \\\"{x:1641,y:979,t:1526929949022};\\\", \\\"{x:1640,y:979,t:1526929949038};\\\", \\\"{x:1639,y:979,t:1526929949055};\\\", \\\"{x:1638,y:979,t:1526929949071};\\\", \\\"{x:1635,y:979,t:1526929949089};\\\", \\\"{x:1634,y:980,t:1526929949105};\\\", \\\"{x:1632,y:981,t:1526929949122};\\\", \\\"{x:1631,y:981,t:1526929949190};\\\", \\\"{x:1630,y:981,t:1526929949205};\\\", \\\"{x:1629,y:981,t:1526929949222};\\\", \\\"{x:1628,y:981,t:1526929949239};\\\", \\\"{x:1627,y:981,t:1526929949256};\\\", \\\"{x:1626,y:981,t:1526929949272};\\\", \\\"{x:1625,y:981,t:1526929949295};\\\", \\\"{x:1623,y:981,t:1526929949318};\\\", \\\"{x:1622,y:980,t:1526929949343};\\\", \\\"{x:1620,y:979,t:1526929949356};\\\", \\\"{x:1618,y:979,t:1526929949372};\\\", \\\"{x:1617,y:978,t:1526929949389};\\\", \\\"{x:1616,y:977,t:1526929949406};\\\", \\\"{x:1614,y:976,t:1526929949454};\\\", \\\"{x:1614,y:975,t:1526929949470};\\\", \\\"{x:1613,y:974,t:1526929949478};\\\", \\\"{x:1612,y:974,t:1526929949488};\\\", \\\"{x:1612,y:972,t:1526929949506};\\\", \\\"{x:1611,y:970,t:1526929949522};\\\", \\\"{x:1610,y:969,t:1526929949539};\\\", \\\"{x:1609,y:969,t:1526929949555};\\\", \\\"{x:1609,y:968,t:1526929949575};\\\", \\\"{x:1609,y:967,t:1526929949598};\\\", \\\"{x:1609,y:966,t:1526929949606};\\\", \\\"{x:1609,y:965,t:1526929949623};\\\", \\\"{x:1608,y:963,t:1526929949639};\\\", \\\"{x:1608,y:965,t:1526929949994};\\\", \\\"{x:1608,y:966,t:1526929950026};\\\", \\\"{x:1608,y:968,t:1526929950042};\\\", \\\"{x:1608,y:969,t:1526929950067};\\\", \\\"{x:1608,y:971,t:1526929950090};\\\", \\\"{x:1608,y:972,t:1526929950115};\\\", \\\"{x:1608,y:974,t:1526929950138};\\\", \\\"{x:1608,y:976,t:1526929950154};\\\", \\\"{x:1608,y:977,t:1526929950161};\\\", \\\"{x:1608,y:978,t:1526929950176};\\\", \\\"{x:1606,y:979,t:1526929950193};\\\", \\\"{x:1605,y:981,t:1526929950209};\\\", \\\"{x:1604,y:981,t:1526929950227};\\\", \\\"{x:1601,y:982,t:1526929950243};\\\", \\\"{x:1600,y:982,t:1526929950265};\\\", \\\"{x:1598,y:984,t:1526929950276};\\\", \\\"{x:1597,y:984,t:1526929950293};\\\", \\\"{x:1594,y:985,t:1526929950309};\\\", \\\"{x:1591,y:986,t:1526929950327};\\\", \\\"{x:1590,y:986,t:1526929950343};\\\", \\\"{x:1586,y:987,t:1526929950360};\\\", \\\"{x:1584,y:987,t:1526929950376};\\\", \\\"{x:1581,y:987,t:1526929950394};\\\", \\\"{x:1578,y:987,t:1526929950410};\\\", \\\"{x:1576,y:987,t:1526929950426};\\\", \\\"{x:1574,y:987,t:1526929950444};\\\", \\\"{x:1573,y:987,t:1526929950459};\\\", \\\"{x:1572,y:987,t:1526929950477};\\\", \\\"{x:1571,y:987,t:1526929950493};\\\", \\\"{x:1568,y:987,t:1526929950509};\\\", \\\"{x:1565,y:987,t:1526929950527};\\\", \\\"{x:1561,y:987,t:1526929950544};\\\", \\\"{x:1559,y:986,t:1526929950560};\\\", \\\"{x:1557,y:984,t:1526929950577};\\\", \\\"{x:1555,y:983,t:1526929950594};\\\", \\\"{x:1554,y:982,t:1526929950609};\\\", \\\"{x:1552,y:980,t:1526929950627};\\\", \\\"{x:1551,y:979,t:1526929950643};\\\", \\\"{x:1548,y:976,t:1526929950661};\\\", \\\"{x:1546,y:973,t:1526929950677};\\\", \\\"{x:1546,y:971,t:1526929950694};\\\", \\\"{x:1546,y:970,t:1526929950747};\\\", \\\"{x:1546,y:969,t:1526929950762};\\\", \\\"{x:1546,y:968,t:1526929950777};\\\", \\\"{x:1546,y:965,t:1526929950794};\\\", \\\"{x:1546,y:964,t:1526929950811};\\\", \\\"{x:1546,y:962,t:1526929950827};\\\", \\\"{x:1545,y:961,t:1526929950843};\\\", \\\"{x:1544,y:962,t:1526929950993};\\\", \\\"{x:1541,y:966,t:1526929951010};\\\", \\\"{x:1537,y:970,t:1526929951027};\\\", \\\"{x:1532,y:973,t:1526929951043};\\\", \\\"{x:1526,y:974,t:1526929951061};\\\", \\\"{x:1521,y:975,t:1526929951077};\\\", \\\"{x:1515,y:975,t:1526929951093};\\\", \\\"{x:1508,y:975,t:1526929951110};\\\", \\\"{x:1498,y:975,t:1526929951128};\\\", \\\"{x:1492,y:975,t:1526929951143};\\\", \\\"{x:1488,y:975,t:1526929951161};\\\", \\\"{x:1484,y:975,t:1526929951178};\\\", \\\"{x:1483,y:975,t:1526929951193};\\\", \\\"{x:1481,y:975,t:1526929951290};\\\", \\\"{x:1481,y:974,t:1526929951297};\\\", \\\"{x:1479,y:973,t:1526929951310};\\\", \\\"{x:1479,y:971,t:1526929951327};\\\", \\\"{x:1478,y:970,t:1526929951343};\\\", \\\"{x:1478,y:969,t:1526929951360};\\\", \\\"{x:1477,y:969,t:1526929951425};\\\", \\\"{x:1477,y:968,t:1526929951482};\\\", \\\"{x:1477,y:967,t:1526929951546};\\\", \\\"{x:1476,y:967,t:1526929951562};\\\", \\\"{x:1474,y:967,t:1526929951682};\\\", \\\"{x:1473,y:967,t:1526929951694};\\\", \\\"{x:1472,y:969,t:1526929951711};\\\", \\\"{x:1471,y:970,t:1526929951727};\\\", \\\"{x:1471,y:971,t:1526929951744};\\\", \\\"{x:1470,y:971,t:1526929951761};\\\", \\\"{x:1467,y:973,t:1526929951778};\\\", \\\"{x:1466,y:974,t:1526929951794};\\\", \\\"{x:1464,y:975,t:1526929951811};\\\", \\\"{x:1460,y:975,t:1526929951828};\\\", \\\"{x:1453,y:978,t:1526929951844};\\\", \\\"{x:1447,y:979,t:1526929951860};\\\", \\\"{x:1442,y:979,t:1526929951877};\\\", \\\"{x:1438,y:981,t:1526929951894};\\\", \\\"{x:1435,y:981,t:1526929951910};\\\", \\\"{x:1431,y:981,t:1526929951927};\\\", \\\"{x:1427,y:981,t:1526929951945};\\\", \\\"{x:1419,y:981,t:1526929951961};\\\", \\\"{x:1416,y:981,t:1526929951978};\\\", \\\"{x:1413,y:981,t:1526929951995};\\\", \\\"{x:1411,y:981,t:1526929952011};\\\", \\\"{x:1409,y:981,t:1526929952033};\\\", \\\"{x:1408,y:981,t:1526929952065};\\\", \\\"{x:1407,y:980,t:1526929952077};\\\", \\\"{x:1405,y:978,t:1526929952095};\\\", \\\"{x:1404,y:978,t:1526929952111};\\\", \\\"{x:1403,y:976,t:1526929952128};\\\", \\\"{x:1402,y:975,t:1526929952162};\\\", \\\"{x:1399,y:975,t:1526929952251};\\\", \\\"{x:1397,y:976,t:1526929952262};\\\", \\\"{x:1392,y:977,t:1526929952278};\\\", \\\"{x:1385,y:979,t:1526929952295};\\\", \\\"{x:1380,y:980,t:1526929952311};\\\", \\\"{x:1372,y:980,t:1526929952328};\\\", \\\"{x:1365,y:980,t:1526929952345};\\\", \\\"{x:1360,y:980,t:1526929952361};\\\", \\\"{x:1357,y:980,t:1526929952377};\\\", \\\"{x:1356,y:980,t:1526929952402};\\\", \\\"{x:1355,y:980,t:1526929952412};\\\", \\\"{x:1354,y:980,t:1526929952429};\\\", \\\"{x:1353,y:980,t:1526929952445};\\\", \\\"{x:1350,y:980,t:1526929952462};\\\", \\\"{x:1350,y:979,t:1526929952478};\\\", \\\"{x:1349,y:979,t:1526929952529};\\\", \\\"{x:1348,y:979,t:1526929952553};\\\", \\\"{x:1347,y:979,t:1526929952570};\\\", \\\"{x:1346,y:979,t:1526929952675};\\\", \\\"{x:1345,y:979,t:1526929952738};\\\", \\\"{x:1344,y:979,t:1526929952753};\\\", \\\"{x:1344,y:978,t:1526929952762};\\\", \\\"{x:1342,y:976,t:1526929952778};\\\", \\\"{x:1341,y:975,t:1526929952801};\\\", \\\"{x:1341,y:974,t:1526929952811};\\\", \\\"{x:1341,y:972,t:1526929952829};\\\", \\\"{x:1340,y:972,t:1526929952857};\\\", \\\"{x:1340,y:971,t:1526929952873};\\\", \\\"{x:1340,y:970,t:1526929952922};\\\", \\\"{x:1340,y:969,t:1526929952945};\\\", \\\"{x:1340,y:968,t:1526929952978};\\\", \\\"{x:1340,y:967,t:1526929953002};\\\", \\\"{x:1340,y:966,t:1526929953025};\\\", \\\"{x:1341,y:966,t:1526929953050};\\\", \\\"{x:1342,y:965,t:1526929953074};\\\", \\\"{x:1343,y:965,t:1526929953089};\\\", \\\"{x:1344,y:965,t:1526929953114};\\\", \\\"{x:1345,y:964,t:1526929953138};\\\", \\\"{x:1346,y:964,t:1526929953194};\\\", \\\"{x:1347,y:963,t:1526929953203};\\\", \\\"{x:1348,y:963,t:1526929953362};\\\", \\\"{x:1349,y:963,t:1526929953417};\\\", \\\"{x:1351,y:961,t:1526929953681};\\\", \\\"{x:1351,y:959,t:1526929954802};\\\", \\\"{x:1351,y:958,t:1526929954814};\\\", \\\"{x:1349,y:952,t:1526929954830};\\\", \\\"{x:1347,y:946,t:1526929954847};\\\", \\\"{x:1346,y:943,t:1526929954864};\\\", \\\"{x:1346,y:940,t:1526929954879};\\\", \\\"{x:1346,y:938,t:1526929954897};\\\", \\\"{x:1346,y:935,t:1526929954913};\\\", \\\"{x:1346,y:928,t:1526929954929};\\\", \\\"{x:1346,y:922,t:1526929954946};\\\", \\\"{x:1346,y:919,t:1526929954964};\\\", \\\"{x:1346,y:915,t:1526929954980};\\\", \\\"{x:1346,y:913,t:1526929954996};\\\", \\\"{x:1347,y:909,t:1526929955014};\\\", \\\"{x:1348,y:906,t:1526929955030};\\\", \\\"{x:1348,y:902,t:1526929955047};\\\", \\\"{x:1350,y:898,t:1526929955065};\\\", \\\"{x:1350,y:896,t:1526929955079};\\\", \\\"{x:1350,y:895,t:1526929955706};\\\", \\\"{x:1349,y:894,t:1526929955801};\\\", \\\"{x:1348,y:894,t:1526929955857};\\\", \\\"{x:1348,y:893,t:1526929955898};\\\", \\\"{x:1347,y:892,t:1526929955921};\\\", \\\"{x:1347,y:891,t:1526929955994};\\\", \\\"{x:1347,y:889,t:1526929956122};\\\", \\\"{x:1347,y:888,t:1526929956202};\\\", \\\"{x:1347,y:887,t:1526929956217};\\\", \\\"{x:1347,y:886,t:1526929956266};\\\", \\\"{x:1347,y:885,t:1526929956305};\\\", \\\"{x:1347,y:884,t:1526929956329};\\\", \\\"{x:1347,y:882,t:1526929956338};\\\", \\\"{x:1348,y:881,t:1526929956348};\\\", \\\"{x:1348,y:879,t:1526929956365};\\\", \\\"{x:1349,y:876,t:1526929956381};\\\", \\\"{x:1350,y:874,t:1526929956398};\\\", \\\"{x:1350,y:872,t:1526929956415};\\\", \\\"{x:1351,y:870,t:1526929956431};\\\", \\\"{x:1352,y:868,t:1526929956448};\\\", \\\"{x:1352,y:865,t:1526929956465};\\\", \\\"{x:1353,y:862,t:1526929956481};\\\", \\\"{x:1354,y:857,t:1526929956497};\\\", \\\"{x:1356,y:853,t:1526929956515};\\\", \\\"{x:1357,y:849,t:1526929956531};\\\", \\\"{x:1357,y:847,t:1526929956548};\\\", \\\"{x:1358,y:844,t:1526929956565};\\\", \\\"{x:1358,y:842,t:1526929956581};\\\", \\\"{x:1359,y:840,t:1526929956597};\\\", \\\"{x:1359,y:836,t:1526929956615};\\\", \\\"{x:1359,y:835,t:1526929956631};\\\", \\\"{x:1359,y:833,t:1526929956647};\\\", \\\"{x:1359,y:831,t:1526929956665};\\\", \\\"{x:1359,y:829,t:1526929956681};\\\", \\\"{x:1359,y:826,t:1526929956698};\\\", \\\"{x:1359,y:824,t:1526929956715};\\\", \\\"{x:1359,y:822,t:1526929956731};\\\", \\\"{x:1359,y:821,t:1526929956753};\\\", \\\"{x:1359,y:820,t:1526929956765};\\\", \\\"{x:1359,y:819,t:1526929956782};\\\", \\\"{x:1359,y:817,t:1526929956798};\\\", \\\"{x:1359,y:815,t:1526929956814};\\\", \\\"{x:1359,y:811,t:1526929956832};\\\", \\\"{x:1358,y:808,t:1526929956848};\\\", \\\"{x:1357,y:806,t:1526929956865};\\\", \\\"{x:1356,y:800,t:1526929956882};\\\", \\\"{x:1354,y:797,t:1526929956898};\\\", \\\"{x:1353,y:795,t:1526929956915};\\\", \\\"{x:1352,y:790,t:1526929956931};\\\", \\\"{x:1349,y:786,t:1526929956947};\\\", \\\"{x:1347,y:780,t:1526929956964};\\\", \\\"{x:1344,y:774,t:1526929956982};\\\", \\\"{x:1342,y:768,t:1526929956998};\\\", \\\"{x:1337,y:758,t:1526929957014};\\\", \\\"{x:1337,y:754,t:1526929957031};\\\", \\\"{x:1333,y:745,t:1526929957048};\\\", \\\"{x:1328,y:736,t:1526929957065};\\\", \\\"{x:1325,y:727,t:1526929957082};\\\", \\\"{x:1324,y:722,t:1526929957097};\\\", \\\"{x:1321,y:717,t:1526929957115};\\\", \\\"{x:1320,y:712,t:1526929957132};\\\", \\\"{x:1319,y:706,t:1526929957148};\\\", \\\"{x:1316,y:699,t:1526929957165};\\\", \\\"{x:1315,y:692,t:1526929957182};\\\", \\\"{x:1315,y:686,t:1526929957198};\\\", \\\"{x:1315,y:681,t:1526929957215};\\\", \\\"{x:1315,y:674,t:1526929957232};\\\", \\\"{x:1315,y:669,t:1526929957248};\\\", \\\"{x:1315,y:663,t:1526929957265};\\\", \\\"{x:1315,y:654,t:1526929957282};\\\", \\\"{x:1315,y:648,t:1526929957299};\\\", \\\"{x:1315,y:639,t:1526929957315};\\\", \\\"{x:1315,y:633,t:1526929957332};\\\", \\\"{x:1315,y:621,t:1526929957349};\\\", \\\"{x:1317,y:609,t:1526929957365};\\\", \\\"{x:1319,y:600,t:1526929957382};\\\", \\\"{x:1321,y:589,t:1526929957399};\\\", \\\"{x:1322,y:578,t:1526929957415};\\\", \\\"{x:1323,y:568,t:1526929957432};\\\", \\\"{x:1323,y:559,t:1526929957449};\\\", \\\"{x:1326,y:550,t:1526929957465};\\\", \\\"{x:1326,y:537,t:1526929957482};\\\", \\\"{x:1327,y:528,t:1526929957499};\\\", \\\"{x:1327,y:523,t:1526929957515};\\\", \\\"{x:1327,y:519,t:1526929957532};\\\", \\\"{x:1327,y:515,t:1526929957549};\\\", \\\"{x:1327,y:511,t:1526929957565};\\\", \\\"{x:1327,y:508,t:1526929957582};\\\", \\\"{x:1327,y:507,t:1526929957599};\\\", \\\"{x:1327,y:505,t:1526929957615};\\\", \\\"{x:1327,y:504,t:1526929957634};\\\", \\\"{x:1327,y:503,t:1526929957649};\\\", \\\"{x:1327,y:502,t:1526929957665};\\\", \\\"{x:1327,y:496,t:1526929957682};\\\", \\\"{x:1327,y:492,t:1526929957699};\\\", \\\"{x:1327,y:488,t:1526929957715};\\\", \\\"{x:1327,y:483,t:1526929957732};\\\", \\\"{x:1328,y:478,t:1526929957748};\\\", \\\"{x:1328,y:473,t:1526929957766};\\\", \\\"{x:1328,y:470,t:1526929957782};\\\", \\\"{x:1328,y:469,t:1526929957799};\\\", \\\"{x:1328,y:468,t:1526929957816};\\\", \\\"{x:1328,y:467,t:1526929957832};\\\", \\\"{x:1328,y:466,t:1526929957865};\\\", \\\"{x:1328,y:465,t:1526929957889};\\\", \\\"{x:1328,y:464,t:1526929957906};\\\", \\\"{x:1328,y:463,t:1526929957922};\\\", \\\"{x:1328,y:462,t:1526929957946};\\\", \\\"{x:1328,y:461,t:1526929957954};\\\", \\\"{x:1328,y:460,t:1526929957966};\\\", \\\"{x:1328,y:459,t:1526929957982};\\\", \\\"{x:1328,y:455,t:1526929957999};\\\", \\\"{x:1329,y:451,t:1526929958016};\\\", \\\"{x:1330,y:444,t:1526929958032};\\\", \\\"{x:1332,y:437,t:1526929958049};\\\", \\\"{x:1334,y:427,t:1526929958066};\\\", \\\"{x:1335,y:425,t:1526929958082};\\\", \\\"{x:1335,y:423,t:1526929958099};\\\", \\\"{x:1336,y:423,t:1526929958290};\\\", \\\"{x:1337,y:423,t:1526929958299};\\\", \\\"{x:1339,y:425,t:1526929958317};\\\", \\\"{x:1345,y:434,t:1526929958333};\\\", \\\"{x:1348,y:441,t:1526929958350};\\\", \\\"{x:1352,y:450,t:1526929958366};\\\", \\\"{x:1359,y:461,t:1526929958383};\\\", \\\"{x:1367,y:474,t:1526929958399};\\\", \\\"{x:1376,y:491,t:1526929958416};\\\", \\\"{x:1384,y:509,t:1526929958433};\\\", \\\"{x:1396,y:532,t:1526929958450};\\\", \\\"{x:1414,y:576,t:1526929958467};\\\", \\\"{x:1424,y:607,t:1526929958484};\\\", \\\"{x:1431,y:631,t:1526929958499};\\\", \\\"{x:1432,y:660,t:1526929958516};\\\", \\\"{x:1432,y:683,t:1526929958534};\\\", \\\"{x:1432,y:704,t:1526929958549};\\\", \\\"{x:1422,y:719,t:1526929958566};\\\", \\\"{x:1416,y:732,t:1526929958583};\\\", \\\"{x:1409,y:741,t:1526929958599};\\\", \\\"{x:1404,y:746,t:1526929958616};\\\", \\\"{x:1392,y:754,t:1526929958633};\\\", \\\"{x:1383,y:759,t:1526929958649};\\\", \\\"{x:1370,y:763,t:1526929958666};\\\", \\\"{x:1360,y:764,t:1526929958683};\\\", \\\"{x:1350,y:765,t:1526929958700};\\\", \\\"{x:1340,y:768,t:1526929958716};\\\", \\\"{x:1326,y:768,t:1526929958733};\\\", \\\"{x:1309,y:768,t:1526929958750};\\\", \\\"{x:1293,y:768,t:1526929958766};\\\", \\\"{x:1274,y:768,t:1526929958782};\\\", \\\"{x:1263,y:768,t:1526929958800};\\\", \\\"{x:1254,y:768,t:1526929958816};\\\", \\\"{x:1249,y:768,t:1526929958833};\\\", \\\"{x:1247,y:767,t:1526929958849};\\\", \\\"{x:1245,y:767,t:1526929958881};\\\", \\\"{x:1244,y:767,t:1526929958889};\\\", \\\"{x:1242,y:764,t:1526929958905};\\\", \\\"{x:1240,y:763,t:1526929958916};\\\", \\\"{x:1234,y:756,t:1526929958933};\\\", \\\"{x:1229,y:751,t:1526929958949};\\\", \\\"{x:1224,y:746,t:1526929958965};\\\", \\\"{x:1222,y:743,t:1526929958983};\\\", \\\"{x:1220,y:740,t:1526929958999};\\\", \\\"{x:1219,y:737,t:1526929959016};\\\", \\\"{x:1218,y:734,t:1526929959033};\\\", \\\"{x:1218,y:731,t:1526929959049};\\\", \\\"{x:1218,y:730,t:1526929959066};\\\", \\\"{x:1218,y:726,t:1526929959082};\\\", \\\"{x:1221,y:722,t:1526929959100};\\\", \\\"{x:1228,y:718,t:1526929959116};\\\", \\\"{x:1235,y:713,t:1526929959133};\\\", \\\"{x:1245,y:707,t:1526929959149};\\\", \\\"{x:1257,y:702,t:1526929959167};\\\", \\\"{x:1267,y:699,t:1526929959182};\\\", \\\"{x:1274,y:696,t:1526929959200};\\\", \\\"{x:1280,y:695,t:1526929959218};\\\", \\\"{x:1285,y:693,t:1526929959233};\\\", \\\"{x:1294,y:692,t:1526929959249};\\\", \\\"{x:1299,y:692,t:1526929959267};\\\", \\\"{x:1304,y:692,t:1526929959283};\\\", \\\"{x:1309,y:692,t:1526929959300};\\\", \\\"{x:1311,y:692,t:1526929959317};\\\", \\\"{x:1313,y:692,t:1526929959333};\\\", \\\"{x:1315,y:691,t:1526929959350};\\\", \\\"{x:1317,y:691,t:1526929959367};\\\", \\\"{x:1321,y:691,t:1526929959383};\\\", \\\"{x:1324,y:691,t:1526929959400};\\\", \\\"{x:1328,y:691,t:1526929959417};\\\", \\\"{x:1329,y:691,t:1526929959433};\\\", \\\"{x:1335,y:692,t:1526929959450};\\\", \\\"{x:1340,y:694,t:1526929959467};\\\", \\\"{x:1350,y:695,t:1526929959483};\\\", \\\"{x:1363,y:697,t:1526929959500};\\\", \\\"{x:1373,y:698,t:1526929959518};\\\", \\\"{x:1383,y:700,t:1526929959534};\\\", \\\"{x:1393,y:700,t:1526929959550};\\\", \\\"{x:1400,y:702,t:1526929959568};\\\", \\\"{x:1406,y:703,t:1526929959584};\\\", \\\"{x:1412,y:703,t:1526929959601};\\\", \\\"{x:1420,y:705,t:1526929959618};\\\", \\\"{x:1433,y:706,t:1526929959634};\\\", \\\"{x:1446,y:707,t:1526929959650};\\\", \\\"{x:1461,y:711,t:1526929959667};\\\", \\\"{x:1477,y:711,t:1526929959684};\\\", \\\"{x:1491,y:712,t:1526929959700};\\\", \\\"{x:1509,y:713,t:1526929959717};\\\", \\\"{x:1526,y:714,t:1526929959734};\\\", \\\"{x:1541,y:717,t:1526929959749};\\\", \\\"{x:1554,y:717,t:1526929959767};\\\", \\\"{x:1565,y:717,t:1526929959784};\\\", \\\"{x:1577,y:717,t:1526929959800};\\\", \\\"{x:1585,y:717,t:1526929959817};\\\", \\\"{x:1594,y:717,t:1526929959834};\\\", \\\"{x:1598,y:717,t:1526929959851};\\\", \\\"{x:1603,y:717,t:1526929959867};\\\", \\\"{x:1607,y:717,t:1526929959884};\\\", \\\"{x:1610,y:717,t:1526929959900};\\\", \\\"{x:1615,y:717,t:1526929959917};\\\", \\\"{x:1618,y:717,t:1526929959934};\\\", \\\"{x:1621,y:717,t:1526929959949};\\\", \\\"{x:1623,y:717,t:1526929959966};\\\", \\\"{x:1624,y:716,t:1526929959984};\\\", \\\"{x:1627,y:716,t:1526929960000};\\\", \\\"{x:1630,y:714,t:1526929960017};\\\", \\\"{x:1632,y:714,t:1526929960033};\\\", \\\"{x:1635,y:713,t:1526929960051};\\\", \\\"{x:1638,y:712,t:1526929960066};\\\", \\\"{x:1639,y:712,t:1526929960084};\\\", \\\"{x:1642,y:710,t:1526929960101};\\\", \\\"{x:1645,y:710,t:1526929960117};\\\", \\\"{x:1649,y:708,t:1526929960134};\\\", \\\"{x:1652,y:706,t:1526929960151};\\\", \\\"{x:1654,y:706,t:1526929960166};\\\", \\\"{x:1656,y:705,t:1526929960183};\\\", \\\"{x:1658,y:705,t:1526929960200};\\\", \\\"{x:1655,y:705,t:1526929960290};\\\", \\\"{x:1649,y:706,t:1526929960301};\\\", \\\"{x:1632,y:712,t:1526929960317};\\\", \\\"{x:1605,y:718,t:1526929960334};\\\", \\\"{x:1570,y:725,t:1526929960351};\\\", \\\"{x:1539,y:734,t:1526929960367};\\\", \\\"{x:1510,y:741,t:1526929960384};\\\", \\\"{x:1489,y:746,t:1526929960401};\\\", \\\"{x:1469,y:754,t:1526929960417};\\\", \\\"{x:1440,y:757,t:1526929960434};\\\", \\\"{x:1421,y:761,t:1526929960451};\\\", \\\"{x:1400,y:764,t:1526929960467};\\\", \\\"{x:1381,y:766,t:1526929960484};\\\", \\\"{x:1366,y:770,t:1526929960502};\\\", \\\"{x:1355,y:771,t:1526929960517};\\\", \\\"{x:1347,y:772,t:1526929960534};\\\", \\\"{x:1344,y:773,t:1526929960551};\\\", \\\"{x:1342,y:773,t:1526929960568};\\\", \\\"{x:1342,y:774,t:1526929960584};\\\", \\\"{x:1343,y:774,t:1526929960787};\\\", \\\"{x:1346,y:774,t:1526929960801};\\\", \\\"{x:1355,y:771,t:1526929960819};\\\", \\\"{x:1362,y:770,t:1526929960834};\\\", \\\"{x:1366,y:770,t:1526929960851};\\\", \\\"{x:1370,y:769,t:1526929960868};\\\", \\\"{x:1371,y:769,t:1526929960897};\\\", \\\"{x:1374,y:769,t:1526929961114};\\\", \\\"{x:1374,y:768,t:1526929961122};\\\", \\\"{x:1374,y:767,t:1526929961138};\\\", \\\"{x:1375,y:767,t:1526929961170};\\\", \\\"{x:1375,y:766,t:1526929961225};\\\", \\\"{x:1376,y:766,t:1526929961291};\\\", \\\"{x:1377,y:766,t:1526929961301};\\\", \\\"{x:1378,y:765,t:1526929961370};\\\", \\\"{x:1378,y:767,t:1526929965241};\\\", \\\"{x:1378,y:772,t:1526929965254};\\\", \\\"{x:1373,y:780,t:1526929965271};\\\", \\\"{x:1368,y:792,t:1526929965288};\\\", \\\"{x:1359,y:805,t:1526929965305};\\\", \\\"{x:1354,y:820,t:1526929965321};\\\", \\\"{x:1346,y:842,t:1526929965338};\\\", \\\"{x:1343,y:852,t:1526929965355};\\\", \\\"{x:1343,y:860,t:1526929965372};\\\", \\\"{x:1343,y:870,t:1526929965389};\\\", \\\"{x:1343,y:883,t:1526929965405};\\\", \\\"{x:1343,y:892,t:1526929965422};\\\", \\\"{x:1345,y:905,t:1526929965439};\\\", \\\"{x:1350,y:919,t:1526929965455};\\\", \\\"{x:1353,y:930,t:1526929965471};\\\", \\\"{x:1356,y:941,t:1526929965489};\\\", \\\"{x:1360,y:951,t:1526929965504};\\\", \\\"{x:1366,y:960,t:1526929965521};\\\", \\\"{x:1376,y:972,t:1526929965538};\\\", \\\"{x:1379,y:975,t:1526929965554};\\\", \\\"{x:1382,y:977,t:1526929965572};\\\", \\\"{x:1384,y:978,t:1526929965589};\\\", \\\"{x:1386,y:979,t:1526929965604};\\\", \\\"{x:1389,y:981,t:1526929965621};\\\", \\\"{x:1390,y:982,t:1526929965639};\\\", \\\"{x:1391,y:982,t:1526929965730};\\\", \\\"{x:1392,y:982,t:1526929965738};\\\", \\\"{x:1393,y:981,t:1526929965756};\\\", \\\"{x:1394,y:977,t:1526929965771};\\\", \\\"{x:1394,y:975,t:1526929965788};\\\", \\\"{x:1394,y:970,t:1526929965805};\\\", \\\"{x:1394,y:969,t:1526929965821};\\\", \\\"{x:1394,y:967,t:1526929965838};\\\", \\\"{x:1394,y:966,t:1526929965855};\\\", \\\"{x:1395,y:964,t:1526929965871};\\\", \\\"{x:1397,y:964,t:1526929965938};\\\", \\\"{x:1400,y:965,t:1526929965956};\\\", \\\"{x:1406,y:969,t:1526929965971};\\\", \\\"{x:1410,y:972,t:1526929965989};\\\", \\\"{x:1418,y:977,t:1526929966005};\\\", \\\"{x:1423,y:979,t:1526929966021};\\\", \\\"{x:1428,y:981,t:1526929966038};\\\", \\\"{x:1432,y:981,t:1526929966055};\\\", \\\"{x:1433,y:981,t:1526929966071};\\\", \\\"{x:1436,y:981,t:1526929966089};\\\", \\\"{x:1441,y:980,t:1526929966105};\\\", \\\"{x:1445,y:976,t:1526929966121};\\\", \\\"{x:1454,y:971,t:1526929966138};\\\", \\\"{x:1460,y:969,t:1526929966155};\\\", \\\"{x:1461,y:968,t:1526929966171};\\\", \\\"{x:1462,y:968,t:1526929966189};\\\", \\\"{x:1462,y:967,t:1526929966205};\\\", \\\"{x:1462,y:966,t:1526929966250};\\\", \\\"{x:1462,y:965,t:1526929966266};\\\", \\\"{x:1462,y:963,t:1526929966282};\\\", \\\"{x:1462,y:962,t:1526929966291};\\\", \\\"{x:1461,y:962,t:1526929966306};\\\", \\\"{x:1459,y:962,t:1526929966322};\\\", \\\"{x:1456,y:962,t:1526929966339};\\\", \\\"{x:1452,y:962,t:1526929966356};\\\", \\\"{x:1449,y:962,t:1526929966373};\\\", \\\"{x:1447,y:962,t:1526929966389};\\\", \\\"{x:1446,y:962,t:1526929966426};\\\", \\\"{x:1446,y:963,t:1526929966523};\\\", \\\"{x:1446,y:964,t:1526929966739};\\\", \\\"{x:1447,y:965,t:1526929966756};\\\", \\\"{x:1448,y:965,t:1526929966773};\\\", \\\"{x:1450,y:965,t:1526929966790};\\\", \\\"{x:1453,y:966,t:1526929966806};\\\", \\\"{x:1456,y:967,t:1526929966823};\\\", \\\"{x:1458,y:968,t:1526929966840};\\\", \\\"{x:1460,y:968,t:1526929966856};\\\", \\\"{x:1463,y:969,t:1526929966873};\\\", \\\"{x:1465,y:969,t:1526929966890};\\\", \\\"{x:1474,y:970,t:1526929966906};\\\", \\\"{x:1480,y:970,t:1526929966923};\\\", \\\"{x:1486,y:970,t:1526929966940};\\\", \\\"{x:1493,y:970,t:1526929966956};\\\", \\\"{x:1499,y:970,t:1526929966972};\\\", \\\"{x:1504,y:970,t:1526929966990};\\\", \\\"{x:1508,y:970,t:1526929967006};\\\", \\\"{x:1510,y:968,t:1526929967023};\\\", \\\"{x:1511,y:968,t:1526929967040};\\\", \\\"{x:1512,y:967,t:1526929967066};\\\", \\\"{x:1514,y:966,t:1526929967090};\\\", \\\"{x:1515,y:966,t:1526929967106};\\\", \\\"{x:1515,y:965,t:1526929967122};\\\", \\\"{x:1517,y:965,t:1526929967140};\\\", \\\"{x:1518,y:964,t:1526929967203};\\\", \\\"{x:1517,y:964,t:1526929967481};\\\", \\\"{x:1516,y:964,t:1526929967514};\\\", \\\"{x:1516,y:965,t:1526929968291};\\\", \\\"{x:1516,y:966,t:1526929968314};\\\", \\\"{x:1517,y:966,t:1526929968323};\\\", \\\"{x:1518,y:967,t:1526929968341};\\\", \\\"{x:1518,y:968,t:1526929968356};\\\", \\\"{x:1519,y:969,t:1526929968373};\\\", \\\"{x:1521,y:969,t:1526929968390};\\\", \\\"{x:1523,y:970,t:1526929968407};\\\", \\\"{x:1527,y:971,t:1526929968423};\\\", \\\"{x:1530,y:971,t:1526929968440};\\\", \\\"{x:1533,y:972,t:1526929968456};\\\", \\\"{x:1539,y:974,t:1526929968473};\\\", \\\"{x:1544,y:974,t:1526929968489};\\\", \\\"{x:1545,y:974,t:1526929968507};\\\", \\\"{x:1547,y:975,t:1526929968524};\\\", \\\"{x:1549,y:975,t:1526929968541};\\\", \\\"{x:1551,y:975,t:1526929968556};\\\", \\\"{x:1552,y:975,t:1526929968574};\\\", \\\"{x:1554,y:975,t:1526929968590};\\\", \\\"{x:1555,y:975,t:1526929968607};\\\", \\\"{x:1557,y:974,t:1526929968624};\\\", \\\"{x:1558,y:973,t:1526929968641};\\\", \\\"{x:1559,y:973,t:1526929968657};\\\", \\\"{x:1560,y:973,t:1526929968674};\\\", \\\"{x:1561,y:973,t:1526929968690};\\\", \\\"{x:1562,y:972,t:1526929968707};\\\", \\\"{x:1563,y:972,t:1526929968730};\\\", \\\"{x:1564,y:971,t:1526929968741};\\\", \\\"{x:1565,y:970,t:1526929968762};\\\", \\\"{x:1566,y:970,t:1526929968794};\\\", \\\"{x:1567,y:969,t:1526929968809};\\\", \\\"{x:1569,y:969,t:1526929968850};\\\", \\\"{x:1570,y:969,t:1526929968866};\\\", \\\"{x:1571,y:969,t:1526929968874};\\\", \\\"{x:1573,y:968,t:1526929968891};\\\", \\\"{x:1575,y:967,t:1526929968907};\\\", \\\"{x:1576,y:967,t:1526929968962};\\\", \\\"{x:1576,y:966,t:1526929968974};\\\", \\\"{x:1578,y:965,t:1526929968994};\\\", \\\"{x:1578,y:964,t:1526929969147};\\\", \\\"{x:1576,y:964,t:1526929970139};\\\", \\\"{x:1572,y:964,t:1526929970146};\\\", \\\"{x:1568,y:966,t:1526929970159};\\\", \\\"{x:1555,y:967,t:1526929970175};\\\", \\\"{x:1540,y:969,t:1526929970192};\\\", \\\"{x:1522,y:971,t:1526929970209};\\\", \\\"{x:1503,y:971,t:1526929970225};\\\", \\\"{x:1462,y:975,t:1526929970242};\\\", \\\"{x:1438,y:978,t:1526929970258};\\\", \\\"{x:1414,y:978,t:1526929970275};\\\", \\\"{x:1392,y:979,t:1526929970293};\\\", \\\"{x:1374,y:979,t:1526929970309};\\\", \\\"{x:1359,y:979,t:1526929970325};\\\", \\\"{x:1352,y:979,t:1526929970341};\\\", \\\"{x:1347,y:979,t:1526929970359};\\\", \\\"{x:1344,y:979,t:1526929970374};\\\", \\\"{x:1340,y:980,t:1526929970392};\\\", \\\"{x:1336,y:982,t:1526929970408};\\\", \\\"{x:1335,y:982,t:1526929970425};\\\", \\\"{x:1334,y:982,t:1526929970442};\\\", \\\"{x:1333,y:982,t:1526929970522};\\\", \\\"{x:1336,y:983,t:1526929970537};\\\", \\\"{x:1340,y:984,t:1526929970545};\\\", \\\"{x:1343,y:984,t:1526929970558};\\\", \\\"{x:1352,y:986,t:1526929970575};\\\", \\\"{x:1356,y:986,t:1526929970591};\\\", \\\"{x:1358,y:987,t:1526929970609};\\\", \\\"{x:1359,y:987,t:1526929970625};\\\", \\\"{x:1359,y:986,t:1526929970874};\\\", \\\"{x:1357,y:983,t:1526929970890};\\\", \\\"{x:1356,y:982,t:1526929970897};\\\", \\\"{x:1356,y:981,t:1526929970908};\\\", \\\"{x:1355,y:979,t:1526929970925};\\\", \\\"{x:1353,y:978,t:1526929970941};\\\", \\\"{x:1353,y:976,t:1526929970958};\\\", \\\"{x:1350,y:973,t:1526929970975};\\\", \\\"{x:1348,y:971,t:1526929970991};\\\", \\\"{x:1346,y:969,t:1526929971009};\\\", \\\"{x:1345,y:966,t:1526929971026};\\\", \\\"{x:1345,y:965,t:1526929971049};\\\", \\\"{x:1345,y:964,t:1526929971073};\\\", \\\"{x:1345,y:963,t:1526929971147};\\\", \\\"{x:1344,y:963,t:1526929971178};\\\", \\\"{x:1344,y:962,t:1526929971211};\\\", \\\"{x:1343,y:962,t:1526929971242};\\\", \\\"{x:1343,y:961,t:1526929971353};\\\", \\\"{x:1342,y:960,t:1526929971554};\\\", \\\"{x:1342,y:959,t:1526929971634};\\\", \\\"{x:1342,y:958,t:1526929971658};\\\", \\\"{x:1342,y:957,t:1526929971666};\\\", \\\"{x:1342,y:956,t:1526929971681};\\\", \\\"{x:1341,y:954,t:1526929971722};\\\", \\\"{x:1340,y:953,t:1526929971729};\\\", \\\"{x:1339,y:951,t:1526929971754};\\\", \\\"{x:1338,y:949,t:1526929971770};\\\", \\\"{x:1338,y:948,t:1526929971778};\\\", \\\"{x:1338,y:947,t:1526929971793};\\\", \\\"{x:1336,y:943,t:1526929971810};\\\", \\\"{x:1336,y:941,t:1526929971826};\\\", \\\"{x:1336,y:939,t:1526929971843};\\\", \\\"{x:1335,y:934,t:1526929971860};\\\", \\\"{x:1334,y:930,t:1526929971876};\\\", \\\"{x:1332,y:923,t:1526929971893};\\\", \\\"{x:1329,y:915,t:1526929971910};\\\", \\\"{x:1328,y:909,t:1526929971926};\\\", \\\"{x:1328,y:907,t:1526929971943};\\\", \\\"{x:1328,y:905,t:1526929971960};\\\", \\\"{x:1327,y:902,t:1526929971976};\\\", \\\"{x:1327,y:900,t:1526929971994};\\\", \\\"{x:1327,y:899,t:1526929972026};\\\", \\\"{x:1327,y:897,t:1526929972050};\\\", \\\"{x:1327,y:896,t:1526929972154};\\\", \\\"{x:1329,y:896,t:1526929972194};\\\", \\\"{x:1332,y:895,t:1526929972210};\\\", \\\"{x:1334,y:893,t:1526929972227};\\\", \\\"{x:1335,y:893,t:1526929972242};\\\", \\\"{x:1336,y:893,t:1526929972266};\\\", \\\"{x:1337,y:893,t:1526929972298};\\\", \\\"{x:1339,y:893,t:1526929972610};\\\", \\\"{x:1346,y:892,t:1526929972626};\\\", \\\"{x:1353,y:892,t:1526929972644};\\\", \\\"{x:1360,y:891,t:1526929972659};\\\", \\\"{x:1366,y:890,t:1526929972676};\\\", \\\"{x:1370,y:889,t:1526929972693};\\\", \\\"{x:1375,y:888,t:1526929972710};\\\", \\\"{x:1381,y:887,t:1526929972726};\\\", \\\"{x:1389,y:886,t:1526929972743};\\\", \\\"{x:1399,y:886,t:1526929972759};\\\", \\\"{x:1408,y:886,t:1526929972776};\\\", \\\"{x:1432,y:885,t:1526929972793};\\\", \\\"{x:1450,y:885,t:1526929972810};\\\", \\\"{x:1470,y:885,t:1526929972827};\\\", \\\"{x:1494,y:885,t:1526929972843};\\\", \\\"{x:1525,y:885,t:1526929972859};\\\", \\\"{x:1552,y:885,t:1526929972877};\\\", \\\"{x:1574,y:886,t:1526929972893};\\\", \\\"{x:1595,y:891,t:1526929972910};\\\", \\\"{x:1609,y:894,t:1526929972926};\\\", \\\"{x:1616,y:900,t:1526929972944};\\\", \\\"{x:1620,y:903,t:1526929972960};\\\", \\\"{x:1623,y:907,t:1526929972976};\\\", \\\"{x:1626,y:912,t:1526929972994};\\\", \\\"{x:1627,y:918,t:1526929973011};\\\", \\\"{x:1628,y:927,t:1526929973027};\\\", \\\"{x:1629,y:936,t:1526929973044};\\\", \\\"{x:1629,y:943,t:1526929973061};\\\", \\\"{x:1628,y:950,t:1526929973076};\\\", \\\"{x:1622,y:956,t:1526929973093};\\\", \\\"{x:1610,y:962,t:1526929973110};\\\", \\\"{x:1595,y:968,t:1526929973127};\\\", \\\"{x:1583,y:970,t:1526929973144};\\\", \\\"{x:1570,y:974,t:1526929973160};\\\", \\\"{x:1560,y:975,t:1526929973177};\\\", \\\"{x:1554,y:976,t:1526929973194};\\\", \\\"{x:1553,y:976,t:1526929973283};\\\", \\\"{x:1553,y:975,t:1526929973338};\\\", \\\"{x:1553,y:974,t:1526929973346};\\\", \\\"{x:1553,y:973,t:1526929973362};\\\", \\\"{x:1553,y:972,t:1526929973394};\\\", \\\"{x:1553,y:971,t:1526929973410};\\\", \\\"{x:1553,y:970,t:1526929973442};\\\", \\\"{x:1553,y:969,t:1526929973450};\\\", \\\"{x:1553,y:968,t:1526929973461};\\\", \\\"{x:1553,y:967,t:1526929973478};\\\", \\\"{x:1552,y:965,t:1526929973494};\\\", \\\"{x:1551,y:965,t:1526929973511};\\\", \\\"{x:1551,y:964,t:1526929973546};\\\", \\\"{x:1551,y:963,t:1526929973570};\\\", \\\"{x:1551,y:962,t:1526929973578};\\\", \\\"{x:1551,y:961,t:1526929973594};\\\", \\\"{x:1551,y:960,t:1526929973634};\\\", \\\"{x:1550,y:959,t:1526929973644};\\\", \\\"{x:1549,y:957,t:1526929973683};\\\", \\\"{x:1549,y:955,t:1526929973707};\\\", \\\"{x:1548,y:954,t:1526929973722};\\\", \\\"{x:1548,y:953,t:1526929973730};\\\", \\\"{x:1548,y:952,t:1526929973745};\\\", \\\"{x:1548,y:949,t:1526929973761};\\\", \\\"{x:1548,y:948,t:1526929973778};\\\", \\\"{x:1548,y:947,t:1526929973794};\\\", \\\"{x:1548,y:945,t:1526929973811};\\\", \\\"{x:1547,y:943,t:1526929973828};\\\", \\\"{x:1547,y:942,t:1526929973850};\\\", \\\"{x:1546,y:941,t:1526929973861};\\\", \\\"{x:1545,y:940,t:1526929973878};\\\", \\\"{x:1545,y:939,t:1526929973894};\\\", \\\"{x:1545,y:938,t:1526929973913};\\\", \\\"{x:1544,y:937,t:1526929973929};\\\", \\\"{x:1544,y:936,t:1526929973953};\\\", \\\"{x:1544,y:935,t:1526929973961};\\\", \\\"{x:1544,y:934,t:1526929973978};\\\", \\\"{x:1544,y:933,t:1526929974114};\\\", \\\"{x:1544,y:932,t:1526929974346};\\\", \\\"{x:1544,y:930,t:1526929974825};\\\", \\\"{x:1544,y:929,t:1526929974841};\\\", \\\"{x:1544,y:928,t:1526929975049};\\\", \\\"{x:1544,y:927,t:1526929975169};\\\", \\\"{x:1545,y:926,t:1526929975179};\\\", \\\"{x:1545,y:925,t:1526929975667};\\\", \\\"{x:1545,y:926,t:1526929975682};\\\", \\\"{x:1544,y:930,t:1526929975696};\\\", \\\"{x:1543,y:937,t:1526929975711};\\\", \\\"{x:1542,y:940,t:1526929975729};\\\", \\\"{x:1541,y:944,t:1526929975745};\\\", \\\"{x:1541,y:945,t:1526929975777};\\\", \\\"{x:1541,y:946,t:1526929975785};\\\", \\\"{x:1541,y:947,t:1526929975817};\\\", \\\"{x:1541,y:949,t:1526929975829};\\\", \\\"{x:1541,y:951,t:1526929975857};\\\", \\\"{x:1542,y:952,t:1526929975865};\\\", \\\"{x:1542,y:953,t:1526929975881};\\\", \\\"{x:1542,y:954,t:1526929975896};\\\", \\\"{x:1544,y:956,t:1526929975913};\\\", \\\"{x:1545,y:958,t:1526929975928};\\\", \\\"{x:1547,y:960,t:1526929975946};\\\", \\\"{x:1547,y:961,t:1526929975962};\\\", \\\"{x:1548,y:963,t:1526929975979};\\\", \\\"{x:1550,y:965,t:1526929976001};\\\", \\\"{x:1550,y:966,t:1526929976017};\\\", \\\"{x:1550,y:967,t:1526929976029};\\\", \\\"{x:1551,y:969,t:1526929976046};\\\", \\\"{x:1551,y:970,t:1526929976063};\\\", \\\"{x:1551,y:971,t:1526929976078};\\\", \\\"{x:1551,y:972,t:1526929976096};\\\", \\\"{x:1550,y:974,t:1526929976114};\\\", \\\"{x:1549,y:975,t:1526929976129};\\\", \\\"{x:1546,y:976,t:1526929976146};\\\", \\\"{x:1542,y:977,t:1526929976163};\\\", \\\"{x:1537,y:978,t:1526929976178};\\\", \\\"{x:1535,y:978,t:1526929976195};\\\", \\\"{x:1534,y:978,t:1526929976212};\\\", \\\"{x:1533,y:978,t:1526929976229};\\\", \\\"{x:1532,y:978,t:1526929976273};\\\", \\\"{x:1531,y:978,t:1526929976281};\\\", \\\"{x:1530,y:978,t:1526929976296};\\\", \\\"{x:1528,y:978,t:1526929976321};\\\", \\\"{x:1527,y:978,t:1526929976353};\\\", \\\"{x:1526,y:978,t:1526929976393};\\\", \\\"{x:1524,y:977,t:1526929976409};\\\", \\\"{x:1523,y:977,t:1526929976425};\\\", \\\"{x:1520,y:976,t:1526929976441};\\\", \\\"{x:1519,y:975,t:1526929976473};\\\", \\\"{x:1518,y:975,t:1526929976521};\\\", \\\"{x:1517,y:974,t:1526929976537};\\\", \\\"{x:1516,y:974,t:1526929976546};\\\", \\\"{x:1515,y:973,t:1526929976562};\\\", \\\"{x:1515,y:972,t:1526929976579};\\\", \\\"{x:1515,y:971,t:1526929976665};\\\", \\\"{x:1515,y:970,t:1526929976761};\\\", \\\"{x:1515,y:969,t:1526929976794};\\\", \\\"{x:1515,y:968,t:1526929976849};\\\", \\\"{x:1515,y:967,t:1526929976865};\\\", \\\"{x:1514,y:966,t:1526929976881};\\\", \\\"{x:1514,y:965,t:1526929976929};\\\", \\\"{x:1514,y:964,t:1526929976946};\\\", \\\"{x:1513,y:964,t:1526929976962};\\\", \\\"{x:1513,y:963,t:1526929977009};\\\", \\\"{x:1513,y:962,t:1526929977025};\\\", \\\"{x:1513,y:961,t:1526929977041};\\\", \\\"{x:1513,y:960,t:1526929977050};\\\", \\\"{x:1513,y:959,t:1526929977063};\\\", \\\"{x:1511,y:954,t:1526929977079};\\\", \\\"{x:1510,y:947,t:1526929977097};\\\", \\\"{x:1510,y:938,t:1526929977113};\\\", \\\"{x:1506,y:918,t:1526929977130};\\\", \\\"{x:1500,y:901,t:1526929977146};\\\", \\\"{x:1489,y:878,t:1526929977163};\\\", \\\"{x:1473,y:849,t:1526929977180};\\\", \\\"{x:1448,y:817,t:1526929977197};\\\", \\\"{x:1425,y:777,t:1526929977213};\\\", \\\"{x:1411,y:739,t:1526929977230};\\\", \\\"{x:1403,y:706,t:1526929977246};\\\", \\\"{x:1400,y:678,t:1526929977264};\\\", \\\"{x:1399,y:658,t:1526929977280};\\\", \\\"{x:1398,y:648,t:1526929977297};\\\", \\\"{x:1398,y:642,t:1526929977314};\\\", \\\"{x:1398,y:641,t:1526929977330};\\\", \\\"{x:1398,y:640,t:1526929977347};\\\", \\\"{x:1398,y:639,t:1526929977364};\\\", \\\"{x:1399,y:638,t:1526929977380};\\\", \\\"{x:1402,y:638,t:1526929977409};\\\", \\\"{x:1403,y:637,t:1526929977417};\\\", \\\"{x:1406,y:637,t:1526929977429};\\\", \\\"{x:1413,y:637,t:1526929977447};\\\", \\\"{x:1419,y:639,t:1526929977464};\\\", \\\"{x:1431,y:649,t:1526929977479};\\\", \\\"{x:1445,y:664,t:1526929977497};\\\", \\\"{x:1458,y:688,t:1526929977513};\\\", \\\"{x:1461,y:695,t:1526929977530};\\\", \\\"{x:1465,y:708,t:1526929977546};\\\", \\\"{x:1469,y:718,t:1526929977566};\\\", \\\"{x:1475,y:729,t:1526929977579};\\\", \\\"{x:1479,y:737,t:1526929977596};\\\", \\\"{x:1484,y:749,t:1526929977614};\\\", \\\"{x:1488,y:756,t:1526929977629};\\\", \\\"{x:1492,y:763,t:1526929977646};\\\", \\\"{x:1494,y:766,t:1526929977664};\\\", \\\"{x:1496,y:768,t:1526929977680};\\\", \\\"{x:1496,y:769,t:1526929977697};\\\", \\\"{x:1497,y:770,t:1526929977714};\\\", \\\"{x:1498,y:770,t:1526929977849};\\\", \\\"{x:1498,y:769,t:1526929977863};\\\", \\\"{x:1500,y:767,t:1526929977881};\\\", \\\"{x:1500,y:765,t:1526929977897};\\\", \\\"{x:1501,y:760,t:1526929977913};\\\", \\\"{x:1501,y:758,t:1526929977931};\\\", \\\"{x:1501,y:756,t:1526929977946};\\\", \\\"{x:1502,y:756,t:1526929977963};\\\", \\\"{x:1503,y:756,t:1526929978042};\\\", \\\"{x:1503,y:758,t:1526929978049};\\\", \\\"{x:1506,y:763,t:1526929978064};\\\", \\\"{x:1509,y:769,t:1526929978081};\\\", \\\"{x:1513,y:780,t:1526929978096};\\\", \\\"{x:1522,y:799,t:1526929978114};\\\", \\\"{x:1527,y:811,t:1526929978130};\\\", \\\"{x:1532,y:824,t:1526929978146};\\\", \\\"{x:1533,y:837,t:1526929978164};\\\", \\\"{x:1534,y:847,t:1526929978180};\\\", \\\"{x:1536,y:856,t:1526929978197};\\\", \\\"{x:1537,y:865,t:1526929978215};\\\", \\\"{x:1537,y:876,t:1526929978230};\\\", \\\"{x:1540,y:884,t:1526929978247};\\\", \\\"{x:1541,y:890,t:1526929978264};\\\", \\\"{x:1542,y:895,t:1526929978281};\\\", \\\"{x:1542,y:900,t:1526929978297};\\\", \\\"{x:1542,y:904,t:1526929978314};\\\", \\\"{x:1542,y:906,t:1526929978330};\\\", \\\"{x:1542,y:907,t:1526929978348};\\\", \\\"{x:1542,y:908,t:1526929978364};\\\", \\\"{x:1542,y:910,t:1526929978380};\\\", \\\"{x:1540,y:913,t:1526929978397};\\\", \\\"{x:1538,y:914,t:1526929978414};\\\", \\\"{x:1535,y:916,t:1526929978431};\\\", \\\"{x:1533,y:916,t:1526929978448};\\\", \\\"{x:1530,y:916,t:1526929978464};\\\", \\\"{x:1529,y:916,t:1526929978481};\\\", \\\"{x:1527,y:916,t:1526929978498};\\\", \\\"{x:1526,y:916,t:1526929978530};\\\", \\\"{x:1524,y:916,t:1526929978548};\\\", \\\"{x:1523,y:916,t:1526929978565};\\\", \\\"{x:1521,y:915,t:1526929978581};\\\", \\\"{x:1520,y:914,t:1526929978598};\\\", \\\"{x:1520,y:913,t:1526929978626};\\\", \\\"{x:1520,y:912,t:1526929978771};\\\", \\\"{x:1520,y:913,t:1526929978801};\\\", \\\"{x:1520,y:914,t:1526929978819};\\\", \\\"{x:1520,y:915,t:1526929978831};\\\", \\\"{x:1520,y:918,t:1526929978849};\\\", \\\"{x:1521,y:921,t:1526929978865};\\\", \\\"{x:1521,y:924,t:1526929978882};\\\", \\\"{x:1522,y:930,t:1526929978898};\\\", \\\"{x:1522,y:934,t:1526929978915};\\\", \\\"{x:1521,y:939,t:1526929978931};\\\", \\\"{x:1521,y:940,t:1526929978969};\\\", \\\"{x:1521,y:941,t:1526929978985};\\\", \\\"{x:1521,y:942,t:1526929978997};\\\", \\\"{x:1522,y:942,t:1526929979033};\\\", \\\"{x:1522,y:943,t:1526929979057};\\\", \\\"{x:1522,y:944,t:1526929979073};\\\", \\\"{x:1522,y:945,t:1526929979089};\\\", \\\"{x:1522,y:943,t:1526929979218};\\\", \\\"{x:1521,y:940,t:1526929979232};\\\", \\\"{x:1514,y:930,t:1526929979247};\\\", \\\"{x:1504,y:911,t:1526929979265};\\\", \\\"{x:1495,y:887,t:1526929979281};\\\", \\\"{x:1494,y:869,t:1526929979297};\\\", \\\"{x:1493,y:851,t:1526929979315};\\\", \\\"{x:1493,y:832,t:1526929979332};\\\", \\\"{x:1493,y:807,t:1526929979348};\\\", \\\"{x:1493,y:784,t:1526929979365};\\\", \\\"{x:1493,y:761,t:1526929979381};\\\", \\\"{x:1493,y:745,t:1526929979398};\\\", \\\"{x:1489,y:726,t:1526929979414};\\\", \\\"{x:1486,y:712,t:1526929979431};\\\", \\\"{x:1483,y:701,t:1526929979448};\\\", \\\"{x:1478,y:687,t:1526929979465};\\\", \\\"{x:1472,y:671,t:1526929979481};\\\", \\\"{x:1469,y:663,t:1526929979498};\\\", \\\"{x:1469,y:659,t:1526929979515};\\\", \\\"{x:1468,y:655,t:1526929979531};\\\", \\\"{x:1468,y:654,t:1526929979547};\\\", \\\"{x:1468,y:653,t:1526929979564};\\\", \\\"{x:1468,y:652,t:1526929979673};\\\", \\\"{x:1469,y:652,t:1526929979681};\\\", \\\"{x:1470,y:655,t:1526929979699};\\\", \\\"{x:1474,y:661,t:1526929979715};\\\", \\\"{x:1476,y:665,t:1526929979732};\\\", \\\"{x:1477,y:667,t:1526929979748};\\\", \\\"{x:1479,y:669,t:1526929979765};\\\", \\\"{x:1479,y:670,t:1526929979794};\\\", \\\"{x:1480,y:670,t:1526929979850};\\\", \\\"{x:1482,y:669,t:1526929979866};\\\", \\\"{x:1484,y:666,t:1526929979882};\\\", \\\"{x:1487,y:665,t:1526929979899};\\\", \\\"{x:1489,y:663,t:1526929979916};\\\", \\\"{x:1490,y:662,t:1526929979933};\\\", \\\"{x:1490,y:660,t:1526929979949};\\\", \\\"{x:1490,y:659,t:1526929979965};\\\", \\\"{x:1490,y:657,t:1526929979982};\\\", \\\"{x:1491,y:656,t:1526929979999};\\\", \\\"{x:1492,y:653,t:1526929980016};\\\", \\\"{x:1492,y:652,t:1526929980042};\\\", \\\"{x:1492,y:651,t:1526929980049};\\\", \\\"{x:1492,y:650,t:1526929980065};\\\", \\\"{x:1492,y:649,t:1526929980081};\\\", \\\"{x:1492,y:647,t:1526929980099};\\\", \\\"{x:1492,y:646,t:1526929980145};\\\", \\\"{x:1492,y:645,t:1526929980177};\\\", \\\"{x:1493,y:644,t:1526929980209};\\\", \\\"{x:1493,y:643,t:1526929980241};\\\", \\\"{x:1494,y:642,t:1526929980265};\\\", \\\"{x:1496,y:641,t:1526929980282};\\\", \\\"{x:1497,y:639,t:1526929980298};\\\", \\\"{x:1499,y:637,t:1526929980315};\\\", \\\"{x:1500,y:636,t:1526929980332};\\\", \\\"{x:1503,y:635,t:1526929980348};\\\", \\\"{x:1508,y:631,t:1526929980366};\\\", \\\"{x:1513,y:628,t:1526929980381};\\\", \\\"{x:1515,y:626,t:1526929980399};\\\", \\\"{x:1517,y:626,t:1526929980415};\\\", \\\"{x:1516,y:626,t:1526929980738};\\\", \\\"{x:1513,y:628,t:1526929980749};\\\", \\\"{x:1497,y:635,t:1526929980766};\\\", \\\"{x:1454,y:653,t:1526929980783};\\\", \\\"{x:1377,y:671,t:1526929980799};\\\", \\\"{x:1247,y:688,t:1526929980816};\\\", \\\"{x:1061,y:717,t:1526929980833};\\\", \\\"{x:829,y:752,t:1526929980848};\\\", \\\"{x:394,y:813,t:1526929980865};\\\", \\\"{x:82,y:830,t:1526929980882};\\\", \\\"{x:0,y:870,t:1526929980899};\\\", \\\"{x:0,y:900,t:1526929980916};\\\", \\\"{x:0,y:918,t:1526929980932};\\\", \\\"{x:0,y:924,t:1526929980948};\\\", \\\"{x:0,y:925,t:1526929980966};\\\", \\\"{x:1,y:925,t:1526929981026};\\\", \\\"{x:5,y:925,t:1526929981033};\\\", \\\"{x:12,y:925,t:1526929981049};\\\", \\\"{x:26,y:922,t:1526929981066};\\\", \\\"{x:50,y:915,t:1526929981082};\\\", \\\"{x:74,y:909,t:1526929981099};\\\", \\\"{x:106,y:899,t:1526929981116};\\\", \\\"{x:186,y:869,t:1526929981133};\\\", \\\"{x:279,y:832,t:1526929981150};\\\", \\\"{x:369,y:798,t:1526929981166};\\\", \\\"{x:450,y:774,t:1526929981183};\\\", \\\"{x:497,y:766,t:1526929981200};\\\", \\\"{x:511,y:761,t:1526929981216};\\\", \\\"{x:516,y:759,t:1526929981233};\\\", \\\"{x:518,y:757,t:1526929981249};\\\", \\\"{x:519,y:756,t:1526929981266};\\\", \\\"{x:522,y:752,t:1526929981283};\\\", \\\"{x:531,y:739,t:1526929981300};\\\", \\\"{x:538,y:729,t:1526929981317};\\\", \\\"{x:546,y:718,t:1526929981333};\\\", \\\"{x:552,y:710,t:1526929981350};\\\", \\\"{x:553,y:705,t:1526929981364};\\\", \\\"{x:553,y:702,t:1526929981380};\\\", \\\"{x:555,y:698,t:1526929981397};\\\", \\\"{x:555,y:695,t:1526929981414};\\\", \\\"{x:554,y:692,t:1526929981435};\\\", \\\"{x:554,y:691,t:1526929981465};\\\", \\\"{x:553,y:691,t:1526929981537};\\\", \\\"{x:552,y:691,t:1526929981553};\\\", \\\"{x:551,y:691,t:1526929981569};\\\", \\\"{x:546,y:694,t:1526929981585};\\\", \\\"{x:545,y:696,t:1526929981601};\\\", \\\"{x:543,y:698,t:1526929981619};\\\", \\\"{x:543,y:699,t:1526929981636};\\\", \\\"{x:542,y:699,t:1526929981651};\\\", \\\"{x:542,y:701,t:1526929981745};\\\", \\\"{x:542,y:703,t:1526929981785};\\\", \\\"{x:542,y:704,t:1526929981802};\\\", \\\"{x:540,y:708,t:1526929981818};\\\", \\\"{x:538,y:709,t:1526929981836};\\\", \\\"{x:538,y:710,t:1526929981852};\\\", \\\"{x:538,y:711,t:1526929981869};\\\", \\\"{x:538,y:712,t:1526929982153};\\\", \\\"{x:535,y:712,t:1526929982394};\\\", \\\"{x:530,y:712,t:1526929982403};\\\", \\\"{x:509,y:718,t:1526929982419};\\\", \\\"{x:474,y:725,t:1526929982436};\\\", \\\"{x:421,y:740,t:1526929982453};\\\", \\\"{x:369,y:752,t:1526929982470};\\\", \\\"{x:315,y:763,t:1526929982486};\\\", \\\"{x:274,y:773,t:1526929982503};\\\", \\\"{x:250,y:780,t:1526929982519};\\\", \\\"{x:233,y:783,t:1526929982535};\\\", \\\"{x:222,y:785,t:1526929982553};\\\", \\\"{x:212,y:785,t:1526929982569};\\\", \\\"{x:210,y:785,t:1526929982586};\\\", \\\"{x:208,y:784,t:1526929982633};\\\", \\\"{x:208,y:782,t:1526929982649};\\\", \\\"{x:208,y:780,t:1526929982656};\\\", \\\"{x:211,y:778,t:1526929982670};\\\", \\\"{x:216,y:775,t:1526929982686};\\\", \\\"{x:224,y:770,t:1526929982702};\\\", \\\"{x:232,y:767,t:1526929982719};\\\", \\\"{x:247,y:761,t:1526929982735};\\\", \\\"{x:261,y:758,t:1526929982753};\\\", \\\"{x:286,y:753,t:1526929982770};\\\", \\\"{x:298,y:746,t:1526929982787};\\\", \\\"{x:304,y:744,t:1526929982803};\\\", \\\"{x:307,y:742,t:1526929982820};\\\", \\\"{x:309,y:742,t:1526929982836};\\\", \\\"{x:310,y:742,t:1526929982853};\\\", \\\"{x:311,y:742,t:1526929982870};\\\" ] }, { \\\"rt\\\": 171227, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 504320, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-01 PM-I -I -O -O -Z -Z -A -I -G -E -E -E -O -I -I -12 PM-Z -Z -C -A -Z -U -F -K -O -O -K -H -H -H -E -E -I -J -04 PM-J -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:312,y:742,t:1526929983569};\\\", \\\"{x:313,y:742,t:1526929983577};\\\", \\\"{x:314,y:742,t:1526929983587};\\\", \\\"{x:315,y:742,t:1526929983603};\\\", \\\"{x:319,y:744,t:1526929983619};\\\", \\\"{x:321,y:745,t:1526929983636};\\\", \\\"{x:324,y:746,t:1526929983653};\\\", \\\"{x:327,y:749,t:1526929983671};\\\", \\\"{x:330,y:749,t:1526929983687};\\\", \\\"{x:335,y:752,t:1526929983704};\\\", \\\"{x:339,y:753,t:1526929983720};\\\", \\\"{x:347,y:757,t:1526929983737};\\\", \\\"{x:350,y:758,t:1526929983754};\\\", \\\"{x:353,y:759,t:1526929983771};\\\", \\\"{x:357,y:761,t:1526929983787};\\\", \\\"{x:359,y:763,t:1526929983803};\\\", \\\"{x:361,y:764,t:1526929983821};\\\", \\\"{x:364,y:765,t:1526929983837};\\\", \\\"{x:364,y:766,t:1526929983854};\\\", \\\"{x:365,y:766,t:1526929983871};\\\", \\\"{x:366,y:767,t:1526929983887};\\\", \\\"{x:369,y:768,t:1526929983999};\\\", \\\"{x:369,y:769,t:1526929984013};\\\", \\\"{x:370,y:769,t:1526929984049};\\\", \\\"{x:370,y:770,t:1526929984057};\\\", \\\"{x:371,y:770,t:1526929984129};\\\", \\\"{x:371,y:771,t:1526929984289};\\\", \\\"{x:372,y:771,t:1526929984393};\\\", \\\"{x:373,y:771,t:1526929984403};\\\", \\\"{x:372,y:769,t:1526929984625};\\\", \\\"{x:371,y:766,t:1526929984638};\\\", \\\"{x:367,y:760,t:1526929984655};\\\", \\\"{x:364,y:751,t:1526929984670};\\\", \\\"{x:361,y:737,t:1526929984687};\\\", \\\"{x:358,y:715,t:1526929984704};\\\", \\\"{x:354,y:698,t:1526929984721};\\\", \\\"{x:353,y:679,t:1526929984737};\\\", \\\"{x:353,y:656,t:1526929984755};\\\", \\\"{x:358,y:630,t:1526929984771};\\\", \\\"{x:384,y:595,t:1526929984788};\\\", \\\"{x:410,y:564,t:1526929984805};\\\", \\\"{x:447,y:536,t:1526929984823};\\\", \\\"{x:480,y:517,t:1526929984838};\\\", \\\"{x:512,y:498,t:1526929984855};\\\", \\\"{x:534,y:483,t:1526929984870};\\\", \\\"{x:553,y:472,t:1526929984888};\\\", \\\"{x:569,y:462,t:1526929984904};\\\", \\\"{x:577,y:458,t:1526929984921};\\\", \\\"{x:584,y:454,t:1526929984938};\\\", \\\"{x:591,y:449,t:1526929984954};\\\", \\\"{x:605,y:443,t:1526929984972};\\\", \\\"{x:616,y:436,t:1526929984988};\\\", \\\"{x:625,y:431,t:1526929985005};\\\", \\\"{x:629,y:430,t:1526929985022};\\\", \\\"{x:632,y:429,t:1526929985038};\\\", \\\"{x:633,y:428,t:1526929985055};\\\", \\\"{x:635,y:428,t:1526929985121};\\\", \\\"{x:636,y:428,t:1526929985152};\\\", \\\"{x:638,y:428,t:1526929985177};\\\", \\\"{x:639,y:429,t:1526929985201};\\\", \\\"{x:640,y:430,t:1526929985217};\\\", \\\"{x:640,y:431,t:1526929985224};\\\", \\\"{x:640,y:432,t:1526929985238};\\\", \\\"{x:642,y:434,t:1526929985255};\\\", \\\"{x:642,y:436,t:1526929985272};\\\", \\\"{x:642,y:439,t:1526929985289};\\\", \\\"{x:642,y:441,t:1526929985304};\\\", \\\"{x:642,y:443,t:1526929985322};\\\", \\\"{x:642,y:444,t:1526929985339};\\\", \\\"{x:641,y:447,t:1526929985355};\\\", \\\"{x:639,y:449,t:1526929985377};\\\", \\\"{x:638,y:450,t:1526929985388};\\\", \\\"{x:636,y:450,t:1526929985406};\\\", \\\"{x:635,y:451,t:1526929985421};\\\", \\\"{x:633,y:453,t:1526929985439};\\\", \\\"{x:630,y:453,t:1526929985456};\\\", \\\"{x:626,y:454,t:1526929985472};\\\", \\\"{x:618,y:457,t:1526929985489};\\\", \\\"{x:609,y:457,t:1526929985505};\\\", \\\"{x:597,y:461,t:1526929985522};\\\", \\\"{x:582,y:463,t:1526929985539};\\\", \\\"{x:569,y:466,t:1526929985556};\\\", \\\"{x:552,y:469,t:1526929985573};\\\", \\\"{x:536,y:475,t:1526929985589};\\\", \\\"{x:525,y:477,t:1526929985606};\\\", \\\"{x:517,y:478,t:1526929985623};\\\", \\\"{x:511,y:478,t:1526929985639};\\\", \\\"{x:508,y:479,t:1526929985655};\\\", \\\"{x:506,y:481,t:1526929985673};\\\", \\\"{x:505,y:481,t:1526929985689};\\\", \\\"{x:504,y:482,t:1526929985705};\\\", \\\"{x:503,y:482,t:1526929985729};\\\", \\\"{x:503,y:483,t:1526929985817};\\\", \\\"{x:503,y:484,t:1526929985921};\\\", \\\"{x:504,y:484,t:1526929985930};\\\", \\\"{x:507,y:484,t:1526929985940};\\\", \\\"{x:512,y:484,t:1526929985956};\\\", \\\"{x:519,y:485,t:1526929985972};\\\", \\\"{x:523,y:485,t:1526929985990};\\\", \\\"{x:529,y:485,t:1526929986006};\\\", \\\"{x:533,y:485,t:1526929986023};\\\", \\\"{x:539,y:485,t:1526929986040};\\\", \\\"{x:543,y:485,t:1526929986057};\\\", \\\"{x:545,y:485,t:1526929986073};\\\", \\\"{x:549,y:485,t:1526929986090};\\\", \\\"{x:552,y:485,t:1526929986107};\\\", \\\"{x:555,y:485,t:1526929986123};\\\", \\\"{x:556,y:484,t:1526929986139};\\\", \\\"{x:558,y:484,t:1526929986156};\\\", \\\"{x:559,y:484,t:1526929986173};\\\", \\\"{x:561,y:483,t:1526929986190};\\\", \\\"{x:562,y:483,t:1526929986207};\\\", \\\"{x:563,y:483,t:1526929986223};\\\", \\\"{x:564,y:483,t:1526929986240};\\\", \\\"{x:567,y:483,t:1526929986256};\\\", \\\"{x:570,y:482,t:1526929986272};\\\", \\\"{x:574,y:482,t:1526929986290};\\\", \\\"{x:577,y:481,t:1526929986306};\\\", \\\"{x:581,y:481,t:1526929986324};\\\", \\\"{x:583,y:480,t:1526929986339};\\\", \\\"{x:586,y:480,t:1526929986357};\\\", \\\"{x:587,y:480,t:1526929986374};\\\", \\\"{x:588,y:480,t:1526929986417};\\\", \\\"{x:590,y:480,t:1526929986425};\\\", \\\"{x:592,y:478,t:1526929986449};\\\", \\\"{x:593,y:478,t:1526929986481};\\\", \\\"{x:594,y:478,t:1526929986521};\\\", \\\"{x:595,y:478,t:1526929986706};\\\", \\\"{x:596,y:478,t:1526929986729};\\\", \\\"{x:597,y:478,t:1526929986753};\\\", \\\"{x:598,y:478,t:1526929986761};\\\", \\\"{x:600,y:478,t:1526929986774};\\\", \\\"{x:601,y:478,t:1526929986791};\\\", \\\"{x:603,y:478,t:1526929986808};\\\", \\\"{x:607,y:478,t:1526929986825};\\\", \\\"{x:613,y:477,t:1526929986842};\\\", \\\"{x:614,y:477,t:1526929986858};\\\", \\\"{x:616,y:477,t:1526929986875};\\\", \\\"{x:617,y:477,t:1526929986891};\\\", \\\"{x:621,y:476,t:1526929986909};\\\", \\\"{x:625,y:475,t:1526929986924};\\\", \\\"{x:630,y:474,t:1526929986941};\\\", \\\"{x:633,y:474,t:1526929986959};\\\", \\\"{x:637,y:474,t:1526929986976};\\\", \\\"{x:641,y:474,t:1526929986991};\\\", \\\"{x:646,y:474,t:1526929987009};\\\", \\\"{x:652,y:474,t:1526929987025};\\\", \\\"{x:653,y:474,t:1526929987042};\\\", \\\"{x:655,y:474,t:1526929987090};\\\", \\\"{x:656,y:474,t:1526929987122};\\\", \\\"{x:658,y:474,t:1526929987145};\\\", \\\"{x:660,y:474,t:1526929987162};\\\", \\\"{x:661,y:474,t:1526929987176};\\\", \\\"{x:666,y:476,t:1526929987192};\\\", \\\"{x:671,y:478,t:1526929987208};\\\", \\\"{x:679,y:481,t:1526929987226};\\\", \\\"{x:684,y:483,t:1526929987242};\\\", \\\"{x:687,y:485,t:1526929987258};\\\", \\\"{x:692,y:488,t:1526929987275};\\\", \\\"{x:699,y:492,t:1526929987292};\\\", \\\"{x:706,y:496,t:1526929987308};\\\", \\\"{x:718,y:503,t:1526929987326};\\\", \\\"{x:727,y:509,t:1526929987343};\\\", \\\"{x:740,y:516,t:1526929987359};\\\", \\\"{x:751,y:523,t:1526929987377};\\\", \\\"{x:759,y:526,t:1526929987392};\\\", \\\"{x:769,y:533,t:1526929987409};\\\", \\\"{x:771,y:534,t:1526929987423};\\\", \\\"{x:778,y:538,t:1526929987440};\\\", \\\"{x:783,y:541,t:1526929987457};\\\", \\\"{x:785,y:542,t:1526929987473};\\\", \\\"{x:787,y:543,t:1526929987490};\\\", \\\"{x:788,y:545,t:1526929987537};\\\", \\\"{x:789,y:545,t:1526929987545};\\\", \\\"{x:790,y:545,t:1526929987557};\\\", \\\"{x:790,y:546,t:1526929987573};\\\", \\\"{x:791,y:546,t:1526929987590};\\\", \\\"{x:792,y:548,t:1526929987607};\\\", \\\"{x:793,y:548,t:1526929987641};\\\", \\\"{x:793,y:549,t:1526929987657};\\\", \\\"{x:794,y:551,t:1526929987707};\\\", \\\"{x:795,y:553,t:1526929987825};\\\", \\\"{x:795,y:554,t:1526929988050};\\\", \\\"{x:795,y:555,t:1526929988089};\\\", \\\"{x:796,y:557,t:1526929988098};\\\", \\\"{x:797,y:559,t:1526929988109};\\\", \\\"{x:799,y:563,t:1526929988124};\\\", \\\"{x:802,y:569,t:1526929988141};\\\", \\\"{x:808,y:579,t:1526929988157};\\\", \\\"{x:815,y:591,t:1526929988174};\\\", \\\"{x:827,y:602,t:1526929988191};\\\", \\\"{x:843,y:615,t:1526929988207};\\\", \\\"{x:868,y:630,t:1526929988224};\\\", \\\"{x:929,y:655,t:1526929988240};\\\", \\\"{x:977,y:671,t:1526929988257};\\\", \\\"{x:1033,y:679,t:1526929988274};\\\", \\\"{x:1088,y:685,t:1526929988291};\\\", \\\"{x:1142,y:685,t:1526929988308};\\\", \\\"{x:1189,y:685,t:1526929988324};\\\", \\\"{x:1229,y:687,t:1526929988341};\\\", \\\"{x:1257,y:687,t:1526929988359};\\\", \\\"{x:1289,y:679,t:1526929988374};\\\", \\\"{x:1317,y:670,t:1526929988392};\\\", \\\"{x:1337,y:664,t:1526929988408};\\\", \\\"{x:1354,y:657,t:1526929988424};\\\", \\\"{x:1373,y:649,t:1526929988442};\\\", \\\"{x:1383,y:642,t:1526929988458};\\\", \\\"{x:1385,y:641,t:1526929988475};\\\", \\\"{x:1387,y:639,t:1526929988491};\\\", \\\"{x:1388,y:637,t:1526929988508};\\\", \\\"{x:1389,y:635,t:1526929988525};\\\", \\\"{x:1390,y:632,t:1526929988541};\\\", \\\"{x:1391,y:629,t:1526929988558};\\\", \\\"{x:1392,y:624,t:1526929988575};\\\", \\\"{x:1392,y:621,t:1526929988592};\\\", \\\"{x:1392,y:618,t:1526929988608};\\\", \\\"{x:1392,y:615,t:1526929988625};\\\", \\\"{x:1392,y:612,t:1526929988642};\\\", \\\"{x:1391,y:609,t:1526929988658};\\\", \\\"{x:1390,y:607,t:1526929988675};\\\", \\\"{x:1388,y:604,t:1526929988693};\\\", \\\"{x:1386,y:601,t:1526929988708};\\\", \\\"{x:1385,y:599,t:1526929988725};\\\", \\\"{x:1384,y:596,t:1526929988742};\\\", \\\"{x:1382,y:593,t:1526929988759};\\\", \\\"{x:1381,y:591,t:1526929988776};\\\", \\\"{x:1380,y:590,t:1526929988792};\\\", \\\"{x:1379,y:589,t:1526929988809};\\\", \\\"{x:1378,y:588,t:1526929988825};\\\", \\\"{x:1376,y:587,t:1526929988858};\\\", \\\"{x:1375,y:587,t:1526929988882};\\\", \\\"{x:1374,y:586,t:1526929988898};\\\", \\\"{x:1373,y:586,t:1526929989138};\\\", \\\"{x:1372,y:586,t:1526929989170};\\\", \\\"{x:1369,y:584,t:1526929989832};\\\", \\\"{x:1367,y:583,t:1526929989849};\\\", \\\"{x:1363,y:582,t:1526929989861};\\\", \\\"{x:1358,y:580,t:1526929989878};\\\", \\\"{x:1351,y:579,t:1526929989894};\\\", \\\"{x:1343,y:579,t:1526929989911};\\\", \\\"{x:1334,y:579,t:1526929989928};\\\", \\\"{x:1319,y:579,t:1526929989944};\\\", \\\"{x:1284,y:580,t:1526929989961};\\\", \\\"{x:1254,y:585,t:1526929989978};\\\", \\\"{x:1225,y:589,t:1526929989995};\\\", \\\"{x:1202,y:593,t:1526929990011};\\\", \\\"{x:1183,y:600,t:1526929990028};\\\", \\\"{x:1169,y:605,t:1526929990045};\\\", \\\"{x:1158,y:613,t:1526929990061};\\\", \\\"{x:1151,y:620,t:1526929990079};\\\", \\\"{x:1147,y:625,t:1526929990095};\\\", \\\"{x:1144,y:630,t:1526929990111};\\\", \\\"{x:1143,y:632,t:1526929990129};\\\", \\\"{x:1142,y:634,t:1526929990145};\\\", \\\"{x:1142,y:636,t:1526929990227};\\\", \\\"{x:1143,y:636,t:1526929990233};\\\", \\\"{x:1144,y:636,t:1526929990246};\\\", \\\"{x:1148,y:637,t:1526929990263};\\\", \\\"{x:1153,y:637,t:1526929990280};\\\", \\\"{x:1163,y:637,t:1526929990296};\\\", \\\"{x:1179,y:637,t:1526929990313};\\\", \\\"{x:1209,y:637,t:1526929990329};\\\", \\\"{x:1232,y:636,t:1526929990345};\\\", \\\"{x:1257,y:632,t:1526929990362};\\\", \\\"{x:1285,y:625,t:1526929990379};\\\", \\\"{x:1308,y:619,t:1526929990395};\\\", \\\"{x:1327,y:610,t:1526929990412};\\\", \\\"{x:1344,y:606,t:1526929990429};\\\", \\\"{x:1357,y:601,t:1526929990446};\\\", \\\"{x:1368,y:597,t:1526929990462};\\\", \\\"{x:1376,y:594,t:1526929990479};\\\", \\\"{x:1378,y:593,t:1526929990496};\\\", \\\"{x:1379,y:592,t:1526929990777};\\\", \\\"{x:1379,y:591,t:1526929990793};\\\", \\\"{x:1379,y:590,t:1526929990801};\\\", \\\"{x:1379,y:589,t:1526929990818};\\\", \\\"{x:1379,y:587,t:1526929990830};\\\", \\\"{x:1379,y:584,t:1526929990846};\\\", \\\"{x:1379,y:583,t:1526929990864};\\\", \\\"{x:1379,y:581,t:1526929990881};\\\", \\\"{x:1379,y:578,t:1526929990898};\\\", \\\"{x:1379,y:576,t:1526929990913};\\\", \\\"{x:1379,y:574,t:1526929990930};\\\", \\\"{x:1379,y:572,t:1526929990948};\\\", \\\"{x:1379,y:571,t:1526929990963};\\\", \\\"{x:1379,y:570,t:1526929990980};\\\", \\\"{x:1379,y:569,t:1526929991009};\\\", \\\"{x:1379,y:568,t:1526929991603};\\\", \\\"{x:1379,y:565,t:1526929991626};\\\", \\\"{x:1379,y:564,t:1526929991650};\\\", \\\"{x:1380,y:563,t:1526929991674};\\\", \\\"{x:1380,y:562,t:1526929991683};\\\", \\\"{x:1381,y:562,t:1526929991706};\\\", \\\"{x:1381,y:561,t:1526929991738};\\\", \\\"{x:1382,y:561,t:1526929992817};\\\", \\\"{x:1383,y:562,t:1526929992825};\\\", \\\"{x:1384,y:564,t:1526929992834};\\\", \\\"{x:1388,y:568,t:1526929992850};\\\", \\\"{x:1390,y:573,t:1526929992868};\\\", \\\"{x:1392,y:576,t:1526929992884};\\\", \\\"{x:1396,y:581,t:1526929992901};\\\", \\\"{x:1398,y:583,t:1526929992918};\\\", \\\"{x:1400,y:587,t:1526929992934};\\\", \\\"{x:1403,y:589,t:1526929992951};\\\", \\\"{x:1404,y:592,t:1526929992968};\\\", \\\"{x:1410,y:600,t:1526929992985};\\\", \\\"{x:1413,y:603,t:1526929993001};\\\", \\\"{x:1417,y:607,t:1526929993018};\\\", \\\"{x:1423,y:612,t:1526929993035};\\\", \\\"{x:1433,y:618,t:1526929993051};\\\", \\\"{x:1445,y:625,t:1526929993068};\\\", \\\"{x:1456,y:633,t:1526929993085};\\\", \\\"{x:1468,y:646,t:1526929993101};\\\", \\\"{x:1474,y:657,t:1526929993118};\\\", \\\"{x:1483,y:668,t:1526929993135};\\\", \\\"{x:1492,y:684,t:1526929993151};\\\", \\\"{x:1500,y:704,t:1526929993168};\\\", \\\"{x:1508,y:722,t:1526929993185};\\\", \\\"{x:1513,y:732,t:1526929993203};\\\", \\\"{x:1515,y:743,t:1526929993218};\\\", \\\"{x:1520,y:759,t:1526929993236};\\\", \\\"{x:1524,y:770,t:1526929993253};\\\", \\\"{x:1525,y:783,t:1526929993269};\\\", \\\"{x:1528,y:795,t:1526929993285};\\\", \\\"{x:1530,y:807,t:1526929993303};\\\", \\\"{x:1531,y:817,t:1526929993320};\\\", \\\"{x:1533,y:831,t:1526929993335};\\\", \\\"{x:1534,y:843,t:1526929993352};\\\", \\\"{x:1534,y:861,t:1526929993369};\\\", \\\"{x:1534,y:871,t:1526929993385};\\\", \\\"{x:1534,y:883,t:1526929993402};\\\", \\\"{x:1534,y:894,t:1526929993419};\\\", \\\"{x:1534,y:908,t:1526929993435};\\\", \\\"{x:1532,y:917,t:1526929993452};\\\", \\\"{x:1529,y:926,t:1526929993470};\\\", \\\"{x:1527,y:935,t:1526929993487};\\\", \\\"{x:1523,y:942,t:1526929993503};\\\", \\\"{x:1520,y:949,t:1526929993520};\\\", \\\"{x:1516,y:954,t:1526929993537};\\\", \\\"{x:1515,y:956,t:1526929993552};\\\", \\\"{x:1515,y:957,t:1526929993569};\\\", \\\"{x:1512,y:960,t:1526929993587};\\\", \\\"{x:1507,y:964,t:1526929993603};\\\", \\\"{x:1499,y:971,t:1526929993620};\\\", \\\"{x:1486,y:980,t:1526929993636};\\\", \\\"{x:1470,y:989,t:1526929993653};\\\", \\\"{x:1455,y:997,t:1526929993669};\\\", \\\"{x:1443,y:1002,t:1526929993686};\\\", \\\"{x:1440,y:1002,t:1526929993703};\\\", \\\"{x:1436,y:1003,t:1526929993719};\\\", \\\"{x:1433,y:1003,t:1526929993736};\\\", \\\"{x:1425,y:1004,t:1526929993753};\\\", \\\"{x:1421,y:1004,t:1526929993771};\\\", \\\"{x:1412,y:1004,t:1526929993787};\\\", \\\"{x:1404,y:1004,t:1526929993803};\\\", \\\"{x:1396,y:1004,t:1526929993821};\\\", \\\"{x:1389,y:1004,t:1526929993837};\\\", \\\"{x:1387,y:1004,t:1526929993853};\\\", \\\"{x:1386,y:1004,t:1526929993871};\\\", \\\"{x:1386,y:1002,t:1526929993969};\\\", \\\"{x:1386,y:999,t:1526929993985};\\\", \\\"{x:1387,y:997,t:1526929994001};\\\", \\\"{x:1388,y:995,t:1526929994009};\\\", \\\"{x:1389,y:993,t:1526929994020};\\\", \\\"{x:1390,y:992,t:1526929994038};\\\", \\\"{x:1392,y:990,t:1526929994054};\\\", \\\"{x:1394,y:989,t:1526929994071};\\\", \\\"{x:1395,y:988,t:1526929994087};\\\", \\\"{x:1396,y:987,t:1526929994104};\\\", \\\"{x:1397,y:986,t:1526929994121};\\\", \\\"{x:1398,y:985,t:1526929994145};\\\", \\\"{x:1399,y:985,t:1526929994161};\\\", \\\"{x:1400,y:984,t:1526929994170};\\\", \\\"{x:1401,y:983,t:1526929994187};\\\", \\\"{x:1402,y:982,t:1526929994204};\\\", \\\"{x:1404,y:980,t:1526929994221};\\\", \\\"{x:1407,y:977,t:1526929994237};\\\", \\\"{x:1410,y:973,t:1526929994254};\\\", \\\"{x:1413,y:970,t:1526929994272};\\\", \\\"{x:1416,y:965,t:1526929994287};\\\", \\\"{x:1420,y:960,t:1526929994305};\\\", \\\"{x:1424,y:953,t:1526929994321};\\\", \\\"{x:1426,y:940,t:1526929994337};\\\", \\\"{x:1426,y:931,t:1526929994354};\\\", \\\"{x:1427,y:923,t:1526929994371};\\\", \\\"{x:1427,y:912,t:1526929994388};\\\", \\\"{x:1427,y:899,t:1526929994404};\\\", \\\"{x:1425,y:887,t:1526929994422};\\\", \\\"{x:1422,y:881,t:1526929994439};\\\", \\\"{x:1418,y:873,t:1526929994455};\\\", \\\"{x:1413,y:860,t:1526929994471};\\\", \\\"{x:1406,y:846,t:1526929994488};\\\", \\\"{x:1391,y:827,t:1526929994505};\\\", \\\"{x:1382,y:817,t:1526929994521};\\\", \\\"{x:1370,y:807,t:1526929994538};\\\", \\\"{x:1361,y:800,t:1526929994555};\\\", \\\"{x:1354,y:798,t:1526929994572};\\\", \\\"{x:1347,y:794,t:1526929994588};\\\", \\\"{x:1340,y:790,t:1526929994606};\\\", \\\"{x:1329,y:782,t:1526929994622};\\\", \\\"{x:1322,y:775,t:1526929994638};\\\", \\\"{x:1315,y:770,t:1526929994656};\\\", \\\"{x:1307,y:766,t:1526929994672};\\\", \\\"{x:1303,y:762,t:1526929994689};\\\", \\\"{x:1297,y:757,t:1526929994705};\\\", \\\"{x:1294,y:754,t:1526929994722};\\\", \\\"{x:1291,y:751,t:1526929994738};\\\", \\\"{x:1287,y:747,t:1526929994755};\\\", \\\"{x:1284,y:743,t:1526929994772};\\\", \\\"{x:1283,y:741,t:1526929994789};\\\", \\\"{x:1281,y:740,t:1526929994805};\\\", \\\"{x:1280,y:738,t:1526929994823};\\\", \\\"{x:1280,y:736,t:1526929994839};\\\", \\\"{x:1278,y:727,t:1526929994855};\\\", \\\"{x:1275,y:710,t:1526929994872};\\\", \\\"{x:1271,y:675,t:1526929994889};\\\", \\\"{x:1271,y:638,t:1526929994905};\\\", \\\"{x:1271,y:602,t:1526929994922};\\\", \\\"{x:1271,y:573,t:1526929994939};\\\", \\\"{x:1271,y:552,t:1526929994955};\\\", \\\"{x:1271,y:537,t:1526929994972};\\\", \\\"{x:1274,y:527,t:1526929994989};\\\", \\\"{x:1275,y:523,t:1526929995006};\\\", \\\"{x:1277,y:519,t:1526929995022};\\\", \\\"{x:1277,y:517,t:1526929995039};\\\", \\\"{x:1278,y:512,t:1526929995056};\\\", \\\"{x:1280,y:509,t:1526929995073};\\\", \\\"{x:1280,y:505,t:1526929995090};\\\", \\\"{x:1280,y:503,t:1526929995107};\\\", \\\"{x:1281,y:502,t:1526929995162};\\\", \\\"{x:1282,y:502,t:1526929995194};\\\", \\\"{x:1283,y:502,t:1526929995206};\\\", \\\"{x:1284,y:502,t:1526929995223};\\\", \\\"{x:1287,y:503,t:1526929995239};\\\", \\\"{x:1289,y:503,t:1526929995257};\\\", \\\"{x:1292,y:505,t:1526929995273};\\\", \\\"{x:1295,y:506,t:1526929995290};\\\", \\\"{x:1301,y:506,t:1526929995307};\\\", \\\"{x:1305,y:506,t:1526929995323};\\\", \\\"{x:1307,y:507,t:1526929995340};\\\", \\\"{x:1307,y:506,t:1526929995857};\\\", \\\"{x:1306,y:506,t:1526929996033};\\\", \\\"{x:1306,y:507,t:1526929996161};\\\", \\\"{x:1305,y:507,t:1526929996176};\\\", \\\"{x:1304,y:509,t:1526929996192};\\\", \\\"{x:1302,y:510,t:1526929996208};\\\", \\\"{x:1301,y:510,t:1526929996281};\\\", \\\"{x:1300,y:510,t:1526929996417};\\\", \\\"{x:1300,y:509,t:1526929996465};\\\", \\\"{x:1301,y:508,t:1526929996601};\\\", \\\"{x:1303,y:507,t:1526929996624};\\\", \\\"{x:1303,y:506,t:1526929996633};\\\", \\\"{x:1305,y:506,t:1526929996644};\\\", \\\"{x:1308,y:504,t:1526929996659};\\\", \\\"{x:1309,y:503,t:1526929996676};\\\", \\\"{x:1311,y:502,t:1526929996693};\\\", \\\"{x:1312,y:501,t:1526929996710};\\\", \\\"{x:1313,y:500,t:1526929996726};\\\", \\\"{x:1314,y:499,t:1526929996744};\\\", \\\"{x:1316,y:498,t:1526929996785};\\\", \\\"{x:1316,y:497,t:1526929996800};\\\", \\\"{x:1317,y:497,t:1526929996832};\\\", \\\"{x:1317,y:496,t:1526929996857};\\\", \\\"{x:1318,y:495,t:1526929996937};\\\", \\\"{x:1319,y:495,t:1526929997009};\\\", \\\"{x:1320,y:494,t:1526929997787};\\\", \\\"{x:1321,y:493,t:1526929997817};\\\", \\\"{x:1322,y:493,t:1526929997849};\\\", \\\"{x:1323,y:493,t:1526929997874};\\\", \\\"{x:1324,y:493,t:1526929998305};\\\", \\\"{x:1325,y:493,t:1526929998312};\\\", \\\"{x:1325,y:494,t:1526929998337};\\\", \\\"{x:1325,y:496,t:1526929998369};\\\", \\\"{x:1324,y:497,t:1526929998425};\\\", \\\"{x:1323,y:497,t:1526929998457};\\\", \\\"{x:1323,y:498,t:1526929998473};\\\", \\\"{x:1321,y:498,t:1526929998489};\\\", \\\"{x:1319,y:499,t:1526929998497};\\\", \\\"{x:1318,y:499,t:1526929998513};\\\", \\\"{x:1317,y:499,t:1526929998530};\\\", \\\"{x:1316,y:499,t:1526929998547};\\\", \\\"{x:1315,y:499,t:1526929998564};\\\", \\\"{x:1314,y:499,t:1526929998601};\\\", \\\"{x:1313,y:499,t:1526929998634};\\\", \\\"{x:1312,y:499,t:1526929998665};\\\", \\\"{x:1312,y:500,t:1526929998681};\\\", \\\"{x:1311,y:500,t:1526929998761};\\\", \\\"{x:1310,y:500,t:1526929998768};\\\", \\\"{x:1310,y:499,t:1526929999001};\\\", \\\"{x:1310,y:498,t:1526929999015};\\\", \\\"{x:1310,y:497,t:1526929999041};\\\", \\\"{x:1311,y:497,t:1526929999081};\\\", \\\"{x:1312,y:497,t:1526929999481};\\\", \\\"{x:1313,y:497,t:1526929999497};\\\", \\\"{x:1314,y:497,t:1526929999505};\\\", \\\"{x:1315,y:497,t:1526929999538};\\\", \\\"{x:1316,y:498,t:1526929999549};\\\", \\\"{x:1317,y:499,t:1526929999566};\\\", \\\"{x:1317,y:502,t:1526929999584};\\\", \\\"{x:1318,y:504,t:1526929999600};\\\", \\\"{x:1319,y:506,t:1526929999617};\\\", \\\"{x:1320,y:510,t:1526929999633};\\\", \\\"{x:1321,y:517,t:1526929999650};\\\", \\\"{x:1321,y:522,t:1526929999667};\\\", \\\"{x:1321,y:527,t:1526929999683};\\\", \\\"{x:1322,y:533,t:1526929999700};\\\", \\\"{x:1322,y:537,t:1526929999717};\\\", \\\"{x:1322,y:543,t:1526929999734};\\\", \\\"{x:1322,y:553,t:1526929999750};\\\", \\\"{x:1322,y:561,t:1526929999767};\\\", \\\"{x:1320,y:573,t:1526929999784};\\\", \\\"{x:1319,y:583,t:1526929999800};\\\", \\\"{x:1319,y:589,t:1526929999817};\\\", \\\"{x:1315,y:600,t:1526929999834};\\\", \\\"{x:1315,y:604,t:1526929999851};\\\", \\\"{x:1314,y:606,t:1526929999867};\\\", \\\"{x:1314,y:608,t:1526929999884};\\\", \\\"{x:1314,y:611,t:1526929999901};\\\", \\\"{x:1313,y:613,t:1526929999916};\\\", \\\"{x:1313,y:616,t:1526929999934};\\\", \\\"{x:1312,y:619,t:1526929999950};\\\", \\\"{x:1312,y:623,t:1526929999968};\\\", \\\"{x:1311,y:624,t:1526929999984};\\\", \\\"{x:1311,y:625,t:1526930000001};\\\", \\\"{x:1311,y:627,t:1526930000017};\\\", \\\"{x:1311,y:628,t:1526930000041};\\\", \\\"{x:1311,y:629,t:1526930000057};\\\", \\\"{x:1311,y:630,t:1526930000068};\\\", \\\"{x:1311,y:631,t:1526930000084};\\\", \\\"{x:1311,y:632,t:1526930000100};\\\", \\\"{x:1311,y:633,t:1526930000118};\\\", \\\"{x:1311,y:634,t:1526930000138};\\\", \\\"{x:1311,y:635,t:1526930000151};\\\", \\\"{x:1310,y:637,t:1526930000168};\\\", \\\"{x:1309,y:639,t:1526930000185};\\\", \\\"{x:1309,y:641,t:1526930000200};\\\", \\\"{x:1310,y:645,t:1526930000218};\\\", \\\"{x:1310,y:649,t:1526930000234};\\\", \\\"{x:1310,y:653,t:1526930000251};\\\", \\\"{x:1310,y:657,t:1526930000267};\\\", \\\"{x:1310,y:665,t:1526930000285};\\\", \\\"{x:1310,y:670,t:1526930000301};\\\", \\\"{x:1309,y:675,t:1526930000318};\\\", \\\"{x:1308,y:680,t:1526930000334};\\\", \\\"{x:1308,y:682,t:1526930000351};\\\", \\\"{x:1308,y:685,t:1526930000367};\\\", \\\"{x:1308,y:686,t:1526930000385};\\\", \\\"{x:1308,y:688,t:1526930000401};\\\", \\\"{x:1308,y:691,t:1526930000419};\\\", \\\"{x:1308,y:692,t:1526930000434};\\\", \\\"{x:1308,y:694,t:1526930000451};\\\", \\\"{x:1308,y:696,t:1526930000468};\\\", \\\"{x:1308,y:697,t:1526930000485};\\\", \\\"{x:1308,y:698,t:1526930000502};\\\", \\\"{x:1308,y:699,t:1526930000519};\\\", \\\"{x:1308,y:701,t:1526930000535};\\\", \\\"{x:1308,y:702,t:1526930000552};\\\", \\\"{x:1308,y:704,t:1526930000568};\\\", \\\"{x:1308,y:707,t:1526930000585};\\\", \\\"{x:1308,y:708,t:1526930000602};\\\", \\\"{x:1308,y:711,t:1526930000619};\\\", \\\"{x:1308,y:712,t:1526930000635};\\\", \\\"{x:1308,y:714,t:1526930000652};\\\", \\\"{x:1308,y:715,t:1526930000668};\\\", \\\"{x:1308,y:717,t:1526930000685};\\\", \\\"{x:1308,y:718,t:1526930000702};\\\", \\\"{x:1308,y:721,t:1526930000719};\\\", \\\"{x:1308,y:724,t:1526930000736};\\\", \\\"{x:1308,y:728,t:1526930000752};\\\", \\\"{x:1308,y:732,t:1526930000768};\\\", \\\"{x:1308,y:738,t:1526930000785};\\\", \\\"{x:1308,y:744,t:1526930000802};\\\", \\\"{x:1309,y:747,t:1526930000818};\\\", \\\"{x:1310,y:749,t:1526930000835};\\\", \\\"{x:1312,y:755,t:1526930000853};\\\", \\\"{x:1313,y:761,t:1526930000869};\\\", \\\"{x:1317,y:770,t:1526930000885};\\\", \\\"{x:1317,y:776,t:1526930000903};\\\", \\\"{x:1319,y:783,t:1526930000920};\\\", \\\"{x:1323,y:793,t:1526930000936};\\\", \\\"{x:1327,y:803,t:1526930000953};\\\", \\\"{x:1332,y:816,t:1526930000969};\\\", \\\"{x:1336,y:826,t:1526930000986};\\\", \\\"{x:1337,y:833,t:1526930001003};\\\", \\\"{x:1340,y:841,t:1526930001020};\\\", \\\"{x:1341,y:848,t:1526930001036};\\\", \\\"{x:1342,y:856,t:1526930001053};\\\", \\\"{x:1345,y:862,t:1526930001070};\\\", \\\"{x:1346,y:869,t:1526930001086};\\\", \\\"{x:1348,y:873,t:1526930001102};\\\", \\\"{x:1348,y:878,t:1526930001119};\\\", \\\"{x:1348,y:881,t:1526930001137};\\\", \\\"{x:1348,y:887,t:1526930001153};\\\", \\\"{x:1348,y:896,t:1526930001170};\\\", \\\"{x:1348,y:903,t:1526930001188};\\\", \\\"{x:1344,y:911,t:1526930001203};\\\", \\\"{x:1344,y:917,t:1526930001220};\\\", \\\"{x:1343,y:922,t:1526930001237};\\\", \\\"{x:1342,y:927,t:1526930001254};\\\", \\\"{x:1341,y:932,t:1526930001270};\\\", \\\"{x:1339,y:935,t:1526930001287};\\\", \\\"{x:1339,y:937,t:1526930001304};\\\", \\\"{x:1339,y:941,t:1526930001320};\\\", \\\"{x:1338,y:943,t:1526930001338};\\\", \\\"{x:1333,y:949,t:1526930001354};\\\", \\\"{x:1331,y:952,t:1526930001371};\\\", \\\"{x:1331,y:953,t:1526930001387};\\\", \\\"{x:1330,y:955,t:1526930001404};\\\", \\\"{x:1329,y:958,t:1526930001421};\\\", \\\"{x:1328,y:958,t:1526930001437};\\\", \\\"{x:1328,y:959,t:1526930001454};\\\", \\\"{x:1327,y:960,t:1526930001490};\\\", \\\"{x:1326,y:960,t:1526930001514};\\\", \\\"{x:1325,y:961,t:1526930001522};\\\", \\\"{x:1324,y:962,t:1526930001538};\\\", \\\"{x:1322,y:963,t:1526930001555};\\\", \\\"{x:1321,y:965,t:1526930001571};\\\", \\\"{x:1320,y:966,t:1526930001589};\\\", \\\"{x:1319,y:966,t:1526930001666};\\\", \\\"{x:1318,y:966,t:1526930001810};\\\", \\\"{x:1315,y:965,t:1526930001822};\\\", \\\"{x:1303,y:950,t:1526930001839};\\\", \\\"{x:1288,y:932,t:1526930001855};\\\", \\\"{x:1276,y:913,t:1526930001872};\\\", \\\"{x:1268,y:894,t:1526930001888};\\\", \\\"{x:1268,y:871,t:1526930001905};\\\", \\\"{x:1273,y:833,t:1526930001921};\\\", \\\"{x:1279,y:811,t:1526930001938};\\\", \\\"{x:1286,y:785,t:1526930001956};\\\", \\\"{x:1289,y:758,t:1526930001972};\\\", \\\"{x:1289,y:728,t:1526930001989};\\\", \\\"{x:1289,y:689,t:1526930002006};\\\", \\\"{x:1289,y:658,t:1526930002023};\\\", \\\"{x:1289,y:627,t:1526930002039};\\\", \\\"{x:1292,y:598,t:1526930002055};\\\", \\\"{x:1296,y:575,t:1526930002072};\\\", \\\"{x:1298,y:548,t:1526930002089};\\\", \\\"{x:1301,y:532,t:1526930002106};\\\", \\\"{x:1301,y:521,t:1526930002121};\\\", \\\"{x:1301,y:515,t:1526930002139};\\\", \\\"{x:1301,y:511,t:1526930002155};\\\", \\\"{x:1301,y:507,t:1526930002171};\\\", \\\"{x:1301,y:505,t:1526930002188};\\\", \\\"{x:1300,y:503,t:1526930002205};\\\", \\\"{x:1300,y:502,t:1526930002361};\\\", \\\"{x:1300,y:501,t:1526930002489};\\\", \\\"{x:1300,y:500,t:1526930002514};\\\", \\\"{x:1301,y:499,t:1526930002530};\\\", \\\"{x:1302,y:498,t:1526930002562};\\\", \\\"{x:1303,y:498,t:1526930002602};\\\", \\\"{x:1304,y:498,t:1526930002618};\\\", \\\"{x:1306,y:497,t:1526930002642};\\\", \\\"{x:1307,y:497,t:1526930002666};\\\", \\\"{x:1309,y:497,t:1526930002674};\\\", \\\"{x:1310,y:496,t:1526930002707};\\\", \\\"{x:1311,y:496,t:1526930002754};\\\", \\\"{x:1312,y:496,t:1526930002769};\\\", \\\"{x:1313,y:495,t:1526930002794};\\\", \\\"{x:1314,y:495,t:1526930005584};\\\", \\\"{x:1315,y:495,t:1526930005785};\\\", \\\"{x:1315,y:496,t:1526930007769};\\\", \\\"{x:1315,y:497,t:1526930007817};\\\", \\\"{x:1315,y:498,t:1526930008570};\\\", \\\"{x:1314,y:498,t:1526930008601};\\\", \\\"{x:1313,y:498,t:1526930008674};\\\", \\\"{x:1313,y:497,t:1526930008809};\\\", \\\"{x:1313,y:496,t:1526930008921};\\\", \\\"{x:1313,y:495,t:1526930008969};\\\", \\\"{x:1313,y:494,t:1526930009481};\\\", \\\"{x:1315,y:494,t:1526930009672};\\\", \\\"{x:1320,y:494,t:1526930009688};\\\", \\\"{x:1325,y:495,t:1526930009705};\\\", \\\"{x:1335,y:497,t:1526930009722};\\\", \\\"{x:1346,y:498,t:1526930009739};\\\", \\\"{x:1356,y:500,t:1526930009756};\\\", \\\"{x:1365,y:500,t:1526930009772};\\\", \\\"{x:1371,y:501,t:1526930009789};\\\", \\\"{x:1374,y:502,t:1526930009806};\\\", \\\"{x:1376,y:502,t:1526930010141};\\\", \\\"{x:1377,y:502,t:1526930010165};\\\", \\\"{x:1379,y:502,t:1526930010181};\\\", \\\"{x:1380,y:502,t:1526930010193};\\\", \\\"{x:1389,y:501,t:1526930010210};\\\", \\\"{x:1397,y:500,t:1526930010227};\\\", \\\"{x:1408,y:500,t:1526930010243};\\\", \\\"{x:1429,y:500,t:1526930010260};\\\", \\\"{x:1436,y:500,t:1526930010277};\\\", \\\"{x:1440,y:500,t:1526930010294};\\\", \\\"{x:1441,y:500,t:1526930010829};\\\", \\\"{x:1447,y:499,t:1526930010845};\\\", \\\"{x:1457,y:499,t:1526930010862};\\\", \\\"{x:1467,y:499,t:1526930010880};\\\", \\\"{x:1475,y:499,t:1526930010896};\\\", \\\"{x:1478,y:499,t:1526930010913};\\\", \\\"{x:1482,y:499,t:1526930010929};\\\", \\\"{x:1483,y:499,t:1526930010946};\\\", \\\"{x:1484,y:499,t:1526930010973};\\\", \\\"{x:1485,y:499,t:1526930010996};\\\", \\\"{x:1487,y:499,t:1526930011020};\\\", \\\"{x:1488,y:499,t:1526930011044};\\\", \\\"{x:1491,y:499,t:1526930011060};\\\", \\\"{x:1492,y:499,t:1526930011068};\\\", \\\"{x:1495,y:499,t:1526930011078};\\\", \\\"{x:1503,y:499,t:1526930011095};\\\", \\\"{x:1512,y:499,t:1526930011112};\\\", \\\"{x:1520,y:499,t:1526930011128};\\\", \\\"{x:1525,y:499,t:1526930011146};\\\", \\\"{x:1527,y:499,t:1526930011163};\\\", \\\"{x:1528,y:499,t:1526930011179};\\\", \\\"{x:1527,y:499,t:1526930011644};\\\", \\\"{x:1525,y:499,t:1526930011677};\\\", \\\"{x:1524,y:499,t:1526930011709};\\\", \\\"{x:1523,y:499,t:1526930011741};\\\", \\\"{x:1522,y:499,t:1526930011749};\\\", \\\"{x:1521,y:499,t:1526930011764};\\\", \\\"{x:1519,y:499,t:1526930011780};\\\", \\\"{x:1518,y:499,t:1526930011797};\\\", \\\"{x:1516,y:499,t:1526930011821};\\\", \\\"{x:1515,y:499,t:1526930011868};\\\", \\\"{x:1514,y:499,t:1526930011981};\\\", \\\"{x:1515,y:499,t:1526930012821};\\\", \\\"{x:1516,y:499,t:1526930012838};\\\", \\\"{x:1518,y:499,t:1526930012851};\\\", \\\"{x:1519,y:499,t:1526930012866};\\\", \\\"{x:1521,y:499,t:1526930012883};\\\", \\\"{x:1524,y:499,t:1526930012900};\\\", \\\"{x:1528,y:499,t:1526930012916};\\\", \\\"{x:1531,y:499,t:1526930012933};\\\", \\\"{x:1535,y:500,t:1526930012949};\\\", \\\"{x:1538,y:500,t:1526930012967};\\\", \\\"{x:1542,y:501,t:1526930012983};\\\", \\\"{x:1543,y:501,t:1526930012999};\\\", \\\"{x:1546,y:501,t:1526930013017};\\\", \\\"{x:1550,y:503,t:1526930013033};\\\", \\\"{x:1551,y:503,t:1526930013050};\\\", \\\"{x:1553,y:503,t:1526930013066};\\\", \\\"{x:1555,y:503,t:1526930013084};\\\", \\\"{x:1556,y:503,t:1526930013100};\\\", \\\"{x:1557,y:503,t:1526930013117};\\\", \\\"{x:1558,y:503,t:1526930013133};\\\", \\\"{x:1559,y:503,t:1526930013150};\\\", \\\"{x:1560,y:503,t:1526930013167};\\\", \\\"{x:1561,y:503,t:1526930013184};\\\", \\\"{x:1562,y:503,t:1526930013204};\\\", \\\"{x:1563,y:503,t:1526930013220};\\\", \\\"{x:1564,y:503,t:1526930013245};\\\", \\\"{x:1565,y:503,t:1526930013277};\\\", \\\"{x:1566,y:503,t:1526930013284};\\\", \\\"{x:1567,y:503,t:1526930013301};\\\", \\\"{x:1569,y:503,t:1526930013332};\\\", \\\"{x:1570,y:503,t:1526930013390};\\\", \\\"{x:1571,y:503,t:1526930013484};\\\", \\\"{x:1572,y:502,t:1526930013500};\\\", \\\"{x:1573,y:501,t:1526930013556};\\\", \\\"{x:1574,y:501,t:1526930013572};\\\", \\\"{x:1575,y:500,t:1526930013604};\\\", \\\"{x:1576,y:500,t:1526930013652};\\\", \\\"{x:1576,y:499,t:1526930013709};\\\", \\\"{x:1577,y:499,t:1526930013749};\\\", \\\"{x:1578,y:498,t:1526930013798};\\\", \\\"{x:1580,y:498,t:1526930017252};\\\", \\\"{x:1584,y:498,t:1526930017260};\\\", \\\"{x:1588,y:498,t:1526930017276};\\\", \\\"{x:1613,y:500,t:1526930017292};\\\", \\\"{x:1628,y:500,t:1526930017310};\\\", \\\"{x:1635,y:500,t:1526930017326};\\\", \\\"{x:1640,y:500,t:1526930017343};\\\", \\\"{x:1641,y:500,t:1526930017405};\\\", \\\"{x:1642,y:500,t:1526930017517};\\\", \\\"{x:1642,y:499,t:1526930017612};\\\", \\\"{x:1642,y:498,t:1526930017828};\\\", \\\"{x:1643,y:498,t:1526930017933};\\\", \\\"{x:1643,y:497,t:1526930017964};\\\", \\\"{x:1644,y:497,t:1526930018068};\\\", \\\"{x:1645,y:497,t:1526930018172};\\\", \\\"{x:1646,y:497,t:1526930018180};\\\", \\\"{x:1646,y:498,t:1526930018195};\\\", \\\"{x:1646,y:499,t:1526930018212};\\\", \\\"{x:1646,y:502,t:1526930018228};\\\", \\\"{x:1647,y:505,t:1526930018245};\\\", \\\"{x:1647,y:508,t:1526930018262};\\\", \\\"{x:1648,y:510,t:1526930018277};\\\", \\\"{x:1648,y:512,t:1526930018295};\\\", \\\"{x:1649,y:516,t:1526930018312};\\\", \\\"{x:1649,y:518,t:1526930018329};\\\", \\\"{x:1650,y:523,t:1526930018344};\\\", \\\"{x:1650,y:525,t:1526930018362};\\\", \\\"{x:1650,y:529,t:1526930018379};\\\", \\\"{x:1650,y:532,t:1526930018395};\\\", \\\"{x:1650,y:534,t:1526930018412};\\\", \\\"{x:1651,y:538,t:1526930018428};\\\", \\\"{x:1652,y:540,t:1526930018445};\\\", \\\"{x:1653,y:542,t:1526930018462};\\\", \\\"{x:1654,y:543,t:1526930018479};\\\", \\\"{x:1654,y:545,t:1526930018495};\\\", \\\"{x:1654,y:548,t:1526930018512};\\\", \\\"{x:1656,y:550,t:1526930018529};\\\", \\\"{x:1656,y:552,t:1526930018546};\\\", \\\"{x:1656,y:554,t:1526930018562};\\\", \\\"{x:1657,y:556,t:1526930018579};\\\", \\\"{x:1658,y:559,t:1526930018596};\\\", \\\"{x:1658,y:561,t:1526930018612};\\\", \\\"{x:1659,y:565,t:1526930018629};\\\", \\\"{x:1660,y:568,t:1526930018646};\\\", \\\"{x:1660,y:569,t:1526930018663};\\\", \\\"{x:1660,y:571,t:1526930018679};\\\", \\\"{x:1660,y:572,t:1526930018696};\\\", \\\"{x:1660,y:574,t:1526930018713};\\\", \\\"{x:1660,y:575,t:1526930018748};\\\", \\\"{x:1660,y:576,t:1526930018764};\\\", \\\"{x:1660,y:577,t:1526930018780};\\\", \\\"{x:1661,y:578,t:1526930018812};\\\", \\\"{x:1661,y:579,t:1526930018820};\\\", \\\"{x:1661,y:580,t:1526930018836};\\\", \\\"{x:1661,y:581,t:1526930018846};\\\", \\\"{x:1661,y:582,t:1526930018863};\\\", \\\"{x:1661,y:584,t:1526930018880};\\\", \\\"{x:1661,y:585,t:1526930018895};\\\", \\\"{x:1662,y:588,t:1526930018913};\\\", \\\"{x:1662,y:589,t:1526930018930};\\\", \\\"{x:1662,y:590,t:1526930018947};\\\", \\\"{x:1662,y:593,t:1526930018962};\\\", \\\"{x:1662,y:595,t:1526930018980};\\\", \\\"{x:1662,y:596,t:1526930018997};\\\", \\\"{x:1662,y:599,t:1526930019013};\\\", \\\"{x:1662,y:602,t:1526930019029};\\\", \\\"{x:1662,y:604,t:1526930019047};\\\", \\\"{x:1662,y:608,t:1526930019063};\\\", \\\"{x:1662,y:611,t:1526930019080};\\\", \\\"{x:1662,y:615,t:1526930019096};\\\", \\\"{x:1662,y:619,t:1526930019114};\\\", \\\"{x:1662,y:624,t:1526930019130};\\\", \\\"{x:1662,y:632,t:1526930019147};\\\", \\\"{x:1662,y:644,t:1526930019164};\\\", \\\"{x:1662,y:652,t:1526930019180};\\\", \\\"{x:1662,y:666,t:1526930019197};\\\", \\\"{x:1662,y:677,t:1526930019214};\\\", \\\"{x:1662,y:688,t:1526930019230};\\\", \\\"{x:1661,y:701,t:1526930019246};\\\", \\\"{x:1660,y:712,t:1526930019264};\\\", \\\"{x:1658,y:721,t:1526930019281};\\\", \\\"{x:1658,y:730,t:1526930019297};\\\", \\\"{x:1657,y:736,t:1526930019315};\\\", \\\"{x:1657,y:740,t:1526930019331};\\\", \\\"{x:1656,y:743,t:1526930019347};\\\", \\\"{x:1656,y:747,t:1526930019364};\\\", \\\"{x:1656,y:751,t:1526930019381};\\\", \\\"{x:1654,y:756,t:1526930019397};\\\", \\\"{x:1654,y:762,t:1526930019414};\\\", \\\"{x:1653,y:770,t:1526930019430};\\\", \\\"{x:1653,y:780,t:1526930019448};\\\", \\\"{x:1652,y:791,t:1526930019464};\\\", \\\"{x:1652,y:799,t:1526930019481};\\\", \\\"{x:1649,y:816,t:1526930019498};\\\", \\\"{x:1648,y:827,t:1526930019515};\\\", \\\"{x:1646,y:843,t:1526930019531};\\\", \\\"{x:1642,y:868,t:1526930019548};\\\", \\\"{x:1642,y:882,t:1526930019564};\\\", \\\"{x:1639,y:892,t:1526930019581};\\\", \\\"{x:1639,y:898,t:1526930019598};\\\", \\\"{x:1639,y:902,t:1526930019615};\\\", \\\"{x:1639,y:905,t:1526930019630};\\\", \\\"{x:1639,y:906,t:1526930019648};\\\", \\\"{x:1639,y:909,t:1526930019665};\\\", \\\"{x:1639,y:912,t:1526930019681};\\\", \\\"{x:1639,y:915,t:1526930019698};\\\", \\\"{x:1639,y:917,t:1526930019715};\\\", \\\"{x:1639,y:920,t:1526930019732};\\\", \\\"{x:1640,y:922,t:1526930019748};\\\", \\\"{x:1640,y:923,t:1526930019765};\\\", \\\"{x:1640,y:925,t:1526930019783};\\\", \\\"{x:1642,y:926,t:1526930019799};\\\", \\\"{x:1642,y:928,t:1526930019815};\\\", \\\"{x:1644,y:930,t:1526930019832};\\\", \\\"{x:1646,y:933,t:1526930019848};\\\", \\\"{x:1647,y:936,t:1526930019865};\\\", \\\"{x:1649,y:938,t:1526930019882};\\\", \\\"{x:1649,y:940,t:1526930019898};\\\", \\\"{x:1649,y:941,t:1526930019916};\\\", \\\"{x:1649,y:942,t:1526930019931};\\\", \\\"{x:1650,y:944,t:1526930019949};\\\", \\\"{x:1650,y:946,t:1526930019965};\\\", \\\"{x:1650,y:948,t:1526930019982};\\\", \\\"{x:1651,y:950,t:1526930019999};\\\", \\\"{x:1651,y:951,t:1526930020016};\\\", \\\"{x:1651,y:952,t:1526930020045};\\\", \\\"{x:1651,y:953,t:1526930020052};\\\", \\\"{x:1651,y:954,t:1526930020066};\\\", \\\"{x:1651,y:955,t:1526930020083};\\\", \\\"{x:1651,y:956,t:1526930020099};\\\", \\\"{x:1651,y:957,t:1526930020117};\\\", \\\"{x:1651,y:958,t:1526930020157};\\\", \\\"{x:1651,y:959,t:1526930020166};\\\", \\\"{x:1651,y:960,t:1526930020184};\\\", \\\"{x:1652,y:962,t:1526930020237};\\\", \\\"{x:1652,y:963,t:1526930020277};\\\", \\\"{x:1652,y:964,t:1526930020326};\\\", \\\"{x:1651,y:961,t:1526930020558};\\\", \\\"{x:1648,y:954,t:1526930020568};\\\", \\\"{x:1647,y:947,t:1526930020583};\\\", \\\"{x:1647,y:938,t:1526930020601};\\\", \\\"{x:1646,y:931,t:1526930020617};\\\", \\\"{x:1644,y:925,t:1526930020635};\\\", \\\"{x:1643,y:918,t:1526930020651};\\\", \\\"{x:1643,y:915,t:1526930020668};\\\", \\\"{x:1643,y:911,t:1526930020685};\\\", \\\"{x:1643,y:908,t:1526930020701};\\\", \\\"{x:1643,y:905,t:1526930020717};\\\", \\\"{x:1643,y:902,t:1526930020735};\\\", \\\"{x:1643,y:901,t:1526930020750};\\\", \\\"{x:1643,y:899,t:1526930020768};\\\", \\\"{x:1643,y:898,t:1526930020784};\\\", \\\"{x:1643,y:894,t:1526930020802};\\\", \\\"{x:1642,y:891,t:1526930020818};\\\", \\\"{x:1642,y:888,t:1526930020835};\\\", \\\"{x:1641,y:884,t:1526930020851};\\\", \\\"{x:1641,y:880,t:1526930020867};\\\", \\\"{x:1640,y:870,t:1526930020884};\\\", \\\"{x:1639,y:865,t:1526930020901};\\\", \\\"{x:1639,y:858,t:1526930020918};\\\", \\\"{x:1639,y:853,t:1526930020934};\\\", \\\"{x:1639,y:848,t:1526930020951};\\\", \\\"{x:1639,y:844,t:1526930020968};\\\", \\\"{x:1639,y:838,t:1526930020984};\\\", \\\"{x:1639,y:835,t:1526930021001};\\\", \\\"{x:1639,y:829,t:1526930021018};\\\", \\\"{x:1639,y:825,t:1526930021034};\\\", \\\"{x:1639,y:821,t:1526930021051};\\\", \\\"{x:1639,y:812,t:1526930021068};\\\", \\\"{x:1638,y:805,t:1526930021085};\\\", \\\"{x:1638,y:801,t:1526930021101};\\\", \\\"{x:1638,y:798,t:1526930021118};\\\", \\\"{x:1637,y:794,t:1526930021135};\\\", \\\"{x:1637,y:791,t:1526930021151};\\\", \\\"{x:1637,y:789,t:1526930021168};\\\", \\\"{x:1637,y:788,t:1526930021185};\\\", \\\"{x:1637,y:785,t:1526930021201};\\\", \\\"{x:1637,y:784,t:1526930021218};\\\", \\\"{x:1637,y:782,t:1526930021235};\\\", \\\"{x:1637,y:781,t:1526930021252};\\\", \\\"{x:1637,y:779,t:1526930021268};\\\", \\\"{x:1637,y:777,t:1526930021285};\\\", \\\"{x:1637,y:776,t:1526930021302};\\\", \\\"{x:1637,y:771,t:1526930021318};\\\", \\\"{x:1638,y:769,t:1526930021335};\\\", \\\"{x:1638,y:766,t:1526930021352};\\\", \\\"{x:1639,y:765,t:1526930021368};\\\", \\\"{x:1640,y:759,t:1526930021385};\\\", \\\"{x:1640,y:758,t:1526930021402};\\\", \\\"{x:1641,y:754,t:1526930021419};\\\", \\\"{x:1641,y:751,t:1526930021435};\\\", \\\"{x:1644,y:747,t:1526930021452};\\\", \\\"{x:1644,y:746,t:1526930021469};\\\", \\\"{x:1644,y:745,t:1526930021485};\\\", \\\"{x:1644,y:744,t:1526930021502};\\\", \\\"{x:1644,y:743,t:1526930021519};\\\", \\\"{x:1644,y:742,t:1526930021536};\\\", \\\"{x:1644,y:740,t:1526930021552};\\\", \\\"{x:1644,y:738,t:1526930021569};\\\", \\\"{x:1644,y:736,t:1526930021586};\\\", \\\"{x:1644,y:735,t:1526930021604};\\\", \\\"{x:1644,y:733,t:1526930021628};\\\", \\\"{x:1644,y:732,t:1526930021652};\\\", \\\"{x:1644,y:728,t:1526930021669};\\\", \\\"{x:1644,y:725,t:1526930021686};\\\", \\\"{x:1644,y:722,t:1526930021704};\\\", \\\"{x:1644,y:718,t:1526930021719};\\\", \\\"{x:1644,y:714,t:1526930021736};\\\", \\\"{x:1644,y:708,t:1526930021753};\\\", \\\"{x:1644,y:701,t:1526930021770};\\\", \\\"{x:1644,y:695,t:1526930021786};\\\", \\\"{x:1644,y:688,t:1526930021803};\\\", \\\"{x:1644,y:684,t:1526930021820};\\\", \\\"{x:1644,y:680,t:1526930021836};\\\", \\\"{x:1644,y:677,t:1526930021854};\\\", \\\"{x:1644,y:674,t:1526930021870};\\\", \\\"{x:1644,y:670,t:1526930021886};\\\", \\\"{x:1644,y:668,t:1526930021903};\\\", \\\"{x:1644,y:666,t:1526930021920};\\\", \\\"{x:1644,y:663,t:1526930021936};\\\", \\\"{x:1644,y:661,t:1526930021953};\\\", \\\"{x:1644,y:657,t:1526930021970};\\\", \\\"{x:1644,y:655,t:1526930021987};\\\", \\\"{x:1644,y:653,t:1526930022003};\\\", \\\"{x:1644,y:651,t:1526930022020};\\\", \\\"{x:1644,y:648,t:1526930022036};\\\", \\\"{x:1644,y:646,t:1526930022053};\\\", \\\"{x:1644,y:642,t:1526930022070};\\\", \\\"{x:1644,y:640,t:1526930022087};\\\", \\\"{x:1644,y:639,t:1526930022103};\\\", \\\"{x:1644,y:638,t:1526930022121};\\\", \\\"{x:1644,y:636,t:1526930022137};\\\", \\\"{x:1644,y:635,t:1526930022154};\\\", \\\"{x:1644,y:632,t:1526930022170};\\\", \\\"{x:1643,y:630,t:1526930022187};\\\", \\\"{x:1643,y:626,t:1526930022205};\\\", \\\"{x:1643,y:621,t:1526930022220};\\\", \\\"{x:1643,y:618,t:1526930022237};\\\", \\\"{x:1644,y:614,t:1526930022254};\\\", \\\"{x:1644,y:611,t:1526930022270};\\\", \\\"{x:1644,y:608,t:1526930022288};\\\", \\\"{x:1644,y:603,t:1526930022304};\\\", \\\"{x:1644,y:600,t:1526930022322};\\\", \\\"{x:1644,y:594,t:1526930022337};\\\", \\\"{x:1643,y:591,t:1526930022354};\\\", \\\"{x:1643,y:587,t:1526930022371};\\\", \\\"{x:1642,y:584,t:1526930022388};\\\", \\\"{x:1640,y:578,t:1526930022405};\\\", \\\"{x:1640,y:575,t:1526930022422};\\\", \\\"{x:1640,y:572,t:1526930022438};\\\", \\\"{x:1640,y:569,t:1526930022454};\\\", \\\"{x:1640,y:567,t:1526930022471};\\\", \\\"{x:1640,y:566,t:1526930022488};\\\", \\\"{x:1640,y:562,t:1526930022504};\\\", \\\"{x:1640,y:560,t:1526930022521};\\\", \\\"{x:1640,y:555,t:1526930022539};\\\", \\\"{x:1640,y:553,t:1526930022555};\\\", \\\"{x:1640,y:549,t:1526930022572};\\\", \\\"{x:1640,y:544,t:1526930022588};\\\", \\\"{x:1640,y:541,t:1526930022605};\\\", \\\"{x:1640,y:537,t:1526930022621};\\\", \\\"{x:1640,y:535,t:1526930022639};\\\", \\\"{x:1640,y:531,t:1526930022656};\\\", \\\"{x:1640,y:528,t:1526930022671};\\\", \\\"{x:1640,y:523,t:1526930022688};\\\", \\\"{x:1641,y:520,t:1526930022705};\\\", \\\"{x:1642,y:517,t:1526930022721};\\\", \\\"{x:1643,y:513,t:1526930022738};\\\", \\\"{x:1644,y:512,t:1526930022756};\\\", \\\"{x:1644,y:511,t:1526930022797};\\\", \\\"{x:1644,y:510,t:1526930022812};\\\", \\\"{x:1644,y:509,t:1526930022836};\\\", \\\"{x:1645,y:507,t:1526930022845};\\\", \\\"{x:1646,y:507,t:1526930022860};\\\", \\\"{x:1647,y:506,t:1526930022876};\\\", \\\"{x:1647,y:505,t:1526930022900};\\\", \\\"{x:1647,y:504,t:1526930022924};\\\", \\\"{x:1648,y:502,t:1526930022949};\\\", \\\"{x:1650,y:501,t:1526930022980};\\\", \\\"{x:1650,y:500,t:1526930023052};\\\", \\\"{x:1649,y:501,t:1526930023404};\\\", \\\"{x:1646,y:506,t:1526930023412};\\\", \\\"{x:1645,y:509,t:1526930023423};\\\", \\\"{x:1637,y:522,t:1526930023440};\\\", \\\"{x:1631,y:530,t:1526930023456};\\\", \\\"{x:1627,y:538,t:1526930023473};\\\", \\\"{x:1626,y:542,t:1526930023490};\\\", \\\"{x:1625,y:544,t:1526930023507};\\\", \\\"{x:1624,y:547,t:1526930023524};\\\", \\\"{x:1624,y:550,t:1526930023540};\\\", \\\"{x:1624,y:554,t:1526930023557};\\\", \\\"{x:1624,y:556,t:1526930023573};\\\", \\\"{x:1624,y:557,t:1526930023590};\\\", \\\"{x:1624,y:560,t:1526930023607};\\\", \\\"{x:1624,y:561,t:1526930023623};\\\", \\\"{x:1624,y:562,t:1526930023641};\\\", \\\"{x:1624,y:563,t:1526930023657};\\\", \\\"{x:1624,y:564,t:1526930023675};\\\", \\\"{x:1624,y:567,t:1526930023691};\\\", \\\"{x:1624,y:570,t:1526930023708};\\\", \\\"{x:1624,y:574,t:1526930023724};\\\", \\\"{x:1624,y:576,t:1526930023741};\\\", \\\"{x:1624,y:578,t:1526930023758};\\\", \\\"{x:1624,y:579,t:1526930023775};\\\", \\\"{x:1624,y:580,t:1526930023791};\\\", \\\"{x:1623,y:582,t:1526930023808};\\\", \\\"{x:1623,y:584,t:1526930023824};\\\", \\\"{x:1622,y:586,t:1526930023842};\\\", \\\"{x:1621,y:589,t:1526930023857};\\\", \\\"{x:1621,y:591,t:1526930023874};\\\", \\\"{x:1621,y:592,t:1526930023892};\\\", \\\"{x:1621,y:595,t:1526930023908};\\\", \\\"{x:1621,y:598,t:1526930023924};\\\", \\\"{x:1620,y:601,t:1526930023941};\\\", \\\"{x:1620,y:602,t:1526930023958};\\\", \\\"{x:1620,y:605,t:1526930023974};\\\", \\\"{x:1620,y:609,t:1526930023992};\\\", \\\"{x:1620,y:614,t:1526930024008};\\\", \\\"{x:1620,y:621,t:1526930024025};\\\", \\\"{x:1619,y:628,t:1526930024041};\\\", \\\"{x:1619,y:636,t:1526930024058};\\\", \\\"{x:1619,y:647,t:1526930024074};\\\", \\\"{x:1618,y:660,t:1526930024092};\\\", \\\"{x:1616,y:677,t:1526930024108};\\\", \\\"{x:1616,y:689,t:1526930024125};\\\", \\\"{x:1616,y:697,t:1526930024142};\\\", \\\"{x:1616,y:703,t:1526930024158};\\\", \\\"{x:1616,y:708,t:1526930024175};\\\", \\\"{x:1616,y:712,t:1526930024191};\\\", \\\"{x:1616,y:715,t:1526930024209};\\\", \\\"{x:1616,y:720,t:1526930024225};\\\", \\\"{x:1617,y:722,t:1526930024242};\\\", \\\"{x:1618,y:724,t:1526930024258};\\\", \\\"{x:1618,y:727,t:1526930024276};\\\", \\\"{x:1618,y:730,t:1526930024292};\\\", \\\"{x:1618,y:732,t:1526930024308};\\\", \\\"{x:1618,y:733,t:1526930024325};\\\", \\\"{x:1618,y:735,t:1526930024348};\\\", \\\"{x:1618,y:736,t:1526930024358};\\\", \\\"{x:1618,y:738,t:1526930024375};\\\", \\\"{x:1617,y:741,t:1526930024392};\\\", \\\"{x:1617,y:744,t:1526930024409};\\\", \\\"{x:1617,y:746,t:1526930024426};\\\", \\\"{x:1617,y:750,t:1526930024442};\\\", \\\"{x:1617,y:756,t:1526930024459};\\\", \\\"{x:1616,y:761,t:1526930024475};\\\", \\\"{x:1614,y:770,t:1526930024492};\\\", \\\"{x:1614,y:778,t:1526930024509};\\\", \\\"{x:1614,y:783,t:1526930024525};\\\", \\\"{x:1612,y:788,t:1526930024543};\\\", \\\"{x:1612,y:792,t:1526930024559};\\\", \\\"{x:1611,y:796,t:1526930024577};\\\", \\\"{x:1611,y:799,t:1526930024592};\\\", \\\"{x:1611,y:803,t:1526930024610};\\\", \\\"{x:1611,y:807,t:1526930024626};\\\", \\\"{x:1610,y:811,t:1526930024643};\\\", \\\"{x:1610,y:814,t:1526930024660};\\\", \\\"{x:1610,y:817,t:1526930024676};\\\", \\\"{x:1610,y:820,t:1526930024692};\\\", \\\"{x:1610,y:823,t:1526930024710};\\\", \\\"{x:1610,y:826,t:1526930024727};\\\", \\\"{x:1610,y:830,t:1526930024744};\\\", \\\"{x:1608,y:832,t:1526930024760};\\\", \\\"{x:1608,y:835,t:1526930024777};\\\", \\\"{x:1608,y:837,t:1526930024794};\\\", \\\"{x:1608,y:840,t:1526930024810};\\\", \\\"{x:1608,y:842,t:1526930024827};\\\", \\\"{x:1608,y:844,t:1526930024844};\\\", \\\"{x:1608,y:847,t:1526930024860};\\\", \\\"{x:1608,y:852,t:1526930024876};\\\", \\\"{x:1608,y:856,t:1526930024894};\\\", \\\"{x:1608,y:860,t:1526930024911};\\\", \\\"{x:1608,y:863,t:1526930024927};\\\", \\\"{x:1608,y:867,t:1526930024944};\\\", \\\"{x:1608,y:870,t:1526930024961};\\\", \\\"{x:1608,y:874,t:1526930024977};\\\", \\\"{x:1608,y:878,t:1526930024994};\\\", \\\"{x:1608,y:880,t:1526930025011};\\\", \\\"{x:1609,y:882,t:1526930025027};\\\", \\\"{x:1609,y:885,t:1526930025043};\\\", \\\"{x:1609,y:890,t:1526930025060};\\\", \\\"{x:1611,y:897,t:1526930025078};\\\", \\\"{x:1612,y:901,t:1526930025094};\\\", \\\"{x:1613,y:906,t:1526930025110};\\\", \\\"{x:1613,y:909,t:1526930025127};\\\", \\\"{x:1613,y:911,t:1526930025143};\\\", \\\"{x:1614,y:913,t:1526930025160};\\\", \\\"{x:1614,y:914,t:1526930025180};\\\", \\\"{x:1614,y:915,t:1526930025194};\\\", \\\"{x:1615,y:918,t:1526930025210};\\\", \\\"{x:1616,y:921,t:1526930025227};\\\", \\\"{x:1617,y:927,t:1526930025244};\\\", \\\"{x:1618,y:928,t:1526930025260};\\\", \\\"{x:1618,y:921,t:1526930025372};\\\", \\\"{x:1616,y:911,t:1526930025380};\\\", \\\"{x:1612,y:899,t:1526930025394};\\\", \\\"{x:1599,y:870,t:1526930025411};\\\", \\\"{x:1592,y:843,t:1526930025427};\\\", \\\"{x:1585,y:804,t:1526930025444};\\\", \\\"{x:1582,y:775,t:1526930025461};\\\", \\\"{x:1582,y:742,t:1526930025478};\\\", \\\"{x:1582,y:713,t:1526930025494};\\\", \\\"{x:1582,y:690,t:1526930025511};\\\", \\\"{x:1582,y:671,t:1526930025528};\\\", \\\"{x:1582,y:662,t:1526930025544};\\\", \\\"{x:1582,y:648,t:1526930025561};\\\", \\\"{x:1582,y:637,t:1526930025578};\\\", \\\"{x:1582,y:628,t:1526930025594};\\\", \\\"{x:1582,y:621,t:1526930025611};\\\", \\\"{x:1582,y:612,t:1526930025628};\\\", \\\"{x:1582,y:607,t:1526930025645};\\\", \\\"{x:1584,y:602,t:1526930025661};\\\", \\\"{x:1586,y:597,t:1526930025679};\\\", \\\"{x:1587,y:595,t:1526930025695};\\\", \\\"{x:1589,y:593,t:1526930025711};\\\", \\\"{x:1591,y:591,t:1526930025729};\\\", \\\"{x:1593,y:588,t:1526930025745};\\\", \\\"{x:1596,y:585,t:1526930025761};\\\", \\\"{x:1597,y:584,t:1526930025778};\\\", \\\"{x:1599,y:582,t:1526930025795};\\\", \\\"{x:1600,y:581,t:1526930025812};\\\", \\\"{x:1602,y:580,t:1526930025828};\\\", \\\"{x:1604,y:578,t:1526930025845};\\\", \\\"{x:1605,y:577,t:1526930025863};\\\", \\\"{x:1607,y:575,t:1526930025878};\\\", \\\"{x:1608,y:574,t:1526930025895};\\\", \\\"{x:1608,y:573,t:1526930025912};\\\", \\\"{x:1608,y:572,t:1526930025981};\\\", \\\"{x:1608,y:571,t:1526930026021};\\\", \\\"{x:1608,y:570,t:1526930026029};\\\", \\\"{x:1608,y:569,t:1526930026045};\\\", \\\"{x:1608,y:568,t:1526930026062};\\\", \\\"{x:1608,y:567,t:1526930026085};\\\", \\\"{x:1609,y:566,t:1526930026100};\\\", \\\"{x:1609,y:565,t:1526930026125};\\\", \\\"{x:1609,y:563,t:1526930026146};\\\", \\\"{x:1609,y:562,t:1526930026162};\\\", \\\"{x:1609,y:560,t:1526930026180};\\\", \\\"{x:1610,y:558,t:1526930026196};\\\", \\\"{x:1611,y:557,t:1526930026212};\\\", \\\"{x:1611,y:558,t:1526930026796};\\\", \\\"{x:1611,y:560,t:1526930026852};\\\", \\\"{x:1610,y:561,t:1526930026881};\\\", \\\"{x:1609,y:561,t:1526930027260};\\\", \\\"{x:1608,y:561,t:1526930027301};\\\", \\\"{x:1606,y:561,t:1526930027315};\\\", \\\"{x:1604,y:561,t:1526930027339};\\\", \\\"{x:1603,y:560,t:1526930027356};\\\", \\\"{x:1602,y:560,t:1526930027365};\\\", \\\"{x:1601,y:559,t:1526930027382};\\\", \\\"{x:1600,y:559,t:1526930027398};\\\", \\\"{x:1599,y:559,t:1526930027415};\\\", \\\"{x:1598,y:558,t:1526930027433};\\\", \\\"{x:1597,y:558,t:1526930027452};\\\", \\\"{x:1596,y:557,t:1526930027468};\\\", \\\"{x:1595,y:557,t:1526930027556};\\\", \\\"{x:1593,y:557,t:1526930027565};\\\", \\\"{x:1592,y:557,t:1526930027614};\\\", \\\"{x:1590,y:558,t:1526930027620};\\\", \\\"{x:1588,y:558,t:1526930027637};\\\", \\\"{x:1587,y:559,t:1526930027650};\\\", \\\"{x:1583,y:559,t:1526930027667};\\\", \\\"{x:1580,y:561,t:1526930027683};\\\", \\\"{x:1577,y:562,t:1526930027700};\\\", \\\"{x:1569,y:564,t:1526930027716};\\\", \\\"{x:1564,y:565,t:1526930027733};\\\", \\\"{x:1560,y:565,t:1526930027750};\\\", \\\"{x:1558,y:566,t:1526930027767};\\\", \\\"{x:1557,y:566,t:1526930027784};\\\", \\\"{x:1555,y:567,t:1526930027799};\\\", \\\"{x:1554,y:567,t:1526930027817};\\\", \\\"{x:1548,y:568,t:1526930027834};\\\", \\\"{x:1546,y:568,t:1526930027850};\\\", \\\"{x:1544,y:568,t:1526930027867};\\\", \\\"{x:1542,y:568,t:1526930027884};\\\", \\\"{x:1541,y:568,t:1526930027900};\\\", \\\"{x:1539,y:568,t:1526930027917};\\\", \\\"{x:1538,y:568,t:1526930027965};\\\", \\\"{x:1537,y:567,t:1526930028117};\\\", \\\"{x:1537,y:566,t:1526930028149};\\\", \\\"{x:1536,y:565,t:1526930028173};\\\", \\\"{x:1536,y:564,t:1526930028213};\\\", \\\"{x:1536,y:563,t:1526930028245};\\\", \\\"{x:1535,y:562,t:1526930028278};\\\", \\\"{x:1535,y:561,t:1526930028348};\\\", \\\"{x:1534,y:561,t:1526930028428};\\\", \\\"{x:1533,y:559,t:1526930028516};\\\", \\\"{x:1532,y:559,t:1526930028572};\\\", \\\"{x:1532,y:558,t:1526930028587};\\\", \\\"{x:1532,y:557,t:1526930028852};\\\", \\\"{x:1531,y:555,t:1526930028868};\\\", \\\"{x:1530,y:555,t:1526930028886};\\\", \\\"{x:1530,y:554,t:1526930028964};\\\", \\\"{x:1530,y:553,t:1526930029012};\\\", \\\"{x:1528,y:551,t:1526930031445};\\\", \\\"{x:1523,y:547,t:1526930031458};\\\", \\\"{x:1506,y:536,t:1526930031475};\\\", \\\"{x:1489,y:530,t:1526930031491};\\\", \\\"{x:1469,y:521,t:1526930031507};\\\", \\\"{x:1449,y:514,t:1526930031525};\\\", \\\"{x:1443,y:510,t:1526930031541};\\\", \\\"{x:1440,y:509,t:1526930031558};\\\", \\\"{x:1440,y:508,t:1526930031574};\\\", \\\"{x:1437,y:507,t:1526930031592};\\\", \\\"{x:1432,y:503,t:1526930031608};\\\", \\\"{x:1428,y:501,t:1526930031624};\\\", \\\"{x:1426,y:500,t:1526930031641};\\\", \\\"{x:1425,y:500,t:1526930031660};\\\", \\\"{x:1424,y:500,t:1526930031674};\\\", \\\"{x:1422,y:500,t:1526930031691};\\\", \\\"{x:1413,y:500,t:1526930031708};\\\", \\\"{x:1406,y:500,t:1526930031725};\\\", \\\"{x:1394,y:500,t:1526930031741};\\\", \\\"{x:1377,y:500,t:1526930031759};\\\", \\\"{x:1363,y:500,t:1526930031775};\\\", \\\"{x:1352,y:500,t:1526930031791};\\\", \\\"{x:1347,y:500,t:1526930031808};\\\", \\\"{x:1346,y:500,t:1526930031876};\\\", \\\"{x:1346,y:498,t:1526930031932};\\\", \\\"{x:1346,y:497,t:1526930031943};\\\", \\\"{x:1351,y:494,t:1526930031959};\\\", \\\"{x:1363,y:491,t:1526930031976};\\\", \\\"{x:1381,y:489,t:1526930031993};\\\", \\\"{x:1400,y:487,t:1526930032009};\\\", \\\"{x:1417,y:486,t:1526930032026};\\\", \\\"{x:1432,y:486,t:1526930032043};\\\", \\\"{x:1445,y:486,t:1526930032059};\\\", \\\"{x:1455,y:488,t:1526930032076};\\\", \\\"{x:1465,y:489,t:1526930032092};\\\", \\\"{x:1471,y:490,t:1526930032109};\\\", \\\"{x:1476,y:490,t:1526930032126};\\\", \\\"{x:1479,y:492,t:1526930032142};\\\", \\\"{x:1482,y:492,t:1526930032159};\\\", \\\"{x:1483,y:492,t:1526930032220};\\\", \\\"{x:1483,y:493,t:1526930032228};\\\", \\\"{x:1483,y:494,t:1526930032243};\\\", \\\"{x:1483,y:496,t:1526930032260};\\\", \\\"{x:1483,y:499,t:1526930032277};\\\", \\\"{x:1484,y:499,t:1526930032332};\\\", \\\"{x:1485,y:499,t:1526930032343};\\\", \\\"{x:1489,y:499,t:1526930032360};\\\", \\\"{x:1498,y:499,t:1526930032376};\\\", \\\"{x:1506,y:499,t:1526930032393};\\\", \\\"{x:1515,y:499,t:1526930032409};\\\", \\\"{x:1523,y:499,t:1526930032426};\\\", \\\"{x:1526,y:499,t:1526930032443};\\\", \\\"{x:1531,y:499,t:1526930032460};\\\", \\\"{x:1532,y:499,t:1526930032493};\\\", \\\"{x:1533,y:499,t:1526930032501};\\\", \\\"{x:1534,y:499,t:1526930032511};\\\", \\\"{x:1536,y:499,t:1526930032527};\\\", \\\"{x:1539,y:498,t:1526930032543};\\\", \\\"{x:1537,y:498,t:1526930032622};\\\", \\\"{x:1530,y:498,t:1526930032628};\\\", \\\"{x:1520,y:499,t:1526930032644};\\\", \\\"{x:1472,y:499,t:1526930032660};\\\", \\\"{x:1425,y:499,t:1526930032678};\\\", \\\"{x:1387,y:499,t:1526930032694};\\\", \\\"{x:1362,y:499,t:1526930032710};\\\", \\\"{x:1352,y:499,t:1526930032728};\\\", \\\"{x:1350,y:499,t:1526930032743};\\\", \\\"{x:1349,y:500,t:1526930032926};\\\", \\\"{x:1349,y:501,t:1526930032933};\\\", \\\"{x:1349,y:502,t:1526930032945};\\\", \\\"{x:1345,y:504,t:1526930032962};\\\", \\\"{x:1339,y:506,t:1526930032978};\\\", \\\"{x:1334,y:507,t:1526930032995};\\\", \\\"{x:1329,y:507,t:1526930033012};\\\", \\\"{x:1324,y:507,t:1526930033028};\\\", \\\"{x:1316,y:507,t:1526930033045};\\\", \\\"{x:1313,y:507,t:1526930033062};\\\", \\\"{x:1312,y:507,t:1526930033079};\\\", \\\"{x:1310,y:507,t:1526930033140};\\\", \\\"{x:1309,y:507,t:1526930033180};\\\", \\\"{x:1309,y:509,t:1526930033301};\\\", \\\"{x:1309,y:514,t:1526930033312};\\\", \\\"{x:1311,y:522,t:1526930033329};\\\", \\\"{x:1315,y:534,t:1526930033345};\\\", \\\"{x:1317,y:547,t:1526930033362};\\\", \\\"{x:1320,y:561,t:1526930033378};\\\", \\\"{x:1322,y:574,t:1526930033395};\\\", \\\"{x:1324,y:597,t:1526930033412};\\\", \\\"{x:1324,y:615,t:1526930033429};\\\", \\\"{x:1324,y:633,t:1526930033445};\\\", \\\"{x:1324,y:648,t:1526930033463};\\\", \\\"{x:1324,y:659,t:1526930033479};\\\", \\\"{x:1324,y:666,t:1526930033496};\\\", \\\"{x:1324,y:676,t:1526930033512};\\\", \\\"{x:1324,y:683,t:1526930033530};\\\", \\\"{x:1324,y:690,t:1526930033546};\\\", \\\"{x:1324,y:701,t:1526930033562};\\\", \\\"{x:1324,y:714,t:1526930033579};\\\", \\\"{x:1324,y:725,t:1526930033596};\\\", \\\"{x:1325,y:739,t:1526930033613};\\\", \\\"{x:1327,y:745,t:1526930033630};\\\", \\\"{x:1327,y:748,t:1526930033645};\\\", \\\"{x:1327,y:753,t:1526930033663};\\\", \\\"{x:1327,y:757,t:1526930033679};\\\", \\\"{x:1327,y:759,t:1526930033696};\\\", \\\"{x:1327,y:760,t:1526930033713};\\\", \\\"{x:1327,y:762,t:1526930033729};\\\", \\\"{x:1325,y:765,t:1526930033746};\\\", \\\"{x:1325,y:768,t:1526930033762};\\\", \\\"{x:1325,y:770,t:1526930033780};\\\", \\\"{x:1324,y:775,t:1526930033796};\\\", \\\"{x:1324,y:779,t:1526930033812};\\\", \\\"{x:1321,y:784,t:1526930033830};\\\", \\\"{x:1319,y:788,t:1526930033847};\\\", \\\"{x:1318,y:794,t:1526930033863};\\\", \\\"{x:1317,y:799,t:1526930033880};\\\", \\\"{x:1315,y:804,t:1526930033896};\\\", \\\"{x:1314,y:808,t:1526930033914};\\\", \\\"{x:1311,y:816,t:1526930033929};\\\", \\\"{x:1309,y:824,t:1526930033946};\\\", \\\"{x:1308,y:831,t:1526930033963};\\\", \\\"{x:1307,y:841,t:1526930033980};\\\", \\\"{x:1305,y:847,t:1526930033997};\\\", \\\"{x:1305,y:851,t:1526930034013};\\\", \\\"{x:1305,y:856,t:1526930034031};\\\", \\\"{x:1305,y:859,t:1526930034047};\\\", \\\"{x:1304,y:863,t:1526930034064};\\\", \\\"{x:1304,y:866,t:1526930034081};\\\", \\\"{x:1304,y:869,t:1526930034098};\\\", \\\"{x:1304,y:872,t:1526930034114};\\\", \\\"{x:1304,y:876,t:1526930034131};\\\", \\\"{x:1304,y:879,t:1526930034147};\\\", \\\"{x:1305,y:882,t:1526930034164};\\\", \\\"{x:1306,y:886,t:1526930034181};\\\", \\\"{x:1307,y:891,t:1526930034197};\\\", \\\"{x:1308,y:896,t:1526930034214};\\\", \\\"{x:1309,y:902,t:1526930034231};\\\", \\\"{x:1309,y:912,t:1526930034247};\\\", \\\"{x:1309,y:921,t:1526930034263};\\\", \\\"{x:1309,y:927,t:1526930034280};\\\", \\\"{x:1309,y:934,t:1526930034297};\\\", \\\"{x:1309,y:939,t:1526930034315};\\\", \\\"{x:1310,y:949,t:1526930034331};\\\", \\\"{x:1312,y:954,t:1526930034347};\\\", \\\"{x:1313,y:957,t:1526930034364};\\\", \\\"{x:1313,y:958,t:1526930034380};\\\", \\\"{x:1314,y:960,t:1526930034397};\\\", \\\"{x:1314,y:961,t:1526930034564};\\\", \\\"{x:1315,y:961,t:1526930034669};\\\", \\\"{x:1315,y:962,t:1526930034884};\\\", \\\"{x:1315,y:963,t:1526930034940};\\\", \\\"{x:1315,y:964,t:1526930034971};\\\", \\\"{x:1315,y:966,t:1526930037140};\\\", \\\"{x:1314,y:968,t:1526930037156};\\\", \\\"{x:1314,y:969,t:1526930037172};\\\", \\\"{x:1313,y:969,t:1526930037188};\\\", \\\"{x:1313,y:970,t:1526930037204};\\\", \\\"{x:1313,y:971,t:1526930037220};\\\", \\\"{x:1311,y:971,t:1526930037596};\\\", \\\"{x:1311,y:970,t:1526930037620};\\\", \\\"{x:1310,y:969,t:1526930037636};\\\", \\\"{x:1310,y:968,t:1526930037652};\\\", \\\"{x:1310,y:967,t:1526930037716};\\\", \\\"{x:1310,y:965,t:1526930037764};\\\", \\\"{x:1310,y:964,t:1526930037869};\\\", \\\"{x:1310,y:962,t:1526930037949};\\\", \\\"{x:1309,y:961,t:1526930037964};\\\", \\\"{x:1309,y:959,t:1526930038021};\\\", \\\"{x:1309,y:958,t:1526930038044};\\\", \\\"{x:1309,y:956,t:1526930038056};\\\", \\\"{x:1309,y:954,t:1526930038074};\\\", \\\"{x:1308,y:951,t:1526930038090};\\\", \\\"{x:1308,y:945,t:1526930038107};\\\", \\\"{x:1308,y:940,t:1526930038123};\\\", \\\"{x:1306,y:928,t:1526930038141};\\\", \\\"{x:1305,y:916,t:1526930038156};\\\", \\\"{x:1303,y:892,t:1526930038174};\\\", \\\"{x:1301,y:874,t:1526930038191};\\\", \\\"{x:1301,y:855,t:1526930038207};\\\", \\\"{x:1301,y:837,t:1526930038223};\\\", \\\"{x:1301,y:821,t:1526930038241};\\\", \\\"{x:1301,y:807,t:1526930038257};\\\", \\\"{x:1301,y:788,t:1526930038273};\\\", \\\"{x:1301,y:770,t:1526930038290};\\\", \\\"{x:1302,y:754,t:1526930038307};\\\", \\\"{x:1303,y:741,t:1526930038323};\\\", \\\"{x:1303,y:731,t:1526930038341};\\\", \\\"{x:1305,y:715,t:1526930038357};\\\", \\\"{x:1305,y:704,t:1526930038373};\\\", \\\"{x:1305,y:691,t:1526930038390};\\\", \\\"{x:1306,y:677,t:1526930038407};\\\", \\\"{x:1307,y:664,t:1526930038424};\\\", \\\"{x:1310,y:648,t:1526930038440};\\\", \\\"{x:1311,y:629,t:1526930038458};\\\", \\\"{x:1311,y:607,t:1526930038476};\\\", \\\"{x:1311,y:590,t:1526930038490};\\\", \\\"{x:1311,y:571,t:1526930038507};\\\", \\\"{x:1314,y:535,t:1526930038524};\\\", \\\"{x:1314,y:513,t:1526930038541};\\\", \\\"{x:1314,y:494,t:1526930038557};\\\", \\\"{x:1314,y:479,t:1526930038575};\\\", \\\"{x:1314,y:463,t:1526930038592};\\\", \\\"{x:1314,y:444,t:1526930038607};\\\", \\\"{x:1314,y:437,t:1526930038624};\\\", \\\"{x:1315,y:433,t:1526930038641};\\\", \\\"{x:1315,y:432,t:1526930038658};\\\", \\\"{x:1315,y:431,t:1526930038675};\\\", \\\"{x:1315,y:433,t:1526930038861};\\\", \\\"{x:1315,y:437,t:1526930038875};\\\", \\\"{x:1315,y:445,t:1526930038891};\\\", \\\"{x:1315,y:461,t:1526930038908};\\\", \\\"{x:1315,y:468,t:1526930038924};\\\", \\\"{x:1315,y:472,t:1526930038941};\\\", \\\"{x:1316,y:475,t:1526930038958};\\\", \\\"{x:1317,y:478,t:1526930038975};\\\", \\\"{x:1317,y:481,t:1526930038991};\\\", \\\"{x:1320,y:485,t:1526930039008};\\\", \\\"{x:1320,y:487,t:1526930039025};\\\", \\\"{x:1322,y:489,t:1526930039042};\\\", \\\"{x:1322,y:490,t:1526930039060};\\\", \\\"{x:1323,y:491,t:1526930039076};\\\", \\\"{x:1323,y:492,t:1526930039124};\\\", \\\"{x:1323,y:493,t:1526930039148};\\\", \\\"{x:1323,y:494,t:1526930039205};\\\", \\\"{x:1323,y:495,t:1526930039237};\\\", \\\"{x:1322,y:495,t:1526930039245};\\\", \\\"{x:1321,y:496,t:1526930039293};\\\", \\\"{x:1320,y:496,t:1526930039444};\\\", \\\"{x:1319,y:496,t:1526930039509};\\\", \\\"{x:1318,y:496,t:1526930039548};\\\", \\\"{x:1317,y:496,t:1526930039564};\\\", \\\"{x:1316,y:496,t:1526930039629};\\\", \\\"{x:1315,y:496,t:1526930039669};\\\", \\\"{x:1314,y:495,t:1526930039709};\\\", \\\"{x:1315,y:495,t:1526930048397};\\\", \\\"{x:1317,y:495,t:1526930048413};\\\", \\\"{x:1319,y:495,t:1526930048430};\\\", \\\"{x:1320,y:495,t:1526930048460};\\\", \\\"{x:1321,y:495,t:1526930048470};\\\", \\\"{x:1322,y:495,t:1526930048480};\\\", \\\"{x:1325,y:495,t:1526930048497};\\\", \\\"{x:1329,y:495,t:1526930048513};\\\", \\\"{x:1331,y:495,t:1526930048530};\\\", \\\"{x:1333,y:495,t:1526930048547};\\\", \\\"{x:1335,y:495,t:1526930048563};\\\", \\\"{x:1339,y:495,t:1526930048580};\\\", \\\"{x:1352,y:495,t:1526930048596};\\\", \\\"{x:1356,y:495,t:1526930048614};\\\", \\\"{x:1359,y:494,t:1526930048629};\\\", \\\"{x:1361,y:494,t:1526930048647};\\\", \\\"{x:1363,y:494,t:1526930048663};\\\", \\\"{x:1365,y:494,t:1526930048684};\\\", \\\"{x:1367,y:492,t:1526930048697};\\\", \\\"{x:1373,y:492,t:1526930048713};\\\", \\\"{x:1375,y:492,t:1526930048731};\\\", \\\"{x:1376,y:492,t:1526930048746};\\\", \\\"{x:1377,y:492,t:1526930048764};\\\", \\\"{x:1379,y:492,t:1526930048781};\\\", \\\"{x:1380,y:492,t:1526930049237};\\\", \\\"{x:1381,y:492,t:1526930049247};\\\", \\\"{x:1382,y:493,t:1526930049284};\\\", \\\"{x:1384,y:495,t:1526930049317};\\\", \\\"{x:1386,y:495,t:1526930049332};\\\", \\\"{x:1387,y:496,t:1526930049348};\\\", \\\"{x:1388,y:496,t:1526930049364};\\\", \\\"{x:1389,y:497,t:1526930049382};\\\", \\\"{x:1392,y:498,t:1526930049399};\\\", \\\"{x:1393,y:499,t:1526930049414};\\\", \\\"{x:1399,y:499,t:1526930049432};\\\", \\\"{x:1406,y:502,t:1526930049449};\\\", \\\"{x:1412,y:503,t:1526930049466};\\\", \\\"{x:1420,y:506,t:1526930049482};\\\", \\\"{x:1425,y:506,t:1526930049498};\\\", \\\"{x:1428,y:506,t:1526930049516};\\\", \\\"{x:1431,y:506,t:1526930049532};\\\", \\\"{x:1435,y:506,t:1526930049548};\\\", \\\"{x:1438,y:506,t:1526930049566};\\\", \\\"{x:1441,y:506,t:1526930049582};\\\", \\\"{x:1443,y:506,t:1526930049599};\\\", \\\"{x:1445,y:506,t:1526930049616};\\\", \\\"{x:1445,y:505,t:1526930049637};\\\", \\\"{x:1447,y:505,t:1526930049649};\\\", \\\"{x:1447,y:504,t:1526930049669};\\\", \\\"{x:1447,y:503,t:1526930049700};\\\", \\\"{x:1447,y:502,t:1526930049717};\\\", \\\"{x:1447,y:500,t:1526930049749};\\\", \\\"{x:1446,y:499,t:1526930049773};\\\", \\\"{x:1444,y:497,t:1526930049797};\\\", \\\"{x:1443,y:496,t:1526930049845};\\\", \\\"{x:1443,y:497,t:1526930049997};\\\", \\\"{x:1443,y:498,t:1526930050005};\\\", \\\"{x:1444,y:500,t:1526930050016};\\\", \\\"{x:1445,y:501,t:1526930050033};\\\", \\\"{x:1447,y:504,t:1526930050050};\\\", \\\"{x:1448,y:505,t:1526930050066};\\\", \\\"{x:1450,y:506,t:1526930050084};\\\", \\\"{x:1451,y:506,t:1526930050100};\\\", \\\"{x:1454,y:507,t:1526930050117};\\\", \\\"{x:1457,y:507,t:1526930050134};\\\", \\\"{x:1461,y:508,t:1526930050149};\\\", \\\"{x:1464,y:510,t:1526930050166};\\\", \\\"{x:1467,y:510,t:1526930050184};\\\", \\\"{x:1468,y:510,t:1526930050199};\\\", \\\"{x:1470,y:510,t:1526930050228};\\\", \\\"{x:1472,y:510,t:1526930050237};\\\", \\\"{x:1474,y:510,t:1526930050251};\\\", \\\"{x:1481,y:510,t:1526930050267};\\\", \\\"{x:1487,y:511,t:1526930050284};\\\", \\\"{x:1497,y:511,t:1526930050300};\\\", \\\"{x:1498,y:511,t:1526930050316};\\\", \\\"{x:1499,y:511,t:1526930050334};\\\", \\\"{x:1500,y:511,t:1526930050372};\\\", \\\"{x:1500,y:510,t:1526930050388};\\\", \\\"{x:1502,y:510,t:1526930050403};\\\", \\\"{x:1503,y:509,t:1526930050428};\\\", \\\"{x:1503,y:508,t:1526930050444};\\\", \\\"{x:1504,y:508,t:1526930050460};\\\", \\\"{x:1504,y:507,t:1526930050492};\\\", \\\"{x:1505,y:505,t:1526930050507};\\\", \\\"{x:1505,y:504,t:1526930050532};\\\", \\\"{x:1505,y:502,t:1526930050564};\\\", \\\"{x:1507,y:501,t:1526930050613};\\\", \\\"{x:1507,y:500,t:1526930050628};\\\", \\\"{x:1508,y:499,t:1526930050652};\\\", \\\"{x:1508,y:498,t:1526930050676};\\\", \\\"{x:1509,y:497,t:1526930050749};\\\", \\\"{x:1510,y:496,t:1526930050772};\\\", \\\"{x:1511,y:496,t:1526930050797};\\\", \\\"{x:1512,y:495,t:1526930051109};\\\", \\\"{x:1513,y:495,t:1526930051469};\\\", \\\"{x:1513,y:496,t:1526930051605};\\\", \\\"{x:1513,y:497,t:1526930051757};\\\", \\\"{x:1513,y:498,t:1526930051949};\\\", \\\"{x:1515,y:498,t:1526930051965};\\\", \\\"{x:1517,y:498,t:1526930051973};\\\", \\\"{x:1520,y:498,t:1526930051988};\\\", \\\"{x:1523,y:499,t:1526930052004};\\\", \\\"{x:1526,y:500,t:1526930052020};\\\", \\\"{x:1527,y:500,t:1526930052052};\\\", \\\"{x:1528,y:500,t:1526930052084};\\\", \\\"{x:1529,y:500,t:1526930052093};\\\", \\\"{x:1530,y:500,t:1526930052104};\\\", \\\"{x:1531,y:500,t:1526930052121};\\\", \\\"{x:1534,y:500,t:1526930052137};\\\", \\\"{x:1535,y:500,t:1526930052203};\\\", \\\"{x:1537,y:500,t:1526930052222};\\\", \\\"{x:1539,y:500,t:1526930052237};\\\", \\\"{x:1540,y:500,t:1526930052254};\\\", \\\"{x:1542,y:500,t:1526930052271};\\\", \\\"{x:1543,y:500,t:1526930052287};\\\", \\\"{x:1543,y:499,t:1526930052484};\\\", \\\"{x:1543,y:498,t:1526930052604};\\\", \\\"{x:1543,y:497,t:1526930052636};\\\", \\\"{x:1544,y:497,t:1526930053013};\\\", \\\"{x:1544,y:498,t:1526930053029};\\\", \\\"{x:1544,y:499,t:1526930053052};\\\", \\\"{x:1544,y:500,t:1526930053060};\\\", \\\"{x:1544,y:501,t:1526930053073};\\\", \\\"{x:1544,y:502,t:1526930053090};\\\", \\\"{x:1544,y:504,t:1526930053107};\\\", \\\"{x:1544,y:505,t:1526930053124};\\\", \\\"{x:1544,y:506,t:1526930053140};\\\", \\\"{x:1544,y:507,t:1526930053156};\\\", \\\"{x:1544,y:508,t:1526930053173};\\\", \\\"{x:1544,y:510,t:1526930053190};\\\", \\\"{x:1544,y:511,t:1526930053211};\\\", \\\"{x:1544,y:513,t:1526930053236};\\\", \\\"{x:1544,y:514,t:1526930053244};\\\", \\\"{x:1544,y:515,t:1526930053268};\\\", \\\"{x:1544,y:516,t:1526930053275};\\\", \\\"{x:1544,y:517,t:1526930053290};\\\", \\\"{x:1544,y:518,t:1526930053306};\\\", \\\"{x:1544,y:520,t:1526930053323};\\\", \\\"{x:1544,y:521,t:1526930053339};\\\", \\\"{x:1544,y:523,t:1526930053357};\\\", \\\"{x:1544,y:525,t:1526930053374};\\\", \\\"{x:1544,y:526,t:1526930053390};\\\", \\\"{x:1544,y:527,t:1526930053407};\\\", \\\"{x:1544,y:529,t:1526930053423};\\\", \\\"{x:1544,y:530,t:1526930053440};\\\", \\\"{x:1544,y:532,t:1526930053457};\\\", \\\"{x:1544,y:534,t:1526930053474};\\\", \\\"{x:1544,y:535,t:1526930053492};\\\", \\\"{x:1544,y:537,t:1526930053516};\\\", \\\"{x:1544,y:538,t:1526930053540};\\\", \\\"{x:1544,y:540,t:1526930053548};\\\", \\\"{x:1545,y:542,t:1526930053571};\\\", \\\"{x:1545,y:543,t:1526930053595};\\\", \\\"{x:1545,y:544,t:1526930053611};\\\", \\\"{x:1545,y:546,t:1526930053627};\\\", \\\"{x:1545,y:547,t:1526930053643};\\\", \\\"{x:1545,y:548,t:1526930053668};\\\", \\\"{x:1545,y:549,t:1526930053683};\\\", \\\"{x:1545,y:550,t:1526930053692};\\\", \\\"{x:1545,y:551,t:1526930053707};\\\", \\\"{x:1545,y:552,t:1526930053725};\\\", \\\"{x:1546,y:553,t:1526930053741};\\\", \\\"{x:1546,y:554,t:1526930053764};\\\", \\\"{x:1546,y:555,t:1526930053774};\\\", \\\"{x:1546,y:556,t:1526930053792};\\\", \\\"{x:1546,y:557,t:1526930053812};\\\", \\\"{x:1546,y:558,t:1526930053824};\\\", \\\"{x:1546,y:559,t:1526930053841};\\\", \\\"{x:1546,y:561,t:1526930053858};\\\", \\\"{x:1546,y:562,t:1526930053875};\\\", \\\"{x:1546,y:564,t:1526930053892};\\\", \\\"{x:1546,y:567,t:1526930053908};\\\", \\\"{x:1546,y:568,t:1526930053939};\\\", \\\"{x:1546,y:569,t:1526930053947};\\\", \\\"{x:1546,y:570,t:1526930053971};\\\", \\\"{x:1546,y:571,t:1526930053979};\\\", \\\"{x:1546,y:572,t:1526930053992};\\\", \\\"{x:1546,y:573,t:1526930054008};\\\", \\\"{x:1546,y:575,t:1526930054026};\\\", \\\"{x:1546,y:578,t:1526930054042};\\\", \\\"{x:1546,y:580,t:1526930054060};\\\", \\\"{x:1546,y:581,t:1526930054075};\\\", \\\"{x:1546,y:583,t:1526930054091};\\\", \\\"{x:1545,y:584,t:1526930054109};\\\", \\\"{x:1545,y:585,t:1526930054125};\\\", \\\"{x:1545,y:586,t:1526930054142};\\\", \\\"{x:1545,y:588,t:1526930054159};\\\", \\\"{x:1545,y:590,t:1526930054176};\\\", \\\"{x:1545,y:592,t:1526930054192};\\\", \\\"{x:1545,y:594,t:1526930054208};\\\", \\\"{x:1545,y:596,t:1526930054226};\\\", \\\"{x:1544,y:599,t:1526930054243};\\\", \\\"{x:1544,y:601,t:1526930054259};\\\", \\\"{x:1543,y:603,t:1526930054276};\\\", \\\"{x:1543,y:605,t:1526930054293};\\\", \\\"{x:1542,y:606,t:1526930054310};\\\", \\\"{x:1542,y:608,t:1526930054326};\\\", \\\"{x:1542,y:609,t:1526930054343};\\\", \\\"{x:1542,y:610,t:1526930054360};\\\", \\\"{x:1542,y:612,t:1526930054376};\\\", \\\"{x:1542,y:614,t:1526930054393};\\\", \\\"{x:1542,y:616,t:1526930054410};\\\", \\\"{x:1542,y:619,t:1526930054425};\\\", \\\"{x:1542,y:621,t:1526930054442};\\\", \\\"{x:1543,y:622,t:1526930054459};\\\", \\\"{x:1543,y:623,t:1526930054476};\\\", \\\"{x:1543,y:624,t:1526930054493};\\\", \\\"{x:1543,y:625,t:1526930054515};\\\", \\\"{x:1543,y:626,t:1526930054526};\\\", \\\"{x:1544,y:627,t:1526930054542};\\\", \\\"{x:1544,y:628,t:1526930054560};\\\", \\\"{x:1545,y:630,t:1526930054576};\\\", \\\"{x:1545,y:631,t:1526930054593};\\\", \\\"{x:1545,y:633,t:1526930054610};\\\", \\\"{x:1546,y:634,t:1526930054627};\\\", \\\"{x:1546,y:637,t:1526930054644};\\\", \\\"{x:1546,y:641,t:1526930054660};\\\", \\\"{x:1546,y:644,t:1526930054677};\\\", \\\"{x:1548,y:647,t:1526930054694};\\\", \\\"{x:1549,y:650,t:1526930054709};\\\", \\\"{x:1549,y:651,t:1526930054727};\\\", \\\"{x:1549,y:653,t:1526930054744};\\\", \\\"{x:1549,y:654,t:1526930054760};\\\", \\\"{x:1549,y:656,t:1526930054777};\\\", \\\"{x:1549,y:658,t:1526930054794};\\\", \\\"{x:1550,y:660,t:1526930054811};\\\", \\\"{x:1550,y:661,t:1526930054827};\\\", \\\"{x:1550,y:664,t:1526930054844};\\\", \\\"{x:1550,y:666,t:1526930054861};\\\", \\\"{x:1550,y:669,t:1526930054877};\\\", \\\"{x:1550,y:672,t:1526930054894};\\\", \\\"{x:1550,y:673,t:1526930054911};\\\", \\\"{x:1550,y:674,t:1526930054928};\\\", \\\"{x:1550,y:675,t:1526930054944};\\\", \\\"{x:1550,y:676,t:1526930054961};\\\", \\\"{x:1550,y:677,t:1526930054977};\\\", \\\"{x:1550,y:679,t:1526930054993};\\\", \\\"{x:1549,y:682,t:1526930055011};\\\", \\\"{x:1549,y:684,t:1526930055028};\\\", \\\"{x:1549,y:687,t:1526930055044};\\\", \\\"{x:1548,y:689,t:1526930055061};\\\", \\\"{x:1548,y:690,t:1526930055078};\\\", \\\"{x:1548,y:692,t:1526930055095};\\\", \\\"{x:1547,y:693,t:1526930055111};\\\", \\\"{x:1547,y:694,t:1526930055132};\\\", \\\"{x:1547,y:695,t:1526930055145};\\\", \\\"{x:1547,y:696,t:1526930055161};\\\", \\\"{x:1547,y:699,t:1526930055189};\\\", \\\"{x:1547,y:700,t:1526930055204};\\\", \\\"{x:1547,y:702,t:1526930055212};\\\", \\\"{x:1546,y:702,t:1526930055228};\\\", \\\"{x:1546,y:704,t:1526930055244};\\\", \\\"{x:1546,y:705,t:1526930055262};\\\", \\\"{x:1546,y:706,t:1526930055278};\\\", \\\"{x:1546,y:707,t:1526930055295};\\\", \\\"{x:1546,y:708,t:1526930055312};\\\", \\\"{x:1546,y:709,t:1526930055328};\\\", \\\"{x:1546,y:710,t:1526930055348};\\\", \\\"{x:1546,y:711,t:1526930055362};\\\", \\\"{x:1545,y:711,t:1526930055379};\\\", \\\"{x:1545,y:713,t:1526930055395};\\\", \\\"{x:1545,y:715,t:1526930055412};\\\", \\\"{x:1545,y:716,t:1526930055437};\\\", \\\"{x:1545,y:717,t:1526930055453};\\\", \\\"{x:1545,y:718,t:1526930055462};\\\", \\\"{x:1545,y:719,t:1526930055484};\\\", \\\"{x:1545,y:720,t:1526930055495};\\\", \\\"{x:1545,y:721,t:1526930055511};\\\", \\\"{x:1545,y:722,t:1526930055531};\\\", \\\"{x:1545,y:723,t:1526930055545};\\\", \\\"{x:1545,y:724,t:1526930055561};\\\", \\\"{x:1545,y:725,t:1526930055596};\\\", \\\"{x:1545,y:726,t:1526930055619};\\\", \\\"{x:1545,y:727,t:1526930055652};\\\", \\\"{x:1545,y:728,t:1526930055668};\\\", \\\"{x:1545,y:729,t:1526930055683};\\\", \\\"{x:1545,y:730,t:1526930055716};\\\", \\\"{x:1545,y:731,t:1526930055732};\\\", \\\"{x:1545,y:732,t:1526930055747};\\\", \\\"{x:1545,y:733,t:1526930055763};\\\", \\\"{x:1545,y:734,t:1526930055778};\\\", \\\"{x:1545,y:735,t:1526930055795};\\\", \\\"{x:1546,y:737,t:1526930055835};\\\", \\\"{x:1546,y:738,t:1526930055867};\\\", \\\"{x:1546,y:740,t:1526930055900};\\\", \\\"{x:1546,y:741,t:1526930055923};\\\", \\\"{x:1546,y:742,t:1526930055940};\\\", \\\"{x:1546,y:743,t:1526930055948};\\\", \\\"{x:1546,y:744,t:1526930055964};\\\", \\\"{x:1547,y:746,t:1526930055988};\\\", \\\"{x:1547,y:747,t:1526930056012};\\\", \\\"{x:1547,y:748,t:1526930056036};\\\", \\\"{x:1547,y:749,t:1526930056047};\\\", \\\"{x:1549,y:751,t:1526930056063};\\\", \\\"{x:1549,y:752,t:1526930056084};\\\", \\\"{x:1549,y:753,t:1526930056096};\\\", \\\"{x:1549,y:754,t:1526930056112};\\\", \\\"{x:1549,y:757,t:1526930056130};\\\", \\\"{x:1549,y:759,t:1526930056148};\\\", \\\"{x:1550,y:761,t:1526930056163};\\\", \\\"{x:1550,y:762,t:1526930056180};\\\", \\\"{x:1550,y:766,t:1526930056197};\\\", \\\"{x:1550,y:767,t:1526930056214};\\\", \\\"{x:1550,y:769,t:1526930056229};\\\", \\\"{x:1550,y:770,t:1526930056246};\\\", \\\"{x:1551,y:771,t:1526930056263};\\\", \\\"{x:1552,y:772,t:1526930056280};\\\", \\\"{x:1552,y:773,t:1526930056296};\\\", \\\"{x:1552,y:775,t:1526930056314};\\\", \\\"{x:1552,y:776,t:1526930056330};\\\", \\\"{x:1552,y:777,t:1526930056346};\\\", \\\"{x:1552,y:779,t:1526930056364};\\\", \\\"{x:1552,y:781,t:1526930056380};\\\", \\\"{x:1552,y:782,t:1526930056396};\\\", \\\"{x:1552,y:784,t:1526930056413};\\\", \\\"{x:1552,y:785,t:1526930056430};\\\", \\\"{x:1552,y:787,t:1526930056451};\\\", \\\"{x:1552,y:788,t:1526930056467};\\\", \\\"{x:1552,y:790,t:1526930056484};\\\", \\\"{x:1552,y:791,t:1526930056507};\\\", \\\"{x:1552,y:793,t:1526930056524};\\\", \\\"{x:1552,y:794,t:1526930056540};\\\", \\\"{x:1551,y:795,t:1526930056548};\\\", \\\"{x:1551,y:797,t:1526930056564};\\\", \\\"{x:1551,y:798,t:1526930056580};\\\", \\\"{x:1551,y:799,t:1526930056597};\\\", \\\"{x:1549,y:801,t:1526930056628};\\\", \\\"{x:1549,y:802,t:1526930056652};\\\", \\\"{x:1549,y:803,t:1526930056676};\\\", \\\"{x:1549,y:804,t:1526930056748};\\\", \\\"{x:1549,y:806,t:1526930056764};\\\", \\\"{x:1549,y:808,t:1526930056787};\\\", \\\"{x:1549,y:809,t:1526930056803};\\\", \\\"{x:1549,y:810,t:1526930056820};\\\", \\\"{x:1549,y:812,t:1526930056832};\\\", \\\"{x:1549,y:813,t:1526930056852};\\\", \\\"{x:1549,y:815,t:1526930056864};\\\", \\\"{x:1548,y:818,t:1526930056881};\\\", \\\"{x:1548,y:820,t:1526930056898};\\\", \\\"{x:1548,y:823,t:1526930056914};\\\", \\\"{x:1548,y:828,t:1526930056931};\\\", \\\"{x:1548,y:830,t:1526930056948};\\\", \\\"{x:1548,y:832,t:1526930056964};\\\", \\\"{x:1547,y:834,t:1526930056981};\\\", \\\"{x:1547,y:835,t:1526930057003};\\\", \\\"{x:1547,y:836,t:1526930057027};\\\", \\\"{x:1547,y:838,t:1526930057043};\\\", \\\"{x:1547,y:839,t:1526930057059};\\\", \\\"{x:1547,y:841,t:1526930057091};\\\", \\\"{x:1547,y:842,t:1526930057116};\\\", \\\"{x:1548,y:842,t:1526930057147};\\\", \\\"{x:1548,y:843,t:1526930057156};\\\", \\\"{x:1548,y:845,t:1526930057165};\\\", \\\"{x:1550,y:848,t:1526930057182};\\\", \\\"{x:1553,y:852,t:1526930057198};\\\", \\\"{x:1553,y:855,t:1526930057216};\\\", \\\"{x:1555,y:857,t:1526930057232};\\\", \\\"{x:1556,y:861,t:1526930057248};\\\", \\\"{x:1557,y:862,t:1526930057265};\\\", \\\"{x:1557,y:863,t:1526930057283};\\\", \\\"{x:1557,y:864,t:1526930057300};\\\", \\\"{x:1558,y:866,t:1526930057316};\\\", \\\"{x:1558,y:867,t:1526930057341};\\\", \\\"{x:1558,y:868,t:1526930057349};\\\", \\\"{x:1558,y:869,t:1526930057429};\\\", \\\"{x:1558,y:870,t:1526930057452};\\\", \\\"{x:1558,y:871,t:1526930057466};\\\", \\\"{x:1558,y:873,t:1526930057483};\\\", \\\"{x:1558,y:874,t:1526930057500};\\\", \\\"{x:1558,y:876,t:1526930057516};\\\", \\\"{x:1558,y:878,t:1526930057540};\\\", \\\"{x:1558,y:880,t:1526930057572};\\\", \\\"{x:1558,y:881,t:1526930057582};\\\", \\\"{x:1558,y:884,t:1526930057599};\\\", \\\"{x:1558,y:886,t:1526930057617};\\\", \\\"{x:1558,y:887,t:1526930057635};\\\", \\\"{x:1558,y:888,t:1526930057650};\\\", \\\"{x:1558,y:889,t:1526930057666};\\\", \\\"{x:1558,y:892,t:1526930057683};\\\", \\\"{x:1558,y:895,t:1526930057700};\\\", \\\"{x:1558,y:897,t:1526930057717};\\\", \\\"{x:1558,y:901,t:1526930057734};\\\", \\\"{x:1558,y:903,t:1526930057749};\\\", \\\"{x:1558,y:906,t:1526930057766};\\\", \\\"{x:1558,y:907,t:1526930057783};\\\", \\\"{x:1558,y:910,t:1526930057800};\\\", \\\"{x:1558,y:912,t:1526930057816};\\\", \\\"{x:1558,y:915,t:1526930057834};\\\", \\\"{x:1558,y:919,t:1526930057850};\\\", \\\"{x:1558,y:921,t:1526930057867};\\\", \\\"{x:1557,y:926,t:1526930057884};\\\", \\\"{x:1557,y:927,t:1526930057900};\\\", \\\"{x:1557,y:929,t:1526930057917};\\\", \\\"{x:1557,y:930,t:1526930057933};\\\", \\\"{x:1556,y:931,t:1526930057950};\\\", \\\"{x:1556,y:932,t:1526930057980};\\\", \\\"{x:1556,y:933,t:1526930058003};\\\", \\\"{x:1555,y:935,t:1526930058020};\\\", \\\"{x:1555,y:936,t:1526930058035};\\\", \\\"{x:1555,y:937,t:1526930058052};\\\", \\\"{x:1554,y:938,t:1526930058067};\\\", \\\"{x:1554,y:939,t:1526930058099};\\\", \\\"{x:1553,y:940,t:1526930058115};\\\", \\\"{x:1552,y:940,t:1526930058132};\\\", \\\"{x:1552,y:941,t:1526930058139};\\\", \\\"{x:1552,y:942,t:1526930058151};\\\", \\\"{x:1552,y:943,t:1526930058172};\\\", \\\"{x:1552,y:944,t:1526930058184};\\\", \\\"{x:1552,y:945,t:1526930058201};\\\", \\\"{x:1551,y:945,t:1526930058217};\\\", \\\"{x:1551,y:947,t:1526930058235};\\\", \\\"{x:1551,y:948,t:1526930058251};\\\", \\\"{x:1551,y:949,t:1526930058267};\\\", \\\"{x:1551,y:951,t:1526930058285};\\\", \\\"{x:1550,y:951,t:1526930058301};\\\", \\\"{x:1549,y:953,t:1526930058317};\\\", \\\"{x:1549,y:954,t:1526930058348};\\\", \\\"{x:1549,y:956,t:1526930058404};\\\", \\\"{x:1549,y:958,t:1526930058435};\\\", \\\"{x:1549,y:959,t:1526930058460};\\\", \\\"{x:1549,y:960,t:1526930058468};\\\", \\\"{x:1549,y:961,t:1526930058485};\\\", \\\"{x:1549,y:962,t:1526930058508};\\\", \\\"{x:1549,y:963,t:1526930058525};\\\", \\\"{x:1547,y:964,t:1526930077304};\\\", \\\"{x:1542,y:962,t:1526930077315};\\\", \\\"{x:1523,y:945,t:1526930077331};\\\", \\\"{x:1489,y:918,t:1526930077347};\\\", \\\"{x:1435,y:876,t:1526930077363};\\\", \\\"{x:1348,y:827,t:1526930077381};\\\", \\\"{x:1242,y:757,t:1526930077397};\\\", \\\"{x:1128,y:693,t:1526930077414};\\\", \\\"{x:941,y:603,t:1526930077431};\\\", \\\"{x:828,y:555,t:1526930077447};\\\", \\\"{x:739,y:516,t:1526930077469};\\\", \\\"{x:683,y:487,t:1526930077485};\\\", \\\"{x:642,y:471,t:1526930077502};\\\", \\\"{x:632,y:467,t:1526930077519};\\\", \\\"{x:625,y:467,t:1526930077535};\\\", \\\"{x:616,y:467,t:1526930077552};\\\", \\\"{x:604,y:467,t:1526930077570};\\\", \\\"{x:584,y:469,t:1526930077586};\\\", \\\"{x:559,y:471,t:1526930077602};\\\", \\\"{x:540,y:474,t:1526930077620};\\\", \\\"{x:523,y:479,t:1526930077636};\\\", \\\"{x:512,y:482,t:1526930077652};\\\", \\\"{x:508,y:486,t:1526930077670};\\\", \\\"{x:507,y:493,t:1526930077686};\\\", \\\"{x:507,y:504,t:1526930077703};\\\", \\\"{x:512,y:514,t:1526930077719};\\\", \\\"{x:519,y:527,t:1526930077736};\\\", \\\"{x:529,y:540,t:1526930077752};\\\", \\\"{x:542,y:561,t:1526930077770};\\\", \\\"{x:565,y:589,t:1526930077787};\\\", \\\"{x:583,y:612,t:1526930077803};\\\", \\\"{x:601,y:633,t:1526930077821};\\\", \\\"{x:614,y:649,t:1526930077837};\\\", \\\"{x:622,y:657,t:1526930077852};\\\", \\\"{x:630,y:661,t:1526930077870};\\\", \\\"{x:634,y:662,t:1526930077886};\\\", \\\"{x:635,y:661,t:1526930077991};\\\", \\\"{x:635,y:660,t:1526930078004};\\\", \\\"{x:636,y:655,t:1526930078021};\\\", \\\"{x:636,y:650,t:1526930078036};\\\", \\\"{x:636,y:645,t:1526930078053};\\\", \\\"{x:633,y:639,t:1526930078070};\\\", \\\"{x:631,y:632,t:1526930078087};\\\", \\\"{x:629,y:628,t:1526930078103};\\\", \\\"{x:628,y:625,t:1526930078120};\\\", \\\"{x:625,y:622,t:1526930078136};\\\", \\\"{x:623,y:619,t:1526930078154};\\\", \\\"{x:622,y:618,t:1526930078169};\\\", \\\"{x:619,y:616,t:1526930078187};\\\", \\\"{x:617,y:615,t:1526930078203};\\\", \\\"{x:616,y:614,t:1526930078220};\\\", \\\"{x:615,y:614,t:1526930078236};\\\", \\\"{x:614,y:612,t:1526930078255};\\\", \\\"{x:613,y:612,t:1526930078279};\\\", \\\"{x:612,y:612,t:1526930078295};\\\", \\\"{x:618,y:615,t:1526930078863};\\\", \\\"{x:641,y:628,t:1526930078871};\\\", \\\"{x:711,y:665,t:1526930078887};\\\", \\\"{x:798,y:696,t:1526930078904};\\\", \\\"{x:898,y:724,t:1526930078921};\\\", \\\"{x:1004,y:761,t:1526930078938};\\\", \\\"{x:1103,y:801,t:1526930078953};\\\", \\\"{x:1185,y:843,t:1526930078971};\\\", \\\"{x:1245,y:881,t:1526930078987};\\\", \\\"{x:1276,y:909,t:1526930079004};\\\", \\\"{x:1288,y:926,t:1526930079021};\\\", \\\"{x:1295,y:940,t:1526930079037};\\\", \\\"{x:1299,y:949,t:1526930079053};\\\", \\\"{x:1304,y:960,t:1526930079071};\\\", \\\"{x:1307,y:965,t:1526930079087};\\\", \\\"{x:1311,y:971,t:1526930079103};\\\", \\\"{x:1322,y:979,t:1526930079121};\\\", \\\"{x:1335,y:984,t:1526930079138};\\\", \\\"{x:1350,y:986,t:1526930079154};\\\", \\\"{x:1362,y:989,t:1526930079171};\\\", \\\"{x:1367,y:989,t:1526930079188};\\\", \\\"{x:1369,y:988,t:1526930079255};\\\", \\\"{x:1369,y:984,t:1526930079271};\\\", \\\"{x:1370,y:976,t:1526930079288};\\\", \\\"{x:1370,y:970,t:1526930079304};\\\", \\\"{x:1370,y:962,t:1526930079321};\\\", \\\"{x:1369,y:953,t:1526930079338};\\\", \\\"{x:1367,y:948,t:1526930079354};\\\", \\\"{x:1365,y:943,t:1526930079371};\\\", \\\"{x:1364,y:940,t:1526930079388};\\\", \\\"{x:1361,y:935,t:1526930079405};\\\", \\\"{x:1359,y:929,t:1526930079421};\\\", \\\"{x:1357,y:922,t:1526930079438};\\\", \\\"{x:1354,y:915,t:1526930079455};\\\", \\\"{x:1351,y:912,t:1526930079471};\\\", \\\"{x:1350,y:910,t:1526930079488};\\\", \\\"{x:1349,y:909,t:1526930079505};\\\", \\\"{x:1349,y:908,t:1526930079521};\\\", \\\"{x:1349,y:907,t:1526930079538};\\\", \\\"{x:1349,y:906,t:1526930079816};\\\", \\\"{x:1349,y:905,t:1526930079823};\\\", \\\"{x:1348,y:903,t:1526930079838};\\\", \\\"{x:1347,y:901,t:1526930079872};\\\", \\\"{x:1347,y:900,t:1526930079888};\\\", \\\"{x:1346,y:899,t:1526930079911};\\\", \\\"{x:1346,y:898,t:1526930079927};\\\", \\\"{x:1346,y:897,t:1526930079959};\\\", \\\"{x:1346,y:896,t:1526930080016};\\\", \\\"{x:1345,y:896,t:1526930080039};\\\", \\\"{x:1345,y:895,t:1526930080520};\\\", \\\"{x:1345,y:894,t:1526930080575};\\\", \\\"{x:1345,y:892,t:1526930080759};\\\", \\\"{x:1345,y:891,t:1526930082241};\\\", \\\"{x:1345,y:889,t:1526930082256};\\\", \\\"{x:1344,y:888,t:1526930082342};\\\", \\\"{x:1342,y:887,t:1526930082357};\\\", \\\"{x:1329,y:885,t:1526930082373};\\\", \\\"{x:1307,y:882,t:1526930082390};\\\", \\\"{x:1266,y:876,t:1526930082406};\\\", \\\"{x:1245,y:872,t:1526930082422};\\\", \\\"{x:1228,y:866,t:1526930082439};\\\", \\\"{x:1222,y:865,t:1526930082457};\\\", \\\"{x:1220,y:863,t:1526930082473};\\\", \\\"{x:1219,y:863,t:1526930082489};\\\", \\\"{x:1218,y:863,t:1526930082506};\\\", \\\"{x:1218,y:862,t:1526930082567};\\\", \\\"{x:1217,y:862,t:1526930082574};\\\", \\\"{x:1217,y:861,t:1526930082590};\\\", \\\"{x:1217,y:857,t:1526930082607};\\\", \\\"{x:1217,y:856,t:1526930082622};\\\", \\\"{x:1217,y:853,t:1526930082640};\\\", \\\"{x:1217,y:851,t:1526930082656};\\\", \\\"{x:1217,y:850,t:1526930082673};\\\", \\\"{x:1217,y:848,t:1526930082691};\\\", \\\"{x:1217,y:845,t:1526930082707};\\\", \\\"{x:1217,y:844,t:1526930082724};\\\", \\\"{x:1217,y:841,t:1526930082740};\\\", \\\"{x:1217,y:840,t:1526930082758};\\\", \\\"{x:1217,y:838,t:1526930082774};\\\", \\\"{x:1217,y:837,t:1526930082790};\\\", \\\"{x:1217,y:835,t:1526930082816};\\\", \\\"{x:1217,y:834,t:1526930083064};\\\", \\\"{x:1217,y:833,t:1526930083112};\\\", \\\"{x:1217,y:832,t:1526930083142};\\\", \\\"{x:1218,y:830,t:1526930083199};\\\", \\\"{x:1218,y:829,t:1526930083319};\\\", \\\"{x:1219,y:828,t:1526930083343};\\\", \\\"{x:1219,y:827,t:1526930083416};\\\", \\\"{x:1221,y:827,t:1526930083568};\\\", \\\"{x:1224,y:827,t:1526930083575};\\\", \\\"{x:1236,y:829,t:1526930083591};\\\", \\\"{x:1257,y:835,t:1526930083607};\\\", \\\"{x:1280,y:840,t:1526930083624};\\\", \\\"{x:1299,y:846,t:1526930083641};\\\", \\\"{x:1313,y:848,t:1526930083658};\\\", \\\"{x:1319,y:848,t:1526930083675};\\\", \\\"{x:1320,y:848,t:1526930083736};\\\", \\\"{x:1320,y:847,t:1526930083760};\\\", \\\"{x:1320,y:846,t:1526930083775};\\\", \\\"{x:1320,y:844,t:1526930083790};\\\", \\\"{x:1320,y:841,t:1526930083808};\\\", \\\"{x:1320,y:840,t:1526930083824};\\\", \\\"{x:1320,y:838,t:1526930083840};\\\", \\\"{x:1319,y:836,t:1526930083858};\\\", \\\"{x:1317,y:835,t:1526930083874};\\\", \\\"{x:1316,y:834,t:1526930083891};\\\", \\\"{x:1315,y:834,t:1526930083907};\\\", \\\"{x:1312,y:833,t:1526930083923};\\\", \\\"{x:1309,y:832,t:1526930083943};\\\", \\\"{x:1310,y:831,t:1526930084039};\\\", \\\"{x:1312,y:831,t:1526930084054};\\\", \\\"{x:1315,y:831,t:1526930084063};\\\", \\\"{x:1317,y:831,t:1526930084074};\\\", \\\"{x:1324,y:831,t:1526930084091};\\\", \\\"{x:1332,y:831,t:1526930084108};\\\", \\\"{x:1340,y:831,t:1526930084125};\\\", \\\"{x:1343,y:831,t:1526930084141};\\\", \\\"{x:1344,y:831,t:1526930084158};\\\", \\\"{x:1346,y:831,t:1526930084175};\\\", \\\"{x:1347,y:831,t:1526930084344};\\\", \\\"{x:1348,y:830,t:1526930084358};\\\", \\\"{x:1347,y:830,t:1526930084576};\\\", \\\"{x:1340,y:830,t:1526930084593};\\\", \\\"{x:1331,y:830,t:1526930084608};\\\", \\\"{x:1318,y:830,t:1526930084625};\\\", \\\"{x:1311,y:828,t:1526930084643};\\\", \\\"{x:1303,y:828,t:1526930084658};\\\", \\\"{x:1299,y:828,t:1526930084675};\\\", \\\"{x:1297,y:828,t:1526930084692};\\\", \\\"{x:1296,y:828,t:1526930084711};\\\", \\\"{x:1295,y:828,t:1526930084742};\\\", \\\"{x:1294,y:828,t:1526930084758};\\\", \\\"{x:1293,y:828,t:1526930084774};\\\", \\\"{x:1290,y:828,t:1526930084792};\\\", \\\"{x:1288,y:828,t:1526930084808};\\\", \\\"{x:1287,y:828,t:1526930084825};\\\", \\\"{x:1284,y:829,t:1526930084842};\\\", \\\"{x:1283,y:829,t:1526930084858};\\\", \\\"{x:1282,y:829,t:1526930084874};\\\", \\\"{x:1281,y:830,t:1526930084892};\\\", \\\"{x:1280,y:830,t:1526930084908};\\\", \\\"{x:1279,y:831,t:1526930084925};\\\", \\\"{x:1278,y:832,t:1526930084942};\\\", \\\"{x:1278,y:831,t:1526930085376};\\\", \\\"{x:1278,y:830,t:1526930085432};\\\", \\\"{x:1278,y:829,t:1526930085442};\\\", \\\"{x:1278,y:828,t:1526930085459};\\\", \\\"{x:1277,y:828,t:1526930085551};\\\", \\\"{x:1277,y:827,t:1526930085624};\\\", \\\"{x:1278,y:828,t:1526930087672};\\\", \\\"{x:1281,y:828,t:1526930087719};\\\", \\\"{x:1283,y:829,t:1526930087735};\\\", \\\"{x:1285,y:829,t:1526930087744};\\\", \\\"{x:1292,y:830,t:1526930087761};\\\", \\\"{x:1300,y:832,t:1526930087778};\\\", \\\"{x:1310,y:833,t:1526930087794};\\\", \\\"{x:1319,y:836,t:1526930087810};\\\", \\\"{x:1329,y:837,t:1526930087827};\\\", \\\"{x:1333,y:837,t:1526930087844};\\\", \\\"{x:1335,y:837,t:1526930087859};\\\", \\\"{x:1336,y:837,t:1526930087894};\\\", \\\"{x:1338,y:837,t:1526930087910};\\\", \\\"{x:1339,y:837,t:1526930087950};\\\", \\\"{x:1340,y:837,t:1526930087974};\\\", \\\"{x:1341,y:837,t:1526930087998};\\\", \\\"{x:1342,y:836,t:1526930088079};\\\", \\\"{x:1343,y:835,t:1526930088103};\\\", \\\"{x:1343,y:834,t:1526930088174};\\\", \\\"{x:1344,y:835,t:1526930088358};\\\", \\\"{x:1345,y:835,t:1526930088374};\\\", \\\"{x:1346,y:836,t:1526930088383};\\\", \\\"{x:1348,y:837,t:1526930088394};\\\", \\\"{x:1352,y:838,t:1526930088412};\\\", \\\"{x:1359,y:839,t:1526930088427};\\\", \\\"{x:1369,y:842,t:1526930088444};\\\", \\\"{x:1379,y:842,t:1526930088461};\\\", \\\"{x:1393,y:845,t:1526930088479};\\\", \\\"{x:1396,y:845,t:1526930088495};\\\", \\\"{x:1401,y:845,t:1526930088511};\\\", \\\"{x:1404,y:845,t:1526930088529};\\\", \\\"{x:1410,y:845,t:1526930088544};\\\", \\\"{x:1416,y:844,t:1526930088562};\\\", \\\"{x:1423,y:841,t:1526930088579};\\\", \\\"{x:1430,y:840,t:1526930088594};\\\", \\\"{x:1436,y:838,t:1526930088611};\\\", \\\"{x:1440,y:836,t:1526930088629};\\\", \\\"{x:1441,y:836,t:1526930088644};\\\", \\\"{x:1441,y:835,t:1526930088671};\\\", \\\"{x:1441,y:834,t:1526930088703};\\\", \\\"{x:1438,y:832,t:1526930088711};\\\", \\\"{x:1429,y:829,t:1526930088729};\\\", \\\"{x:1410,y:827,t:1526930088745};\\\", \\\"{x:1388,y:824,t:1526930088762};\\\", \\\"{x:1370,y:821,t:1526930088778};\\\", \\\"{x:1356,y:821,t:1526930088794};\\\", \\\"{x:1349,y:821,t:1526930088812};\\\", \\\"{x:1348,y:821,t:1526930088829};\\\", \\\"{x:1348,y:822,t:1526930089024};\\\", \\\"{x:1348,y:823,t:1526930089048};\\\", \\\"{x:1349,y:824,t:1526930089119};\\\", \\\"{x:1349,y:825,t:1526930089263};\\\", \\\"{x:1349,y:826,t:1526930089688};\\\", \\\"{x:1349,y:827,t:1526930089703};\\\", \\\"{x:1349,y:828,t:1526930089719};\\\", \\\"{x:1348,y:828,t:1526930089774};\\\", \\\"{x:1347,y:829,t:1526930090022};\\\", \\\"{x:1346,y:829,t:1526930090054};\\\", \\\"{x:1345,y:829,t:1526930090910};\\\", \\\"{x:1345,y:831,t:1526930090918};\\\", \\\"{x:1345,y:833,t:1526930090929};\\\", \\\"{x:1345,y:839,t:1526930090946};\\\", \\\"{x:1348,y:848,t:1526930090962};\\\", \\\"{x:1350,y:857,t:1526930090979};\\\", \\\"{x:1350,y:863,t:1526930090996};\\\", \\\"{x:1351,y:869,t:1526930091013};\\\", \\\"{x:1351,y:875,t:1526930091029};\\\", \\\"{x:1351,y:880,t:1526930091047};\\\", \\\"{x:1351,y:883,t:1526930091062};\\\", \\\"{x:1352,y:886,t:1526930091079};\\\", \\\"{x:1352,y:887,t:1526930091096};\\\", \\\"{x:1352,y:888,t:1526930091113};\\\", \\\"{x:1354,y:889,t:1526930091129};\\\", \\\"{x:1354,y:890,t:1526930091183};\\\", \\\"{x:1353,y:890,t:1526930091352};\\\", \\\"{x:1352,y:891,t:1526930091480};\\\", \\\"{x:1350,y:891,t:1526930092086};\\\", \\\"{x:1350,y:892,t:1526930092126};\\\", \\\"{x:1349,y:893,t:1526930092199};\\\", \\\"{x:1349,y:894,t:1526930092670};\\\", \\\"{x:1350,y:894,t:1526930092694};\\\", \\\"{x:1351,y:894,t:1526930092718};\\\", \\\"{x:1352,y:894,t:1526930092734};\\\", \\\"{x:1353,y:894,t:1526930092747};\\\", \\\"{x:1355,y:894,t:1526930092767};\\\", \\\"{x:1356,y:894,t:1526930092781};\\\", \\\"{x:1357,y:894,t:1526930092797};\\\", \\\"{x:1363,y:894,t:1526930092815};\\\", \\\"{x:1365,y:894,t:1526930092839};\\\", \\\"{x:1366,y:894,t:1526930092847};\\\", \\\"{x:1367,y:894,t:1526930092871};\\\", \\\"{x:1368,y:894,t:1526930092886};\\\", \\\"{x:1369,y:894,t:1526930092902};\\\", \\\"{x:1370,y:894,t:1526930092926};\\\", \\\"{x:1371,y:894,t:1526930092943};\\\", \\\"{x:1372,y:894,t:1526930092951};\\\", \\\"{x:1373,y:894,t:1526930092975};\\\", \\\"{x:1375,y:894,t:1526930092983};\\\", \\\"{x:1376,y:894,t:1526930093007};\\\", \\\"{x:1377,y:894,t:1526930093023};\\\", \\\"{x:1378,y:894,t:1526930093079};\\\", \\\"{x:1379,y:894,t:1526930093121};\\\", \\\"{x:1380,y:894,t:1526930093132};\\\", \\\"{x:1382,y:894,t:1526930093148};\\\", \\\"{x:1383,y:894,t:1526930093164};\\\", \\\"{x:1384,y:894,t:1526930093246};\\\", \\\"{x:1385,y:894,t:1526930093367};\\\", \\\"{x:1384,y:894,t:1526930093487};\\\", \\\"{x:1382,y:895,t:1526930093499};\\\", \\\"{x:1381,y:895,t:1526930093514};\\\", \\\"{x:1379,y:895,t:1526930093531};\\\", \\\"{x:1378,y:895,t:1526930093549};\\\", \\\"{x:1377,y:896,t:1526930093566};\\\", \\\"{x:1375,y:896,t:1526930093598};\\\", \\\"{x:1374,y:897,t:1526930093646};\\\", \\\"{x:1375,y:898,t:1526930094071};\\\", \\\"{x:1377,y:898,t:1526930094087};\\\", \\\"{x:1378,y:898,t:1526930094098};\\\", \\\"{x:1379,y:899,t:1526930094151};\\\", \\\"{x:1379,y:900,t:1526930094190};\\\", \\\"{x:1380,y:900,t:1526930094214};\\\", \\\"{x:1381,y:900,t:1526930094687};\\\", \\\"{x:1382,y:900,t:1526930094711};\\\", \\\"{x:1383,y:900,t:1526930094735};\\\", \\\"{x:1384,y:900,t:1526930094751};\\\", \\\"{x:1385,y:900,t:1526930094775};\\\", \\\"{x:1386,y:900,t:1526930094791};\\\", \\\"{x:1387,y:900,t:1526930094807};\\\", \\\"{x:1388,y:900,t:1526930094823};\\\", \\\"{x:1390,y:900,t:1526930094833};\\\", \\\"{x:1394,y:900,t:1526930094849};\\\", \\\"{x:1395,y:900,t:1526930094866};\\\", \\\"{x:1397,y:900,t:1526930094882};\\\", \\\"{x:1399,y:900,t:1526930094900};\\\", \\\"{x:1402,y:900,t:1526930094916};\\\", \\\"{x:1408,y:901,t:1526930094933};\\\", \\\"{x:1413,y:902,t:1526930094950};\\\", \\\"{x:1418,y:903,t:1526930094965};\\\", \\\"{x:1421,y:903,t:1526930094982};\\\", \\\"{x:1422,y:903,t:1526930094999};\\\", \\\"{x:1423,y:903,t:1526930095023};\\\", \\\"{x:1425,y:901,t:1526930095087};\\\", \\\"{x:1425,y:900,t:1526930095127};\\\", \\\"{x:1425,y:899,t:1526930095143};\\\", \\\"{x:1425,y:898,t:1526930095151};\\\", \\\"{x:1425,y:897,t:1526930095191};\\\", \\\"{x:1424,y:897,t:1526930095199};\\\", \\\"{x:1422,y:895,t:1526930095217};\\\", \\\"{x:1422,y:894,t:1526930095232};\\\", \\\"{x:1420,y:892,t:1526930095250};\\\", \\\"{x:1418,y:892,t:1526930095267};\\\", \\\"{x:1418,y:891,t:1526930095367};\\\", \\\"{x:1416,y:891,t:1526930095703};\\\", \\\"{x:1415,y:891,t:1526930095717};\\\", \\\"{x:1413,y:892,t:1526930095734};\\\", \\\"{x:1412,y:893,t:1526930095750};\\\", \\\"{x:1410,y:893,t:1526930095767};\\\", \\\"{x:1404,y:893,t:1526930095783};\\\", \\\"{x:1394,y:893,t:1526930095800};\\\", \\\"{x:1382,y:893,t:1526930095817};\\\", \\\"{x:1372,y:893,t:1526930095834};\\\", \\\"{x:1366,y:893,t:1526930095850};\\\", \\\"{x:1364,y:893,t:1526930095868};\\\", \\\"{x:1363,y:893,t:1526930095942};\\\", \\\"{x:1364,y:893,t:1526930096463};\\\", \\\"{x:1366,y:893,t:1526930096471};\\\", \\\"{x:1371,y:891,t:1526930096484};\\\", \\\"{x:1378,y:889,t:1526930096501};\\\", \\\"{x:1390,y:885,t:1526930096517};\\\", \\\"{x:1403,y:882,t:1526930096534};\\\", \\\"{x:1421,y:879,t:1526930096551};\\\", \\\"{x:1425,y:876,t:1526930096567};\\\", \\\"{x:1430,y:873,t:1526930096584};\\\", \\\"{x:1433,y:871,t:1526930096601};\\\", \\\"{x:1437,y:868,t:1526930096618};\\\", \\\"{x:1442,y:865,t:1526930096634};\\\", \\\"{x:1447,y:863,t:1526930096651};\\\", \\\"{x:1453,y:860,t:1526930096668};\\\", \\\"{x:1460,y:857,t:1526930096684};\\\", \\\"{x:1464,y:854,t:1526930096701};\\\", \\\"{x:1470,y:852,t:1526930096719};\\\", \\\"{x:1472,y:850,t:1526930096734};\\\", \\\"{x:1476,y:847,t:1526930096751};\\\", \\\"{x:1477,y:847,t:1526930096767};\\\", \\\"{x:1480,y:846,t:1526930096784};\\\", \\\"{x:1485,y:844,t:1526930096801};\\\", \\\"{x:1486,y:843,t:1526930096818};\\\", \\\"{x:1492,y:842,t:1526930096834};\\\", \\\"{x:1493,y:842,t:1526930096851};\\\", \\\"{x:1493,y:840,t:1526930097127};\\\", \\\"{x:1492,y:840,t:1526930097143};\\\", \\\"{x:1492,y:839,t:1526930097183};\\\", \\\"{x:1490,y:839,t:1526930097247};\\\", \\\"{x:1489,y:837,t:1526930097263};\\\", \\\"{x:1488,y:837,t:1526930097271};\\\", \\\"{x:1488,y:836,t:1526930097287};\\\", \\\"{x:1487,y:835,t:1526930097301};\\\", \\\"{x:1485,y:834,t:1526930097320};\\\", \\\"{x:1485,y:833,t:1526930097335};\\\", \\\"{x:1484,y:833,t:1526930097351};\\\", \\\"{x:1484,y:832,t:1526930097439};\\\", \\\"{x:1482,y:832,t:1526930097750};\\\", \\\"{x:1481,y:832,t:1526930097758};\\\", \\\"{x:1480,y:832,t:1526930097767};\\\", \\\"{x:1475,y:832,t:1526930097785};\\\", \\\"{x:1463,y:832,t:1526930097801};\\\", \\\"{x:1445,y:832,t:1526930097817};\\\", \\\"{x:1418,y:828,t:1526930097835};\\\", \\\"{x:1385,y:823,t:1526930097851};\\\", \\\"{x:1352,y:816,t:1526930097868};\\\", \\\"{x:1325,y:808,t:1526930097884};\\\", \\\"{x:1304,y:803,t:1526930097902};\\\", \\\"{x:1286,y:797,t:1526930097918};\\\", \\\"{x:1286,y:796,t:1526930097934};\\\", \\\"{x:1288,y:795,t:1526930097998};\\\", \\\"{x:1290,y:795,t:1526930098005};\\\", \\\"{x:1293,y:795,t:1526930098029};\\\", \\\"{x:1296,y:795,t:1526930098038};\\\", \\\"{x:1300,y:792,t:1526930098051};\\\", \\\"{x:1313,y:789,t:1526930098068};\\\", \\\"{x:1327,y:786,t:1526930098085};\\\", \\\"{x:1343,y:780,t:1526930098101};\\\", \\\"{x:1357,y:774,t:1526930098118};\\\", \\\"{x:1361,y:772,t:1526930098134};\\\", \\\"{x:1362,y:771,t:1526930098151};\\\", \\\"{x:1362,y:770,t:1526930098168};\\\", \\\"{x:1363,y:770,t:1526930098206};\\\", \\\"{x:1364,y:768,t:1526930098217};\\\", \\\"{x:1365,y:767,t:1526930098234};\\\", \\\"{x:1366,y:767,t:1526930098251};\\\", \\\"{x:1367,y:766,t:1526930098268};\\\", \\\"{x:1368,y:765,t:1526930098294};\\\", \\\"{x:1369,y:765,t:1526930099871};\\\", \\\"{x:1370,y:765,t:1526930099887};\\\", \\\"{x:1371,y:765,t:1526930099903};\\\", \\\"{x:1373,y:763,t:1526930099920};\\\", \\\"{x:1374,y:763,t:1526930099937};\\\", \\\"{x:1375,y:763,t:1526930099959};\\\", \\\"{x:1376,y:763,t:1526930099987};\\\", \\\"{x:1377,y:763,t:1526930100063};\\\", \\\"{x:1378,y:763,t:1526930100079};\\\", \\\"{x:1379,y:762,t:1526930100182};\\\", \\\"{x:1383,y:761,t:1526930100286};\\\", \\\"{x:1383,y:762,t:1526930100974};\\\", \\\"{x:1383,y:763,t:1526930100987};\\\", \\\"{x:1384,y:765,t:1526930101003};\\\", \\\"{x:1385,y:767,t:1526930101020};\\\", \\\"{x:1387,y:770,t:1526930101037};\\\", \\\"{x:1390,y:771,t:1526930101054};\\\", \\\"{x:1395,y:773,t:1526930101070};\\\", \\\"{x:1400,y:774,t:1526930101086};\\\", \\\"{x:1404,y:775,t:1526930101103};\\\", \\\"{x:1408,y:775,t:1526930101120};\\\", \\\"{x:1416,y:776,t:1526930101137};\\\", \\\"{x:1423,y:776,t:1526930101154};\\\", \\\"{x:1429,y:776,t:1526930101171};\\\", \\\"{x:1436,y:776,t:1526930101186};\\\", \\\"{x:1442,y:776,t:1526930101203};\\\", \\\"{x:1444,y:776,t:1526930101221};\\\", \\\"{x:1447,y:776,t:1526930101237};\\\", \\\"{x:1449,y:776,t:1526930101253};\\\", \\\"{x:1453,y:776,t:1526930101270};\\\", \\\"{x:1457,y:776,t:1526930101288};\\\", \\\"{x:1460,y:776,t:1526930101304};\\\", \\\"{x:1462,y:776,t:1526930101320};\\\", \\\"{x:1465,y:775,t:1526930101337};\\\", \\\"{x:1466,y:774,t:1526930101366};\\\", \\\"{x:1467,y:773,t:1526930101382};\\\", \\\"{x:1467,y:772,t:1526930101478};\\\", \\\"{x:1467,y:771,t:1526930101510};\\\", \\\"{x:1467,y:770,t:1526930101521};\\\", \\\"{x:1467,y:771,t:1526930101702};\\\", \\\"{x:1467,y:774,t:1526930101718};\\\", \\\"{x:1467,y:775,t:1526930101726};\\\", \\\"{x:1468,y:776,t:1526930101738};\\\", \\\"{x:1469,y:778,t:1526930101755};\\\", \\\"{x:1474,y:779,t:1526930101771};\\\", \\\"{x:1484,y:781,t:1526930101787};\\\", \\\"{x:1492,y:781,t:1526930101805};\\\", \\\"{x:1501,y:781,t:1526930101821};\\\", \\\"{x:1507,y:781,t:1526930101837};\\\", \\\"{x:1511,y:780,t:1526930101854};\\\", \\\"{x:1512,y:779,t:1526930101871};\\\", \\\"{x:1514,y:777,t:1526930101888};\\\", \\\"{x:1515,y:775,t:1526930101905};\\\", \\\"{x:1516,y:774,t:1526930101927};\\\", \\\"{x:1516,y:772,t:1526930101938};\\\", \\\"{x:1518,y:771,t:1526930101955};\\\", \\\"{x:1518,y:769,t:1526930101971};\\\", \\\"{x:1519,y:768,t:1526930101988};\\\", \\\"{x:1521,y:766,t:1526930102005};\\\", \\\"{x:1521,y:765,t:1526930102020};\\\", \\\"{x:1522,y:764,t:1526930102038};\\\", \\\"{x:1522,y:763,t:1526930102055};\\\", \\\"{x:1522,y:762,t:1526930102096};\\\", \\\"{x:1522,y:763,t:1526930102263};\\\", \\\"{x:1522,y:764,t:1526930102271};\\\", \\\"{x:1522,y:766,t:1526930102288};\\\", \\\"{x:1522,y:770,t:1526930102306};\\\", \\\"{x:1522,y:772,t:1526930102322};\\\", \\\"{x:1523,y:773,t:1526930102338};\\\", \\\"{x:1525,y:774,t:1526930102355};\\\", \\\"{x:1528,y:775,t:1526930102372};\\\", \\\"{x:1532,y:775,t:1526930102388};\\\", \\\"{x:1538,y:776,t:1526930102405};\\\", \\\"{x:1542,y:776,t:1526930102423};\\\", \\\"{x:1550,y:776,t:1526930102438};\\\", \\\"{x:1553,y:776,t:1526930102455};\\\", \\\"{x:1554,y:776,t:1526930102472};\\\", \\\"{x:1558,y:776,t:1526930102488};\\\", \\\"{x:1559,y:775,t:1526930102506};\\\", \\\"{x:1561,y:774,t:1526930102522};\\\", \\\"{x:1563,y:773,t:1526930102538};\\\", \\\"{x:1564,y:772,t:1526930102555};\\\", \\\"{x:1567,y:771,t:1526930102572};\\\", \\\"{x:1569,y:770,t:1526930102588};\\\", \\\"{x:1570,y:769,t:1526930102605};\\\", \\\"{x:1573,y:768,t:1526930102622};\\\", \\\"{x:1576,y:768,t:1526930102638};\\\", \\\"{x:1582,y:765,t:1526930102655};\\\", \\\"{x:1584,y:765,t:1526930102673};\\\", \\\"{x:1587,y:764,t:1526930102689};\\\", \\\"{x:1589,y:763,t:1526930102706};\\\", \\\"{x:1590,y:763,t:1526930102722};\\\", \\\"{x:1590,y:762,t:1526930102740};\\\", \\\"{x:1591,y:761,t:1526930102759};\\\", \\\"{x:1592,y:761,t:1526930102775};\\\", \\\"{x:1593,y:761,t:1526930102789};\\\", \\\"{x:1594,y:759,t:1526930102805};\\\", \\\"{x:1594,y:760,t:1526930103039};\\\", \\\"{x:1594,y:761,t:1526930103111};\\\", \\\"{x:1594,y:762,t:1526930103744};\\\", \\\"{x:1591,y:762,t:1526930105072};\\\", \\\"{x:1588,y:762,t:1526930105079};\\\", \\\"{x:1586,y:762,t:1526930105090};\\\", \\\"{x:1580,y:762,t:1526930105107};\\\", \\\"{x:1579,y:762,t:1526930105125};\\\", \\\"{x:1576,y:762,t:1526930105139};\\\", \\\"{x:1575,y:762,t:1526930105157};\\\", \\\"{x:1574,y:762,t:1526930105206};\\\", \\\"{x:1573,y:762,t:1526930105246};\\\", \\\"{x:1574,y:761,t:1526930105503};\\\", \\\"{x:1574,y:760,t:1526930105687};\\\", \\\"{x:1573,y:760,t:1526930109015};\\\", \\\"{x:1570,y:760,t:1526930109026};\\\", \\\"{x:1566,y:760,t:1526930109043};\\\", \\\"{x:1563,y:760,t:1526930109060};\\\", \\\"{x:1562,y:760,t:1526930109077};\\\", \\\"{x:1561,y:760,t:1526930109093};\\\", \\\"{x:1560,y:760,t:1526930109110};\\\", \\\"{x:1559,y:760,t:1526930109126};\\\", \\\"{x:1558,y:760,t:1526930109143};\\\", \\\"{x:1556,y:760,t:1526930109160};\\\", \\\"{x:1553,y:760,t:1526930109176};\\\", \\\"{x:1549,y:760,t:1526930109194};\\\", \\\"{x:1545,y:760,t:1526930109210};\\\", \\\"{x:1541,y:760,t:1526930109227};\\\", \\\"{x:1535,y:760,t:1526930109243};\\\", \\\"{x:1528,y:760,t:1526930109260};\\\", \\\"{x:1524,y:760,t:1526930109276};\\\", \\\"{x:1520,y:760,t:1526930109294};\\\", \\\"{x:1517,y:760,t:1526930109311};\\\", \\\"{x:1514,y:760,t:1526930109328};\\\", \\\"{x:1512,y:760,t:1526930109343};\\\", \\\"{x:1510,y:760,t:1526930109360};\\\", \\\"{x:1506,y:760,t:1526930109378};\\\", \\\"{x:1502,y:760,t:1526930109393};\\\", \\\"{x:1498,y:760,t:1526930109410};\\\", \\\"{x:1495,y:760,t:1526930109427};\\\", \\\"{x:1493,y:760,t:1526930109444};\\\", \\\"{x:1489,y:760,t:1526930109461};\\\", \\\"{x:1485,y:760,t:1526930109477};\\\", \\\"{x:1480,y:761,t:1526930109493};\\\", \\\"{x:1474,y:761,t:1526930109511};\\\", \\\"{x:1473,y:761,t:1526930109528};\\\", \\\"{x:1472,y:761,t:1526930109544};\\\", \\\"{x:1473,y:761,t:1526930111230};\\\", \\\"{x:1474,y:761,t:1526930111246};\\\", \\\"{x:1475,y:761,t:1526930111260};\\\", \\\"{x:1476,y:762,t:1526930111278};\\\", \\\"{x:1477,y:762,t:1526930111295};\\\", \\\"{x:1480,y:762,t:1526930111311};\\\", \\\"{x:1481,y:763,t:1526930111328};\\\", \\\"{x:1484,y:763,t:1526930111344};\\\", \\\"{x:1488,y:764,t:1526930111361};\\\", \\\"{x:1496,y:766,t:1526930111378};\\\", \\\"{x:1501,y:766,t:1526930111394};\\\", \\\"{x:1507,y:768,t:1526930111411};\\\", \\\"{x:1511,y:770,t:1526930111428};\\\", \\\"{x:1512,y:770,t:1526930111445};\\\", \\\"{x:1514,y:771,t:1526930111460};\\\", \\\"{x:1515,y:771,t:1526930111502};\\\", \\\"{x:1516,y:771,t:1526930111511};\\\", \\\"{x:1519,y:774,t:1526930111528};\\\", \\\"{x:1523,y:778,t:1526930111545};\\\", \\\"{x:1529,y:784,t:1526930111561};\\\", \\\"{x:1534,y:790,t:1526930111578};\\\", \\\"{x:1539,y:797,t:1526930111594};\\\", \\\"{x:1544,y:804,t:1526930111611};\\\", \\\"{x:1546,y:810,t:1526930111628};\\\", \\\"{x:1548,y:814,t:1526930111645};\\\", \\\"{x:1550,y:822,t:1526930111662};\\\", \\\"{x:1550,y:826,t:1526930111678};\\\", \\\"{x:1551,y:830,t:1526930111694};\\\", \\\"{x:1551,y:834,t:1526930111712};\\\", \\\"{x:1552,y:837,t:1526930111727};\\\", \\\"{x:1554,y:839,t:1526930111745};\\\", \\\"{x:1554,y:840,t:1526930111762};\\\", \\\"{x:1554,y:841,t:1526930111862};\\\", \\\"{x:1554,y:840,t:1526930112021};\\\", \\\"{x:1553,y:840,t:1526930112029};\\\", \\\"{x:1553,y:839,t:1526930112044};\\\", \\\"{x:1553,y:836,t:1526930112061};\\\", \\\"{x:1553,y:835,t:1526930112078};\\\", \\\"{x:1553,y:834,t:1526930112094};\\\", \\\"{x:1553,y:833,t:1526930112183};\\\", \\\"{x:1551,y:832,t:1526930112214};\\\", \\\"{x:1551,y:831,t:1526930112871};\\\", \\\"{x:1550,y:830,t:1526930113519};\\\", \\\"{x:1550,y:829,t:1526930113551};\\\", \\\"{x:1549,y:829,t:1526930113599};\\\", \\\"{x:1548,y:829,t:1526930113655};\\\", \\\"{x:1547,y:828,t:1526930113671};\\\", \\\"{x:1546,y:828,t:1526930113728};\\\", \\\"{x:1545,y:828,t:1526930113743};\\\", \\\"{x:1544,y:828,t:1526930113807};\\\", \\\"{x:1544,y:827,t:1526930115014};\\\", \\\"{x:1544,y:826,t:1526930115718};\\\", \\\"{x:1545,y:826,t:1526930115846};\\\", \\\"{x:1546,y:826,t:1526930115926};\\\", \\\"{x:1547,y:825,t:1526930115966};\\\", \\\"{x:1548,y:825,t:1526930116423};\\\", \\\"{x:1550,y:825,t:1526930116535};\\\", \\\"{x:1550,y:827,t:1526930116640};\\\", \\\"{x:1550,y:829,t:1526930116759};\\\", \\\"{x:1550,y:830,t:1526930116807};\\\", \\\"{x:1549,y:830,t:1526930116822};\\\", \\\"{x:1548,y:830,t:1526930116903};\\\", \\\"{x:1548,y:831,t:1526930117054};\\\", \\\"{x:1547,y:831,t:1526930117366};\\\", \\\"{x:1546,y:831,t:1526930117422};\\\", \\\"{x:1545,y:831,t:1526930117631};\\\", \\\"{x:1545,y:830,t:1526930117654};\\\", \\\"{x:1545,y:828,t:1526930117666};\\\", \\\"{x:1545,y:827,t:1526930117682};\\\", \\\"{x:1543,y:823,t:1526930117699};\\\", \\\"{x:1543,y:821,t:1526930117716};\\\", \\\"{x:1543,y:818,t:1526930117732};\\\", \\\"{x:1542,y:816,t:1526930117749};\\\", \\\"{x:1542,y:812,t:1526930117766};\\\", \\\"{x:1541,y:809,t:1526930117782};\\\", \\\"{x:1541,y:803,t:1526930117799};\\\", \\\"{x:1539,y:798,t:1526930117816};\\\", \\\"{x:1538,y:792,t:1526930117832};\\\", \\\"{x:1537,y:785,t:1526930117849};\\\", \\\"{x:1536,y:777,t:1526930117866};\\\", \\\"{x:1533,y:767,t:1526930117882};\\\", \\\"{x:1532,y:759,t:1526930117899};\\\", \\\"{x:1530,y:748,t:1526930117916};\\\", \\\"{x:1527,y:739,t:1526930117933};\\\", \\\"{x:1521,y:728,t:1526930117949};\\\", \\\"{x:1515,y:715,t:1526930117966};\\\", \\\"{x:1514,y:708,t:1526930117983};\\\", \\\"{x:1511,y:702,t:1526930117999};\\\", \\\"{x:1510,y:696,t:1526930118016};\\\", \\\"{x:1510,y:688,t:1526930118033};\\\", \\\"{x:1510,y:680,t:1526930118049};\\\", \\\"{x:1510,y:667,t:1526930118066};\\\", \\\"{x:1510,y:659,t:1526930118083};\\\", \\\"{x:1510,y:652,t:1526930118099};\\\", \\\"{x:1510,y:649,t:1526930118117};\\\", \\\"{x:1510,y:646,t:1526930118133};\\\", \\\"{x:1510,y:643,t:1526930118149};\\\", \\\"{x:1511,y:639,t:1526930118165};\\\", \\\"{x:1512,y:637,t:1526930118183};\\\", \\\"{x:1514,y:634,t:1526930118199};\\\", \\\"{x:1515,y:633,t:1526930118216};\\\", \\\"{x:1515,y:632,t:1526930118233};\\\", \\\"{x:1515,y:631,t:1526930118838};\\\", \\\"{x:1514,y:631,t:1526930123822};\\\", \\\"{x:1504,y:631,t:1526930123838};\\\", \\\"{x:1490,y:631,t:1526930123854};\\\", \\\"{x:1476,y:631,t:1526930123870};\\\", \\\"{x:1471,y:631,t:1526930123888};\\\", \\\"{x:1468,y:631,t:1526930123903};\\\", \\\"{x:1466,y:631,t:1526930123921};\\\", \\\"{x:1461,y:631,t:1526930123937};\\\", \\\"{x:1454,y:631,t:1526930123954};\\\", \\\"{x:1444,y:632,t:1526930123970};\\\", \\\"{x:1432,y:633,t:1526930123988};\\\", \\\"{x:1416,y:633,t:1526930124004};\\\", \\\"{x:1401,y:633,t:1526930124020};\\\", \\\"{x:1390,y:633,t:1526930124038};\\\", \\\"{x:1382,y:633,t:1526930124053};\\\", \\\"{x:1371,y:633,t:1526930124071};\\\", \\\"{x:1363,y:633,t:1526930124087};\\\", \\\"{x:1353,y:634,t:1526930124105};\\\", \\\"{x:1335,y:637,t:1526930124120};\\\", \\\"{x:1317,y:637,t:1526930124137};\\\", \\\"{x:1294,y:640,t:1526930124154};\\\", \\\"{x:1276,y:640,t:1526930124170};\\\", \\\"{x:1267,y:641,t:1526930124188};\\\", \\\"{x:1266,y:641,t:1526930124205};\\\", \\\"{x:1265,y:641,t:1526930124334};\\\", \\\"{x:1264,y:641,t:1526930124375};\\\", \\\"{x:1264,y:640,t:1526930124391};\\\", \\\"{x:1265,y:639,t:1526930124415};\\\", \\\"{x:1265,y:638,t:1526930124430};\\\", \\\"{x:1266,y:637,t:1526930124437};\\\", \\\"{x:1269,y:635,t:1526930124454};\\\", \\\"{x:1272,y:633,t:1526930124470};\\\", \\\"{x:1275,y:632,t:1526930124487};\\\", \\\"{x:1278,y:630,t:1526930124504};\\\", \\\"{x:1280,y:629,t:1526930124522};\\\", \\\"{x:1283,y:628,t:1526930124537};\\\", \\\"{x:1285,y:628,t:1526930124554};\\\", \\\"{x:1287,y:626,t:1526930124571};\\\", \\\"{x:1288,y:626,t:1526930124587};\\\", \\\"{x:1291,y:626,t:1526930124604};\\\", \\\"{x:1295,y:625,t:1526930124621};\\\", \\\"{x:1297,y:625,t:1526930124637};\\\", \\\"{x:1302,y:624,t:1526930124654};\\\", \\\"{x:1305,y:624,t:1526930124671};\\\", \\\"{x:1308,y:623,t:1526930124687};\\\", \\\"{x:1308,y:622,t:1526930124705};\\\", \\\"{x:1309,y:622,t:1526930124721};\\\", \\\"{x:1311,y:622,t:1526930124749};\\\", \\\"{x:1312,y:622,t:1526930124781};\\\", \\\"{x:1314,y:622,t:1526930124853};\\\", \\\"{x:1314,y:623,t:1526930125046};\\\", \\\"{x:1314,y:624,t:1526930125077};\\\", \\\"{x:1314,y:625,t:1526930125093};\\\", \\\"{x:1314,y:626,t:1526930125126};\\\", \\\"{x:1314,y:627,t:1526930125142};\\\", \\\"{x:1314,y:628,t:1526930125181};\\\", \\\"{x:1315,y:628,t:1526930125255};\\\", \\\"{x:1325,y:630,t:1526930125272};\\\", \\\"{x:1344,y:632,t:1526930125289};\\\", \\\"{x:1366,y:636,t:1526930125305};\\\", \\\"{x:1389,y:638,t:1526930125322};\\\", \\\"{x:1406,y:640,t:1526930125339};\\\", \\\"{x:1420,y:640,t:1526930125354};\\\", \\\"{x:1427,y:641,t:1526930125371};\\\", \\\"{x:1434,y:641,t:1526930125389};\\\", \\\"{x:1442,y:641,t:1526930125405};\\\", \\\"{x:1453,y:641,t:1526930125422};\\\", \\\"{x:1466,y:641,t:1526930125438};\\\", \\\"{x:1471,y:641,t:1526930125455};\\\", \\\"{x:1476,y:641,t:1526930125471};\\\", \\\"{x:1478,y:641,t:1526930125489};\\\", \\\"{x:1482,y:641,t:1526930125505};\\\", \\\"{x:1485,y:641,t:1526930125521};\\\", \\\"{x:1491,y:641,t:1526930125539};\\\", \\\"{x:1496,y:641,t:1526930125555};\\\", \\\"{x:1501,y:641,t:1526930125572};\\\", \\\"{x:1508,y:640,t:1526930125589};\\\", \\\"{x:1512,y:639,t:1526930125606};\\\", \\\"{x:1513,y:638,t:1526930125622};\\\", \\\"{x:1515,y:638,t:1526930125646};\\\", \\\"{x:1516,y:638,t:1526930125703};\\\", \\\"{x:1517,y:637,t:1526930125710};\\\", \\\"{x:1517,y:636,t:1526930125726};\\\", \\\"{x:1517,y:635,t:1526930125894};\\\", \\\"{x:1517,y:634,t:1526930125922};\\\", \\\"{x:1517,y:633,t:1526930126022};\\\", \\\"{x:1526,y:633,t:1526930126039};\\\", \\\"{x:1541,y:633,t:1526930126055};\\\", \\\"{x:1557,y:633,t:1526930126073};\\\", \\\"{x:1575,y:633,t:1526930126088};\\\", \\\"{x:1584,y:633,t:1526930126105};\\\", \\\"{x:1586,y:633,t:1526930126123};\\\", \\\"{x:1587,y:633,t:1526930126158};\\\", \\\"{x:1588,y:633,t:1526930126173};\\\", \\\"{x:1590,y:633,t:1526930126188};\\\", \\\"{x:1599,y:631,t:1526930126206};\\\", \\\"{x:1603,y:631,t:1526930126222};\\\", \\\"{x:1607,y:629,t:1526930126239};\\\", \\\"{x:1610,y:629,t:1526930126256};\\\", \\\"{x:1612,y:629,t:1526930126273};\\\", \\\"{x:1613,y:629,t:1526930126288};\\\", \\\"{x:1616,y:629,t:1526930126306};\\\", \\\"{x:1621,y:629,t:1526930126322};\\\", \\\"{x:1627,y:629,t:1526930126338};\\\", \\\"{x:1633,y:628,t:1526930126356};\\\", \\\"{x:1639,y:628,t:1526930126373};\\\", \\\"{x:1640,y:628,t:1526930126687};\\\", \\\"{x:1641,y:628,t:1526930126703};\\\", \\\"{x:1642,y:628,t:1526930126726};\\\", \\\"{x:1643,y:628,t:1526930126751};\\\", \\\"{x:1644,y:628,t:1526930126766};\\\", \\\"{x:1645,y:628,t:1526930126774};\\\", \\\"{x:1646,y:628,t:1526930126791};\\\", \\\"{x:1647,y:628,t:1526930126831};\\\", \\\"{x:1648,y:628,t:1526930126935};\\\", \\\"{x:1649,y:628,t:1526930126958};\\\", \\\"{x:1650,y:628,t:1526930127070};\\\", \\\"{x:1649,y:628,t:1526930130609};\\\", \\\"{x:1648,y:629,t:1526930130617};\\\", \\\"{x:1645,y:629,t:1526930130630};\\\", \\\"{x:1639,y:629,t:1526930130646};\\\", \\\"{x:1632,y:629,t:1526930130662};\\\", \\\"{x:1624,y:629,t:1526930130679};\\\", \\\"{x:1616,y:630,t:1526930130696};\\\", \\\"{x:1612,y:630,t:1526930130712};\\\", \\\"{x:1605,y:631,t:1526930130729};\\\", \\\"{x:1597,y:632,t:1526930130745};\\\", \\\"{x:1591,y:633,t:1526930130763};\\\", \\\"{x:1586,y:634,t:1526930130779};\\\", \\\"{x:1580,y:634,t:1526930130796};\\\", \\\"{x:1573,y:634,t:1526930130813};\\\", \\\"{x:1565,y:635,t:1526930130830};\\\", \\\"{x:1558,y:636,t:1526930130846};\\\", \\\"{x:1549,y:636,t:1526930130863};\\\", \\\"{x:1540,y:636,t:1526930130879};\\\", \\\"{x:1530,y:637,t:1526930130896};\\\", \\\"{x:1518,y:638,t:1526930130912};\\\", \\\"{x:1508,y:639,t:1526930130930};\\\", \\\"{x:1504,y:641,t:1526930130946};\\\", \\\"{x:1500,y:641,t:1526930130962};\\\", \\\"{x:1496,y:641,t:1526930130979};\\\", \\\"{x:1495,y:641,t:1526930130996};\\\", \\\"{x:1493,y:641,t:1526930131013};\\\", \\\"{x:1492,y:641,t:1526930131030};\\\", \\\"{x:1491,y:641,t:1526930131050};\\\", \\\"{x:1490,y:641,t:1526930131138};\\\", \\\"{x:1489,y:641,t:1526930131153};\\\", \\\"{x:1488,y:641,t:1526930131178};\\\", \\\"{x:1487,y:641,t:1526930131186};\\\", \\\"{x:1485,y:641,t:1526930131196};\\\", \\\"{x:1483,y:640,t:1526930131234};\\\", \\\"{x:1483,y:639,t:1526930131250};\\\", \\\"{x:1482,y:639,t:1526930131266};\\\", \\\"{x:1481,y:638,t:1526930131281};\\\", \\\"{x:1480,y:638,t:1526930131315};\\\", \\\"{x:1479,y:637,t:1526930131338};\\\", \\\"{x:1479,y:636,t:1526930131378};\\\", \\\"{x:1479,y:635,t:1526930131467};\\\", \\\"{x:1479,y:633,t:1526930131515};\\\", \\\"{x:1479,y:632,t:1526930131594};\\\", \\\"{x:1479,y:631,t:1526930131673};\\\", \\\"{x:1479,y:630,t:1526930131898};\\\", \\\"{x:1480,y:630,t:1526930131921};\\\", \\\"{x:1480,y:629,t:1526930133738};\\\", \\\"{x:1480,y:628,t:1526930133749};\\\", \\\"{x:1478,y:626,t:1526930133765};\\\", \\\"{x:1478,y:625,t:1526930133782};\\\", \\\"{x:1477,y:624,t:1526930133799};\\\", \\\"{x:1476,y:623,t:1526930133815};\\\", \\\"{x:1475,y:623,t:1526930133832};\\\", \\\"{x:1474,y:621,t:1526930133849};\\\", \\\"{x:1473,y:619,t:1526930133865};\\\", \\\"{x:1471,y:618,t:1526930133881};\\\", \\\"{x:1470,y:616,t:1526930133898};\\\", \\\"{x:1468,y:616,t:1526930133915};\\\", \\\"{x:1466,y:614,t:1526930133932};\\\", \\\"{x:1463,y:612,t:1526930133949};\\\", \\\"{x:1460,y:612,t:1526930133965};\\\", \\\"{x:1456,y:610,t:1526930133982};\\\", \\\"{x:1452,y:608,t:1526930133999};\\\", \\\"{x:1448,y:605,t:1526930134015};\\\", \\\"{x:1444,y:603,t:1526930134032};\\\", \\\"{x:1440,y:600,t:1526930134048};\\\", \\\"{x:1433,y:597,t:1526930134066};\\\", \\\"{x:1428,y:594,t:1526930134082};\\\", \\\"{x:1425,y:591,t:1526930134099};\\\", \\\"{x:1423,y:589,t:1526930134115};\\\", \\\"{x:1421,y:588,t:1526930134132};\\\", \\\"{x:1418,y:583,t:1526930134149};\\\", \\\"{x:1416,y:580,t:1526930134165};\\\", \\\"{x:1414,y:578,t:1526930134181};\\\", \\\"{x:1414,y:575,t:1526930134198};\\\", \\\"{x:1412,y:572,t:1526930134215};\\\", \\\"{x:1412,y:568,t:1526930134232};\\\", \\\"{x:1412,y:567,t:1526930134248};\\\", \\\"{x:1412,y:563,t:1526930134265};\\\", \\\"{x:1412,y:561,t:1526930134281};\\\", \\\"{x:1411,y:560,t:1526930134299};\\\", \\\"{x:1411,y:557,t:1526930134316};\\\", \\\"{x:1410,y:555,t:1526930134332};\\\", \\\"{x:1410,y:554,t:1526930134353};\\\", \\\"{x:1409,y:553,t:1526930134377};\\\", \\\"{x:1409,y:552,t:1526930134409};\\\", \\\"{x:1411,y:552,t:1526930134778};\\\", \\\"{x:1419,y:551,t:1526930134786};\\\", \\\"{x:1429,y:551,t:1526930134799};\\\", \\\"{x:1451,y:551,t:1526930134816};\\\", \\\"{x:1474,y:551,t:1526930134832};\\\", \\\"{x:1498,y:551,t:1526930134848};\\\", \\\"{x:1525,y:551,t:1526930134865};\\\", \\\"{x:1539,y:551,t:1526930134882};\\\", \\\"{x:1549,y:551,t:1526930134899};\\\", \\\"{x:1556,y:551,t:1526930134916};\\\", \\\"{x:1564,y:551,t:1526930134932};\\\", \\\"{x:1573,y:551,t:1526930134949};\\\", \\\"{x:1586,y:550,t:1526930134966};\\\", \\\"{x:1603,y:549,t:1526930134983};\\\", \\\"{x:1621,y:549,t:1526930134999};\\\", \\\"{x:1638,y:549,t:1526930135017};\\\", \\\"{x:1645,y:549,t:1526930135033};\\\", \\\"{x:1647,y:549,t:1526930135050};\\\", \\\"{x:1646,y:549,t:1526930135218};\\\", \\\"{x:1644,y:551,t:1526930135233};\\\", \\\"{x:1630,y:555,t:1526930135250};\\\", \\\"{x:1621,y:559,t:1526930135266};\\\", \\\"{x:1613,y:561,t:1526930135284};\\\", \\\"{x:1609,y:561,t:1526930135300};\\\", \\\"{x:1607,y:561,t:1526930135317};\\\", \\\"{x:1607,y:562,t:1526930135842};\\\", \\\"{x:1607,y:563,t:1526930135897};\\\", \\\"{x:1608,y:564,t:1526930135961};\\\", \\\"{x:1609,y:564,t:1526930136018};\\\", \\\"{x:1610,y:564,t:1526930136065};\\\", \\\"{x:1611,y:564,t:1526930136097};\\\", \\\"{x:1612,y:564,t:1526930136137};\\\", \\\"{x:1613,y:564,t:1526930136233};\\\", \\\"{x:1614,y:564,t:1526930136273};\\\", \\\"{x:1615,y:564,t:1526930136297};\\\", \\\"{x:1617,y:563,t:1526930136650};\\\", \\\"{x:1616,y:563,t:1526930137345};\\\", \\\"{x:1615,y:562,t:1526930137993};\\\", \\\"{x:1614,y:562,t:1526930138025};\\\", \\\"{x:1614,y:561,t:1526930138034};\\\", \\\"{x:1614,y:560,t:1526930138065};\\\", \\\"{x:1613,y:560,t:1526930138129};\\\", \\\"{x:1613,y:559,t:1526930138145};\\\", \\\"{x:1612,y:559,t:1526930138233};\\\", \\\"{x:1610,y:559,t:1526930138265};\\\", \\\"{x:1609,y:559,t:1526930138274};\\\", \\\"{x:1605,y:559,t:1526930138786};\\\", \\\"{x:1588,y:559,t:1526930138802};\\\", \\\"{x:1565,y:559,t:1526930138819};\\\", \\\"{x:1539,y:559,t:1526930138836};\\\", \\\"{x:1512,y:559,t:1526930138853};\\\", \\\"{x:1490,y:559,t:1526930138869};\\\", \\\"{x:1470,y:559,t:1526930138886};\\\", \\\"{x:1454,y:557,t:1526930138902};\\\", \\\"{x:1445,y:555,t:1526930138919};\\\", \\\"{x:1435,y:555,t:1526930138936};\\\", \\\"{x:1419,y:555,t:1526930138952};\\\", \\\"{x:1400,y:555,t:1526930138969};\\\", \\\"{x:1367,y:555,t:1526930138986};\\\", \\\"{x:1343,y:555,t:1526930139002};\\\", \\\"{x:1322,y:552,t:1526930139019};\\\", \\\"{x:1307,y:550,t:1526930139036};\\\", \\\"{x:1293,y:548,t:1526930139052};\\\", \\\"{x:1281,y:547,t:1526930139069};\\\", \\\"{x:1271,y:545,t:1526930139086};\\\", \\\"{x:1265,y:544,t:1526930139102};\\\", \\\"{x:1261,y:542,t:1526930139119};\\\", \\\"{x:1260,y:542,t:1526930139210};\\\", \\\"{x:1259,y:541,t:1526930139220};\\\", \\\"{x:1259,y:539,t:1526930139236};\\\", \\\"{x:1259,y:535,t:1526930139252};\\\", \\\"{x:1262,y:530,t:1526930139270};\\\", \\\"{x:1267,y:526,t:1526930139286};\\\", \\\"{x:1271,y:523,t:1526930139303};\\\", \\\"{x:1274,y:523,t:1526930139319};\\\", \\\"{x:1277,y:521,t:1526930139336};\\\", \\\"{x:1278,y:521,t:1526930139353};\\\", \\\"{x:1281,y:519,t:1526930139369};\\\", \\\"{x:1283,y:519,t:1526930139386};\\\", \\\"{x:1286,y:517,t:1526930139403};\\\", \\\"{x:1288,y:517,t:1526930139419};\\\", \\\"{x:1291,y:515,t:1526930139437};\\\", \\\"{x:1294,y:514,t:1526930139454};\\\", \\\"{x:1297,y:513,t:1526930139469};\\\", \\\"{x:1299,y:512,t:1526930139486};\\\", \\\"{x:1300,y:511,t:1526930139523};\\\", \\\"{x:1301,y:511,t:1526930139536};\\\", \\\"{x:1301,y:510,t:1526930139553};\\\", \\\"{x:1303,y:509,t:1526930139569};\\\", \\\"{x:1304,y:509,t:1526930139594};\\\", \\\"{x:1305,y:508,t:1526930139618};\\\", \\\"{x:1305,y:507,t:1526930139636};\\\", \\\"{x:1306,y:507,t:1526930139653};\\\", \\\"{x:1307,y:506,t:1526930139669};\\\", \\\"{x:1308,y:506,t:1526930139687};\\\", \\\"{x:1310,y:504,t:1526930139703};\\\", \\\"{x:1311,y:504,t:1526930139723};\\\", \\\"{x:1312,y:504,t:1526930139738};\\\", \\\"{x:1313,y:503,t:1526930139753};\\\", \\\"{x:1313,y:502,t:1526930139819};\\\", \\\"{x:1314,y:502,t:1526930139898};\\\", \\\"{x:1315,y:502,t:1526930139962};\\\", \\\"{x:1316,y:502,t:1526930139978};\\\", \\\"{x:1317,y:500,t:1526930140657};\\\", \\\"{x:1318,y:499,t:1526930140669};\\\", \\\"{x:1319,y:497,t:1526930140686};\\\", \\\"{x:1324,y:496,t:1526930140704};\\\", \\\"{x:1329,y:493,t:1526930140720};\\\", \\\"{x:1333,y:491,t:1526930140737};\\\", \\\"{x:1348,y:486,t:1526930140753};\\\", \\\"{x:1363,y:481,t:1526930140770};\\\", \\\"{x:1379,y:478,t:1526930140786};\\\", \\\"{x:1395,y:470,t:1526930140803};\\\", \\\"{x:1408,y:467,t:1526930140820};\\\", \\\"{x:1421,y:463,t:1526930140837};\\\", \\\"{x:1430,y:459,t:1526930140854};\\\", \\\"{x:1434,y:458,t:1526930140870};\\\", \\\"{x:1435,y:457,t:1526930140887};\\\", \\\"{x:1436,y:457,t:1526930140921};\\\", \\\"{x:1437,y:456,t:1526930140936};\\\", \\\"{x:1437,y:455,t:1526930140953};\\\", \\\"{x:1437,y:454,t:1526930140977};\\\", \\\"{x:1437,y:453,t:1526930141001};\\\", \\\"{x:1437,y:452,t:1526930141009};\\\", \\\"{x:1437,y:451,t:1526930141041};\\\", \\\"{x:1436,y:450,t:1526930141066};\\\", \\\"{x:1435,y:449,t:1526930141106};\\\", \\\"{x:1433,y:448,t:1526930141138};\\\", \\\"{x:1432,y:447,t:1526930141154};\\\", \\\"{x:1431,y:446,t:1526930141170};\\\", \\\"{x:1430,y:445,t:1526930141188};\\\", \\\"{x:1430,y:444,t:1526930141257};\\\", \\\"{x:1428,y:443,t:1526930141273};\\\", \\\"{x:1428,y:441,t:1526930141288};\\\", \\\"{x:1427,y:441,t:1526930141321};\\\", \\\"{x:1427,y:440,t:1526930141385};\\\", \\\"{x:1427,y:439,t:1526930141392};\\\", \\\"{x:1427,y:438,t:1526930141404};\\\", \\\"{x:1427,y:437,t:1526930141421};\\\", \\\"{x:1427,y:436,t:1526930141437};\\\", \\\"{x:1426,y:434,t:1526930141454};\\\", \\\"{x:1425,y:434,t:1526930141470};\\\", \\\"{x:1424,y:433,t:1526930143426};\\\", \\\"{x:1422,y:433,t:1526930143441};\\\", \\\"{x:1420,y:432,t:1526930143455};\\\", \\\"{x:1419,y:432,t:1526930143473};\\\", \\\"{x:1418,y:431,t:1526930143489};\\\", \\\"{x:1417,y:431,t:1526930143504};\\\", \\\"{x:1416,y:430,t:1526930143593};\\\", \\\"{x:1415,y:430,t:1526930147874};\\\", \\\"{x:1414,y:430,t:1526930147889};\\\", \\\"{x:1414,y:431,t:1526930147898};\\\", \\\"{x:1414,y:432,t:1526930147909};\\\", \\\"{x:1424,y:436,t:1526930147925};\\\", \\\"{x:1436,y:441,t:1526930147942};\\\", \\\"{x:1447,y:446,t:1526930147959};\\\", \\\"{x:1460,y:452,t:1526930147975};\\\", \\\"{x:1474,y:459,t:1526930147992};\\\", \\\"{x:1491,y:468,t:1526930148009};\\\", \\\"{x:1503,y:473,t:1526930148025};\\\", \\\"{x:1515,y:479,t:1526930148042};\\\", \\\"{x:1533,y:487,t:1526930148059};\\\", \\\"{x:1552,y:494,t:1526930148074};\\\", \\\"{x:1574,y:509,t:1526930148091};\\\", \\\"{x:1593,y:519,t:1526930148108};\\\", \\\"{x:1615,y:532,t:1526930148125};\\\", \\\"{x:1633,y:541,t:1526930148142};\\\", \\\"{x:1641,y:548,t:1526930148159};\\\", \\\"{x:1653,y:558,t:1526930148174};\\\", \\\"{x:1669,y:573,t:1526930148192};\\\", \\\"{x:1686,y:585,t:1526930148209};\\\", \\\"{x:1695,y:591,t:1526930148225};\\\", \\\"{x:1701,y:595,t:1526930148242};\\\", \\\"{x:1705,y:599,t:1526930148259};\\\", \\\"{x:1707,y:601,t:1526930148275};\\\", \\\"{x:1709,y:604,t:1526930148292};\\\", \\\"{x:1709,y:606,t:1526930148309};\\\", \\\"{x:1708,y:608,t:1526930148325};\\\", \\\"{x:1703,y:612,t:1526930148342};\\\", \\\"{x:1690,y:617,t:1526930148359};\\\", \\\"{x:1674,y:621,t:1526930148376};\\\", \\\"{x:1657,y:628,t:1526930148392};\\\", \\\"{x:1638,y:634,t:1526930148409};\\\", \\\"{x:1631,y:637,t:1526930148426};\\\", \\\"{x:1630,y:638,t:1526930148441};\\\", \\\"{x:1629,y:638,t:1526930148459};\\\", \\\"{x:1628,y:639,t:1526930148476};\\\", \\\"{x:1628,y:640,t:1526930148505};\\\", \\\"{x:1629,y:642,t:1526930148521};\\\", \\\"{x:1631,y:646,t:1526930148529};\\\", \\\"{x:1631,y:647,t:1526930148542};\\\", \\\"{x:1631,y:650,t:1526930148559};\\\", \\\"{x:1633,y:652,t:1526930148576};\\\", \\\"{x:1633,y:656,t:1526930148591};\\\", \\\"{x:1633,y:659,t:1526930148609};\\\", \\\"{x:1633,y:663,t:1526930148626};\\\", \\\"{x:1633,y:667,t:1526930148642};\\\", \\\"{x:1630,y:675,t:1526930148659};\\\", \\\"{x:1627,y:684,t:1526930148675};\\\", \\\"{x:1625,y:689,t:1526930148692};\\\", \\\"{x:1623,y:698,t:1526930148709};\\\", \\\"{x:1621,y:706,t:1526930148726};\\\", \\\"{x:1620,y:710,t:1526930148742};\\\", \\\"{x:1618,y:718,t:1526930148759};\\\", \\\"{x:1617,y:729,t:1526930148776};\\\", \\\"{x:1614,y:746,t:1526930148793};\\\", \\\"{x:1613,y:758,t:1526930148809};\\\", \\\"{x:1611,y:772,t:1526930148826};\\\", \\\"{x:1608,y:787,t:1526930148843};\\\", \\\"{x:1607,y:802,t:1526930148859};\\\", \\\"{x:1603,y:818,t:1526930148876};\\\", \\\"{x:1603,y:832,t:1526930148893};\\\", \\\"{x:1602,y:842,t:1526930148909};\\\", \\\"{x:1601,y:851,t:1526930148926};\\\", \\\"{x:1599,y:855,t:1526930148943};\\\", \\\"{x:1598,y:860,t:1526930148959};\\\", \\\"{x:1598,y:862,t:1526930148976};\\\", \\\"{x:1597,y:870,t:1526930148993};\\\", \\\"{x:1595,y:878,t:1526930149009};\\\", \\\"{x:1594,y:888,t:1526930149025};\\\", \\\"{x:1594,y:901,t:1526930149043};\\\", \\\"{x:1594,y:913,t:1526930149058};\\\", \\\"{x:1594,y:921,t:1526930149076};\\\", \\\"{x:1594,y:925,t:1526930149093};\\\", \\\"{x:1594,y:930,t:1526930149108};\\\", \\\"{x:1594,y:934,t:1526930149126};\\\", \\\"{x:1594,y:936,t:1526930149143};\\\", \\\"{x:1594,y:937,t:1526930149159};\\\", \\\"{x:1594,y:939,t:1526930149176};\\\", \\\"{x:1594,y:940,t:1526930149192};\\\", \\\"{x:1594,y:942,t:1526930149216};\\\", \\\"{x:1594,y:943,t:1526930149249};\\\", \\\"{x:1594,y:945,t:1526930149265};\\\", \\\"{x:1594,y:946,t:1526930149281};\\\", \\\"{x:1594,y:948,t:1526930149305};\\\", \\\"{x:1595,y:949,t:1526930149328};\\\", \\\"{x:1596,y:949,t:1526930149361};\\\", \\\"{x:1598,y:952,t:1526930149376};\\\", \\\"{x:1599,y:953,t:1526930149408};\\\", \\\"{x:1600,y:955,t:1526930149433};\\\", \\\"{x:1601,y:956,t:1526930149449};\\\", \\\"{x:1602,y:957,t:1526930149465};\\\", \\\"{x:1603,y:958,t:1526930149475};\\\", \\\"{x:1604,y:960,t:1526930149493};\\\", \\\"{x:1605,y:962,t:1526930149510};\\\", \\\"{x:1606,y:964,t:1526930149526};\\\", \\\"{x:1606,y:965,t:1526930149543};\\\", \\\"{x:1608,y:968,t:1526930149560};\\\", \\\"{x:1609,y:970,t:1526930149577};\\\", \\\"{x:1611,y:972,t:1526930149593};\\\", \\\"{x:1611,y:975,t:1526930149610};\\\", \\\"{x:1612,y:976,t:1526930149625};\\\", \\\"{x:1612,y:977,t:1526930149649};\\\", \\\"{x:1612,y:978,t:1526930149689};\\\", \\\"{x:1613,y:979,t:1526930149697};\\\", \\\"{x:1613,y:978,t:1526930149905};\\\", \\\"{x:1613,y:976,t:1526930149913};\\\", \\\"{x:1614,y:975,t:1526930149927};\\\", \\\"{x:1614,y:974,t:1526930149943};\\\", \\\"{x:1614,y:973,t:1526930149959};\\\", \\\"{x:1614,y:972,t:1526930149977};\\\", \\\"{x:1614,y:971,t:1526930149993};\\\", \\\"{x:1614,y:969,t:1526930150010};\\\", \\\"{x:1614,y:968,t:1526930150027};\\\", \\\"{x:1615,y:966,t:1526930150043};\\\", \\\"{x:1615,y:965,t:1526930150060};\\\", \\\"{x:1615,y:963,t:1526930150077};\\\", \\\"{x:1615,y:962,t:1526930150094};\\\", \\\"{x:1615,y:960,t:1526930150110};\\\", \\\"{x:1615,y:959,t:1526930150127};\\\", \\\"{x:1615,y:957,t:1526930150143};\\\", \\\"{x:1615,y:956,t:1526930150168};\\\", \\\"{x:1615,y:955,t:1526930150177};\\\", \\\"{x:1614,y:952,t:1526930150194};\\\", \\\"{x:1614,y:948,t:1526930150210};\\\", \\\"{x:1613,y:941,t:1526930150227};\\\", \\\"{x:1609,y:928,t:1526930150243};\\\", \\\"{x:1603,y:907,t:1526930150260};\\\", \\\"{x:1590,y:869,t:1526930150277};\\\", \\\"{x:1576,y:822,t:1526930150294};\\\", \\\"{x:1556,y:745,t:1526930150310};\\\", \\\"{x:1531,y:664,t:1526930150327};\\\", \\\"{x:1498,y:571,t:1526930150345};\\\", \\\"{x:1455,y:469,t:1526930150360};\\\", \\\"{x:1391,y:335,t:1526930150376};\\\", \\\"{x:1369,y:275,t:1526930150394};\\\", \\\"{x:1360,y:248,t:1526930150410};\\\", \\\"{x:1352,y:229,t:1526930150427};\\\", \\\"{x:1349,y:220,t:1526930150444};\\\", \\\"{x:1348,y:215,t:1526930150460};\\\", \\\"{x:1348,y:216,t:1526930150577};\\\", \\\"{x:1354,y:233,t:1526930150594};\\\", \\\"{x:1362,y:255,t:1526930150610};\\\", \\\"{x:1377,y:287,t:1526930150627};\\\", \\\"{x:1386,y:309,t:1526930150644};\\\", \\\"{x:1396,y:331,t:1526930150661};\\\", \\\"{x:1404,y:350,t:1526930150676};\\\", \\\"{x:1407,y:363,t:1526930150694};\\\", \\\"{x:1409,y:372,t:1526930150710};\\\", \\\"{x:1411,y:377,t:1526930150727};\\\", \\\"{x:1411,y:385,t:1526930150744};\\\", \\\"{x:1413,y:392,t:1526930150761};\\\", \\\"{x:1413,y:398,t:1526930150777};\\\", \\\"{x:1413,y:403,t:1526930150794};\\\", \\\"{x:1415,y:405,t:1526930150811};\\\", \\\"{x:1415,y:408,t:1526930150827};\\\", \\\"{x:1416,y:411,t:1526930150844};\\\", \\\"{x:1416,y:414,t:1526930150861};\\\", \\\"{x:1416,y:417,t:1526930150877};\\\", \\\"{x:1416,y:422,t:1526930150894};\\\", \\\"{x:1416,y:424,t:1526930150911};\\\", \\\"{x:1416,y:427,t:1526930150927};\\\", \\\"{x:1416,y:429,t:1526930150944};\\\", \\\"{x:1416,y:431,t:1526930150961};\\\", \\\"{x:1416,y:432,t:1526930150977};\\\", \\\"{x:1416,y:433,t:1526930151000};\\\", \\\"{x:1417,y:434,t:1526930151040};\\\", \\\"{x:1417,y:433,t:1526930151464};\\\", \\\"{x:1417,y:432,t:1526930151480};\\\", \\\"{x:1417,y:431,t:1526930151513};\\\", \\\"{x:1417,y:430,t:1526930151537};\\\", \\\"{x:1416,y:430,t:1526930152281};\\\", \\\"{x:1415,y:430,t:1526930152295};\\\", \\\"{x:1413,y:430,t:1526930152394};\\\", \\\"{x:1420,y:430,t:1526930152793};\\\", \\\"{x:1431,y:430,t:1526930152801};\\\", \\\"{x:1442,y:430,t:1526930152813};\\\", \\\"{x:1471,y:430,t:1526930152829};\\\", \\\"{x:1498,y:430,t:1526930152845};\\\", \\\"{x:1522,y:430,t:1526930152862};\\\", \\\"{x:1542,y:430,t:1526930152879};\\\", \\\"{x:1559,y:430,t:1526930152895};\\\", \\\"{x:1573,y:430,t:1526930152912};\\\", \\\"{x:1598,y:430,t:1526930152928};\\\", \\\"{x:1612,y:430,t:1526930152946};\\\", \\\"{x:1624,y:430,t:1526930152962};\\\", \\\"{x:1635,y:430,t:1526930152979};\\\", \\\"{x:1641,y:430,t:1526930152995};\\\", \\\"{x:1644,y:430,t:1526930153012};\\\", \\\"{x:1645,y:430,t:1526930153029};\\\", \\\"{x:1646,y:430,t:1526930153201};\\\", \\\"{x:1648,y:428,t:1526930153212};\\\", \\\"{x:1662,y:427,t:1526930153229};\\\", \\\"{x:1683,y:427,t:1526930153246};\\\", \\\"{x:1715,y:427,t:1526930153262};\\\", \\\"{x:1758,y:427,t:1526930153279};\\\", \\\"{x:1805,y:427,t:1526930153296};\\\", \\\"{x:1835,y:428,t:1526930153313};\\\", \\\"{x:1847,y:429,t:1526930153329};\\\", \\\"{x:1847,y:432,t:1526930153352};\\\", \\\"{x:1842,y:433,t:1526930153362};\\\", \\\"{x:1812,y:439,t:1526930153380};\\\", \\\"{x:1756,y:441,t:1526930153396};\\\", \\\"{x:1665,y:441,t:1526930153412};\\\", \\\"{x:1543,y:441,t:1526930153430};\\\", \\\"{x:1402,y:441,t:1526930153446};\\\", \\\"{x:1269,y:441,t:1526930153462};\\\", \\\"{x:1174,y:441,t:1526930153479};\\\", \\\"{x:1093,y:457,t:1526930153497};\\\", \\\"{x:1035,y:481,t:1526930153512};\\\", \\\"{x:969,y:522,t:1526930153529};\\\", \\\"{x:927,y:552,t:1526930153547};\\\", \\\"{x:881,y:586,t:1526930153565};\\\", \\\"{x:831,y:619,t:1526930153579};\\\", \\\"{x:784,y:646,t:1526930153597};\\\", \\\"{x:671,y:687,t:1526930153617};\\\", \\\"{x:592,y:707,t:1526930153634};\\\", \\\"{x:511,y:732,t:1526930153652};\\\", \\\"{x:449,y:751,t:1526930153667};\\\", \\\"{x:399,y:765,t:1526930153684};\\\", \\\"{x:357,y:776,t:1526930153700};\\\", \\\"{x:332,y:785,t:1526930153717};\\\", \\\"{x:311,y:790,t:1526930153734};\\\", \\\"{x:294,y:793,t:1526930153750};\\\", \\\"{x:273,y:797,t:1526930153767};\\\", \\\"{x:255,y:797,t:1526930153784};\\\", \\\"{x:249,y:797,t:1526930153801};\\\", \\\"{x:248,y:797,t:1526930153858};\\\", \\\"{x:254,y:795,t:1526930153867};\\\", \\\"{x:281,y:789,t:1526930153883};\\\", \\\"{x:318,y:786,t:1526930153900};\\\", \\\"{x:375,y:782,t:1526930153917};\\\", \\\"{x:410,y:782,t:1526930153933};\\\", \\\"{x:446,y:782,t:1526930153949};\\\", \\\"{x:470,y:781,t:1526930153966};\\\", \\\"{x:488,y:781,t:1526930153982};\\\", \\\"{x:498,y:779,t:1526930154000};\\\", \\\"{x:506,y:779,t:1526930154016};\\\", \\\"{x:509,y:778,t:1526930154033};\\\", \\\"{x:510,y:777,t:1526930154057};\\\", \\\"{x:510,y:776,t:1526930154073};\\\", \\\"{x:511,y:774,t:1526930154083};\\\", \\\"{x:513,y:770,t:1526930154099};\\\", \\\"{x:513,y:768,t:1526930154116};\\\", \\\"{x:513,y:763,t:1526930154133};\\\", \\\"{x:513,y:761,t:1526930154149};\\\", \\\"{x:513,y:758,t:1526930154166};\\\", \\\"{x:513,y:756,t:1526930154183};\\\", \\\"{x:512,y:753,t:1526930154199};\\\", \\\"{x:511,y:751,t:1526930154216};\\\", \\\"{x:511,y:749,t:1526930154233};\\\", \\\"{x:509,y:745,t:1526930154248};\\\", \\\"{x:508,y:743,t:1526930154266};\\\", \\\"{x:507,y:741,t:1526930154282};\\\", \\\"{x:506,y:740,t:1526930154299};\\\", \\\"{x:506,y:739,t:1526930154316};\\\", \\\"{x:505,y:738,t:1526930154332};\\\", \\\"{x:505,y:737,t:1526930154349};\\\", \\\"{x:503,y:737,t:1526930154366};\\\", \\\"{x:503,y:736,t:1526930154384};\\\", \\\"{x:503,y:735,t:1526930154449};\\\", \\\"{x:501,y:735,t:1526930154962};\\\", \\\"{x:498,y:737,t:1526930154970};\\\", \\\"{x:493,y:739,t:1526930154984};\\\", \\\"{x:482,y:744,t:1526930155002};\\\", \\\"{x:471,y:749,t:1526930155018};\\\", \\\"{x:461,y:752,t:1526930155035};\\\", \\\"{x:449,y:756,t:1526930155051};\\\", \\\"{x:440,y:757,t:1526930155068};\\\", \\\"{x:430,y:760,t:1526930155085};\\\", \\\"{x:420,y:761,t:1526930155102};\\\", \\\"{x:410,y:761,t:1526930155118};\\\", \\\"{x:397,y:764,t:1526930155135};\\\", \\\"{x:389,y:764,t:1526930155151};\\\", \\\"{x:383,y:765,t:1526930155168};\\\", \\\"{x:376,y:767,t:1526930155185};\\\", \\\"{x:374,y:767,t:1526930155202};\\\", \\\"{x:373,y:767,t:1526930155218};\\\", \\\"{x:372,y:767,t:1526930155688};\\\", \\\"{x:368,y:768,t:1526930155702};\\\", \\\"{x:367,y:768,t:1526930155719};\\\", \\\"{x:364,y:769,t:1526930155735};\\\", \\\"{x:360,y:769,t:1526930155752};\\\", \\\"{x:357,y:769,t:1526930155769};\\\", \\\"{x:353,y:769,t:1526930155786};\\\", \\\"{x:347,y:769,t:1526930155802};\\\", \\\"{x:342,y:769,t:1526930155819};\\\", \\\"{x:337,y:769,t:1526930155836};\\\", \\\"{x:334,y:769,t:1526930155852};\\\", \\\"{x:328,y:769,t:1526930155869};\\\", \\\"{x:327,y:769,t:1526930155886};\\\", \\\"{x:327,y:770,t:1526930155902};\\\", \\\"{x:325,y:770,t:1526930155920};\\\" ] }, { \\\"rt\\\": 9577, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 515399, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:320,y:770,t:1526930157793};\\\", \\\"{x:308,y:760,t:1526930157804};\\\", \\\"{x:276,y:741,t:1526930157821};\\\", \\\"{x:246,y:724,t:1526930157837};\\\", \\\"{x:227,y:716,t:1526930157855};\\\", \\\"{x:220,y:711,t:1526930157871};\\\", \\\"{x:216,y:709,t:1526930157888};\\\", \\\"{x:209,y:708,t:1526930157905};\\\", \\\"{x:201,y:704,t:1526930157920};\\\", \\\"{x:192,y:701,t:1526930157937};\\\", \\\"{x:189,y:699,t:1526930157955};\\\", \\\"{x:188,y:699,t:1526930157970};\\\", \\\"{x:185,y:698,t:1526930157987};\\\", \\\"{x:179,y:695,t:1526930158005};\\\", \\\"{x:174,y:693,t:1526930158021};\\\", \\\"{x:165,y:687,t:1526930158038};\\\", \\\"{x:153,y:677,t:1526930158054};\\\", \\\"{x:149,y:672,t:1526930158071};\\\", \\\"{x:147,y:670,t:1526930158088};\\\", \\\"{x:147,y:669,t:1526930158131};\\\", \\\"{x:146,y:669,t:1526930158169};\\\", \\\"{x:148,y:667,t:1526930158305};\\\", \\\"{x:151,y:666,t:1526930158320};\\\", \\\"{x:151,y:665,t:1526930158337};\\\", \\\"{x:152,y:664,t:1526930158352};\\\", \\\"{x:153,y:664,t:1526930158433};\\\", \\\"{x:157,y:662,t:1526930158441};\\\", \\\"{x:161,y:661,t:1526930158454};\\\", \\\"{x:175,y:659,t:1526930158471};\\\", \\\"{x:197,y:650,t:1526930158489};\\\", \\\"{x:223,y:645,t:1526930158504};\\\", \\\"{x:293,y:634,t:1526930158521};\\\", \\\"{x:351,y:634,t:1526930158538};\\\", \\\"{x:404,y:634,t:1526930158554};\\\", \\\"{x:457,y:634,t:1526930158571};\\\", \\\"{x:510,y:634,t:1526930158588};\\\", \\\"{x:564,y:634,t:1526930158604};\\\", \\\"{x:608,y:634,t:1526930158622};\\\", \\\"{x:641,y:631,t:1526930158639};\\\", \\\"{x:667,y:628,t:1526930158654};\\\", \\\"{x:689,y:626,t:1526930158672};\\\", \\\"{x:707,y:626,t:1526930158688};\\\", \\\"{x:715,y:625,t:1526930158704};\\\", \\\"{x:725,y:625,t:1526930158722};\\\", \\\"{x:733,y:625,t:1526930158738};\\\", \\\"{x:748,y:623,t:1526930158754};\\\", \\\"{x:769,y:618,t:1526930158771};\\\", \\\"{x:810,y:605,t:1526930158788};\\\", \\\"{x:855,y:591,t:1526930158806};\\\", \\\"{x:903,y:577,t:1526930158821};\\\", \\\"{x:947,y:566,t:1526930158838};\\\", \\\"{x:979,y:558,t:1526930158854};\\\", \\\"{x:1000,y:553,t:1526930158871};\\\", \\\"{x:1014,y:549,t:1526930158889};\\\", \\\"{x:1024,y:545,t:1526930158905};\\\", \\\"{x:1030,y:544,t:1526930158921};\\\", \\\"{x:1036,y:542,t:1526930158938};\\\", \\\"{x:1044,y:540,t:1526930158955};\\\", \\\"{x:1051,y:538,t:1526930158971};\\\", \\\"{x:1058,y:537,t:1526930158988};\\\", \\\"{x:1068,y:534,t:1526930159005};\\\", \\\"{x:1081,y:532,t:1526930159021};\\\", \\\"{x:1097,y:531,t:1526930159038};\\\", \\\"{x:1119,y:529,t:1526930159056};\\\", \\\"{x:1140,y:529,t:1526930159071};\\\", \\\"{x:1151,y:529,t:1526930159088};\\\", \\\"{x:1155,y:529,t:1526930159106};\\\", \\\"{x:1157,y:529,t:1526930159144};\\\", \\\"{x:1159,y:529,t:1526930159184};\\\", \\\"{x:1160,y:530,t:1526930159200};\\\", \\\"{x:1160,y:531,t:1526930159217};\\\", \\\"{x:1160,y:532,t:1526930159232};\\\", \\\"{x:1158,y:533,t:1526930159241};\\\", \\\"{x:1155,y:535,t:1526930159255};\\\", \\\"{x:1151,y:539,t:1526930159272};\\\", \\\"{x:1146,y:542,t:1526930159288};\\\", \\\"{x:1135,y:547,t:1526930159305};\\\", \\\"{x:1119,y:551,t:1526930159322};\\\", \\\"{x:1104,y:556,t:1526930159338};\\\", \\\"{x:1095,y:558,t:1526930159355};\\\", \\\"{x:1091,y:559,t:1526930159372};\\\", \\\"{x:1094,y:559,t:1526930159609};\\\", \\\"{x:1100,y:559,t:1526930159623};\\\", \\\"{x:1115,y:558,t:1526930159639};\\\", \\\"{x:1129,y:555,t:1526930159656};\\\", \\\"{x:1146,y:555,t:1526930159673};\\\", \\\"{x:1156,y:555,t:1526930159689};\\\", \\\"{x:1167,y:554,t:1526930159706};\\\", \\\"{x:1174,y:554,t:1526930159722};\\\", \\\"{x:1182,y:553,t:1526930159738};\\\", \\\"{x:1193,y:553,t:1526930159755};\\\", \\\"{x:1207,y:553,t:1526930159772};\\\", \\\"{x:1224,y:554,t:1526930159788};\\\", \\\"{x:1240,y:555,t:1526930159806};\\\", \\\"{x:1255,y:555,t:1526930159823};\\\", \\\"{x:1271,y:555,t:1526930159839};\\\", \\\"{x:1282,y:555,t:1526930159855};\\\", \\\"{x:1290,y:555,t:1526930159873};\\\", \\\"{x:1296,y:555,t:1526930159889};\\\", \\\"{x:1298,y:555,t:1526930159906};\\\", \\\"{x:1299,y:555,t:1526930159969};\\\", \\\"{x:1300,y:555,t:1526930159984};\\\", \\\"{x:1301,y:555,t:1526930160041};\\\", \\\"{x:1302,y:555,t:1526930160056};\\\", \\\"{x:1305,y:555,t:1526930160072};\\\", \\\"{x:1308,y:554,t:1526930160089};\\\", \\\"{x:1312,y:554,t:1526930160105};\\\", \\\"{x:1319,y:553,t:1526930160123};\\\", \\\"{x:1327,y:553,t:1526930160139};\\\", \\\"{x:1333,y:553,t:1526930160156};\\\", \\\"{x:1340,y:553,t:1526930160172};\\\", \\\"{x:1349,y:553,t:1526930160189};\\\", \\\"{x:1356,y:553,t:1526930160205};\\\", \\\"{x:1363,y:553,t:1526930160222};\\\", \\\"{x:1367,y:553,t:1526930160239};\\\", \\\"{x:1369,y:553,t:1526930160256};\\\", \\\"{x:1373,y:553,t:1526930160273};\\\", \\\"{x:1378,y:553,t:1526930160289};\\\", \\\"{x:1381,y:553,t:1526930160307};\\\", \\\"{x:1386,y:554,t:1526930160323};\\\", \\\"{x:1392,y:557,t:1526930160340};\\\", \\\"{x:1397,y:557,t:1526930160356};\\\", \\\"{x:1401,y:558,t:1526930160372};\\\", \\\"{x:1404,y:559,t:1526930160389};\\\", \\\"{x:1406,y:559,t:1526930160407};\\\", \\\"{x:1407,y:559,t:1526930160423};\\\", \\\"{x:1408,y:559,t:1526930160439};\\\", \\\"{x:1409,y:559,t:1526930160457};\\\", \\\"{x:1410,y:559,t:1526930160473};\\\", \\\"{x:1411,y:559,t:1526930160489};\\\", \\\"{x:1407,y:559,t:1526930160585};\\\", \\\"{x:1390,y:562,t:1526930160592};\\\", \\\"{x:1358,y:563,t:1526930160606};\\\", \\\"{x:1253,y:563,t:1526930160622};\\\", \\\"{x:1067,y:557,t:1526930160640};\\\", \\\"{x:839,y:534,t:1526930160657};\\\", \\\"{x:408,y:527,t:1526930160673};\\\", \\\"{x:141,y:527,t:1526930160690};\\\", \\\"{x:0,y:532,t:1526930160706};\\\", \\\"{x:0,y:552,t:1526930160724};\\\", \\\"{x:0,y:558,t:1526930160739};\\\", \\\"{x:1,y:559,t:1526930160769};\\\", \\\"{x:8,y:559,t:1526930160777};\\\", \\\"{x:25,y:559,t:1526930160789};\\\", \\\"{x:75,y:554,t:1526930160807};\\\", \\\"{x:131,y:545,t:1526930160823};\\\", \\\"{x:190,y:536,t:1526930160840};\\\", \\\"{x:300,y:519,t:1526930160856};\\\", \\\"{x:367,y:508,t:1526930160874};\\\", \\\"{x:407,y:503,t:1526930160889};\\\", \\\"{x:425,y:499,t:1526930160906};\\\", \\\"{x:428,y:498,t:1526930160923};\\\", \\\"{x:425,y:498,t:1526930161049};\\\", \\\"{x:420,y:498,t:1526930161056};\\\", \\\"{x:402,y:506,t:1526930161074};\\\", \\\"{x:388,y:513,t:1526930161091};\\\", \\\"{x:375,y:522,t:1526930161107};\\\", \\\"{x:371,y:525,t:1526930161124};\\\", \\\"{x:370,y:525,t:1526930161141};\\\", \\\"{x:371,y:525,t:1526930161156};\\\", \\\"{x:377,y:526,t:1526930161173};\\\", \\\"{x:403,y:526,t:1526930161191};\\\", \\\"{x:434,y:526,t:1526930161207};\\\", \\\"{x:473,y:526,t:1526930161223};\\\", \\\"{x:515,y:526,t:1526930161241};\\\", \\\"{x:561,y:526,t:1526930161256};\\\", \\\"{x:578,y:526,t:1526930161273};\\\", \\\"{x:588,y:526,t:1526930161290};\\\", \\\"{x:589,y:526,t:1526930161307};\\\", \\\"{x:590,y:526,t:1526930161401};\\\", \\\"{x:591,y:526,t:1526930161505};\\\", \\\"{x:593,y:525,t:1526930161512};\\\", \\\"{x:593,y:524,t:1526930161525};\\\", \\\"{x:596,y:520,t:1526930161540};\\\", \\\"{x:598,y:516,t:1526930161557};\\\", \\\"{x:602,y:512,t:1526930161574};\\\", \\\"{x:604,y:510,t:1526930161591};\\\", \\\"{x:604,y:508,t:1526930161607};\\\", \\\"{x:605,y:507,t:1526930161623};\\\", \\\"{x:606,y:506,t:1526930161713};\\\", \\\"{x:607,y:505,t:1526930161920};\\\", \\\"{x:599,y:505,t:1526930161945};\\\", \\\"{x:594,y:505,t:1526930161957};\\\", \\\"{x:577,y:510,t:1526930161974};\\\", \\\"{x:557,y:514,t:1526930161990};\\\", \\\"{x:534,y:525,t:1526930162007};\\\", \\\"{x:500,y:541,t:1526930162025};\\\", \\\"{x:477,y:553,t:1526930162041};\\\", \\\"{x:460,y:561,t:1526930162058};\\\", \\\"{x:447,y:571,t:1526930162075};\\\", \\\"{x:433,y:576,t:1526930162090};\\\", \\\"{x:417,y:582,t:1526930162107};\\\", \\\"{x:399,y:592,t:1526930162124};\\\", \\\"{x:381,y:600,t:1526930162142};\\\", \\\"{x:361,y:609,t:1526930162158};\\\", \\\"{x:341,y:619,t:1526930162175};\\\", \\\"{x:321,y:625,t:1526930162190};\\\", \\\"{x:305,y:631,t:1526930162207};\\\", \\\"{x:284,y:637,t:1526930162225};\\\", \\\"{x:273,y:640,t:1526930162242};\\\", \\\"{x:258,y:642,t:1526930162257};\\\", \\\"{x:244,y:646,t:1526930162274};\\\", \\\"{x:231,y:646,t:1526930162290};\\\", \\\"{x:217,y:646,t:1526930162307};\\\", \\\"{x:208,y:646,t:1526930162325};\\\", \\\"{x:192,y:644,t:1526930162340};\\\", \\\"{x:180,y:644,t:1526930162357};\\\", \\\"{x:172,y:643,t:1526930162374};\\\", \\\"{x:167,y:642,t:1526930162392};\\\", \\\"{x:166,y:641,t:1526930162407};\\\", \\\"{x:167,y:639,t:1526930162449};\\\", \\\"{x:174,y:635,t:1526930162458};\\\", \\\"{x:196,y:627,t:1526930162474};\\\", \\\"{x:236,y:610,t:1526930162491};\\\", \\\"{x:298,y:589,t:1526930162508};\\\", \\\"{x:380,y:571,t:1526930162524};\\\", \\\"{x:469,y:559,t:1526930162542};\\\", \\\"{x:542,y:547,t:1526930162558};\\\", \\\"{x:594,y:542,t:1526930162574};\\\", \\\"{x:622,y:540,t:1526930162591};\\\", \\\"{x:647,y:536,t:1526930162609};\\\", \\\"{x:652,y:536,t:1526930162624};\\\", \\\"{x:656,y:536,t:1526930162641};\\\", \\\"{x:658,y:536,t:1526930162658};\\\", \\\"{x:663,y:536,t:1526930162674};\\\", \\\"{x:674,y:536,t:1526930162692};\\\", \\\"{x:685,y:536,t:1526930162707};\\\", \\\"{x:706,y:536,t:1526930162724};\\\", \\\"{x:720,y:536,t:1526930162741};\\\", \\\"{x:729,y:536,t:1526930162758};\\\", \\\"{x:736,y:536,t:1526930162775};\\\", \\\"{x:738,y:536,t:1526930162791};\\\", \\\"{x:744,y:536,t:1526930162807};\\\", \\\"{x:752,y:538,t:1526930162824};\\\", \\\"{x:756,y:538,t:1526930162841};\\\", \\\"{x:758,y:538,t:1526930162857};\\\", \\\"{x:759,y:538,t:1526930162888};\\\", \\\"{x:760,y:538,t:1526930162904};\\\", \\\"{x:762,y:538,t:1526930162912};\\\", \\\"{x:764,y:538,t:1526930162925};\\\", \\\"{x:768,y:537,t:1526930162940};\\\", \\\"{x:770,y:535,t:1526930162957};\\\", \\\"{x:773,y:535,t:1526930162974};\\\", \\\"{x:775,y:535,t:1526930162990};\\\", \\\"{x:776,y:535,t:1526930163007};\\\", \\\"{x:782,y:535,t:1526930163025};\\\", \\\"{x:790,y:535,t:1526930163040};\\\", \\\"{x:799,y:535,t:1526930163058};\\\", \\\"{x:808,y:535,t:1526930163074};\\\", \\\"{x:817,y:535,t:1526930163090};\\\", \\\"{x:822,y:535,t:1526930163108};\\\", \\\"{x:827,y:535,t:1526930163124};\\\", \\\"{x:828,y:535,t:1526930163141};\\\", \\\"{x:829,y:535,t:1526930163161};\\\", \\\"{x:832,y:535,t:1526930163193};\\\", \\\"{x:840,y:537,t:1526930163209};\\\", \\\"{x:848,y:539,t:1526930163225};\\\", \\\"{x:851,y:539,t:1526930163242};\\\", \\\"{x:852,y:539,t:1526930163329};\\\", \\\"{x:849,y:540,t:1526930163481};\\\", \\\"{x:845,y:541,t:1526930163491};\\\", \\\"{x:841,y:544,t:1526930163508};\\\", \\\"{x:835,y:546,t:1526930163526};\\\", \\\"{x:826,y:551,t:1526930163541};\\\", \\\"{x:819,y:555,t:1526930163559};\\\", \\\"{x:814,y:558,t:1526930163576};\\\", \\\"{x:811,y:561,t:1526930163592};\\\", \\\"{x:807,y:563,t:1526930163609};\\\", \\\"{x:800,y:567,t:1526930163625};\\\", \\\"{x:785,y:574,t:1526930163642};\\\", \\\"{x:768,y:584,t:1526930163658};\\\", \\\"{x:743,y:595,t:1526930163675};\\\", \\\"{x:714,y:609,t:1526930163693};\\\", \\\"{x:685,y:621,t:1526930163708};\\\", \\\"{x:657,y:637,t:1526930163726};\\\", \\\"{x:636,y:649,t:1526930163742};\\\", \\\"{x:617,y:660,t:1526930163758};\\\", \\\"{x:606,y:668,t:1526930163776};\\\", \\\"{x:599,y:676,t:1526930163792};\\\", \\\"{x:591,y:681,t:1526930163808};\\\", \\\"{x:586,y:684,t:1526930163824};\\\", \\\"{x:579,y:686,t:1526930163841};\\\", \\\"{x:570,y:688,t:1526930163858};\\\", \\\"{x:559,y:692,t:1526930163875};\\\", \\\"{x:550,y:696,t:1526930163892};\\\", \\\"{x:546,y:697,t:1526930163908};\\\", \\\"{x:538,y:702,t:1526930163924};\\\", \\\"{x:531,y:704,t:1526930163942};\\\", \\\"{x:525,y:708,t:1526930163959};\\\", \\\"{x:519,y:713,t:1526930163974};\\\", \\\"{x:513,y:716,t:1526930163991};\\\", \\\"{x:512,y:718,t:1526930164007};\\\", \\\"{x:509,y:719,t:1526930164025};\\\", \\\"{x:509,y:720,t:1526930164042};\\\", \\\"{x:508,y:722,t:1526930164058};\\\", \\\"{x:506,y:723,t:1526930164076};\\\", \\\"{x:506,y:724,t:1526930164093};\\\", \\\"{x:506,y:726,t:1526930164109};\\\", \\\"{x:505,y:728,t:1526930164125};\\\", \\\"{x:505,y:730,t:1526930164142};\\\", \\\"{x:504,y:732,t:1526930164160};\\\", \\\"{x:503,y:733,t:1526930164175};\\\", \\\"{x:503,y:734,t:1526930164528};\\\", \\\"{x:502,y:734,t:1526930164560};\\\", \\\"{x:500,y:734,t:1526930166000};\\\", \\\"{x:497,y:734,t:1526930166011};\\\", \\\"{x:485,y:734,t:1526930166027};\\\", \\\"{x:474,y:734,t:1526930166043};\\\", \\\"{x:461,y:732,t:1526930166061};\\\", \\\"{x:452,y:730,t:1526930166078};\\\", \\\"{x:442,y:728,t:1526930166093};\\\", \\\"{x:431,y:725,t:1526930166110};\\\", \\\"{x:426,y:723,t:1526930166127};\\\", \\\"{x:420,y:721,t:1526930166143};\\\", \\\"{x:414,y:719,t:1526930166160};\\\", \\\"{x:411,y:716,t:1526930166178};\\\", \\\"{x:409,y:715,t:1526930166193};\\\", \\\"{x:406,y:714,t:1526930166210};\\\", \\\"{x:404,y:712,t:1526930166227};\\\", \\\"{x:402,y:711,t:1526930166243};\\\", \\\"{x:400,y:709,t:1526930166261};\\\", \\\"{x:399,y:707,t:1526930166277};\\\", \\\"{x:397,y:706,t:1526930166293};\\\", \\\"{x:396,y:705,t:1526930166312};\\\", \\\"{x:395,y:704,t:1526930166360};\\\", \\\"{x:394,y:703,t:1526930166377};\\\", \\\"{x:393,y:702,t:1526930166400};\\\", \\\"{x:392,y:701,t:1526930166424};\\\", \\\"{x:392,y:700,t:1526930166488};\\\" ] }, { \\\"rt\\\": 24297, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 540896, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:392,y:699,t:1526930168577};\\\", \\\"{x:392,y:696,t:1526930168585};\\\", \\\"{x:392,y:694,t:1526930168595};\\\", \\\"{x:392,y:689,t:1526930168612};\\\", \\\"{x:395,y:683,t:1526930168630};\\\", \\\"{x:398,y:680,t:1526930168646};\\\", \\\"{x:399,y:675,t:1526930168663};\\\", \\\"{x:401,y:672,t:1526930168679};\\\", \\\"{x:402,y:670,t:1526930168695};\\\", \\\"{x:405,y:666,t:1526930168713};\\\", \\\"{x:407,y:664,t:1526930168730};\\\", \\\"{x:408,y:662,t:1526930168746};\\\", \\\"{x:409,y:661,t:1526930168761};\\\", \\\"{x:410,y:659,t:1526930168785};\\\", \\\"{x:411,y:658,t:1526930168824};\\\", \\\"{x:411,y:657,t:1526930168840};\\\", \\\"{x:412,y:656,t:1526930168848};\\\", \\\"{x:414,y:655,t:1526930168864};\\\", \\\"{x:415,y:654,t:1526930168879};\\\", \\\"{x:416,y:654,t:1526930168895};\\\", \\\"{x:419,y:652,t:1526930168911};\\\", \\\"{x:421,y:650,t:1526930168928};\\\", \\\"{x:424,y:647,t:1526930168945};\\\", \\\"{x:427,y:643,t:1526930168962};\\\", \\\"{x:431,y:638,t:1526930168979};\\\", \\\"{x:435,y:634,t:1526930168995};\\\", \\\"{x:437,y:628,t:1526930169013};\\\", \\\"{x:440,y:626,t:1526930169030};\\\", \\\"{x:441,y:624,t:1526930169046};\\\", \\\"{x:443,y:620,t:1526930169062};\\\", \\\"{x:444,y:618,t:1526930169080};\\\", \\\"{x:447,y:612,t:1526930169097};\\\", \\\"{x:447,y:610,t:1526930169112};\\\", \\\"{x:448,y:608,t:1526930169129};\\\", \\\"{x:449,y:605,t:1526930169147};\\\", \\\"{x:451,y:601,t:1526930169164};\\\", \\\"{x:451,y:599,t:1526930169180};\\\", \\\"{x:453,y:596,t:1526930169197};\\\", \\\"{x:453,y:594,t:1526930169213};\\\", \\\"{x:453,y:593,t:1526930169230};\\\", \\\"{x:454,y:592,t:1526930169247};\\\", \\\"{x:455,y:591,t:1526930169264};\\\", \\\"{x:455,y:590,t:1526930169289};\\\", \\\"{x:455,y:588,t:1526930169297};\\\", \\\"{x:456,y:588,t:1526930169314};\\\", \\\"{x:456,y:587,t:1526930169330};\\\", \\\"{x:457,y:585,t:1526930169347};\\\", \\\"{x:458,y:583,t:1526930169368};\\\", \\\"{x:459,y:581,t:1526930169384};\\\", \\\"{x:460,y:579,t:1526930169408};\\\", \\\"{x:460,y:578,t:1526930169417};\\\", \\\"{x:460,y:576,t:1526930169441};\\\", \\\"{x:461,y:576,t:1526930169448};\\\", \\\"{x:461,y:575,t:1526930169464};\\\", \\\"{x:462,y:573,t:1526930169479};\\\", \\\"{x:463,y:572,t:1526930169496};\\\", \\\"{x:464,y:569,t:1526930169514};\\\", \\\"{x:464,y:568,t:1526930169545};\\\", \\\"{x:465,y:567,t:1526930169593};\\\", \\\"{x:465,y:566,t:1526930169617};\\\", \\\"{x:466,y:566,t:1526930169630};\\\", \\\"{x:466,y:565,t:1526930169647};\\\", \\\"{x:467,y:563,t:1526930169664};\\\", \\\"{x:467,y:562,t:1526930169680};\\\", \\\"{x:467,y:560,t:1526930169696};\\\", \\\"{x:467,y:559,t:1526930169713};\\\", \\\"{x:469,y:557,t:1526930170360};\\\", \\\"{x:469,y:556,t:1526930170369};\\\", \\\"{x:469,y:554,t:1526930170381};\\\", \\\"{x:469,y:549,t:1526930170398};\\\", \\\"{x:469,y:545,t:1526930170413};\\\", \\\"{x:469,y:539,t:1526930170431};\\\", \\\"{x:469,y:538,t:1526930170448};\\\", \\\"{x:470,y:535,t:1526930170463};\\\", \\\"{x:470,y:532,t:1526930170481};\\\", \\\"{x:470,y:531,t:1526930170792};\\\", \\\"{x:470,y:530,t:1526930170801};\\\", \\\"{x:470,y:529,t:1526930170814};\\\", \\\"{x:470,y:528,t:1526930170830};\\\", \\\"{x:470,y:527,t:1526930170848};\\\", \\\"{x:470,y:526,t:1526930170865};\\\", \\\"{x:470,y:525,t:1526930172208};\\\", \\\"{x:470,y:524,t:1526930172217};\\\", \\\"{x:470,y:523,t:1526930172232};\\\", \\\"{x:469,y:523,t:1526930174585};\\\", \\\"{x:470,y:524,t:1526930174601};\\\", \\\"{x:490,y:529,t:1526930174617};\\\", \\\"{x:523,y:539,t:1526930174634};\\\", \\\"{x:578,y:555,t:1526930174651};\\\", \\\"{x:670,y:581,t:1526930174668};\\\", \\\"{x:789,y:616,t:1526930174684};\\\", \\\"{x:924,y:655,t:1526930174701};\\\", \\\"{x:1065,y:696,t:1526930174718};\\\", \\\"{x:1200,y:726,t:1526930174734};\\\", \\\"{x:1294,y:740,t:1526930174751};\\\", \\\"{x:1332,y:747,t:1526930174768};\\\", \\\"{x:1346,y:749,t:1526930174784};\\\", \\\"{x:1347,y:749,t:1526930174801};\\\", \\\"{x:1348,y:749,t:1526930174832};\\\", \\\"{x:1349,y:749,t:1526930174881};\\\", \\\"{x:1348,y:746,t:1526930174896};\\\", \\\"{x:1346,y:744,t:1526930174904};\\\", \\\"{x:1340,y:740,t:1526930174918};\\\", \\\"{x:1317,y:728,t:1526930174934};\\\", \\\"{x:1276,y:702,t:1526930174951};\\\", \\\"{x:1203,y:662,t:1526930174968};\\\", \\\"{x:1091,y:614,t:1526930174984};\\\", \\\"{x:1045,y:596,t:1526930175001};\\\", \\\"{x:1029,y:588,t:1526930175018};\\\", \\\"{x:1024,y:586,t:1526930175035};\\\", \\\"{x:1023,y:585,t:1526930175051};\\\", \\\"{x:1023,y:584,t:1526930175136};\\\", \\\"{x:1023,y:582,t:1526930175153};\\\", \\\"{x:1023,y:580,t:1526930175167};\\\", \\\"{x:1029,y:580,t:1526930175184};\\\", \\\"{x:1036,y:580,t:1526930175201};\\\", \\\"{x:1052,y:584,t:1526930175217};\\\", \\\"{x:1070,y:592,t:1526930175234};\\\", \\\"{x:1092,y:604,t:1526930175251};\\\", \\\"{x:1112,y:614,t:1526930175267};\\\", \\\"{x:1125,y:620,t:1526930175285};\\\", \\\"{x:1129,y:623,t:1526930175301};\\\", \\\"{x:1130,y:624,t:1526930175318};\\\", \\\"{x:1130,y:625,t:1526930175344};\\\", \\\"{x:1130,y:626,t:1526930175361};\\\", \\\"{x:1130,y:627,t:1526930175392};\\\", \\\"{x:1130,y:628,t:1526930175401};\\\", \\\"{x:1125,y:630,t:1526930175418};\\\", \\\"{x:1120,y:631,t:1526930175435};\\\", \\\"{x:1111,y:631,t:1526930175451};\\\", \\\"{x:1103,y:631,t:1526930175468};\\\", \\\"{x:1095,y:631,t:1526930175485};\\\", \\\"{x:1092,y:631,t:1526930175502};\\\", \\\"{x:1089,y:631,t:1526930175518};\\\", \\\"{x:1086,y:631,t:1526930175535};\\\", \\\"{x:1085,y:631,t:1526930175552};\\\", \\\"{x:1083,y:631,t:1526930175568};\\\", \\\"{x:1083,y:630,t:1526930175777};\\\", \\\"{x:1083,y:629,t:1526930175816};\\\", \\\"{x:1084,y:629,t:1526930175873};\\\", \\\"{x:1085,y:629,t:1526930175985};\\\", \\\"{x:1086,y:629,t:1526930178408};\\\", \\\"{x:1086,y:628,t:1526930182232};\\\", \\\"{x:1089,y:628,t:1526930182239};\\\", \\\"{x:1099,y:631,t:1526930182256};\\\", \\\"{x:1113,y:637,t:1526930182273};\\\", \\\"{x:1125,y:643,t:1526930182290};\\\", \\\"{x:1139,y:649,t:1526930182306};\\\", \\\"{x:1154,y:656,t:1526930182323};\\\", \\\"{x:1162,y:660,t:1526930182340};\\\", \\\"{x:1166,y:663,t:1526930182357};\\\", \\\"{x:1167,y:664,t:1526930182373};\\\", \\\"{x:1168,y:665,t:1526930182390};\\\", \\\"{x:1169,y:666,t:1526930182408};\\\", \\\"{x:1170,y:666,t:1526930182424};\\\", \\\"{x:1175,y:666,t:1526930182441};\\\", \\\"{x:1185,y:667,t:1526930182457};\\\", \\\"{x:1195,y:668,t:1526930182473};\\\", \\\"{x:1210,y:672,t:1526930182490};\\\", \\\"{x:1221,y:676,t:1526930182506};\\\", \\\"{x:1236,y:682,t:1526930182523};\\\", \\\"{x:1253,y:691,t:1526930182540};\\\", \\\"{x:1274,y:703,t:1526930182556};\\\", \\\"{x:1295,y:716,t:1526930182573};\\\", \\\"{x:1313,y:730,t:1526930182590};\\\", \\\"{x:1326,y:743,t:1526930182607};\\\", \\\"{x:1334,y:754,t:1526930182623};\\\", \\\"{x:1340,y:765,t:1526930182640};\\\", \\\"{x:1341,y:768,t:1526930182657};\\\", \\\"{x:1342,y:770,t:1526930182673};\\\", \\\"{x:1344,y:772,t:1526930182690};\\\", \\\"{x:1346,y:777,t:1526930182707};\\\", \\\"{x:1348,y:779,t:1526930182724};\\\", \\\"{x:1350,y:782,t:1526930182740};\\\", \\\"{x:1351,y:784,t:1526930182758};\\\", \\\"{x:1351,y:783,t:1526930182880};\\\", \\\"{x:1351,y:781,t:1526930182890};\\\", \\\"{x:1351,y:779,t:1526930182907};\\\", \\\"{x:1351,y:778,t:1526930182923};\\\", \\\"{x:1350,y:775,t:1526930182940};\\\", \\\"{x:1350,y:773,t:1526930182957};\\\", \\\"{x:1350,y:771,t:1526930182973};\\\", \\\"{x:1350,y:770,t:1526930182990};\\\", \\\"{x:1350,y:768,t:1526930183009};\\\", \\\"{x:1349,y:767,t:1526930183040};\\\", \\\"{x:1347,y:766,t:1526930183337};\\\", \\\"{x:1341,y:764,t:1526930183345};\\\", \\\"{x:1331,y:763,t:1526930183358};\\\", \\\"{x:1299,y:755,t:1526930183374};\\\", \\\"{x:1231,y:741,t:1526930183390};\\\", \\\"{x:1135,y:716,t:1526930183408};\\\", \\\"{x:957,y:657,t:1526930183424};\\\", \\\"{x:859,y:627,t:1526930183440};\\\", \\\"{x:809,y:603,t:1526930183457};\\\", \\\"{x:794,y:591,t:1526930183474};\\\", \\\"{x:793,y:587,t:1526930183490};\\\", \\\"{x:795,y:576,t:1526930183507};\\\", \\\"{x:804,y:562,t:1526930183524};\\\", \\\"{x:813,y:554,t:1526930183541};\\\", \\\"{x:821,y:546,t:1526930183558};\\\", \\\"{x:828,y:540,t:1526930183576};\\\", \\\"{x:832,y:535,t:1526930183591};\\\", \\\"{x:836,y:530,t:1526930183608};\\\", \\\"{x:837,y:528,t:1526930183624};\\\", \\\"{x:839,y:527,t:1526930183641};\\\", \\\"{x:839,y:526,t:1526930183784};\\\", \\\"{x:839,y:525,t:1526930183792};\\\", \\\"{x:839,y:522,t:1526930183809};\\\", \\\"{x:839,y:519,t:1526930183825};\\\", \\\"{x:839,y:517,t:1526930183841};\\\", \\\"{x:839,y:516,t:1526930183859};\\\", \\\"{x:838,y:514,t:1526930183875};\\\", \\\"{x:838,y:510,t:1526930183891};\\\", \\\"{x:838,y:509,t:1526930183908};\\\", \\\"{x:838,y:507,t:1526930183927};\\\", \\\"{x:836,y:506,t:1526930184184};\\\", \\\"{x:831,y:506,t:1526930184192};\\\", \\\"{x:817,y:507,t:1526930184208};\\\", \\\"{x:799,y:513,t:1526930184225};\\\", \\\"{x:771,y:520,t:1526930184242};\\\", \\\"{x:730,y:535,t:1526930184259};\\\", \\\"{x:688,y:550,t:1526930184275};\\\", \\\"{x:656,y:560,t:1526930184293};\\\", \\\"{x:621,y:572,t:1526930184309};\\\", \\\"{x:591,y:579,t:1526930184325};\\\", \\\"{x:567,y:585,t:1526930184342};\\\", \\\"{x:540,y:590,t:1526930184358};\\\", \\\"{x:520,y:591,t:1526930184375};\\\", \\\"{x:492,y:595,t:1526930184392};\\\", \\\"{x:474,y:597,t:1526930184408};\\\", \\\"{x:460,y:601,t:1526930184425};\\\", \\\"{x:447,y:602,t:1526930184442};\\\", \\\"{x:436,y:602,t:1526930184458};\\\", \\\"{x:431,y:602,t:1526930184476};\\\", \\\"{x:429,y:602,t:1526930184492};\\\", \\\"{x:427,y:602,t:1526930184508};\\\", \\\"{x:426,y:602,t:1526930184526};\\\", \\\"{x:425,y:602,t:1526930184544};\\\", \\\"{x:424,y:602,t:1526930184559};\\\", \\\"{x:423,y:602,t:1526930184575};\\\", \\\"{x:421,y:602,t:1526930184784};\\\", \\\"{x:420,y:602,t:1526930184792};\\\", \\\"{x:412,y:601,t:1526930184809};\\\", \\\"{x:403,y:596,t:1526930184827};\\\", \\\"{x:388,y:589,t:1526930184843};\\\", \\\"{x:377,y:581,t:1526930184860};\\\", \\\"{x:369,y:575,t:1526930184875};\\\", \\\"{x:366,y:570,t:1526930184892};\\\", \\\"{x:363,y:564,t:1526930184909};\\\", \\\"{x:361,y:559,t:1526930184925};\\\", \\\"{x:359,y:556,t:1526930184942};\\\", \\\"{x:358,y:553,t:1526930184959};\\\", \\\"{x:358,y:551,t:1526930184976};\\\", \\\"{x:358,y:550,t:1526930184992};\\\", \\\"{x:358,y:546,t:1526930185009};\\\", \\\"{x:358,y:544,t:1526930185026};\\\", \\\"{x:358,y:543,t:1526930185042};\\\", \\\"{x:358,y:539,t:1526930185059};\\\", \\\"{x:358,y:536,t:1526930185076};\\\", \\\"{x:360,y:534,t:1526930185092};\\\", \\\"{x:360,y:533,t:1526930185109};\\\", \\\"{x:361,y:532,t:1526930185126};\\\", \\\"{x:361,y:531,t:1526930185152};\\\", \\\"{x:362,y:530,t:1526930185200};\\\", \\\"{x:362,y:529,t:1526930185305};\\\", \\\"{x:360,y:529,t:1526930185312};\\\", \\\"{x:356,y:527,t:1526930185326};\\\", \\\"{x:345,y:525,t:1526930185342};\\\", \\\"{x:324,y:524,t:1526930185359};\\\", \\\"{x:285,y:521,t:1526930185376};\\\", \\\"{x:259,y:520,t:1526930185392};\\\", \\\"{x:241,y:520,t:1526930185408};\\\", \\\"{x:234,y:520,t:1526930185425};\\\", \\\"{x:230,y:520,t:1526930185442};\\\", \\\"{x:228,y:520,t:1526930185458};\\\", \\\"{x:221,y:520,t:1526930185475};\\\", \\\"{x:211,y:520,t:1526930185492};\\\", \\\"{x:200,y:522,t:1526930185508};\\\", \\\"{x:189,y:526,t:1526930185525};\\\", \\\"{x:180,y:530,t:1526930185542};\\\", \\\"{x:174,y:533,t:1526930185559};\\\", \\\"{x:170,y:543,t:1526930185576};\\\", \\\"{x:169,y:553,t:1526930185594};\\\", \\\"{x:166,y:561,t:1526930185610};\\\", \\\"{x:166,y:570,t:1526930185627};\\\", \\\"{x:166,y:578,t:1526930185643};\\\", \\\"{x:165,y:584,t:1526930185660};\\\", \\\"{x:163,y:587,t:1526930185676};\\\", \\\"{x:163,y:588,t:1526930185693};\\\", \\\"{x:163,y:586,t:1526930185768};\\\", \\\"{x:163,y:585,t:1526930185776};\\\", \\\"{x:164,y:578,t:1526930185793};\\\", \\\"{x:166,y:573,t:1526930185809};\\\", \\\"{x:169,y:566,t:1526930185826};\\\", \\\"{x:170,y:563,t:1526930185843};\\\", \\\"{x:172,y:559,t:1526930185861};\\\", \\\"{x:173,y:555,t:1526930185877};\\\", \\\"{x:174,y:555,t:1526930185893};\\\", \\\"{x:174,y:554,t:1526930185910};\\\", \\\"{x:174,y:552,t:1526930185926};\\\", \\\"{x:174,y:551,t:1526930185952};\\\", \\\"{x:174,y:550,t:1526930185976};\\\", \\\"{x:174,y:549,t:1526930186065};\\\", \\\"{x:174,y:547,t:1526930186088};\\\", \\\"{x:172,y:546,t:1526930186096};\\\", \\\"{x:171,y:545,t:1526930186110};\\\", \\\"{x:169,y:545,t:1526930186127};\\\", \\\"{x:167,y:544,t:1526930186144};\\\", \\\"{x:166,y:543,t:1526930186217};\\\", \\\"{x:165,y:543,t:1526930186425};\\\", \\\"{x:164,y:543,t:1526930186432};\\\", \\\"{x:164,y:543,t:1526930186446};\\\", \\\"{x:162,y:543,t:1526930186461};\\\", \\\"{x:161,y:543,t:1526930186480};\\\", \\\"{x:160,y:544,t:1526930186496};\\\", \\\"{x:159,y:545,t:1526930186510};\\\", \\\"{x:158,y:546,t:1526930186527};\\\", \\\"{x:157,y:548,t:1526930186543};\\\", \\\"{x:157,y:549,t:1526930186560};\\\", \\\"{x:157,y:551,t:1526930186577};\\\", \\\"{x:158,y:553,t:1526930186593};\\\", \\\"{x:162,y:556,t:1526930186611};\\\", \\\"{x:166,y:557,t:1526930186627};\\\", \\\"{x:171,y:560,t:1526930186643};\\\", \\\"{x:174,y:562,t:1526930186660};\\\", \\\"{x:175,y:563,t:1526930186678};\\\", \\\"{x:176,y:563,t:1526930186693};\\\", \\\"{x:177,y:563,t:1526930186710};\\\", \\\"{x:178,y:565,t:1526930187504};\\\", \\\"{x:180,y:567,t:1526930187512};\\\", \\\"{x:181,y:568,t:1526930187527};\\\", \\\"{x:183,y:570,t:1526930187544};\\\", \\\"{x:184,y:572,t:1526930187562};\\\", \\\"{x:185,y:572,t:1526930188040};\\\", \\\"{x:186,y:573,t:1526930188072};\\\", \\\"{x:187,y:573,t:1526930188224};\\\", \\\"{x:190,y:573,t:1526930188248};\\\", \\\"{x:192,y:573,t:1526930188264};\\\", \\\"{x:193,y:573,t:1526930188281};\\\", \\\"{x:195,y:572,t:1526930188296};\\\", \\\"{x:197,y:572,t:1526930188311};\\\", \\\"{x:207,y:571,t:1526930188328};\\\", \\\"{x:217,y:571,t:1526930188345};\\\", \\\"{x:232,y:571,t:1526930188362};\\\", \\\"{x:251,y:571,t:1526930188378};\\\", \\\"{x:269,y:571,t:1526930188396};\\\", \\\"{x:285,y:572,t:1526930188411};\\\", \\\"{x:307,y:575,t:1526930188428};\\\", \\\"{x:332,y:576,t:1526930188445};\\\", \\\"{x:358,y:578,t:1526930188461};\\\", \\\"{x:384,y:579,t:1526930188478};\\\", \\\"{x:411,y:580,t:1526930188495};\\\", \\\"{x:434,y:580,t:1526930188512};\\\", \\\"{x:461,y:580,t:1526930188528};\\\", \\\"{x:471,y:580,t:1526930188546};\\\", \\\"{x:478,y:580,t:1526930188562};\\\", \\\"{x:481,y:580,t:1526930188578};\\\", \\\"{x:482,y:580,t:1526930188633};\\\", \\\"{x:483,y:580,t:1526930189496};\\\", \\\"{x:483,y:579,t:1526930189513};\\\", \\\"{x:485,y:579,t:1526930190548};\\\", \\\"{x:488,y:584,t:1526930190556};\\\", \\\"{x:495,y:591,t:1526930190568};\\\", \\\"{x:516,y:604,t:1526930190586};\\\", \\\"{x:543,y:619,t:1526930190601};\\\", \\\"{x:562,y:630,t:1526930190618};\\\", \\\"{x:569,y:636,t:1526930190635};\\\", \\\"{x:570,y:637,t:1526930190652};\\\", \\\"{x:570,y:639,t:1526930190668};\\\", \\\"{x:570,y:651,t:1526930190684};\\\", \\\"{x:570,y:666,t:1526930190700};\\\", \\\"{x:570,y:667,t:1526930190724};\\\", \\\"{x:568,y:669,t:1526930190740};\\\", \\\"{x:567,y:670,t:1526930190750};\\\", \\\"{x:559,y:677,t:1526930190767};\\\", \\\"{x:551,y:684,t:1526930190785};\\\", \\\"{x:540,y:692,t:1526930190801};\\\", \\\"{x:531,y:698,t:1526930190817};\\\", \\\"{x:522,y:705,t:1526930190834};\\\", \\\"{x:516,y:710,t:1526930190851};\\\", \\\"{x:513,y:714,t:1526930190867};\\\", \\\"{x:507,y:720,t:1526930190884};\\\", \\\"{x:504,y:723,t:1526930190901};\\\", \\\"{x:501,y:727,t:1526930190917};\\\", \\\"{x:500,y:728,t:1526930190940};\\\", \\\"{x:498,y:728,t:1526930191204};\\\", \\\"{x:496,y:728,t:1526930191220};\\\", \\\"{x:495,y:728,t:1526930191246};\\\", \\\"{x:494,y:728,t:1526930191268};\\\", \\\"{x:494,y:727,t:1526930191331};\\\", \\\"{x:494,y:726,t:1526930191356};\\\", \\\"{x:494,y:725,t:1526930191369};\\\", \\\"{x:494,y:724,t:1526930191384};\\\", \\\"{x:494,y:723,t:1526930191401};\\\", \\\"{x:494,y:722,t:1526930191418};\\\", \\\"{x:494,y:721,t:1526930191434};\\\", \\\"{x:494,y:720,t:1526930191500};\\\", \\\"{x:494,y:719,t:1526930191540};\\\", \\\"{x:494,y:718,t:1526930191564};\\\", \\\"{x:494,y:717,t:1526930191587};\\\", \\\"{x:495,y:716,t:1526930191601};\\\", \\\"{x:496,y:715,t:1526930191620};\\\", \\\"{x:497,y:714,t:1526930191636};\\\", \\\"{x:497,y:713,t:1526930191740};\\\", \\\"{x:498,y:712,t:1526930191752};\\\", \\\"{x:498,y:711,t:1526930191768};\\\", \\\"{x:499,y:710,t:1526930191785};\\\", \\\"{x:500,y:708,t:1526930191802};\\\", \\\"{x:501,y:707,t:1526930191852};\\\" ] }, { \\\"rt\\\": 68861, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 611003, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -E -E -E -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:704,t:1526930192469};\\\", \\\"{x:502,y:703,t:1526930192596};\\\", \\\"{x:502,y:702,t:1526930192611};\\\", \\\"{x:502,y:700,t:1526930192628};\\\", \\\"{x:502,y:699,t:1526930192635};\\\", \\\"{x:502,y:697,t:1526930192652};\\\", \\\"{x:502,y:696,t:1526930192669};\\\", \\\"{x:502,y:694,t:1526930192685};\\\", \\\"{x:502,y:693,t:1526930192703};\\\", \\\"{x:502,y:692,t:1526930192719};\\\", \\\"{x:502,y:691,t:1526930192736};\\\", \\\"{x:502,y:690,t:1526930192796};\\\", \\\"{x:502,y:689,t:1526930193108};\\\", \\\"{x:502,y:687,t:1526930193119};\\\", \\\"{x:502,y:686,t:1526930193137};\\\", \\\"{x:500,y:683,t:1526930193153};\\\", \\\"{x:499,y:682,t:1526930193170};\\\", \\\"{x:499,y:681,t:1526930193187};\\\", \\\"{x:499,y:680,t:1526930193212};\\\", \\\"{x:498,y:679,t:1526930193428};\\\", \\\"{x:498,y:678,t:1526930193444};\\\", \\\"{x:498,y:677,t:1526930193453};\\\", \\\"{x:497,y:673,t:1526930193470};\\\", \\\"{x:493,y:664,t:1526930193487};\\\", \\\"{x:483,y:648,t:1526930193502};\\\", \\\"{x:468,y:623,t:1526930193520};\\\", \\\"{x:435,y:573,t:1526930193537};\\\", \\\"{x:401,y:510,t:1526930193554};\\\", \\\"{x:363,y:447,t:1526930193570};\\\", \\\"{x:320,y:376,t:1526930193587};\\\", \\\"{x:282,y:310,t:1526930193604};\\\", \\\"{x:250,y:258,t:1526930193619};\\\", \\\"{x:228,y:217,t:1526930193637};\\\", \\\"{x:221,y:206,t:1526930193653};\\\", \\\"{x:220,y:203,t:1526930193669};\\\", \\\"{x:220,y:206,t:1526930193748};\\\", \\\"{x:223,y:212,t:1526930193755};\\\", \\\"{x:229,y:221,t:1526930193770};\\\", \\\"{x:247,y:239,t:1526930193786};\\\", \\\"{x:278,y:262,t:1526930193803};\\\", \\\"{x:403,y:328,t:1526930193820};\\\", \\\"{x:522,y:381,t:1526930193836};\\\", \\\"{x:661,y:426,t:1526930193853};\\\", \\\"{x:812,y:466,t:1526930193870};\\\", \\\"{x:984,y:490,t:1526930193887};\\\", \\\"{x:1161,y:520,t:1526930193903};\\\", \\\"{x:1312,y:526,t:1526930193920};\\\", \\\"{x:1425,y:526,t:1526930193937};\\\", \\\"{x:1489,y:526,t:1526930193953};\\\", \\\"{x:1504,y:526,t:1526930193970};\\\", \\\"{x:1507,y:526,t:1526930193987};\\\", \\\"{x:1507,y:525,t:1526930194003};\\\", \\\"{x:1495,y:512,t:1526930194019};\\\", \\\"{x:1478,y:503,t:1526930194037};\\\", \\\"{x:1437,y:486,t:1526930194053};\\\", \\\"{x:1365,y:466,t:1526930194071};\\\", \\\"{x:1286,y:450,t:1526930194087};\\\", \\\"{x:1239,y:444,t:1526930194103};\\\", \\\"{x:1200,y:440,t:1526930194120};\\\", \\\"{x:1174,y:439,t:1526930194137};\\\", \\\"{x:1156,y:439,t:1526930194154};\\\", \\\"{x:1146,y:439,t:1526930194171};\\\", \\\"{x:1139,y:443,t:1526930194187};\\\", \\\"{x:1135,y:448,t:1526930194204};\\\", \\\"{x:1130,y:454,t:1526930194221};\\\", \\\"{x:1127,y:458,t:1526930194237};\\\", \\\"{x:1123,y:464,t:1526930194254};\\\", \\\"{x:1115,y:472,t:1526930194271};\\\", \\\"{x:1107,y:483,t:1526930194288};\\\", \\\"{x:1101,y:491,t:1526930194304};\\\", \\\"{x:1094,y:498,t:1526930194321};\\\", \\\"{x:1090,y:502,t:1526930194338};\\\", \\\"{x:1086,y:507,t:1526930194355};\\\", \\\"{x:1085,y:510,t:1526930194370};\\\", \\\"{x:1085,y:512,t:1526930194387};\\\", \\\"{x:1084,y:513,t:1526930194404};\\\", \\\"{x:1084,y:514,t:1526930194644};\\\", \\\"{x:1084,y:515,t:1526930194660};\\\", \\\"{x:1084,y:516,t:1526930194676};\\\", \\\"{x:1084,y:518,t:1526930194687};\\\", \\\"{x:1084,y:519,t:1526930194704};\\\", \\\"{x:1084,y:521,t:1526930194722};\\\", \\\"{x:1084,y:522,t:1526930194738};\\\", \\\"{x:1085,y:522,t:1526930194796};\\\", \\\"{x:1085,y:524,t:1526930194860};\\\", \\\"{x:1086,y:525,t:1526930194908};\\\", \\\"{x:1085,y:524,t:1526930195612};\\\", \\\"{x:1082,y:522,t:1526930195628};\\\", \\\"{x:1082,y:520,t:1526930195643};\\\", \\\"{x:1081,y:518,t:1526930195655};\\\", \\\"{x:1080,y:518,t:1526930195676};\\\", \\\"{x:1079,y:517,t:1526930195688};\\\", \\\"{x:1078,y:516,t:1526930195716};\\\", \\\"{x:1078,y:515,t:1526930195772};\\\", \\\"{x:1077,y:514,t:1526930195788};\\\", \\\"{x:1076,y:513,t:1526930195806};\\\", \\\"{x:1075,y:512,t:1526930195822};\\\", \\\"{x:1074,y:511,t:1526930195838};\\\", \\\"{x:1073,y:509,t:1526930195855};\\\", \\\"{x:1072,y:508,t:1526930195873};\\\", \\\"{x:1072,y:507,t:1526930195924};\\\", \\\"{x:1071,y:507,t:1526930196028};\\\", \\\"{x:1070,y:507,t:1526930196044};\\\", \\\"{x:1070,y:506,t:1526930196056};\\\", \\\"{x:1069,y:506,t:1526930196148};\\\", \\\"{x:1069,y:505,t:1526930196172};\\\", \\\"{x:1068,y:504,t:1526930196196};\\\", \\\"{x:1067,y:503,t:1526930196227};\\\", \\\"{x:1064,y:502,t:1526930196316};\\\", \\\"{x:1065,y:502,t:1526930198380};\\\", \\\"{x:1066,y:502,t:1526930198420};\\\", \\\"{x:1067,y:502,t:1526930198452};\\\", \\\"{x:1067,y:503,t:1526930198491};\\\", \\\"{x:1068,y:505,t:1526930198524};\\\", \\\"{x:1068,y:506,t:1526930198547};\\\", \\\"{x:1068,y:508,t:1526930198572};\\\", \\\"{x:1068,y:509,t:1526930198588};\\\", \\\"{x:1068,y:511,t:1526930198603};\\\", \\\"{x:1068,y:512,t:1526930198612};\\\", \\\"{x:1069,y:513,t:1526930198626};\\\", \\\"{x:1070,y:514,t:1526930198642};\\\", \\\"{x:1071,y:516,t:1526930198658};\\\", \\\"{x:1072,y:518,t:1526930198676};\\\", \\\"{x:1072,y:519,t:1526930198700};\\\", \\\"{x:1073,y:520,t:1526930198708};\\\", \\\"{x:1073,y:521,t:1526930198725};\\\", \\\"{x:1073,y:522,t:1526930198764};\\\", \\\"{x:1073,y:523,t:1526930198845};\\\", \\\"{x:1074,y:524,t:1526930199397};\\\", \\\"{x:1075,y:524,t:1526930199410};\\\", \\\"{x:1076,y:525,t:1526930199426};\\\", \\\"{x:1080,y:527,t:1526930199444};\\\", \\\"{x:1085,y:530,t:1526930199460};\\\", \\\"{x:1090,y:532,t:1526930199476};\\\", \\\"{x:1095,y:533,t:1526930199493};\\\", \\\"{x:1100,y:535,t:1526930199510};\\\", \\\"{x:1112,y:539,t:1526930199528};\\\", \\\"{x:1126,y:542,t:1526930199544};\\\", \\\"{x:1144,y:547,t:1526930199560};\\\", \\\"{x:1160,y:551,t:1526930199578};\\\", \\\"{x:1180,y:558,t:1526930199593};\\\", \\\"{x:1198,y:564,t:1526930199610};\\\", \\\"{x:1220,y:573,t:1526930199628};\\\", \\\"{x:1245,y:593,t:1526930199643};\\\", \\\"{x:1283,y:628,t:1526930199661};\\\", \\\"{x:1317,y:652,t:1526930199676};\\\", \\\"{x:1349,y:677,t:1526930199693};\\\", \\\"{x:1373,y:697,t:1526930199711};\\\", \\\"{x:1394,y:714,t:1526930199727};\\\", \\\"{x:1407,y:724,t:1526930199744};\\\", \\\"{x:1410,y:728,t:1526930199760};\\\", \\\"{x:1410,y:730,t:1526930199778};\\\", \\\"{x:1410,y:731,t:1526930199892};\\\", \\\"{x:1407,y:731,t:1526930199908};\\\", \\\"{x:1403,y:731,t:1526930199916};\\\", \\\"{x:1401,y:731,t:1526930199927};\\\", \\\"{x:1393,y:731,t:1526930199943};\\\", \\\"{x:1387,y:731,t:1526930199960};\\\", \\\"{x:1382,y:731,t:1526930199977};\\\", \\\"{x:1379,y:731,t:1526930199994};\\\", \\\"{x:1376,y:732,t:1526930200010};\\\", \\\"{x:1374,y:734,t:1526930200027};\\\", \\\"{x:1369,y:739,t:1526930200044};\\\", \\\"{x:1366,y:741,t:1526930200060};\\\", \\\"{x:1363,y:745,t:1526930200077};\\\", \\\"{x:1352,y:753,t:1526930200094};\\\", \\\"{x:1349,y:757,t:1526930200111};\\\", \\\"{x:1347,y:759,t:1526930200128};\\\", \\\"{x:1344,y:760,t:1526930200144};\\\", \\\"{x:1343,y:762,t:1526930200161};\\\", \\\"{x:1341,y:763,t:1526930200177};\\\", \\\"{x:1339,y:766,t:1526930200194};\\\", \\\"{x:1338,y:767,t:1526930200212};\\\", \\\"{x:1338,y:768,t:1526930200226};\\\", \\\"{x:1336,y:770,t:1526930200243};\\\", \\\"{x:1335,y:772,t:1526930200260};\\\", \\\"{x:1334,y:773,t:1526930200277};\\\", \\\"{x:1333,y:776,t:1526930200294};\\\", \\\"{x:1330,y:781,t:1526930200311};\\\", \\\"{x:1329,y:782,t:1526930200328};\\\", \\\"{x:1328,y:784,t:1526930200344};\\\", \\\"{x:1328,y:785,t:1526930200371};\\\", \\\"{x:1327,y:784,t:1526930200564};\\\", \\\"{x:1327,y:781,t:1526930200577};\\\", \\\"{x:1324,y:770,t:1526930200594};\\\", \\\"{x:1324,y:765,t:1526930200611};\\\", \\\"{x:1324,y:753,t:1526930200627};\\\", \\\"{x:1323,y:742,t:1526930200644};\\\", \\\"{x:1322,y:734,t:1526930200661};\\\", \\\"{x:1319,y:725,t:1526930200677};\\\", \\\"{x:1317,y:713,t:1526930200694};\\\", \\\"{x:1313,y:698,t:1526930200711};\\\", \\\"{x:1309,y:684,t:1526930200728};\\\", \\\"{x:1307,y:676,t:1526930200745};\\\", \\\"{x:1304,y:666,t:1526930200760};\\\", \\\"{x:1303,y:656,t:1526930200777};\\\", \\\"{x:1300,y:647,t:1526930200794};\\\", \\\"{x:1298,y:641,t:1526930200811};\\\", \\\"{x:1295,y:631,t:1526930200828};\\\", \\\"{x:1294,y:624,t:1526930200845};\\\", \\\"{x:1294,y:618,t:1526930200860};\\\", \\\"{x:1291,y:613,t:1526930200878};\\\", \\\"{x:1290,y:606,t:1526930200895};\\\", \\\"{x:1289,y:601,t:1526930200911};\\\", \\\"{x:1288,y:595,t:1526930200928};\\\", \\\"{x:1288,y:592,t:1526930200945};\\\", \\\"{x:1287,y:590,t:1526930200961};\\\", \\\"{x:1286,y:589,t:1526930200978};\\\", \\\"{x:1286,y:586,t:1526930200995};\\\", \\\"{x:1286,y:582,t:1526930201012};\\\", \\\"{x:1284,y:580,t:1526930201028};\\\", \\\"{x:1284,y:579,t:1526930201045};\\\", \\\"{x:1284,y:578,t:1526930201068};\\\", \\\"{x:1284,y:577,t:1526930201100};\\\", \\\"{x:1284,y:576,t:1526930201124};\\\", \\\"{x:1284,y:575,t:1526930201156};\\\", \\\"{x:1284,y:573,t:1526930201172};\\\", \\\"{x:1285,y:572,t:1526930201180};\\\", \\\"{x:1285,y:570,t:1526930201196};\\\", \\\"{x:1286,y:569,t:1526930201212};\\\", \\\"{x:1287,y:567,t:1526930201228};\\\", \\\"{x:1288,y:566,t:1526930201245};\\\", \\\"{x:1288,y:564,t:1526930201276};\\\", \\\"{x:1288,y:563,t:1526930201292};\\\", \\\"{x:1288,y:562,t:1526930201300};\\\", \\\"{x:1288,y:561,t:1526930201312};\\\", \\\"{x:1288,y:559,t:1526930201329};\\\", \\\"{x:1288,y:557,t:1526930201345};\\\", \\\"{x:1287,y:554,t:1526930201362};\\\", \\\"{x:1287,y:553,t:1526930201378};\\\", \\\"{x:1285,y:552,t:1526930201395};\\\", \\\"{x:1282,y:550,t:1526930201412};\\\", \\\"{x:1277,y:549,t:1526930201429};\\\", \\\"{x:1268,y:547,t:1526930201445};\\\", \\\"{x:1254,y:546,t:1526930201462};\\\", \\\"{x:1243,y:546,t:1526930201479};\\\", \\\"{x:1230,y:545,t:1526930201495};\\\", \\\"{x:1220,y:545,t:1526930201511};\\\", \\\"{x:1213,y:546,t:1526930201529};\\\", \\\"{x:1203,y:548,t:1526930201545};\\\", \\\"{x:1188,y:554,t:1526930201562};\\\", \\\"{x:1175,y:563,t:1526930201579};\\\", \\\"{x:1158,y:576,t:1526930201595};\\\", \\\"{x:1141,y:594,t:1526930201612};\\\", \\\"{x:1132,y:609,t:1526930201629};\\\", \\\"{x:1126,y:629,t:1526930201645};\\\", \\\"{x:1117,y:657,t:1526930201662};\\\", \\\"{x:1110,y:685,t:1526930201679};\\\", \\\"{x:1101,y:713,t:1526930201696};\\\", \\\"{x:1098,y:738,t:1526930201712};\\\", \\\"{x:1096,y:759,t:1526930201729};\\\", \\\"{x:1094,y:774,t:1526930201746};\\\", \\\"{x:1094,y:788,t:1526930201762};\\\", \\\"{x:1097,y:797,t:1526930201779};\\\", \\\"{x:1103,y:812,t:1526930201797};\\\", \\\"{x:1110,y:822,t:1526930201813};\\\", \\\"{x:1118,y:832,t:1526930201829};\\\", \\\"{x:1124,y:841,t:1526930201847};\\\", \\\"{x:1132,y:848,t:1526930201863};\\\", \\\"{x:1142,y:857,t:1526930201879};\\\", \\\"{x:1154,y:864,t:1526930201897};\\\", \\\"{x:1166,y:869,t:1526930201912};\\\", \\\"{x:1180,y:874,t:1526930201930};\\\", \\\"{x:1193,y:878,t:1526930201946};\\\", \\\"{x:1206,y:881,t:1526930201963};\\\", \\\"{x:1219,y:882,t:1526930201979};\\\", \\\"{x:1234,y:883,t:1526930201996};\\\", \\\"{x:1243,y:883,t:1526930202012};\\\", \\\"{x:1248,y:882,t:1526930202029};\\\", \\\"{x:1254,y:879,t:1526930202046};\\\", \\\"{x:1260,y:874,t:1526930202064};\\\", \\\"{x:1264,y:866,t:1526930202079};\\\", \\\"{x:1266,y:851,t:1526930202096};\\\", \\\"{x:1270,y:832,t:1526930202114};\\\", \\\"{x:1271,y:810,t:1526930202130};\\\", \\\"{x:1271,y:787,t:1526930202147};\\\", \\\"{x:1271,y:763,t:1526930202164};\\\", \\\"{x:1271,y:732,t:1526930202180};\\\", \\\"{x:1274,y:700,t:1526930202197};\\\", \\\"{x:1276,y:683,t:1526930202213};\\\", \\\"{x:1279,y:669,t:1526930202229};\\\", \\\"{x:1282,y:652,t:1526930202246};\\\", \\\"{x:1286,y:642,t:1526930202263};\\\", \\\"{x:1290,y:629,t:1526930202280};\\\", \\\"{x:1294,y:617,t:1526930202296};\\\", \\\"{x:1298,y:606,t:1526930202313};\\\", \\\"{x:1300,y:599,t:1526930202330};\\\", \\\"{x:1303,y:586,t:1526930202345};\\\", \\\"{x:1304,y:578,t:1526930202363};\\\", \\\"{x:1304,y:573,t:1526930202379};\\\", \\\"{x:1305,y:569,t:1526930202396};\\\", \\\"{x:1305,y:566,t:1526930202412};\\\", \\\"{x:1305,y:563,t:1526930202430};\\\", \\\"{x:1305,y:561,t:1526930202446};\\\", \\\"{x:1304,y:557,t:1526930202463};\\\", \\\"{x:1303,y:555,t:1526930202480};\\\", \\\"{x:1303,y:554,t:1526930202497};\\\", \\\"{x:1301,y:552,t:1526930202513};\\\", \\\"{x:1300,y:551,t:1526930202530};\\\", \\\"{x:1300,y:550,t:1526930202564};\\\", \\\"{x:1300,y:549,t:1526930202613};\\\", \\\"{x:1300,y:548,t:1526930202637};\\\", \\\"{x:1298,y:547,t:1526930207028};\\\", \\\"{x:1295,y:547,t:1526930207036};\\\", \\\"{x:1292,y:547,t:1526930207051};\\\", \\\"{x:1288,y:548,t:1526930207068};\\\", \\\"{x:1285,y:550,t:1526930207085};\\\", \\\"{x:1284,y:551,t:1526930207101};\\\", \\\"{x:1283,y:551,t:1526930207118};\\\", \\\"{x:1282,y:552,t:1526930207164};\\\", \\\"{x:1282,y:553,t:1526930207172};\\\", \\\"{x:1282,y:554,t:1526930207252};\\\", \\\"{x:1282,y:555,t:1526930207268};\\\", \\\"{x:1281,y:556,t:1526930207285};\\\", \\\"{x:1280,y:556,t:1526930207302};\\\", \\\"{x:1280,y:557,t:1526930207318};\\\", \\\"{x:1280,y:559,t:1526930207340};\\\", \\\"{x:1279,y:559,t:1526930207368};\\\", \\\"{x:1279,y:560,t:1526930207452};\\\", \\\"{x:1276,y:563,t:1526930211555};\\\", \\\"{x:1276,y:564,t:1526930211574};\\\", \\\"{x:1274,y:565,t:1526930211589};\\\", \\\"{x:1275,y:569,t:1526930211949};\\\", \\\"{x:1278,y:574,t:1526930211957};\\\", \\\"{x:1284,y:585,t:1526930211974};\\\", \\\"{x:1296,y:600,t:1526930211991};\\\", \\\"{x:1310,y:616,t:1526930212008};\\\", \\\"{x:1323,y:634,t:1526930212023};\\\", \\\"{x:1334,y:649,t:1526930212040};\\\", \\\"{x:1340,y:661,t:1526930212057};\\\", \\\"{x:1349,y:675,t:1526930212073};\\\", \\\"{x:1351,y:686,t:1526930212090};\\\", \\\"{x:1355,y:697,t:1526930212107};\\\", \\\"{x:1358,y:706,t:1526930212123};\\\", \\\"{x:1365,y:723,t:1526930212141};\\\", \\\"{x:1368,y:731,t:1526930212158};\\\", \\\"{x:1372,y:739,t:1526930212173};\\\", \\\"{x:1377,y:748,t:1526930212190};\\\", \\\"{x:1384,y:758,t:1526930212207};\\\", \\\"{x:1390,y:766,t:1526930212224};\\\", \\\"{x:1395,y:772,t:1526930212240};\\\", \\\"{x:1400,y:775,t:1526930212258};\\\", \\\"{x:1405,y:779,t:1526930212275};\\\", \\\"{x:1409,y:782,t:1526930212291};\\\", \\\"{x:1415,y:786,t:1526930212308};\\\", \\\"{x:1422,y:792,t:1526930212323};\\\", \\\"{x:1426,y:795,t:1526930212340};\\\", \\\"{x:1429,y:798,t:1526930212357};\\\", \\\"{x:1433,y:802,t:1526930212374};\\\", \\\"{x:1439,y:806,t:1526930212391};\\\", \\\"{x:1447,y:813,t:1526930212407};\\\", \\\"{x:1455,y:818,t:1526930212424};\\\", \\\"{x:1459,y:823,t:1526930212440};\\\", \\\"{x:1464,y:825,t:1526930212457};\\\", \\\"{x:1465,y:827,t:1526930212474};\\\", \\\"{x:1467,y:827,t:1526930212540};\\\", \\\"{x:1469,y:827,t:1526930212668};\\\", \\\"{x:1470,y:827,t:1526930212700};\\\", \\\"{x:1471,y:826,t:1526930212716};\\\", \\\"{x:1473,y:826,t:1526930212724};\\\", \\\"{x:1479,y:826,t:1526930212740};\\\", \\\"{x:1491,y:826,t:1526930212758};\\\", \\\"{x:1508,y:826,t:1526930212774};\\\", \\\"{x:1529,y:826,t:1526930212791};\\\", \\\"{x:1545,y:826,t:1526930212807};\\\", \\\"{x:1562,y:829,t:1526930212824};\\\", \\\"{x:1573,y:829,t:1526930212842};\\\", \\\"{x:1579,y:829,t:1526930212857};\\\", \\\"{x:1587,y:830,t:1526930212875};\\\", \\\"{x:1593,y:830,t:1526930212892};\\\", \\\"{x:1602,y:831,t:1526930212908};\\\", \\\"{x:1605,y:832,t:1526930212924};\\\", \\\"{x:1608,y:833,t:1526930212942};\\\", \\\"{x:1609,y:833,t:1526930212958};\\\", \\\"{x:1611,y:833,t:1526930212974};\\\", \\\"{x:1612,y:833,t:1526930213020};\\\", \\\"{x:1613,y:833,t:1526930213044};\\\", \\\"{x:1614,y:833,t:1526930213060};\\\", \\\"{x:1615,y:833,t:1526930213148};\\\", \\\"{x:1616,y:832,t:1526930213325};\\\", \\\"{x:1616,y:831,t:1526930213365};\\\", \\\"{x:1616,y:830,t:1526930213376};\\\", \\\"{x:1616,y:829,t:1526930213392};\\\", \\\"{x:1616,y:828,t:1526930213409};\\\", \\\"{x:1616,y:827,t:1526930213427};\\\", \\\"{x:1616,y:826,t:1526930213460};\\\", \\\"{x:1615,y:824,t:1526930213517};\\\", \\\"{x:1614,y:824,t:1526930213684};\\\", \\\"{x:1612,y:824,t:1526930213748};\\\", \\\"{x:1611,y:824,t:1526930213780};\\\", \\\"{x:1611,y:826,t:1526930220549};\\\", \\\"{x:1611,y:827,t:1526930220597};\\\", \\\"{x:1611,y:829,t:1526930220717};\\\", \\\"{x:1611,y:830,t:1526930220741};\\\", \\\"{x:1611,y:831,t:1526930220790};\\\", \\\"{x:1611,y:833,t:1526930220820};\\\", \\\"{x:1611,y:834,t:1526930220861};\\\", \\\"{x:1611,y:835,t:1526930220876};\\\", \\\"{x:1611,y:836,t:1526930220900};\\\", \\\"{x:1611,y:837,t:1526930220940};\\\", \\\"{x:1611,y:838,t:1526930220965};\\\", \\\"{x:1611,y:839,t:1526930221029};\\\", \\\"{x:1611,y:840,t:1526930221061};\\\", \\\"{x:1611,y:841,t:1526930221076};\\\", \\\"{x:1611,y:842,t:1526930221125};\\\", \\\"{x:1611,y:843,t:1526930221140};\\\", \\\"{x:1611,y:844,t:1526930221181};\\\", \\\"{x:1611,y:845,t:1526930221221};\\\", \\\"{x:1611,y:846,t:1526930221244};\\\", \\\"{x:1611,y:847,t:1526930221277};\\\", \\\"{x:1611,y:848,t:1526930221324};\\\", \\\"{x:1611,y:849,t:1526930221443};\\\", \\\"{x:1610,y:849,t:1526930221508};\\\", \\\"{x:1609,y:848,t:1526930221518};\\\", \\\"{x:1608,y:848,t:1526930221533};\\\", \\\"{x:1608,y:846,t:1526930221551};\\\", \\\"{x:1608,y:844,t:1526930221568};\\\", \\\"{x:1607,y:842,t:1526930221584};\\\", \\\"{x:1607,y:841,t:1526930221601};\\\", \\\"{x:1607,y:840,t:1526930221620};\\\", \\\"{x:1607,y:839,t:1526930221634};\\\", \\\"{x:1607,y:838,t:1526930221651};\\\", \\\"{x:1607,y:837,t:1526930221668};\\\", \\\"{x:1607,y:836,t:1526930221684};\\\", \\\"{x:1607,y:835,t:1526930221701};\\\", \\\"{x:1607,y:834,t:1526930221724};\\\", \\\"{x:1607,y:833,t:1526930221739};\\\", \\\"{x:1607,y:832,t:1526930221924};\\\", \\\"{x:1608,y:832,t:1526930221935};\\\", \\\"{x:1610,y:838,t:1526930221951};\\\", \\\"{x:1611,y:842,t:1526930221967};\\\", \\\"{x:1613,y:847,t:1526930221985};\\\", \\\"{x:1613,y:850,t:1526930222001};\\\", \\\"{x:1613,y:852,t:1526930222017};\\\", \\\"{x:1613,y:853,t:1526930222035};\\\", \\\"{x:1613,y:852,t:1526930222132};\\\", \\\"{x:1613,y:850,t:1526930222139};\\\", \\\"{x:1613,y:848,t:1526930222152};\\\", \\\"{x:1613,y:843,t:1526930222167};\\\", \\\"{x:1613,y:839,t:1526930222185};\\\", \\\"{x:1615,y:836,t:1526930222201};\\\", \\\"{x:1615,y:834,t:1526930222218};\\\", \\\"{x:1615,y:833,t:1526930222235};\\\", \\\"{x:1615,y:831,t:1526930222252};\\\", \\\"{x:1615,y:829,t:1526930222268};\\\", \\\"{x:1615,y:828,t:1526930222286};\\\", \\\"{x:1616,y:826,t:1526930222302};\\\", \\\"{x:1616,y:825,t:1526930222324};\\\", \\\"{x:1616,y:824,t:1526930222741};\\\", \\\"{x:1615,y:824,t:1526930222877};\\\", \\\"{x:1614,y:824,t:1526930258696};\\\", \\\"{x:1613,y:824,t:1526930258712};\\\", \\\"{x:1612,y:824,t:1526930258729};\\\", \\\"{x:1611,y:824,t:1526930258745};\\\", \\\"{x:1610,y:824,t:1526930258775};\\\", \\\"{x:1609,y:824,t:1526930258791};\\\", \\\"{x:1605,y:822,t:1526930258799};\\\", \\\"{x:1601,y:820,t:1526930258812};\\\", \\\"{x:1584,y:817,t:1526930258829};\\\", \\\"{x:1558,y:812,t:1526930258847};\\\", \\\"{x:1513,y:800,t:1526930258862};\\\", \\\"{x:1478,y:789,t:1526930258879};\\\", \\\"{x:1458,y:763,t:1526930258896};\\\", \\\"{x:1436,y:734,t:1526930258913};\\\", \\\"{x:1415,y:718,t:1526930258929};\\\", \\\"{x:1380,y:696,t:1526930258946};\\\", \\\"{x:1332,y:670,t:1526930258963};\\\", \\\"{x:1277,y:646,t:1526930258979};\\\", \\\"{x:1238,y:631,t:1526930258996};\\\", \\\"{x:1211,y:619,t:1526930259013};\\\", \\\"{x:1189,y:610,t:1526930259029};\\\", \\\"{x:1179,y:605,t:1526930259046};\\\", \\\"{x:1169,y:604,t:1526930259062};\\\", \\\"{x:1156,y:600,t:1526930259079};\\\", \\\"{x:1151,y:596,t:1526930259096};\\\", \\\"{x:1145,y:595,t:1526930259112};\\\", \\\"{x:1141,y:593,t:1526930259129};\\\", \\\"{x:1134,y:590,t:1526930259146};\\\", \\\"{x:1133,y:589,t:1526930259163};\\\", \\\"{x:1132,y:589,t:1526930259179};\\\", \\\"{x:1132,y:588,t:1526930259296};\\\", \\\"{x:1131,y:587,t:1526930259313};\\\", \\\"{x:1132,y:585,t:1526930259329};\\\", \\\"{x:1138,y:582,t:1526930259346};\\\", \\\"{x:1143,y:581,t:1526930259362};\\\", \\\"{x:1147,y:579,t:1526930259378};\\\", \\\"{x:1151,y:578,t:1526930259395};\\\", \\\"{x:1155,y:577,t:1526930259413};\\\", \\\"{x:1160,y:575,t:1526930259429};\\\", \\\"{x:1164,y:574,t:1526930259446};\\\", \\\"{x:1177,y:570,t:1526930259462};\\\", \\\"{x:1188,y:566,t:1526930259480};\\\", \\\"{x:1196,y:564,t:1526930259495};\\\", \\\"{x:1199,y:563,t:1526930259512};\\\", \\\"{x:1192,y:563,t:1526930259575};\\\", \\\"{x:1175,y:559,t:1526930259584};\\\", \\\"{x:1141,y:558,t:1526930259596};\\\", \\\"{x:1055,y:547,t:1526930259613};\\\", \\\"{x:946,y:528,t:1526930259632};\\\", \\\"{x:827,y:510,t:1526930259647};\\\", \\\"{x:605,y:465,t:1526930259679};\\\", \\\"{x:579,y:461,t:1526930259702};\\\", \\\"{x:564,y:459,t:1526930259719};\\\", \\\"{x:562,y:459,t:1526930259736};\\\", \\\"{x:559,y:459,t:1526930259751};\\\", \\\"{x:555,y:464,t:1526930259768};\\\", \\\"{x:551,y:467,t:1526930259785};\\\", \\\"{x:548,y:470,t:1526930259803};\\\", \\\"{x:547,y:470,t:1526930259819};\\\", \\\"{x:548,y:471,t:1526930259887};\\\", \\\"{x:563,y:474,t:1526930259903};\\\", \\\"{x:585,y:478,t:1526930259918};\\\", \\\"{x:604,y:480,t:1526930259935};\\\", \\\"{x:618,y:483,t:1526930259953};\\\", \\\"{x:623,y:485,t:1526930259969};\\\", \\\"{x:624,y:486,t:1526930260039};\\\", \\\"{x:626,y:486,t:1526930260055};\\\", \\\"{x:626,y:487,t:1526930260070};\\\", \\\"{x:626,y:489,t:1526930260087};\\\", \\\"{x:626,y:493,t:1526930260111};\\\", \\\"{x:626,y:495,t:1526930260127};\\\", \\\"{x:625,y:497,t:1526930260143};\\\", \\\"{x:624,y:500,t:1526930260160};\\\", \\\"{x:622,y:502,t:1526930260177};\\\", \\\"{x:621,y:503,t:1526930260194};\\\", \\\"{x:620,y:504,t:1526930260215};\\\", \\\"{x:619,y:504,t:1526930260430};\\\", \\\"{x:618,y:504,t:1526930260444};\\\", \\\"{x:617,y:504,t:1526930260460};\\\", \\\"{x:616,y:504,t:1526930260470};\\\", \\\"{x:616,y:504,t:1526930260477};\\\", \\\"{x:614,y:504,t:1526930260494};\\\", \\\"{x:613,y:504,t:1526930260518};\\\", \\\"{x:612,y:506,t:1526930260550};\\\", \\\"{x:612,y:508,t:1526930260561};\\\", \\\"{x:609,y:517,t:1526930260577};\\\", \\\"{x:604,y:529,t:1526930260594};\\\", \\\"{x:594,y:547,t:1526930260610};\\\", \\\"{x:586,y:565,t:1526930260627};\\\", \\\"{x:576,y:585,t:1526930260643};\\\", \\\"{x:566,y:600,t:1526930260661};\\\", \\\"{x:558,y:612,t:1526930260678};\\\", \\\"{x:554,y:623,t:1526930260693};\\\", \\\"{x:547,y:637,t:1526930260711};\\\", \\\"{x:544,y:644,t:1526930260727};\\\", \\\"{x:541,y:651,t:1526930260743};\\\", \\\"{x:536,y:665,t:1526930260760};\\\", \\\"{x:533,y:672,t:1526930260777};\\\", \\\"{x:532,y:680,t:1526930260793};\\\", \\\"{x:529,y:688,t:1526930260811};\\\", \\\"{x:529,y:692,t:1526930260827};\\\", \\\"{x:528,y:694,t:1526930260844};\\\", \\\"{x:528,y:695,t:1526930260860};\\\", \\\"{x:528,y:696,t:1526930260879};\\\", \\\"{x:528,y:697,t:1526930260935};\\\", \\\"{x:528,y:698,t:1526930260943};\\\", \\\"{x:527,y:700,t:1526930260967};\\\", \\\"{x:525,y:703,t:1526930260977};\\\", \\\"{x:520,y:707,t:1526930260993};\\\", \\\"{x:515,y:711,t:1526930261010};\\\", \\\"{x:510,y:715,t:1526930261027};\\\", \\\"{x:506,y:719,t:1526930261042};\\\", \\\"{x:504,y:720,t:1526930261062};\\\", \\\"{x:503,y:722,t:1526930261076};\\\", \\\"{x:501,y:725,t:1526930261094};\\\", \\\"{x:500,y:725,t:1526930261110};\\\", \\\"{x:499,y:726,t:1526930261127};\\\", \\\"{x:499,y:727,t:1526930261150};\\\", \\\"{x:498,y:726,t:1526930261502};\\\", \\\"{x:498,y:724,t:1526930261511};\\\", \\\"{x:494,y:719,t:1526930261528};\\\", \\\"{x:491,y:717,t:1526930261545};\\\", \\\"{x:488,y:713,t:1526930261561};\\\", \\\"{x:487,y:712,t:1526930261578};\\\", \\\"{x:487,y:711,t:1526930261595};\\\", \\\"{x:486,y:710,t:1526930261612};\\\", \\\"{x:484,y:708,t:1526930261628};\\\", \\\"{x:482,y:705,t:1526930261645};\\\", \\\"{x:477,y:699,t:1526930261662};\\\", \\\"{x:471,y:694,t:1526930261678};\\\", \\\"{x:458,y:679,t:1526930261695};\\\", \\\"{x:450,y:667,t:1526930261712};\\\", \\\"{x:443,y:654,t:1526930261728};\\\", \\\"{x:433,y:637,t:1526930261745};\\\", \\\"{x:425,y:617,t:1526930261762};\\\", \\\"{x:413,y:596,t:1526930261778};\\\", \\\"{x:392,y:563,t:1526930261795};\\\", \\\"{x:364,y:525,t:1526930261812};\\\", \\\"{x:335,y:481,t:1526930261828};\\\", \\\"{x:320,y:458,t:1526930261845};\\\", \\\"{x:309,y:436,t:1526930261862};\\\", \\\"{x:302,y:424,t:1526930261878};\\\", \\\"{x:299,y:413,t:1526930261895};\\\", \\\"{x:298,y:412,t:1526930261912};\\\", \\\"{x:298,y:411,t:1526930261943};\\\", \\\"{x:298,y:410,t:1526930261951};\\\", \\\"{x:298,y:408,t:1526930261967};\\\", \\\"{x:298,y:407,t:1526930261978};\\\", \\\"{x:298,y:403,t:1526930261994};\\\", \\\"{x:298,y:400,t:1526930262012};\\\", \\\"{x:297,y:398,t:1526930262028};\\\", \\\"{x:297,y:395,t:1526930262045};\\\", \\\"{x:297,y:394,t:1526930262062};\\\", \\\"{x:297,y:393,t:1526930262079};\\\", \\\"{x:297,y:392,t:1526930262095};\\\", \\\"{x:296,y:391,t:1526930262112};\\\", \\\"{x:295,y:389,t:1526930262129};\\\", \\\"{x:294,y:388,t:1526930262145};\\\", \\\"{x:293,y:387,t:1526930262162};\\\", \\\"{x:293,y:386,t:1526930262179};\\\", \\\"{x:292,y:385,t:1526930262207};\\\", \\\"{x:292,y:384,t:1526930262215};\\\", \\\"{x:291,y:384,t:1526930262231};\\\", \\\"{x:291,y:383,t:1526930262255};\\\", \\\"{x:290,y:382,t:1526930262263};\\\", \\\"{x:290,y:381,t:1526930262295};\\\", \\\"{x:289,y:381,t:1526930262312};\\\", \\\"{x:289,y:380,t:1526930262329};\\\", \\\"{x:287,y:379,t:1526930262369};\\\", \\\"{x:286,y:377,t:1526930262391};\\\", \\\"{x:285,y:377,t:1526930262398};\\\", \\\"{x:285,y:376,t:1526930262412};\\\", \\\"{x:281,y:374,t:1526930262428};\\\", \\\"{x:278,y:373,t:1526930262444};\\\", \\\"{x:274,y:371,t:1526930262462};\\\", \\\"{x:270,y:370,t:1526930262479};\\\", \\\"{x:267,y:369,t:1526930262495};\\\", \\\"{x:265,y:369,t:1526930262566};\\\", \\\"{x:264,y:369,t:1526930262582};\\\" ] }, { \\\"rt\\\": 18028, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 630567, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:280,y:475,t:1526930262861};\\\", \\\"{x:298,y:504,t:1526930262879};\\\", \\\"{x:308,y:521,t:1526930262896};\\\", \\\"{x:316,y:534,t:1526930262913};\\\", \\\"{x:321,y:541,t:1526930262929};\\\", \\\"{x:322,y:547,t:1526930262948};\\\", \\\"{x:321,y:572,t:1526930263015};\\\", \\\"{x:320,y:573,t:1526930263028};\\\", \\\"{x:316,y:578,t:1526930263045};\\\", \\\"{x:314,y:581,t:1526930263062};\\\", \\\"{x:313,y:582,t:1526930263078};\\\", \\\"{x:313,y:583,t:1526930263096};\\\", \\\"{x:312,y:584,t:1526930263214};\\\", \\\"{x:311,y:585,t:1526930263254};\\\", \\\"{x:310,y:585,t:1526930263327};\\\", \\\"{x:308,y:586,t:1526930263351};\\\", \\\"{x:307,y:586,t:1526930263367};\\\", \\\"{x:305,y:586,t:1526930263383};\\\", \\\"{x:303,y:585,t:1526930263407};\\\", \\\"{x:303,y:583,t:1526930263423};\\\", \\\"{x:303,y:582,t:1526930263430};\\\", \\\"{x:303,y:581,t:1526930263446};\\\", \\\"{x:304,y:574,t:1526930263463};\\\", \\\"{x:305,y:569,t:1526930263480};\\\", \\\"{x:309,y:564,t:1526930263496};\\\", \\\"{x:313,y:557,t:1526930263514};\\\", \\\"{x:324,y:550,t:1526930263530};\\\", \\\"{x:337,y:543,t:1526930263546};\\\", \\\"{x:352,y:534,t:1526930263563};\\\", \\\"{x:370,y:527,t:1526930263580};\\\", \\\"{x:391,y:521,t:1526930263596};\\\", \\\"{x:409,y:516,t:1526930263613};\\\", \\\"{x:421,y:510,t:1526930263630};\\\", \\\"{x:429,y:506,t:1526930263646};\\\", \\\"{x:437,y:503,t:1526930263663};\\\", \\\"{x:443,y:501,t:1526930263680};\\\", \\\"{x:449,y:500,t:1526930263695};\\\", \\\"{x:462,y:498,t:1526930263713};\\\", \\\"{x:484,y:497,t:1526930263729};\\\", \\\"{x:508,y:497,t:1526930263746};\\\", \\\"{x:529,y:494,t:1526930263763};\\\", \\\"{x:543,y:492,t:1526930263780};\\\", \\\"{x:550,y:492,t:1526930263797};\\\", \\\"{x:553,y:489,t:1526930263813};\\\", \\\"{x:554,y:489,t:1526930263830};\\\", \\\"{x:555,y:487,t:1526930263903};\\\", \\\"{x:554,y:483,t:1526930263919};\\\", \\\"{x:553,y:482,t:1526930263930};\\\", \\\"{x:540,y:474,t:1526930263947};\\\", \\\"{x:525,y:467,t:1526930263963};\\\", \\\"{x:504,y:462,t:1526930263980};\\\", \\\"{x:485,y:457,t:1526930263997};\\\", \\\"{x:464,y:454,t:1526930264013};\\\", \\\"{x:442,y:452,t:1526930264030};\\\", \\\"{x:416,y:450,t:1526930264047};\\\", \\\"{x:407,y:450,t:1526930264063};\\\", \\\"{x:403,y:450,t:1526930264080};\\\", \\\"{x:399,y:450,t:1526930264097};\\\", \\\"{x:393,y:451,t:1526930264114};\\\", \\\"{x:388,y:453,t:1526930264130};\\\", \\\"{x:379,y:455,t:1526930264147};\\\", \\\"{x:369,y:457,t:1526930264163};\\\", \\\"{x:357,y:461,t:1526930264179};\\\", \\\"{x:346,y:464,t:1526930264197};\\\", \\\"{x:335,y:466,t:1526930264214};\\\", \\\"{x:328,y:467,t:1526930264229};\\\", \\\"{x:324,y:469,t:1526930264247};\\\", \\\"{x:328,y:469,t:1526930264390};\\\", \\\"{x:332,y:469,t:1526930264398};\\\", \\\"{x:338,y:468,t:1526930264414};\\\", \\\"{x:348,y:468,t:1526930264430};\\\", \\\"{x:366,y:467,t:1526930264446};\\\", \\\"{x:373,y:466,t:1526930264464};\\\", \\\"{x:378,y:465,t:1526930264480};\\\", \\\"{x:386,y:464,t:1526930264497};\\\", \\\"{x:393,y:464,t:1526930264514};\\\", \\\"{x:400,y:464,t:1526930264530};\\\", \\\"{x:410,y:463,t:1526930264547};\\\", \\\"{x:424,y:463,t:1526930264564};\\\", \\\"{x:439,y:463,t:1526930264580};\\\", \\\"{x:453,y:463,t:1526930264597};\\\", \\\"{x:471,y:463,t:1526930264614};\\\", \\\"{x:486,y:464,t:1526930264631};\\\", \\\"{x:499,y:465,t:1526930264646};\\\", \\\"{x:508,y:465,t:1526930264664};\\\", \\\"{x:516,y:466,t:1526930264681};\\\", \\\"{x:521,y:466,t:1526930264697};\\\", \\\"{x:524,y:466,t:1526930264714};\\\", \\\"{x:525,y:466,t:1526930264731};\\\", \\\"{x:526,y:466,t:1526930264747};\\\", \\\"{x:527,y:466,t:1526930264983};\\\", \\\"{x:526,y:465,t:1526930264998};\\\", \\\"{x:525,y:464,t:1526930265014};\\\", \\\"{x:523,y:462,t:1526930265031};\\\", \\\"{x:523,y:461,t:1526930265255};\\\", \\\"{x:525,y:461,t:1526930265265};\\\", \\\"{x:537,y:461,t:1526930265282};\\\", \\\"{x:552,y:461,t:1526930265299};\\\", \\\"{x:568,y:461,t:1526930265314};\\\", \\\"{x:583,y:461,t:1526930265332};\\\", \\\"{x:596,y:461,t:1526930265348};\\\", \\\"{x:599,y:461,t:1526930265364};\\\", \\\"{x:600,y:461,t:1526930265382};\\\", \\\"{x:603,y:461,t:1526930265608};\\\", \\\"{x:605,y:461,t:1526930265615};\\\", \\\"{x:613,y:461,t:1526930265631};\\\", \\\"{x:625,y:461,t:1526930265648};\\\", \\\"{x:642,y:461,t:1526930265665};\\\", \\\"{x:658,y:461,t:1526930265681};\\\", \\\"{x:672,y:461,t:1526930265698};\\\", \\\"{x:684,y:461,t:1526930265715};\\\", \\\"{x:693,y:461,t:1526930265732};\\\", \\\"{x:703,y:461,t:1526930265748};\\\", \\\"{x:712,y:461,t:1526930265766};\\\", \\\"{x:720,y:462,t:1526930265781};\\\", \\\"{x:726,y:462,t:1526930265798};\\\", \\\"{x:729,y:462,t:1526930265815};\\\", \\\"{x:730,y:462,t:1526930266223};\\\", \\\"{x:729,y:460,t:1526930266255};\\\", \\\"{x:728,y:459,t:1526930266271};\\\", \\\"{x:727,y:459,t:1526930266287};\\\", \\\"{x:727,y:458,t:1526930266303};\\\", \\\"{x:726,y:458,t:1526930266343};\\\", \\\"{x:725,y:458,t:1526930266359};\\\", \\\"{x:724,y:457,t:1526930266367};\\\", \\\"{x:723,y:456,t:1526930266382};\\\", \\\"{x:721,y:456,t:1526930266399};\\\", \\\"{x:718,y:455,t:1526930266415};\\\", \\\"{x:715,y:454,t:1526930266432};\\\", \\\"{x:713,y:453,t:1526930266449};\\\", \\\"{x:712,y:453,t:1526930266465};\\\", \\\"{x:711,y:453,t:1526930266487};\\\", \\\"{x:711,y:452,t:1526930266527};\\\", \\\"{x:710,y:452,t:1526930266535};\\\", \\\"{x:709,y:452,t:1526930266583};\\\", \\\"{x:708,y:452,t:1526930266599};\\\", \\\"{x:707,y:452,t:1526930266623};\\\", \\\"{x:706,y:452,t:1526930266695};\\\", \\\"{x:704,y:452,t:1526930266702};\\\", \\\"{x:703,y:452,t:1526930266719};\\\", \\\"{x:702,y:452,t:1526930266751};\\\", \\\"{x:701,y:452,t:1526930266783};\\\", \\\"{x:700,y:452,t:1526930266799};\\\", \\\"{x:698,y:452,t:1526930266816};\\\", \\\"{x:697,y:452,t:1526930266832};\\\", \\\"{x:694,y:452,t:1526930266849};\\\", \\\"{x:692,y:450,t:1526930266867};\\\", \\\"{x:691,y:450,t:1526930266902};\\\", \\\"{x:695,y:450,t:1526930268743};\\\", \\\"{x:701,y:451,t:1526930268751};\\\", \\\"{x:722,y:457,t:1526930268767};\\\", \\\"{x:753,y:467,t:1526930268784};\\\", \\\"{x:786,y:476,t:1526930268801};\\\", \\\"{x:825,y:487,t:1526930268818};\\\", \\\"{x:860,y:497,t:1526930268834};\\\", \\\"{x:896,y:507,t:1526930268850};\\\", \\\"{x:935,y:518,t:1526930268866};\\\", \\\"{x:975,y:531,t:1526930268882};\\\", \\\"{x:1013,y:546,t:1526930268900};\\\", \\\"{x:1047,y:564,t:1526930268917};\\\", \\\"{x:1098,y:600,t:1526930268935};\\\", \\\"{x:1123,y:626,t:1526930268950};\\\", \\\"{x:1154,y:662,t:1526930268967};\\\", \\\"{x:1180,y:697,t:1526930268984};\\\", \\\"{x:1194,y:723,t:1526930269000};\\\", \\\"{x:1204,y:743,t:1526930269017};\\\", \\\"{x:1209,y:756,t:1526930269034};\\\", \\\"{x:1211,y:769,t:1526930269051};\\\", \\\"{x:1213,y:781,t:1526930269067};\\\", \\\"{x:1215,y:788,t:1526930269084};\\\", \\\"{x:1215,y:793,t:1526930269101};\\\", \\\"{x:1218,y:800,t:1526930269117};\\\", \\\"{x:1225,y:815,t:1526930269135};\\\", \\\"{x:1230,y:829,t:1526930269151};\\\", \\\"{x:1232,y:832,t:1526930269168};\\\", \\\"{x:1232,y:833,t:1526930269184};\\\", \\\"{x:1232,y:835,t:1526930269272};\\\", \\\"{x:1232,y:836,t:1526930269319};\\\", \\\"{x:1229,y:836,t:1526930269335};\\\", \\\"{x:1225,y:837,t:1526930269351};\\\", \\\"{x:1221,y:837,t:1526930269369};\\\", \\\"{x:1218,y:837,t:1526930269384};\\\", \\\"{x:1214,y:837,t:1526930269401};\\\", \\\"{x:1212,y:837,t:1526930269418};\\\", \\\"{x:1207,y:837,t:1526930269434};\\\", \\\"{x:1203,y:837,t:1526930269451};\\\", \\\"{x:1201,y:837,t:1526930269468};\\\", \\\"{x:1199,y:836,t:1526930269544};\\\", \\\"{x:1199,y:835,t:1526930269552};\\\", \\\"{x:1198,y:835,t:1526930269575};\\\", \\\"{x:1198,y:834,t:1526930269585};\\\", \\\"{x:1197,y:834,t:1526930269601};\\\", \\\"{x:1197,y:833,t:1526930269619};\\\", \\\"{x:1197,y:831,t:1526930269634};\\\", \\\"{x:1196,y:830,t:1526930269652};\\\", \\\"{x:1196,y:829,t:1526930269668};\\\", \\\"{x:1196,y:828,t:1526930269685};\\\", \\\"{x:1196,y:827,t:1526930269702};\\\", \\\"{x:1197,y:825,t:1526930269719};\\\", \\\"{x:1197,y:824,t:1526930269735};\\\", \\\"{x:1198,y:823,t:1526930269752};\\\", \\\"{x:1199,y:822,t:1526930269769};\\\", \\\"{x:1200,y:821,t:1526930269784};\\\", \\\"{x:1200,y:820,t:1526930269802};\\\", \\\"{x:1201,y:819,t:1526930269823};\\\", \\\"{x:1202,y:819,t:1526930269839};\\\", \\\"{x:1203,y:819,t:1526930270015};\\\", \\\"{x:1206,y:819,t:1526930270039};\\\", \\\"{x:1207,y:820,t:1526930270095};\\\", \\\"{x:1207,y:821,t:1526930270136};\\\", \\\"{x:1208,y:822,t:1526930270152};\\\", \\\"{x:1208,y:823,t:1526930270183};\\\", \\\"{x:1209,y:824,t:1526930270231};\\\", \\\"{x:1208,y:823,t:1526930271783};\\\", \\\"{x:1208,y:822,t:1526930271791};\\\", \\\"{x:1208,y:821,t:1526930271803};\\\", \\\"{x:1206,y:819,t:1526930271820};\\\", \\\"{x:1203,y:817,t:1526930271836};\\\", \\\"{x:1200,y:814,t:1526930271853};\\\", \\\"{x:1198,y:813,t:1526930271870};\\\", \\\"{x:1194,y:809,t:1526930271887};\\\", \\\"{x:1193,y:807,t:1526930271904};\\\", \\\"{x:1190,y:805,t:1526930271920};\\\", \\\"{x:1188,y:801,t:1526930271937};\\\", \\\"{x:1186,y:799,t:1526930271953};\\\", \\\"{x:1185,y:796,t:1526930271971};\\\", \\\"{x:1182,y:793,t:1526930271987};\\\", \\\"{x:1181,y:788,t:1526930272004};\\\", \\\"{x:1179,y:784,t:1526930272019};\\\", \\\"{x:1177,y:781,t:1526930272037};\\\", \\\"{x:1177,y:778,t:1526930272054};\\\", \\\"{x:1177,y:777,t:1526930272070};\\\", \\\"{x:1176,y:776,t:1526930272086};\\\", \\\"{x:1175,y:773,t:1526930272103};\\\", \\\"{x:1174,y:772,t:1526930272120};\\\", \\\"{x:1174,y:769,t:1526930272136};\\\", \\\"{x:1173,y:768,t:1526930272154};\\\", \\\"{x:1172,y:766,t:1526930272172};\\\", \\\"{x:1172,y:765,t:1526930272199};\\\", \\\"{x:1172,y:764,t:1526930272207};\\\", \\\"{x:1171,y:763,t:1526930272220};\\\", \\\"{x:1171,y:762,t:1526930272271};\\\", \\\"{x:1171,y:760,t:1526930278071};\\\", \\\"{x:1172,y:760,t:1526930278488};\\\", \\\"{x:1174,y:760,t:1526930278503};\\\", \\\"{x:1175,y:760,t:1526930278511};\\\", \\\"{x:1176,y:761,t:1526930278528};\\\", \\\"{x:1178,y:764,t:1526930278540};\\\", \\\"{x:1180,y:765,t:1526930278557};\\\", \\\"{x:1183,y:768,t:1526930278574};\\\", \\\"{x:1183,y:769,t:1526930278614};\\\", \\\"{x:1178,y:768,t:1526930278951};\\\", \\\"{x:1128,y:748,t:1526930278976};\\\", \\\"{x:1056,y:728,t:1526930278992};\\\", \\\"{x:962,y:703,t:1526930279009};\\\", \\\"{x:863,y:675,t:1526930279025};\\\", \\\"{x:766,y:651,t:1526930279042};\\\", \\\"{x:700,y:634,t:1526930279059};\\\", \\\"{x:680,y:627,t:1526930279076};\\\", \\\"{x:672,y:625,t:1526930279091};\\\", \\\"{x:669,y:625,t:1526930279182};\\\", \\\"{x:664,y:624,t:1526930279190};\\\", \\\"{x:641,y:616,t:1526930279206};\\\", \\\"{x:599,y:607,t:1526930279223};\\\", \\\"{x:549,y:593,t:1526930279244};\\\", \\\"{x:506,y:579,t:1526930279258};\\\", \\\"{x:477,y:569,t:1526930279276};\\\", \\\"{x:453,y:559,t:1526930279293};\\\", \\\"{x:433,y:549,t:1526930279309};\\\", \\\"{x:422,y:543,t:1526930279325};\\\", \\\"{x:417,y:538,t:1526930279343};\\\", \\\"{x:416,y:537,t:1526930279359};\\\", \\\"{x:415,y:536,t:1526930279375};\\\", \\\"{x:410,y:533,t:1526930279392};\\\", \\\"{x:392,y:526,t:1526930279410};\\\", \\\"{x:368,y:520,t:1526930279426};\\\", \\\"{x:352,y:516,t:1526930279443};\\\", \\\"{x:335,y:515,t:1526930279459};\\\", \\\"{x:327,y:515,t:1526930279476};\\\", \\\"{x:319,y:515,t:1526930279492};\\\", \\\"{x:311,y:515,t:1526930279510};\\\", \\\"{x:301,y:517,t:1526930279525};\\\", \\\"{x:282,y:522,t:1526930279542};\\\", \\\"{x:270,y:527,t:1526930279559};\\\", \\\"{x:261,y:531,t:1526930279575};\\\", \\\"{x:254,y:533,t:1526930279592};\\\", \\\"{x:245,y:535,t:1526930279609};\\\", \\\"{x:235,y:535,t:1526930279626};\\\", \\\"{x:221,y:535,t:1526930279642};\\\", \\\"{x:199,y:529,t:1526930279659};\\\", \\\"{x:185,y:524,t:1526930279678};\\\", \\\"{x:174,y:518,t:1526930279692};\\\", \\\"{x:170,y:516,t:1526930279710};\\\", \\\"{x:168,y:515,t:1526930279725};\\\", \\\"{x:167,y:512,t:1526930279743};\\\", \\\"{x:167,y:511,t:1526930279759};\\\", \\\"{x:165,y:508,t:1526930279776};\\\", \\\"{x:165,y:507,t:1526930279806};\\\", \\\"{x:165,y:506,t:1526930279814};\\\", \\\"{x:165,y:505,t:1526930279838};\\\", \\\"{x:164,y:504,t:1526930279846};\\\", \\\"{x:164,y:503,t:1526930279886};\\\", \\\"{x:167,y:504,t:1526930280142};\\\", \\\"{x:187,y:520,t:1526930280160};\\\", \\\"{x:211,y:537,t:1526930280177};\\\", \\\"{x:248,y:563,t:1526930280193};\\\", \\\"{x:278,y:582,t:1526930280210};\\\", \\\"{x:305,y:601,t:1526930280227};\\\", \\\"{x:328,y:617,t:1526930280243};\\\", \\\"{x:342,y:628,t:1526930280259};\\\", \\\"{x:352,y:635,t:1526930280277};\\\", \\\"{x:363,y:647,t:1526930280293};\\\", \\\"{x:377,y:660,t:1526930280310};\\\", \\\"{x:403,y:678,t:1526930280326};\\\", \\\"{x:420,y:689,t:1526930280343};\\\", \\\"{x:440,y:701,t:1526930280360};\\\", \\\"{x:454,y:711,t:1526930280377};\\\", \\\"{x:462,y:716,t:1526930280392};\\\", \\\"{x:474,y:721,t:1526930280411};\\\", \\\"{x:481,y:725,t:1526930280426};\\\", \\\"{x:490,y:729,t:1526930280444};\\\", \\\"{x:498,y:732,t:1526930280459};\\\", \\\"{x:504,y:732,t:1526930280476};\\\", \\\"{x:508,y:732,t:1526930280494};\\\", \\\"{x:511,y:733,t:1526930280510};\\\", \\\"{x:510,y:733,t:1526930280926};\\\", \\\"{x:509,y:733,t:1526930281158};\\\", \\\"{x:506,y:733,t:1526930281167};\\\", \\\"{x:501,y:733,t:1526930281177};\\\", \\\"{x:488,y:731,t:1526930281194};\\\", \\\"{x:465,y:725,t:1526930281211};\\\", \\\"{x:427,y:711,t:1526930281227};\\\", \\\"{x:374,y:695,t:1526930281244};\\\", \\\"{x:315,y:677,t:1526930281260};\\\", \\\"{x:261,y:655,t:1526930281277};\\\", \\\"{x:232,y:647,t:1526930281294};\\\", \\\"{x:214,y:633,t:1526930281311};\\\", \\\"{x:211,y:628,t:1526930281327};\\\", \\\"{x:211,y:615,t:1526930281344};\\\", \\\"{x:211,y:593,t:1526930281361};\\\", \\\"{x:209,y:573,t:1526930281378};\\\", \\\"{x:206,y:551,t:1526930281394};\\\", \\\"{x:203,y:526,t:1526930281411};\\\", \\\"{x:203,y:500,t:1526930281427};\\\", \\\"{x:203,y:482,t:1526930281444};\\\", \\\"{x:203,y:466,t:1526930281461};\\\", \\\"{x:203,y:458,t:1526930281478};\\\", \\\"{x:203,y:446,t:1526930281494};\\\", \\\"{x:200,y:436,t:1526930281510};\\\", \\\"{x:199,y:432,t:1526930281528};\\\", \\\"{x:198,y:429,t:1526930281544};\\\", \\\"{x:197,y:428,t:1526930281566};\\\", \\\"{x:197,y:426,t:1526930281582};\\\", \\\"{x:196,y:426,t:1526930281630};\\\" ] }, { \\\"rt\\\": 77717, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 709536, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F -Z -Z -Z -I -X -B -O -M -F -F -I -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:201,y:426,t:1526930282318};\\\", \\\"{x:214,y:424,t:1526930282327};\\\", \\\"{x:243,y:423,t:1526930282344};\\\", \\\"{x:286,y:420,t:1526930282361};\\\", \\\"{x:375,y:420,t:1526930282378};\\\", \\\"{x:458,y:420,t:1526930282395};\\\", \\\"{x:536,y:420,t:1526930282412};\\\", \\\"{x:594,y:420,t:1526930282428};\\\", \\\"{x:644,y:424,t:1526930282444};\\\", \\\"{x:681,y:431,t:1526930282462};\\\", \\\"{x:709,y:437,t:1526930282478};\\\", \\\"{x:740,y:447,t:1526930282495};\\\", \\\"{x:780,y:479,t:1526930282566};\\\", \\\"{x:783,y:484,t:1526930282579};\\\", \\\"{x:786,y:491,t:1526930282599};\\\", \\\"{x:786,y:494,t:1526930282611};\\\", \\\"{x:787,y:502,t:1526930282628};\\\", \\\"{x:787,y:511,t:1526930282644};\\\", \\\"{x:784,y:522,t:1526930282661};\\\", \\\"{x:771,y:540,t:1526930282678};\\\", \\\"{x:760,y:553,t:1526930282694};\\\", \\\"{x:749,y:563,t:1526930282712};\\\", \\\"{x:738,y:573,t:1526930282729};\\\", \\\"{x:726,y:581,t:1526930282745};\\\", \\\"{x:711,y:589,t:1526930282762};\\\", \\\"{x:698,y:596,t:1526930282778};\\\", \\\"{x:686,y:600,t:1526930282794};\\\", \\\"{x:678,y:604,t:1526930282812};\\\", \\\"{x:668,y:607,t:1526930282828};\\\", \\\"{x:656,y:612,t:1526930282844};\\\", \\\"{x:646,y:613,t:1526930282862};\\\", \\\"{x:626,y:614,t:1526930282878};\\\", \\\"{x:615,y:614,t:1526930282894};\\\", \\\"{x:607,y:614,t:1526930282912};\\\", \\\"{x:602,y:614,t:1526930282928};\\\", \\\"{x:599,y:614,t:1526930282945};\\\", \\\"{x:599,y:613,t:1526930282966};\\\", \\\"{x:598,y:613,t:1526930282979};\\\", \\\"{x:596,y:609,t:1526930282995};\\\", \\\"{x:592,y:602,t:1526930283012};\\\", \\\"{x:587,y:592,t:1526930283030};\\\", \\\"{x:583,y:580,t:1526930283045};\\\", \\\"{x:582,y:570,t:1526930283061};\\\", \\\"{x:582,y:554,t:1526930283080};\\\", \\\"{x:587,y:541,t:1526930283096};\\\", \\\"{x:589,y:528,t:1526930283112};\\\", \\\"{x:590,y:513,t:1526930283130};\\\", \\\"{x:590,y:498,t:1526930283146};\\\", \\\"{x:585,y:478,t:1526930283162};\\\", \\\"{x:581,y:466,t:1526930283178};\\\", \\\"{x:580,y:463,t:1526930283196};\\\", \\\"{x:578,y:460,t:1526930283212};\\\", \\\"{x:577,y:456,t:1526930283228};\\\", \\\"{x:574,y:454,t:1526930283245};\\\", \\\"{x:571,y:452,t:1526930283261};\\\", \\\"{x:568,y:449,t:1526930283279};\\\", \\\"{x:567,y:449,t:1526930283398};\\\", \\\"{x:566,y:449,t:1526930283411};\\\", \\\"{x:563,y:450,t:1526930283428};\\\", \\\"{x:560,y:451,t:1526930283445};\\\", \\\"{x:559,y:452,t:1526930283461};\\\", \\\"{x:558,y:452,t:1526930283478};\\\", \\\"{x:557,y:453,t:1526930283495};\\\", \\\"{x:556,y:454,t:1526930283518};\\\", \\\"{x:557,y:454,t:1526930284463};\\\", \\\"{x:596,y:454,t:1526930284479};\\\", \\\"{x:641,y:454,t:1526930284496};\\\", \\\"{x:666,y:458,t:1526930284512};\\\", \\\"{x:680,y:460,t:1526930284530};\\\", \\\"{x:684,y:462,t:1526930284546};\\\", \\\"{x:684,y:463,t:1526930284591};\\\", \\\"{x:683,y:463,t:1526930284599};\\\", \\\"{x:680,y:464,t:1526930284612};\\\", \\\"{x:661,y:466,t:1526930284629};\\\", \\\"{x:629,y:466,t:1526930284646};\\\", \\\"{x:565,y:464,t:1526930284663};\\\", \\\"{x:537,y:461,t:1526930284679};\\\", \\\"{x:519,y:458,t:1526930284697};\\\", \\\"{x:510,y:456,t:1526930284712};\\\", \\\"{x:503,y:455,t:1526930284729};\\\", \\\"{x:497,y:454,t:1526930284746};\\\", \\\"{x:491,y:454,t:1526930284762};\\\", \\\"{x:483,y:453,t:1526930284778};\\\", \\\"{x:475,y:452,t:1526930284795};\\\", \\\"{x:465,y:452,t:1526930284811};\\\", \\\"{x:452,y:452,t:1526930284828};\\\", \\\"{x:435,y:452,t:1526930284845};\\\", \\\"{x:431,y:452,t:1526930284862};\\\", \\\"{x:430,y:452,t:1526930284878};\\\", \\\"{x:429,y:452,t:1526930284934};\\\", \\\"{x:427,y:452,t:1526930284946};\\\", \\\"{x:421,y:452,t:1526930284961};\\\", \\\"{x:414,y:452,t:1526930284978};\\\", \\\"{x:409,y:452,t:1526930284996};\\\", \\\"{x:406,y:452,t:1526930285011};\\\", \\\"{x:405,y:452,t:1526930285029};\\\", \\\"{x:409,y:452,t:1526930285559};\\\", \\\"{x:416,y:452,t:1526930285566};\\\", \\\"{x:426,y:452,t:1526930285579};\\\", \\\"{x:453,y:452,t:1526930285596};\\\", \\\"{x:490,y:452,t:1526930285612};\\\", \\\"{x:522,y:452,t:1526930285629};\\\", \\\"{x:550,y:452,t:1526930285646};\\\", \\\"{x:571,y:452,t:1526930285662};\\\", \\\"{x:605,y:452,t:1526930285679};\\\", \\\"{x:629,y:452,t:1526930285696};\\\", \\\"{x:649,y:452,t:1526930285712};\\\", \\\"{x:672,y:452,t:1526930285729};\\\", \\\"{x:689,y:452,t:1526930285746};\\\", \\\"{x:700,y:452,t:1526930285762};\\\", \\\"{x:703,y:453,t:1526930285779};\\\", \\\"{x:705,y:453,t:1526930285903};\\\", \\\"{x:707,y:453,t:1526930285912};\\\", \\\"{x:719,y:454,t:1526930285930};\\\", \\\"{x:750,y:458,t:1526930285946};\\\", \\\"{x:812,y:468,t:1526930285962};\\\", \\\"{x:909,y:482,t:1526930285979};\\\", \\\"{x:1020,y:498,t:1526930285997};\\\", \\\"{x:1135,y:523,t:1526930286012};\\\", \\\"{x:1252,y:543,t:1526930286029};\\\", \\\"{x:1382,y:578,t:1526930286046};\\\", \\\"{x:1427,y:593,t:1526930286063};\\\", \\\"{x:1451,y:605,t:1526930286079};\\\", \\\"{x:1461,y:613,t:1526930286097};\\\", \\\"{x:1461,y:615,t:1526930286112};\\\", \\\"{x:1461,y:616,t:1526930286134};\\\", \\\"{x:1461,y:617,t:1526930286150};\\\", \\\"{x:1460,y:620,t:1526930286162};\\\", \\\"{x:1456,y:623,t:1526930286179};\\\", \\\"{x:1450,y:626,t:1526930286198};\\\", \\\"{x:1438,y:633,t:1526930286213};\\\", \\\"{x:1422,y:641,t:1526930286228};\\\", \\\"{x:1396,y:656,t:1526930286246};\\\", \\\"{x:1381,y:670,t:1526930286262};\\\", \\\"{x:1366,y:689,t:1526930286279};\\\", \\\"{x:1358,y:703,t:1526930286295};\\\", \\\"{x:1350,y:714,t:1526930286312};\\\", \\\"{x:1345,y:723,t:1526930286329};\\\", \\\"{x:1341,y:731,t:1526930286346};\\\", \\\"{x:1339,y:736,t:1526930286361};\\\", \\\"{x:1337,y:741,t:1526930286379};\\\", \\\"{x:1335,y:744,t:1526930286396};\\\", \\\"{x:1333,y:747,t:1526930286412};\\\", \\\"{x:1332,y:750,t:1526930286429};\\\", \\\"{x:1331,y:752,t:1526930286446};\\\", \\\"{x:1330,y:756,t:1526930286462};\\\", \\\"{x:1330,y:757,t:1526930286479};\\\", \\\"{x:1329,y:760,t:1526930286496};\\\", \\\"{x:1329,y:764,t:1526930286512};\\\", \\\"{x:1326,y:767,t:1526930286530};\\\", \\\"{x:1323,y:770,t:1526930286546};\\\", \\\"{x:1319,y:775,t:1526930286563};\\\", \\\"{x:1314,y:777,t:1526930286579};\\\", \\\"{x:1306,y:781,t:1526930286596};\\\", \\\"{x:1302,y:781,t:1526930286613};\\\", \\\"{x:1299,y:781,t:1526930286629};\\\", \\\"{x:1298,y:781,t:1526930286679};\\\", \\\"{x:1298,y:780,t:1526930286696};\\\", \\\"{x:1300,y:772,t:1526930286712};\\\", \\\"{x:1304,y:766,t:1526930286730};\\\", \\\"{x:1310,y:756,t:1526930286746};\\\", \\\"{x:1314,y:750,t:1526930286763};\\\", \\\"{x:1319,y:743,t:1526930286780};\\\", \\\"{x:1323,y:737,t:1526930286796};\\\", \\\"{x:1327,y:727,t:1526930286812};\\\", \\\"{x:1330,y:723,t:1526930286829};\\\", \\\"{x:1330,y:720,t:1526930286847};\\\", \\\"{x:1330,y:718,t:1526930286862};\\\", \\\"{x:1330,y:717,t:1526930286887};\\\", \\\"{x:1330,y:715,t:1526930286896};\\\", \\\"{x:1330,y:714,t:1526930286913};\\\", \\\"{x:1331,y:712,t:1526930286931};\\\", \\\"{x:1331,y:710,t:1526930286947};\\\", \\\"{x:1334,y:708,t:1526930286963};\\\", \\\"{x:1335,y:706,t:1526930286979};\\\", \\\"{x:1336,y:706,t:1526930286996};\\\", \\\"{x:1337,y:705,t:1526930287012};\\\", \\\"{x:1337,y:704,t:1526930287029};\\\", \\\"{x:1338,y:704,t:1526930287071};\\\", \\\"{x:1339,y:703,t:1526930287087};\\\", \\\"{x:1340,y:702,t:1526930287096};\\\", \\\"{x:1340,y:701,t:1526930287113};\\\", \\\"{x:1342,y:701,t:1526930287130};\\\", \\\"{x:1343,y:701,t:1526930287159};\\\", \\\"{x:1345,y:700,t:1526930287208};\\\", \\\"{x:1347,y:699,t:1526930287230};\\\", \\\"{x:1348,y:698,t:1526930287246};\\\", \\\"{x:1349,y:698,t:1526930287279};\\\", \\\"{x:1349,y:697,t:1526930287327};\\\", \\\"{x:1350,y:697,t:1526930287383};\\\", \\\"{x:1351,y:697,t:1526930287455};\\\", \\\"{x:1352,y:697,t:1526930288031};\\\", \\\"{x:1352,y:698,t:1526930288062};\\\", \\\"{x:1353,y:698,t:1526930288080};\\\", \\\"{x:1355,y:699,t:1526930288097};\\\", \\\"{x:1359,y:702,t:1526930288113};\\\", \\\"{x:1367,y:703,t:1526930288130};\\\", \\\"{x:1382,y:706,t:1526930288147};\\\", \\\"{x:1400,y:709,t:1526930288164};\\\", \\\"{x:1420,y:712,t:1526930288179};\\\", \\\"{x:1437,y:714,t:1526930288197};\\\", \\\"{x:1449,y:716,t:1526930288213};\\\", \\\"{x:1456,y:716,t:1526930288230};\\\", \\\"{x:1463,y:716,t:1526930288246};\\\", \\\"{x:1465,y:716,t:1526930288263};\\\", \\\"{x:1466,y:716,t:1526930288279};\\\", \\\"{x:1469,y:716,t:1526930288296};\\\", \\\"{x:1472,y:716,t:1526930288314};\\\", \\\"{x:1476,y:716,t:1526930288330};\\\", \\\"{x:1478,y:716,t:1526930288347};\\\", \\\"{x:1479,y:716,t:1526930288447};\\\", \\\"{x:1479,y:714,t:1526930288462};\\\", \\\"{x:1479,y:710,t:1526930288479};\\\", \\\"{x:1478,y:708,t:1526930288497};\\\", \\\"{x:1477,y:706,t:1526930288514};\\\", \\\"{x:1477,y:705,t:1526930288530};\\\", \\\"{x:1476,y:704,t:1526930288559};\\\", \\\"{x:1476,y:703,t:1526930288567};\\\", \\\"{x:1475,y:702,t:1526930288599};\\\", \\\"{x:1475,y:701,t:1526930288863};\\\", \\\"{x:1480,y:702,t:1526930288879};\\\", \\\"{x:1486,y:705,t:1526930288896};\\\", \\\"{x:1503,y:707,t:1526930288914};\\\", \\\"{x:1525,y:711,t:1526930288930};\\\", \\\"{x:1545,y:712,t:1526930288946};\\\", \\\"{x:1567,y:712,t:1526930288964};\\\", \\\"{x:1579,y:712,t:1526930288979};\\\", \\\"{x:1583,y:712,t:1526930288997};\\\", \\\"{x:1584,y:712,t:1526930289023};\\\", \\\"{x:1586,y:711,t:1526930289031};\\\", \\\"{x:1587,y:711,t:1526930289047};\\\", \\\"{x:1589,y:711,t:1526930289063};\\\", \\\"{x:1590,y:709,t:1526930289080};\\\", \\\"{x:1592,y:708,t:1526930289096};\\\", \\\"{x:1593,y:707,t:1526930289113};\\\", \\\"{x:1596,y:705,t:1526930289130};\\\", \\\"{x:1602,y:703,t:1526930289147};\\\", \\\"{x:1608,y:701,t:1526930289163};\\\", \\\"{x:1614,y:700,t:1526930289179};\\\", \\\"{x:1616,y:699,t:1526930289196};\\\", \\\"{x:1620,y:697,t:1526930289213};\\\", \\\"{x:1621,y:696,t:1526930289311};\\\", \\\"{x:1621,y:695,t:1526930289333};\\\", \\\"{x:1622,y:695,t:1526930289374};\\\", \\\"{x:1622,y:694,t:1526930289430};\\\", \\\"{x:1621,y:694,t:1526930289486};\\\", \\\"{x:1619,y:694,t:1526930289502};\\\", \\\"{x:1617,y:694,t:1526930289558};\\\", \\\"{x:1617,y:695,t:1526930289575};\\\", \\\"{x:1616,y:695,t:1526930289590};\\\", \\\"{x:1614,y:695,t:1526930291271};\\\", \\\"{x:1613,y:696,t:1526930291279};\\\", \\\"{x:1612,y:696,t:1526930291384};\\\", \\\"{x:1612,y:697,t:1526930291486};\\\", \\\"{x:1612,y:698,t:1526930291558};\\\", \\\"{x:1613,y:698,t:1526930291566};\\\", \\\"{x:1613,y:697,t:1526930301615};\\\", \\\"{x:1613,y:696,t:1526930301638};\\\", \\\"{x:1613,y:695,t:1526930301647};\\\", \\\"{x:1613,y:694,t:1526930301663};\\\", \\\"{x:1613,y:693,t:1526930301694};\\\", \\\"{x:1612,y:693,t:1526930301710};\\\", \\\"{x:1612,y:692,t:1526930302486};\\\", \\\"{x:1612,y:691,t:1526930302511};\\\", \\\"{x:1612,y:690,t:1526930304527};\\\", \\\"{x:1610,y:692,t:1526930304535};\\\", \\\"{x:1608,y:694,t:1526930304548};\\\", \\\"{x:1599,y:703,t:1526930304564};\\\", \\\"{x:1584,y:712,t:1526930304581};\\\", \\\"{x:1575,y:719,t:1526930304598};\\\", \\\"{x:1570,y:724,t:1526930304614};\\\", \\\"{x:1570,y:730,t:1526930304631};\\\", \\\"{x:1568,y:735,t:1526930304648};\\\", \\\"{x:1568,y:741,t:1526930304664};\\\", \\\"{x:1568,y:747,t:1526930304681};\\\", \\\"{x:1568,y:755,t:1526930304698};\\\", \\\"{x:1566,y:761,t:1526930304714};\\\", \\\"{x:1565,y:767,t:1526930304731};\\\", \\\"{x:1562,y:775,t:1526930304748};\\\", \\\"{x:1561,y:780,t:1526930304764};\\\", \\\"{x:1558,y:783,t:1526930304781};\\\", \\\"{x:1553,y:791,t:1526930304798};\\\", \\\"{x:1547,y:797,t:1526930304814};\\\", \\\"{x:1541,y:802,t:1526930304831};\\\", \\\"{x:1533,y:807,t:1526930304848};\\\", \\\"{x:1527,y:808,t:1526930304864};\\\", \\\"{x:1525,y:809,t:1526930304881};\\\", \\\"{x:1523,y:811,t:1526930304898};\\\", \\\"{x:1522,y:812,t:1526930304914};\\\", \\\"{x:1520,y:812,t:1526930304931};\\\", \\\"{x:1519,y:812,t:1526930304948};\\\", \\\"{x:1518,y:814,t:1526930304964};\\\", \\\"{x:1516,y:815,t:1526930304981};\\\", \\\"{x:1512,y:817,t:1526930304998};\\\", \\\"{x:1510,y:818,t:1526930305014};\\\", \\\"{x:1509,y:819,t:1526930305031};\\\", \\\"{x:1507,y:821,t:1526930305048};\\\", \\\"{x:1506,y:822,t:1526930305071};\\\", \\\"{x:1506,y:824,t:1526930305110};\\\", \\\"{x:1507,y:824,t:1526930305118};\\\", \\\"{x:1511,y:824,t:1526930305131};\\\", \\\"{x:1523,y:824,t:1526930305148};\\\", \\\"{x:1535,y:824,t:1526930305164};\\\", \\\"{x:1550,y:824,t:1526930305181};\\\", \\\"{x:1573,y:824,t:1526930305199};\\\", \\\"{x:1583,y:824,t:1526930305215};\\\", \\\"{x:1589,y:824,t:1526930305231};\\\", \\\"{x:1594,y:824,t:1526930305248};\\\", \\\"{x:1597,y:824,t:1526930305264};\\\", \\\"{x:1598,y:824,t:1526930305281};\\\", \\\"{x:1602,y:824,t:1526930305298};\\\", \\\"{x:1604,y:824,t:1526930305314};\\\", \\\"{x:1604,y:825,t:1526930305331};\\\", \\\"{x:1605,y:825,t:1526930305463};\\\", \\\"{x:1606,y:825,t:1526930305510};\\\", \\\"{x:1607,y:826,t:1526930305535};\\\", \\\"{x:1608,y:826,t:1526930305575};\\\", \\\"{x:1609,y:826,t:1526930305615};\\\", \\\"{x:1610,y:826,t:1526930305631};\\\", \\\"{x:1611,y:826,t:1526930305679};\\\", \\\"{x:1612,y:826,t:1526930305703};\\\", \\\"{x:1613,y:826,t:1526930305719};\\\", \\\"{x:1615,y:825,t:1526930305767};\\\", \\\"{x:1616,y:825,t:1526930305799};\\\", \\\"{x:1616,y:824,t:1526930305823};\\\", \\\"{x:1617,y:824,t:1526930306607};\\\", \\\"{x:1617,y:825,t:1526930307454};\\\", \\\"{x:1617,y:826,t:1526930307495};\\\", \\\"{x:1616,y:826,t:1526930308127};\\\", \\\"{x:1616,y:827,t:1526930308134};\\\", \\\"{x:1615,y:828,t:1526930308190};\\\", \\\"{x:1614,y:828,t:1526930308319};\\\", \\\"{x:1613,y:828,t:1526930308331};\\\", \\\"{x:1610,y:828,t:1526930308349};\\\", \\\"{x:1600,y:828,t:1526930308364};\\\", \\\"{x:1578,y:828,t:1526930308381};\\\", \\\"{x:1456,y:815,t:1526930308399};\\\", \\\"{x:1328,y:794,t:1526930308415};\\\", \\\"{x:1191,y:759,t:1526930308431};\\\", \\\"{x:1061,y:725,t:1526930308448};\\\", \\\"{x:951,y:697,t:1526930308464};\\\", \\\"{x:876,y:672,t:1526930308481};\\\", \\\"{x:831,y:652,t:1526930308498};\\\", \\\"{x:813,y:648,t:1526930308514};\\\", \\\"{x:809,y:647,t:1526930308531};\\\", \\\"{x:809,y:645,t:1526930308638};\\\", \\\"{x:809,y:643,t:1526930308648};\\\", \\\"{x:804,y:637,t:1526930308664};\\\", \\\"{x:790,y:622,t:1526930308683};\\\", \\\"{x:772,y:609,t:1526930308698};\\\", \\\"{x:743,y:600,t:1526930308714};\\\", \\\"{x:716,y:591,t:1526930308731};\\\", \\\"{x:692,y:584,t:1526930308748};\\\", \\\"{x:675,y:579,t:1526930308765};\\\", \\\"{x:671,y:579,t:1526930308781};\\\", \\\"{x:669,y:579,t:1526930308798};\\\", \\\"{x:664,y:579,t:1526930308816};\\\", \\\"{x:651,y:576,t:1526930308831};\\\", \\\"{x:630,y:574,t:1526930308849};\\\", \\\"{x:612,y:571,t:1526930308866};\\\", \\\"{x:597,y:569,t:1526930308882};\\\", \\\"{x:590,y:569,t:1526930308898};\\\", \\\"{x:587,y:567,t:1526930308916};\\\", \\\"{x:584,y:567,t:1526930308933};\\\", \\\"{x:571,y:568,t:1526930308949};\\\", \\\"{x:552,y:571,t:1526930308966};\\\", \\\"{x:536,y:573,t:1526930308982};\\\", \\\"{x:518,y:577,t:1526930308999};\\\", \\\"{x:499,y:582,t:1526930309016};\\\", \\\"{x:485,y:585,t:1526930309034};\\\", \\\"{x:468,y:590,t:1526930309050};\\\", \\\"{x:451,y:596,t:1526930309066};\\\", \\\"{x:435,y:600,t:1526930309082};\\\", \\\"{x:419,y:605,t:1526930309100};\\\", \\\"{x:404,y:609,t:1526930309117};\\\", \\\"{x:382,y:612,t:1526930309132};\\\", \\\"{x:355,y:615,t:1526930309150};\\\", \\\"{x:344,y:615,t:1526930309166};\\\", \\\"{x:339,y:615,t:1526930309183};\\\", \\\"{x:338,y:615,t:1526930309200};\\\", \\\"{x:336,y:615,t:1526930309216};\\\", \\\"{x:332,y:615,t:1526930309233};\\\", \\\"{x:329,y:614,t:1526930309250};\\\", \\\"{x:328,y:613,t:1526930309267};\\\", \\\"{x:326,y:613,t:1526930309283};\\\", \\\"{x:326,y:612,t:1526930309302};\\\", \\\"{x:325,y:611,t:1526930309316};\\\", \\\"{x:318,y:610,t:1526930309333};\\\", \\\"{x:298,y:607,t:1526930309349};\\\", \\\"{x:283,y:606,t:1526930309366};\\\", \\\"{x:269,y:606,t:1526930309383};\\\", \\\"{x:260,y:606,t:1526930309399};\\\", \\\"{x:252,y:607,t:1526930309417};\\\", \\\"{x:248,y:609,t:1526930309432};\\\", \\\"{x:245,y:611,t:1526930309450};\\\", \\\"{x:244,y:614,t:1526930309467};\\\", \\\"{x:244,y:617,t:1526930309482};\\\", \\\"{x:243,y:623,t:1526930309499};\\\", \\\"{x:242,y:629,t:1526930309517};\\\", \\\"{x:238,y:634,t:1526930309534};\\\", \\\"{x:232,y:639,t:1526930309550};\\\", \\\"{x:227,y:644,t:1526930309566};\\\", \\\"{x:223,y:647,t:1526930309583};\\\", \\\"{x:216,y:650,t:1526930309599};\\\", \\\"{x:212,y:651,t:1526930309616};\\\", \\\"{x:208,y:653,t:1526930309633};\\\", \\\"{x:206,y:653,t:1526930309650};\\\", \\\"{x:203,y:654,t:1526930309666};\\\", \\\"{x:199,y:654,t:1526930309683};\\\", \\\"{x:198,y:654,t:1526930309699};\\\", \\\"{x:199,y:654,t:1526930309750};\\\", \\\"{x:220,y:655,t:1526930309767};\\\", \\\"{x:259,y:655,t:1526930309784};\\\", \\\"{x:312,y:655,t:1526930309802};\\\", \\\"{x:382,y:655,t:1526930309816};\\\", \\\"{x:446,y:655,t:1526930309834};\\\", \\\"{x:499,y:655,t:1526930309849};\\\", \\\"{x:542,y:655,t:1526930309867};\\\", \\\"{x:576,y:649,t:1526930309884};\\\", \\\"{x:605,y:646,t:1526930309899};\\\", \\\"{x:630,y:643,t:1526930309916};\\\", \\\"{x:665,y:637,t:1526930309933};\\\", \\\"{x:688,y:635,t:1526930309949};\\\", \\\"{x:708,y:633,t:1526930309966};\\\", \\\"{x:727,y:630,t:1526930309984};\\\", \\\"{x:736,y:628,t:1526930310001};\\\", \\\"{x:740,y:626,t:1526930310017};\\\", \\\"{x:741,y:625,t:1526930310034};\\\", \\\"{x:739,y:625,t:1526930310102};\\\", \\\"{x:729,y:625,t:1526930310117};\\\", \\\"{x:691,y:625,t:1526930310136};\\\", \\\"{x:671,y:625,t:1526930310149};\\\", \\\"{x:657,y:625,t:1526930310167};\\\", \\\"{x:653,y:625,t:1526930310183};\\\", \\\"{x:652,y:625,t:1526930310200};\\\", \\\"{x:650,y:624,t:1526930310261};\\\", \\\"{x:650,y:623,t:1526930310269};\\\", \\\"{x:649,y:622,t:1526930310283};\\\", \\\"{x:647,y:619,t:1526930310305};\\\", \\\"{x:645,y:617,t:1526930310320};\\\", \\\"{x:643,y:615,t:1526930310338};\\\", \\\"{x:643,y:612,t:1526930310354};\\\", \\\"{x:642,y:611,t:1526930310370};\\\", \\\"{x:640,y:607,t:1526930310387};\\\", \\\"{x:637,y:603,t:1526930310405};\\\", \\\"{x:635,y:601,t:1526930310421};\\\", \\\"{x:634,y:601,t:1526930310438};\\\", \\\"{x:633,y:599,t:1526930310456};\\\", \\\"{x:633,y:596,t:1526930310490};\\\", \\\"{x:633,y:595,t:1526930310505};\\\", \\\"{x:631,y:590,t:1526930310522};\\\", \\\"{x:623,y:586,t:1526930310537};\\\", \\\"{x:619,y:585,t:1526930310555};\\\", \\\"{x:618,y:583,t:1526930310572};\\\", \\\"{x:617,y:583,t:1526930310626};\\\", \\\"{x:617,y:582,t:1526930310637};\\\", \\\"{x:616,y:582,t:1526930310657};\\\", \\\"{x:616,y:581,t:1526930311050};\\\", \\\"{x:617,y:581,t:1526930311057};\\\", \\\"{x:620,y:581,t:1526930311072};\\\", \\\"{x:630,y:584,t:1526930311089};\\\", \\\"{x:645,y:588,t:1526930311106};\\\", \\\"{x:683,y:598,t:1526930311122};\\\", \\\"{x:718,y:606,t:1526930311139};\\\", \\\"{x:752,y:611,t:1526930311155};\\\", \\\"{x:783,y:616,t:1526930311171};\\\", \\\"{x:805,y:618,t:1526930311188};\\\", \\\"{x:821,y:621,t:1526930311205};\\\", \\\"{x:826,y:621,t:1526930311222};\\\", \\\"{x:828,y:621,t:1526930311238};\\\", \\\"{x:830,y:621,t:1526930311254};\\\", \\\"{x:831,y:621,t:1526930311272};\\\", \\\"{x:832,y:621,t:1526930311297};\\\", \\\"{x:835,y:621,t:1526930311746};\\\", \\\"{x:839,y:622,t:1526930311755};\\\", \\\"{x:853,y:627,t:1526930311772};\\\", \\\"{x:875,y:632,t:1526930311789};\\\", \\\"{x:902,y:636,t:1526930311806};\\\", \\\"{x:928,y:639,t:1526930311822};\\\", \\\"{x:959,y:643,t:1526930311838};\\\", \\\"{x:1010,y:654,t:1526930311855};\\\", \\\"{x:1061,y:670,t:1526930311873};\\\", \\\"{x:1119,y:687,t:1526930311889};\\\", \\\"{x:1212,y:716,t:1526930311905};\\\", \\\"{x:1261,y:733,t:1526930311923};\\\", \\\"{x:1289,y:747,t:1526930311939};\\\", \\\"{x:1309,y:759,t:1526930311955};\\\", \\\"{x:1322,y:768,t:1526930311973};\\\", \\\"{x:1337,y:779,t:1526930311989};\\\", \\\"{x:1345,y:785,t:1526930312006};\\\", \\\"{x:1355,y:792,t:1526930312023};\\\", \\\"{x:1364,y:798,t:1526930312039};\\\", \\\"{x:1376,y:808,t:1526930312055};\\\", \\\"{x:1392,y:820,t:1526930312072};\\\", \\\"{x:1408,y:830,t:1526930312088};\\\", \\\"{x:1425,y:841,t:1526930312105};\\\", \\\"{x:1433,y:847,t:1526930312123};\\\", \\\"{x:1434,y:850,t:1526930312139};\\\", \\\"{x:1435,y:852,t:1526930312156};\\\", \\\"{x:1436,y:853,t:1526930312173};\\\", \\\"{x:1436,y:854,t:1526930312189};\\\", \\\"{x:1436,y:855,t:1526930312217};\\\", \\\"{x:1433,y:855,t:1526930312226};\\\", \\\"{x:1427,y:855,t:1526930312239};\\\", \\\"{x:1414,y:854,t:1526930312256};\\\", \\\"{x:1399,y:851,t:1526930312273};\\\", \\\"{x:1386,y:847,t:1526930312289};\\\", \\\"{x:1363,y:840,t:1526930312306};\\\", \\\"{x:1346,y:838,t:1526930312323};\\\", \\\"{x:1330,y:833,t:1526930312339};\\\", \\\"{x:1321,y:827,t:1526930312355};\\\", \\\"{x:1313,y:823,t:1526930312373};\\\", \\\"{x:1307,y:820,t:1526930312390};\\\", \\\"{x:1304,y:818,t:1526930312405};\\\", \\\"{x:1299,y:815,t:1526930312423};\\\", \\\"{x:1287,y:814,t:1526930312440};\\\", \\\"{x:1271,y:813,t:1526930312456};\\\", \\\"{x:1250,y:813,t:1526930312473};\\\", \\\"{x:1223,y:813,t:1526930312489};\\\", \\\"{x:1208,y:813,t:1526930312506};\\\", \\\"{x:1199,y:817,t:1526930312523};\\\", \\\"{x:1191,y:820,t:1526930312540};\\\", \\\"{x:1186,y:821,t:1526930312556};\\\", \\\"{x:1180,y:825,t:1526930312573};\\\", \\\"{x:1177,y:828,t:1526930312590};\\\", \\\"{x:1174,y:829,t:1526930312607};\\\", \\\"{x:1171,y:829,t:1526930312623};\\\", \\\"{x:1169,y:829,t:1526930312643};\\\", \\\"{x:1167,y:829,t:1526930312674};\\\", \\\"{x:1164,y:826,t:1526930312690};\\\", \\\"{x:1157,y:816,t:1526930312706};\\\", \\\"{x:1155,y:807,t:1526930312724};\\\", \\\"{x:1154,y:798,t:1526930312740};\\\", \\\"{x:1154,y:788,t:1526930312756};\\\", \\\"{x:1154,y:780,t:1526930312773};\\\", \\\"{x:1158,y:773,t:1526930312790};\\\", \\\"{x:1161,y:769,t:1526930312806};\\\", \\\"{x:1163,y:766,t:1526930312823};\\\", \\\"{x:1165,y:764,t:1526930312840};\\\", \\\"{x:1165,y:762,t:1526930312856};\\\", \\\"{x:1165,y:761,t:1526930312874};\\\", \\\"{x:1166,y:760,t:1526930313434};\\\", \\\"{x:1167,y:760,t:1526930313458};\\\", \\\"{x:1169,y:760,t:1526930313475};\\\", \\\"{x:1170,y:760,t:1526930313490};\\\", \\\"{x:1174,y:760,t:1526930313507};\\\", \\\"{x:1178,y:761,t:1526930313525};\\\", \\\"{x:1184,y:762,t:1526930313540};\\\", \\\"{x:1190,y:763,t:1526930313558};\\\", \\\"{x:1197,y:764,t:1526930313575};\\\", \\\"{x:1204,y:765,t:1526930313591};\\\", \\\"{x:1212,y:765,t:1526930313607};\\\", \\\"{x:1216,y:765,t:1526930313624};\\\", \\\"{x:1219,y:765,t:1526930313640};\\\", \\\"{x:1220,y:765,t:1526930314043};\\\", \\\"{x:1225,y:765,t:1526930314058};\\\", \\\"{x:1256,y:774,t:1526930314075};\\\", \\\"{x:1272,y:778,t:1526930314092};\\\", \\\"{x:1293,y:783,t:1526930314108};\\\", \\\"{x:1311,y:784,t:1526930314124};\\\", \\\"{x:1327,y:788,t:1526930314142};\\\", \\\"{x:1343,y:789,t:1526930314158};\\\", \\\"{x:1357,y:792,t:1526930314174};\\\", \\\"{x:1364,y:793,t:1526930314191};\\\", \\\"{x:1370,y:797,t:1526930314207};\\\", \\\"{x:1384,y:802,t:1526930314224};\\\", \\\"{x:1399,y:807,t:1526930314242};\\\", \\\"{x:1417,y:812,t:1526930314257};\\\", \\\"{x:1443,y:820,t:1526930314274};\\\", \\\"{x:1455,y:825,t:1526930314291};\\\", \\\"{x:1461,y:827,t:1526930314307};\\\", \\\"{x:1467,y:831,t:1526930314323};\\\", \\\"{x:1469,y:832,t:1526930314340};\\\", \\\"{x:1471,y:835,t:1526930314357};\\\", \\\"{x:1477,y:838,t:1526930314374};\\\", \\\"{x:1486,y:844,t:1526930314391};\\\", \\\"{x:1489,y:845,t:1526930314407};\\\", \\\"{x:1493,y:847,t:1526930314424};\\\", \\\"{x:1493,y:848,t:1526930314450};\\\", \\\"{x:1493,y:847,t:1526930314626};\\\", \\\"{x:1493,y:846,t:1526930314641};\\\", \\\"{x:1489,y:841,t:1526930314658};\\\", \\\"{x:1489,y:840,t:1526930314674};\\\", \\\"{x:1489,y:838,t:1526930314691};\\\", \\\"{x:1488,y:838,t:1526930314755};\\\", \\\"{x:1488,y:837,t:1526930314778};\\\", \\\"{x:1487,y:837,t:1526930314802};\\\", \\\"{x:1487,y:836,t:1526930314995};\\\", \\\"{x:1487,y:835,t:1526930315010};\\\", \\\"{x:1487,y:834,t:1526930315025};\\\", \\\"{x:1487,y:833,t:1526930315707};\\\", \\\"{x:1487,y:832,t:1526930315722};\\\", \\\"{x:1486,y:830,t:1526930315739};\\\", \\\"{x:1485,y:829,t:1526930315762};\\\", \\\"{x:1484,y:828,t:1526930315778};\\\", \\\"{x:1483,y:827,t:1526930315859};\\\", \\\"{x:1482,y:828,t:1526930316482};\\\", \\\"{x:1480,y:829,t:1526930316498};\\\", \\\"{x:1480,y:830,t:1526930316509};\\\", \\\"{x:1479,y:830,t:1526930316526};\\\", \\\"{x:1479,y:831,t:1526930316658};\\\", \\\"{x:1478,y:831,t:1526930316698};\\\", \\\"{x:1480,y:832,t:1526930317747};\\\", \\\"{x:1482,y:834,t:1526930317761};\\\", \\\"{x:1491,y:837,t:1526930317778};\\\", \\\"{x:1506,y:843,t:1526930317794};\\\", \\\"{x:1532,y:849,t:1526930317810};\\\", \\\"{x:1546,y:850,t:1526930317826};\\\", \\\"{x:1557,y:852,t:1526930317844};\\\", \\\"{x:1562,y:852,t:1526930317861};\\\", \\\"{x:1564,y:852,t:1526930317876};\\\", \\\"{x:1566,y:852,t:1526930317894};\\\", \\\"{x:1570,y:852,t:1526930317911};\\\", \\\"{x:1576,y:852,t:1526930317927};\\\", \\\"{x:1582,y:852,t:1526930317943};\\\", \\\"{x:1589,y:852,t:1526930317961};\\\", \\\"{x:1596,y:852,t:1526930317977};\\\", \\\"{x:1602,y:852,t:1526930317993};\\\", \\\"{x:1605,y:852,t:1526930318010};\\\", \\\"{x:1607,y:852,t:1526930318090};\\\", \\\"{x:1608,y:852,t:1526930318098};\\\", \\\"{x:1610,y:852,t:1526930318114};\\\", \\\"{x:1611,y:852,t:1526930318130};\\\", \\\"{x:1611,y:851,t:1526930318235};\\\", \\\"{x:1612,y:850,t:1526930318250};\\\", \\\"{x:1613,y:850,t:1526930318261};\\\", \\\"{x:1613,y:849,t:1526930318277};\\\", \\\"{x:1614,y:849,t:1526930318294};\\\", \\\"{x:1615,y:848,t:1526930318311};\\\", \\\"{x:1616,y:846,t:1526930318327};\\\", \\\"{x:1617,y:845,t:1526930318344};\\\", \\\"{x:1617,y:844,t:1526930318362};\\\", \\\"{x:1617,y:843,t:1526930318386};\\\", \\\"{x:1617,y:842,t:1526930318402};\\\", \\\"{x:1617,y:841,t:1526930318426};\\\", \\\"{x:1617,y:839,t:1526930318458};\\\", \\\"{x:1617,y:838,t:1526930318490};\\\", \\\"{x:1617,y:836,t:1526930318506};\\\", \\\"{x:1617,y:835,t:1526930318522};\\\", \\\"{x:1617,y:834,t:1526930318529};\\\", \\\"{x:1617,y:833,t:1526930318544};\\\", \\\"{x:1617,y:832,t:1526930318561};\\\", \\\"{x:1617,y:829,t:1526930318577};\\\", \\\"{x:1617,y:828,t:1526930318626};\\\", \\\"{x:1617,y:827,t:1526930318650};\\\", \\\"{x:1616,y:826,t:1526930318661};\\\", \\\"{x:1616,y:825,t:1526930318715};\\\", \\\"{x:1614,y:822,t:1526930319707};\\\", \\\"{x:1614,y:821,t:1526930319714};\\\", \\\"{x:1614,y:819,t:1526930319728};\\\", \\\"{x:1613,y:815,t:1526930319745};\\\", \\\"{x:1613,y:811,t:1526930319762};\\\", \\\"{x:1613,y:810,t:1526930319779};\\\", \\\"{x:1613,y:809,t:1526930319875};\\\", \\\"{x:1612,y:809,t:1526930319882};\\\", \\\"{x:1611,y:812,t:1526930319895};\\\", \\\"{x:1611,y:817,t:1526930319912};\\\", \\\"{x:1611,y:823,t:1526930319929};\\\", \\\"{x:1611,y:828,t:1526930319945};\\\", \\\"{x:1611,y:832,t:1526930319962};\\\", \\\"{x:1611,y:838,t:1526930319978};\\\", \\\"{x:1611,y:841,t:1526930319995};\\\", \\\"{x:1611,y:842,t:1526930320012};\\\", \\\"{x:1611,y:843,t:1526930320162};\\\", \\\"{x:1612,y:843,t:1526930320186};\\\", \\\"{x:1613,y:841,t:1526930320196};\\\", \\\"{x:1614,y:841,t:1526930320211};\\\", \\\"{x:1614,y:839,t:1526930320229};\\\", \\\"{x:1615,y:838,t:1526930320258};\\\", \\\"{x:1615,y:836,t:1526930321331};\\\", \\\"{x:1615,y:835,t:1526930321363};\\\", \\\"{x:1615,y:834,t:1526930321380};\\\", \\\"{x:1615,y:833,t:1526930321395};\\\", \\\"{x:1615,y:831,t:1526930321435};\\\", \\\"{x:1615,y:830,t:1526930322914};\\\", \\\"{x:1615,y:829,t:1526930322931};\\\", \\\"{x:1615,y:828,t:1526930322946};\\\", \\\"{x:1615,y:827,t:1526930322987};\\\", \\\"{x:1615,y:826,t:1526930323018};\\\", \\\"{x:1615,y:825,t:1526930323031};\\\", \\\"{x:1614,y:825,t:1526930323047};\\\", \\\"{x:1613,y:824,t:1526930323064};\\\", \\\"{x:1613,y:823,t:1526930323778};\\\", \\\"{x:1612,y:822,t:1526930323834};\\\", \\\"{x:1610,y:821,t:1526930323915};\\\", \\\"{x:1610,y:820,t:1526930324299};\\\", \\\"{x:1609,y:819,t:1526930324402};\\\", \\\"{x:1607,y:819,t:1526930325227};\\\", \\\"{x:1603,y:816,t:1526930325234};\\\", \\\"{x:1599,y:814,t:1526930325248};\\\", \\\"{x:1592,y:811,t:1526930325265};\\\", \\\"{x:1577,y:802,t:1526930325282};\\\", \\\"{x:1572,y:799,t:1526930325298};\\\", \\\"{x:1568,y:796,t:1526930325315};\\\", \\\"{x:1565,y:794,t:1526930325332};\\\", \\\"{x:1561,y:792,t:1526930325348};\\\", \\\"{x:1560,y:791,t:1526930325365};\\\", \\\"{x:1559,y:790,t:1526930325381};\\\", \\\"{x:1558,y:790,t:1526930325398};\\\", \\\"{x:1558,y:789,t:1526930325416};\\\", \\\"{x:1556,y:789,t:1526930325635};\\\", \\\"{x:1553,y:788,t:1526930325649};\\\", \\\"{x:1540,y:782,t:1526930325666};\\\", \\\"{x:1533,y:779,t:1526930325682};\\\", \\\"{x:1528,y:777,t:1526930325699};\\\", \\\"{x:1527,y:776,t:1526930325716};\\\", \\\"{x:1526,y:776,t:1526930325786};\\\", \\\"{x:1525,y:775,t:1526930325798};\\\", \\\"{x:1521,y:774,t:1526930325816};\\\", \\\"{x:1518,y:772,t:1526930325832};\\\", \\\"{x:1514,y:769,t:1526930325849};\\\", \\\"{x:1511,y:768,t:1526930325866};\\\", \\\"{x:1510,y:768,t:1526930325898};\\\", \\\"{x:1508,y:767,t:1526930325916};\\\", \\\"{x:1505,y:766,t:1526930325934};\\\", \\\"{x:1501,y:765,t:1526930325949};\\\", \\\"{x:1499,y:763,t:1526930325966};\\\", \\\"{x:1498,y:763,t:1526930325983};\\\", \\\"{x:1497,y:762,t:1526930325999};\\\", \\\"{x:1496,y:760,t:1526930326016};\\\", \\\"{x:1494,y:759,t:1526930326033};\\\", \\\"{x:1494,y:757,t:1526930326290};\\\", \\\"{x:1495,y:757,t:1526930326306};\\\", \\\"{x:1496,y:757,t:1526930326322};\\\", \\\"{x:1497,y:757,t:1526930326426};\\\", \\\"{x:1498,y:757,t:1526930326451};\\\", \\\"{x:1498,y:756,t:1526930326466};\\\", \\\"{x:1499,y:756,t:1526930326571};\\\", \\\"{x:1500,y:755,t:1526930326583};\\\", \\\"{x:1501,y:755,t:1526930326602};\\\", \\\"{x:1502,y:755,t:1526930326618};\\\", \\\"{x:1503,y:755,t:1526930326634};\\\", \\\"{x:1504,y:755,t:1526930326650};\\\", \\\"{x:1499,y:755,t:1526930326706};\\\", \\\"{x:1487,y:758,t:1526930326716};\\\", \\\"{x:1444,y:762,t:1526930326735};\\\", \\\"{x:1363,y:762,t:1526930326750};\\\", \\\"{x:1277,y:762,t:1526930326766};\\\", \\\"{x:1205,y:762,t:1526930326783};\\\", \\\"{x:1152,y:762,t:1526930326800};\\\", \\\"{x:1122,y:762,t:1526930326815};\\\", \\\"{x:1114,y:764,t:1526930326832};\\\", \\\"{x:1113,y:764,t:1526930326858};\\\", \\\"{x:1112,y:764,t:1526930326874};\\\", \\\"{x:1111,y:764,t:1526930326883};\\\", \\\"{x:1110,y:765,t:1526930326900};\\\", \\\"{x:1108,y:766,t:1526930326916};\\\", \\\"{x:1107,y:767,t:1526930326934};\\\", \\\"{x:1112,y:767,t:1526930327034};\\\", \\\"{x:1128,y:767,t:1526930327050};\\\", \\\"{x:1151,y:767,t:1526930327066};\\\", \\\"{x:1173,y:767,t:1526930327082};\\\", \\\"{x:1196,y:767,t:1526930327099};\\\", \\\"{x:1215,y:767,t:1526930327117};\\\", \\\"{x:1226,y:767,t:1526930327134};\\\", \\\"{x:1239,y:767,t:1526930327150};\\\", \\\"{x:1248,y:767,t:1526930327167};\\\", \\\"{x:1262,y:767,t:1526930327183};\\\", \\\"{x:1276,y:767,t:1526930327200};\\\", \\\"{x:1290,y:767,t:1526930327217};\\\", \\\"{x:1301,y:767,t:1526930327233};\\\", \\\"{x:1321,y:770,t:1526930327250};\\\", \\\"{x:1335,y:771,t:1526930327267};\\\", \\\"{x:1355,y:774,t:1526930327283};\\\", \\\"{x:1373,y:777,t:1526930327300};\\\", \\\"{x:1387,y:778,t:1526930327317};\\\", \\\"{x:1391,y:778,t:1526930327334};\\\", \\\"{x:1392,y:778,t:1526930327483};\\\", \\\"{x:1391,y:777,t:1526930327498};\\\", \\\"{x:1391,y:776,t:1526930327506};\\\", \\\"{x:1389,y:775,t:1526930327517};\\\", \\\"{x:1389,y:773,t:1526930327535};\\\", \\\"{x:1388,y:772,t:1526930327549};\\\", \\\"{x:1388,y:771,t:1526930327601};\\\", \\\"{x:1387,y:771,t:1526930327914};\\\", \\\"{x:1386,y:771,t:1526930327995};\\\", \\\"{x:1386,y:770,t:1526930328017};\\\", \\\"{x:1385,y:770,t:1526930328058};\\\", \\\"{x:1383,y:769,t:1526930328075};\\\", \\\"{x:1382,y:768,t:1526930328139};\\\", \\\"{x:1381,y:767,t:1526930328178};\\\", \\\"{x:1380,y:767,t:1526930328187};\\\", \\\"{x:1380,y:766,t:1526930328201};\\\", \\\"{x:1380,y:765,t:1526930328217};\\\", \\\"{x:1379,y:764,t:1526930328235};\\\", \\\"{x:1383,y:765,t:1526930328425};\\\", \\\"{x:1392,y:767,t:1526930328433};\\\", \\\"{x:1416,y:773,t:1526930328450};\\\", \\\"{x:1435,y:775,t:1526930328467};\\\", \\\"{x:1456,y:778,t:1526930328483};\\\", \\\"{x:1472,y:778,t:1526930328500};\\\", \\\"{x:1479,y:778,t:1526930328517};\\\", \\\"{x:1482,y:778,t:1526930328536};\\\", \\\"{x:1483,y:778,t:1526930328550};\\\", \\\"{x:1486,y:777,t:1526930328567};\\\", \\\"{x:1497,y:776,t:1526930328583};\\\", \\\"{x:1514,y:774,t:1526930328600};\\\", \\\"{x:1540,y:772,t:1526930328617};\\\", \\\"{x:1558,y:772,t:1526930328633};\\\", \\\"{x:1576,y:772,t:1526930328650};\\\", \\\"{x:1588,y:772,t:1526930328668};\\\", \\\"{x:1599,y:772,t:1526930328683};\\\", \\\"{x:1608,y:772,t:1526930328700};\\\", \\\"{x:1614,y:772,t:1526930328718};\\\", \\\"{x:1619,y:772,t:1526930328734};\\\", \\\"{x:1624,y:772,t:1526930328750};\\\", \\\"{x:1627,y:772,t:1526930328768};\\\", \\\"{x:1632,y:772,t:1526930328783};\\\", \\\"{x:1640,y:772,t:1526930328800};\\\", \\\"{x:1647,y:772,t:1526930328818};\\\", \\\"{x:1651,y:772,t:1526930328833};\\\", \\\"{x:1658,y:772,t:1526930328850};\\\", \\\"{x:1662,y:771,t:1526930328867};\\\", \\\"{x:1665,y:771,t:1526930328883};\\\", \\\"{x:1670,y:771,t:1526930328900};\\\", \\\"{x:1674,y:770,t:1526930328918};\\\", \\\"{x:1678,y:768,t:1526930328934};\\\", \\\"{x:1682,y:768,t:1526930328950};\\\", \\\"{x:1688,y:768,t:1526930328967};\\\", \\\"{x:1696,y:767,t:1526930328984};\\\", \\\"{x:1704,y:766,t:1526930329000};\\\", \\\"{x:1713,y:763,t:1526930329017};\\\", \\\"{x:1716,y:762,t:1526930329034};\\\", \\\"{x:1718,y:762,t:1526930329050};\\\", \\\"{x:1719,y:762,t:1526930329068};\\\", \\\"{x:1720,y:762,t:1526930329089};\\\", \\\"{x:1722,y:762,t:1526930329105};\\\", \\\"{x:1723,y:762,t:1526930329117};\\\", \\\"{x:1727,y:760,t:1526930329134};\\\", \\\"{x:1728,y:760,t:1526930329151};\\\", \\\"{x:1726,y:760,t:1526930329314};\\\", \\\"{x:1725,y:761,t:1526930329322};\\\", \\\"{x:1723,y:761,t:1526930329335};\\\", \\\"{x:1721,y:761,t:1526930329351};\\\", \\\"{x:1718,y:763,t:1526930329368};\\\", \\\"{x:1717,y:763,t:1526930329770};\\\", \\\"{x:1716,y:763,t:1526930329835};\\\", \\\"{x:1715,y:763,t:1526930329978};\\\", \\\"{x:1713,y:763,t:1526930329986};\\\", \\\"{x:1704,y:763,t:1526930330002};\\\", \\\"{x:1676,y:763,t:1526930330018};\\\", \\\"{x:1612,y:763,t:1526930330035};\\\", \\\"{x:1526,y:763,t:1526930330052};\\\", \\\"{x:1440,y:761,t:1526930330069};\\\", \\\"{x:1378,y:761,t:1526930330085};\\\", \\\"{x:1334,y:757,t:1526930330102};\\\", \\\"{x:1314,y:757,t:1526930330119};\\\", \\\"{x:1307,y:757,t:1526930330135};\\\", \\\"{x:1308,y:757,t:1526930330218};\\\", \\\"{x:1323,y:757,t:1526930330235};\\\", \\\"{x:1345,y:759,t:1526930330252};\\\", \\\"{x:1369,y:763,t:1526930330270};\\\", \\\"{x:1390,y:763,t:1526930330285};\\\", \\\"{x:1407,y:764,t:1526930330302};\\\", \\\"{x:1421,y:764,t:1526930330319};\\\", \\\"{x:1432,y:764,t:1526930330335};\\\", \\\"{x:1443,y:764,t:1526930330352};\\\", \\\"{x:1451,y:764,t:1526930330369};\\\", \\\"{x:1458,y:762,t:1526930330385};\\\", \\\"{x:1463,y:762,t:1526930330402};\\\", \\\"{x:1464,y:762,t:1526930330418};\\\", \\\"{x:1465,y:762,t:1526930330435};\\\", \\\"{x:1467,y:762,t:1526930330452};\\\", \\\"{x:1470,y:761,t:1526930330469};\\\", \\\"{x:1474,y:761,t:1526930330485};\\\", \\\"{x:1477,y:761,t:1526930330502};\\\", \\\"{x:1482,y:761,t:1526930330519};\\\", \\\"{x:1485,y:761,t:1526930330536};\\\", \\\"{x:1488,y:761,t:1526930330552};\\\", \\\"{x:1489,y:761,t:1526930330569};\\\", \\\"{x:1490,y:761,t:1526930330594};\\\", \\\"{x:1492,y:761,t:1526930330602};\\\", \\\"{x:1494,y:761,t:1526930330618};\\\", \\\"{x:1498,y:761,t:1526930330636};\\\", \\\"{x:1501,y:761,t:1526930330652};\\\", \\\"{x:1502,y:761,t:1526930330668};\\\", \\\"{x:1503,y:761,t:1526930330685};\\\", \\\"{x:1504,y:761,t:1526930330745};\\\", \\\"{x:1505,y:761,t:1526930330753};\\\", \\\"{x:1506,y:761,t:1526930330769};\\\", \\\"{x:1508,y:761,t:1526930330785};\\\", \\\"{x:1511,y:761,t:1526930330802};\\\", \\\"{x:1513,y:761,t:1526930330819};\\\", \\\"{x:1514,y:761,t:1526930331938};\\\", \\\"{x:1515,y:761,t:1526930331977};\\\", \\\"{x:1516,y:762,t:1526930331985};\\\", \\\"{x:1517,y:763,t:1526930332009};\\\", \\\"{x:1519,y:763,t:1526930332057};\\\", \\\"{x:1521,y:763,t:1526930332074};\\\", \\\"{x:1523,y:763,t:1526930332085};\\\", \\\"{x:1526,y:763,t:1526930332103};\\\", \\\"{x:1529,y:763,t:1526930332120};\\\", \\\"{x:1531,y:763,t:1526930332137};\\\", \\\"{x:1533,y:763,t:1526930332153};\\\", \\\"{x:1534,y:763,t:1526930332177};\\\", \\\"{x:1535,y:763,t:1526930332210};\\\", \\\"{x:1536,y:763,t:1526930332226};\\\", \\\"{x:1537,y:763,t:1526930332237};\\\", \\\"{x:1540,y:763,t:1526930332253};\\\", \\\"{x:1543,y:763,t:1526930332269};\\\", \\\"{x:1545,y:763,t:1526930332286};\\\", \\\"{x:1546,y:763,t:1526930332303};\\\", \\\"{x:1547,y:763,t:1526930332322};\\\", \\\"{x:1548,y:763,t:1526930332345};\\\", \\\"{x:1549,y:763,t:1526930332378};\\\", \\\"{x:1550,y:763,t:1526930332434};\\\", \\\"{x:1551,y:763,t:1526930332442};\\\", \\\"{x:1552,y:763,t:1526930332955};\\\", \\\"{x:1553,y:763,t:1526930333074};\\\", \\\"{x:1553,y:765,t:1526930334371};\\\", \\\"{x:1539,y:783,t:1526930334388};\\\", \\\"{x:1518,y:807,t:1526930334406};\\\", \\\"{x:1492,y:839,t:1526930334421};\\\", \\\"{x:1476,y:861,t:1526930334438};\\\", \\\"{x:1466,y:881,t:1526930334455};\\\", \\\"{x:1460,y:897,t:1526930334471};\\\", \\\"{x:1455,y:904,t:1526930334488};\\\", \\\"{x:1454,y:905,t:1526930334506};\\\", \\\"{x:1453,y:906,t:1526930334521};\\\", \\\"{x:1452,y:906,t:1526930334634};\\\", \\\"{x:1449,y:905,t:1526930334643};\\\", \\\"{x:1448,y:903,t:1526930334655};\\\", \\\"{x:1443,y:899,t:1526930334671};\\\", \\\"{x:1438,y:897,t:1526930334688};\\\", \\\"{x:1431,y:897,t:1526930334705};\\\", \\\"{x:1411,y:897,t:1526930334722};\\\", \\\"{x:1400,y:897,t:1526930334738};\\\", \\\"{x:1388,y:897,t:1526930334756};\\\", \\\"{x:1384,y:896,t:1526930334772};\\\", \\\"{x:1383,y:895,t:1526930334805};\\\", \\\"{x:1382,y:895,t:1526930334822};\\\", \\\"{x:1382,y:894,t:1526930334838};\\\", \\\"{x:1382,y:893,t:1526930335473};\\\", \\\"{x:1383,y:892,t:1526930335488};\\\", \\\"{x:1392,y:891,t:1526930335505};\\\", \\\"{x:1403,y:891,t:1526930335522};\\\", \\\"{x:1410,y:891,t:1526930335539};\\\", \\\"{x:1416,y:891,t:1526930335555};\\\", \\\"{x:1420,y:891,t:1526930335572};\\\", \\\"{x:1423,y:891,t:1526930335589};\\\", \\\"{x:1425,y:891,t:1526930335762};\\\", \\\"{x:1426,y:891,t:1526930335772};\\\", \\\"{x:1430,y:891,t:1526930335789};\\\", \\\"{x:1433,y:891,t:1526930335806};\\\", \\\"{x:1435,y:891,t:1526930335823};\\\", \\\"{x:1436,y:891,t:1526930335866};\\\", \\\"{x:1437,y:891,t:1526930335931};\\\", \\\"{x:1439,y:891,t:1526930335939};\\\", \\\"{x:1440,y:891,t:1526930335961};\\\", \\\"{x:1442,y:891,t:1526930335971};\\\", \\\"{x:1443,y:891,t:1526930335989};\\\", \\\"{x:1444,y:891,t:1526930336006};\\\", \\\"{x:1445,y:891,t:1526930336022};\\\", \\\"{x:1446,y:891,t:1526930336041};\\\", \\\"{x:1447,y:891,t:1526930336055};\\\", \\\"{x:1448,y:891,t:1526930336072};\\\", \\\"{x:1450,y:891,t:1526930336089};\\\", \\\"{x:1451,y:891,t:1526930336106};\\\", \\\"{x:1451,y:890,t:1526930340466};\\\", \\\"{x:1451,y:889,t:1526930340481};\\\", \\\"{x:1451,y:887,t:1526930340498};\\\", \\\"{x:1450,y:886,t:1526930340514};\\\", \\\"{x:1448,y:882,t:1526930341331};\\\", \\\"{x:1446,y:880,t:1526930341342};\\\", \\\"{x:1437,y:871,t:1526930341358};\\\", \\\"{x:1421,y:854,t:1526930341376};\\\", \\\"{x:1410,y:836,t:1526930341392};\\\", \\\"{x:1394,y:801,t:1526930341409};\\\", \\\"{x:1389,y:786,t:1526930341425};\\\", \\\"{x:1386,y:770,t:1526930341442};\\\", \\\"{x:1386,y:755,t:1526930341459};\\\", \\\"{x:1386,y:737,t:1526930341476};\\\", \\\"{x:1386,y:715,t:1526930341493};\\\", \\\"{x:1394,y:690,t:1526930341509};\\\", \\\"{x:1402,y:670,t:1526930341526};\\\", \\\"{x:1409,y:651,t:1526930341543};\\\", \\\"{x:1416,y:640,t:1526930341559};\\\", \\\"{x:1418,y:635,t:1526930341576};\\\", \\\"{x:1420,y:629,t:1526930341593};\\\", \\\"{x:1422,y:626,t:1526930341609};\\\", \\\"{x:1423,y:623,t:1526930341627};\\\", \\\"{x:1424,y:621,t:1526930341644};\\\", \\\"{x:1427,y:616,t:1526930341659};\\\", \\\"{x:1432,y:606,t:1526930341676};\\\", \\\"{x:1439,y:595,t:1526930341694};\\\", \\\"{x:1447,y:584,t:1526930341710};\\\", \\\"{x:1454,y:577,t:1526930341726};\\\", \\\"{x:1455,y:574,t:1526930341743};\\\", \\\"{x:1457,y:571,t:1526930341759};\\\", \\\"{x:1458,y:571,t:1526930341777};\\\", \\\"{x:1460,y:571,t:1526930341866};\\\", \\\"{x:1461,y:571,t:1526930341876};\\\", \\\"{x:1462,y:571,t:1526930341893};\\\", \\\"{x:1464,y:571,t:1526930341910};\\\", \\\"{x:1465,y:571,t:1526930341926};\\\", \\\"{x:1466,y:571,t:1526930341944};\\\", \\\"{x:1467,y:571,t:1526930341984};\\\", \\\"{x:1468,y:571,t:1526930342001};\\\", \\\"{x:1469,y:571,t:1526930342041};\\\", \\\"{x:1470,y:571,t:1526930342057};\\\", \\\"{x:1471,y:571,t:1526930342073};\\\", \\\"{x:1473,y:571,t:1526930342114};\\\", \\\"{x:1474,y:571,t:1526930342126};\\\", \\\"{x:1476,y:571,t:1526930342143};\\\", \\\"{x:1477,y:571,t:1526930342161};\\\", \\\"{x:1478,y:571,t:1526930342186};\\\", \\\"{x:1479,y:571,t:1526930342192};\\\", \\\"{x:1480,y:569,t:1526930342209};\\\", \\\"{x:1481,y:569,t:1526930342233};\\\", \\\"{x:1482,y:569,t:1526930342243};\\\", \\\"{x:1483,y:568,t:1526930342260};\\\", \\\"{x:1485,y:568,t:1526930342277};\\\", \\\"{x:1486,y:567,t:1526930342293};\\\", \\\"{x:1488,y:566,t:1526930342311};\\\", \\\"{x:1489,y:566,t:1526930342326};\\\", \\\"{x:1489,y:565,t:1526930342343};\\\", \\\"{x:1487,y:565,t:1526930343490};\\\", \\\"{x:1483,y:565,t:1526930343497};\\\", \\\"{x:1481,y:565,t:1526930343511};\\\", \\\"{x:1472,y:565,t:1526930343527};\\\", \\\"{x:1465,y:565,t:1526930343544};\\\", \\\"{x:1461,y:565,t:1526930343562};\\\", \\\"{x:1460,y:565,t:1526930343578};\\\", \\\"{x:1461,y:565,t:1526930343786};\\\", \\\"{x:1465,y:565,t:1526930343794};\\\", \\\"{x:1475,y:565,t:1526930343812};\\\", \\\"{x:1483,y:565,t:1526930343828};\\\", \\\"{x:1485,y:565,t:1526930343845};\\\", \\\"{x:1484,y:565,t:1526930344146};\\\", \\\"{x:1483,y:566,t:1526930344186};\\\", \\\"{x:1482,y:566,t:1526930344234};\\\", \\\"{x:1481,y:566,t:1526930344266};\\\", \\\"{x:1480,y:566,t:1526930344306};\\\", \\\"{x:1482,y:566,t:1526930344562};\\\", \\\"{x:1490,y:566,t:1526930344578};\\\", \\\"{x:1503,y:566,t:1526930344595};\\\", \\\"{x:1512,y:566,t:1526930344612};\\\", \\\"{x:1520,y:566,t:1526930344628};\\\", \\\"{x:1523,y:566,t:1526930344645};\\\", \\\"{x:1524,y:566,t:1526930344661};\\\", \\\"{x:1525,y:566,t:1526930344679};\\\", \\\"{x:1527,y:566,t:1526930344695};\\\", \\\"{x:1530,y:566,t:1526930344712};\\\", \\\"{x:1535,y:566,t:1526930344728};\\\", \\\"{x:1542,y:566,t:1526930344746};\\\", \\\"{x:1548,y:566,t:1526930344762};\\\", \\\"{x:1552,y:566,t:1526930344778};\\\", \\\"{x:1556,y:566,t:1526930344795};\\\", \\\"{x:1562,y:566,t:1526930344812};\\\", \\\"{x:1566,y:566,t:1526930344828};\\\", \\\"{x:1570,y:566,t:1526930344846};\\\", \\\"{x:1575,y:566,t:1526930344862};\\\", \\\"{x:1582,y:566,t:1526930344878};\\\", \\\"{x:1589,y:566,t:1526930344895};\\\", \\\"{x:1595,y:566,t:1526930344911};\\\", \\\"{x:1600,y:566,t:1526930344928};\\\", \\\"{x:1604,y:566,t:1526930344945};\\\", \\\"{x:1605,y:566,t:1526930344961};\\\", \\\"{x:1605,y:565,t:1526930345242};\\\", \\\"{x:1605,y:564,t:1526930345258};\\\", \\\"{x:1606,y:563,t:1526930345274};\\\", \\\"{x:1607,y:563,t:1526930345290};\\\", \\\"{x:1608,y:563,t:1526930345305};\\\", \\\"{x:1608,y:562,t:1526930345314};\\\", \\\"{x:1609,y:562,t:1526930345338};\\\", \\\"{x:1610,y:562,t:1526930345354};\\\", \\\"{x:1611,y:561,t:1526930345369};\\\", \\\"{x:1612,y:561,t:1526930345882};\\\", \\\"{x:1612,y:560,t:1526930346650};\\\", \\\"{x:1611,y:560,t:1526930347530};\\\", \\\"{x:1610,y:560,t:1526930347618};\\\", \\\"{x:1609,y:560,t:1526930347762};\\\", \\\"{x:1610,y:560,t:1526930351434};\\\", \\\"{x:1611,y:560,t:1526930351449};\\\", \\\"{x:1611,y:559,t:1526930352610};\\\", \\\"{x:1609,y:559,t:1526930352738};\\\", \\\"{x:1608,y:559,t:1526930352810};\\\", \\\"{x:1606,y:559,t:1526930352938};\\\", \\\"{x:1605,y:559,t:1526930352994};\\\", \\\"{x:1602,y:559,t:1526930353314};\\\", \\\"{x:1600,y:561,t:1526930353321};\\\", \\\"{x:1595,y:564,t:1526930353334};\\\", \\\"{x:1583,y:574,t:1526930353351};\\\", \\\"{x:1565,y:585,t:1526930353368};\\\", \\\"{x:1542,y:595,t:1526930353384};\\\", \\\"{x:1513,y:610,t:1526930353401};\\\", \\\"{x:1469,y:635,t:1526930353418};\\\", \\\"{x:1451,y:648,t:1526930353434};\\\", \\\"{x:1432,y:664,t:1526930353450};\\\", \\\"{x:1418,y:681,t:1526930353468};\\\", \\\"{x:1404,y:700,t:1526930353485};\\\", \\\"{x:1392,y:715,t:1526930353501};\\\", \\\"{x:1383,y:729,t:1526930353518};\\\", \\\"{x:1378,y:736,t:1526930353535};\\\", \\\"{x:1378,y:737,t:1526930353554};\\\", \\\"{x:1377,y:739,t:1526930353586};\\\", \\\"{x:1376,y:740,t:1526930353601};\\\", \\\"{x:1376,y:741,t:1526930353641};\\\", \\\"{x:1373,y:739,t:1526930353729};\\\", \\\"{x:1371,y:735,t:1526930353737};\\\", \\\"{x:1369,y:732,t:1526930353751};\\\", \\\"{x:1363,y:726,t:1526930353768};\\\", \\\"{x:1354,y:718,t:1526930353785};\\\", \\\"{x:1351,y:714,t:1526930353801};\\\", \\\"{x:1345,y:710,t:1526930353817};\\\", \\\"{x:1343,y:708,t:1526930353834};\\\", \\\"{x:1342,y:706,t:1526930353851};\\\", \\\"{x:1340,y:704,t:1526930353867};\\\", \\\"{x:1339,y:702,t:1526930353890};\\\", \\\"{x:1338,y:701,t:1526930353906};\\\", \\\"{x:1337,y:700,t:1526930353918};\\\", \\\"{x:1336,y:699,t:1526930353938};\\\", \\\"{x:1336,y:698,t:1526930353961};\\\", \\\"{x:1336,y:697,t:1526930353968};\\\", \\\"{x:1336,y:696,t:1526930354000};\\\", \\\"{x:1336,y:695,t:1526930354033};\\\", \\\"{x:1336,y:694,t:1526930354145};\\\", \\\"{x:1337,y:694,t:1526930355489};\\\", \\\"{x:1338,y:694,t:1526930355501};\\\", \\\"{x:1341,y:694,t:1526930355519};\\\", \\\"{x:1347,y:694,t:1526930355535};\\\", \\\"{x:1350,y:694,t:1526930355552};\\\", \\\"{x:1354,y:694,t:1526930355569};\\\", \\\"{x:1358,y:694,t:1526930355585};\\\", \\\"{x:1360,y:694,t:1526930355603};\\\", \\\"{x:1361,y:694,t:1526930355625};\\\", \\\"{x:1363,y:694,t:1526930355738};\\\", \\\"{x:1364,y:692,t:1526930355762};\\\", \\\"{x:1365,y:692,t:1526930355793};\\\", \\\"{x:1366,y:692,t:1526930355809};\\\", \\\"{x:1367,y:692,t:1526930355850};\\\", \\\"{x:1367,y:691,t:1526930355865};\\\", \\\"{x:1368,y:691,t:1526930355890};\\\", \\\"{x:1369,y:691,t:1526930355905};\\\", \\\"{x:1370,y:691,t:1526930355919};\\\", \\\"{x:1371,y:691,t:1526930355936};\\\", \\\"{x:1373,y:691,t:1526930355952};\\\", \\\"{x:1376,y:691,t:1526930355969};\\\", \\\"{x:1377,y:691,t:1526930355986};\\\", \\\"{x:1378,y:691,t:1526930356003};\\\", \\\"{x:1379,y:691,t:1526930356019};\\\", \\\"{x:1378,y:691,t:1526930356866};\\\", \\\"{x:1375,y:692,t:1526930356874};\\\", \\\"{x:1373,y:693,t:1526930356887};\\\", \\\"{x:1369,y:693,t:1526930356903};\\\", \\\"{x:1366,y:693,t:1526930356920};\\\", \\\"{x:1364,y:694,t:1526930356937};\\\", \\\"{x:1362,y:694,t:1526930356994};\\\", \\\"{x:1360,y:694,t:1526930357003};\\\", \\\"{x:1353,y:694,t:1526930357020};\\\", \\\"{x:1344,y:694,t:1526930357037};\\\", \\\"{x:1334,y:694,t:1526930357055};\\\", \\\"{x:1329,y:694,t:1526930357070};\\\", \\\"{x:1328,y:694,t:1526930357087};\\\", \\\"{x:1327,y:695,t:1526930357354};\\\", \\\"{x:1327,y:699,t:1526930357370};\\\", \\\"{x:1319,y:705,t:1526930357387};\\\", \\\"{x:1303,y:714,t:1526930357404};\\\", \\\"{x:1285,y:724,t:1526930357420};\\\", \\\"{x:1265,y:733,t:1526930357437};\\\", \\\"{x:1249,y:740,t:1526930357454};\\\", \\\"{x:1239,y:747,t:1526930357470};\\\", \\\"{x:1235,y:749,t:1526930357487};\\\", \\\"{x:1234,y:750,t:1526930357504};\\\", \\\"{x:1233,y:751,t:1526930357520};\\\", \\\"{x:1232,y:751,t:1526930357537};\\\", \\\"{x:1232,y:752,t:1526930357585};\\\", \\\"{x:1230,y:753,t:1526930357604};\\\", \\\"{x:1229,y:754,t:1526930357642};\\\", \\\"{x:1227,y:755,t:1526930357665};\\\", \\\"{x:1224,y:757,t:1526930357674};\\\", \\\"{x:1221,y:758,t:1526930357687};\\\", \\\"{x:1208,y:763,t:1526930357704};\\\", \\\"{x:1190,y:769,t:1526930357721};\\\", \\\"{x:1185,y:771,t:1526930357737};\\\", \\\"{x:1184,y:772,t:1526930357754};\\\", \\\"{x:1186,y:772,t:1526930357954};\\\", \\\"{x:1188,y:772,t:1526930357971};\\\", \\\"{x:1188,y:771,t:1526930358178};\\\", \\\"{x:1187,y:771,t:1526930358188};\\\", \\\"{x:1181,y:771,t:1526930358204};\\\", \\\"{x:1180,y:771,t:1526930358221};\\\", \\\"{x:1177,y:770,t:1526930358238};\\\", \\\"{x:1176,y:770,t:1526930358434};\\\", \\\"{x:1176,y:769,t:1526930358458};\\\", \\\"{x:1176,y:767,t:1526930358471};\\\", \\\"{x:1180,y:767,t:1526930358488};\\\", \\\"{x:1190,y:766,t:1526930358505};\\\", \\\"{x:1217,y:766,t:1526930358521};\\\", \\\"{x:1239,y:766,t:1526930358537};\\\", \\\"{x:1265,y:766,t:1526930358554};\\\", \\\"{x:1288,y:766,t:1526930358571};\\\", \\\"{x:1309,y:763,t:1526930358588};\\\", \\\"{x:1322,y:763,t:1526930358604};\\\", \\\"{x:1332,y:763,t:1526930358621};\\\", \\\"{x:1337,y:763,t:1526930358638};\\\", \\\"{x:1341,y:763,t:1526930358654};\\\", \\\"{x:1347,y:763,t:1526930358671};\\\", \\\"{x:1356,y:763,t:1526930358689};\\\", \\\"{x:1380,y:763,t:1526930358705};\\\", \\\"{x:1391,y:763,t:1526930358721};\\\", \\\"{x:1397,y:763,t:1526930358738};\\\", \\\"{x:1399,y:763,t:1526930358755};\\\", \\\"{x:1396,y:762,t:1526930359002};\\\", \\\"{x:1390,y:761,t:1526930359009};\\\", \\\"{x:1379,y:761,t:1526930359021};\\\", \\\"{x:1348,y:757,t:1526930359038};\\\", \\\"{x:1267,y:746,t:1526930359055};\\\", \\\"{x:1156,y:730,t:1526930359071};\\\", \\\"{x:1032,y:713,t:1526930359088};\\\", \\\"{x:858,y:687,t:1526930359105};\\\", \\\"{x:766,y:670,t:1526930359121};\\\", \\\"{x:724,y:659,t:1526930359137};\\\", \\\"{x:705,y:651,t:1526930359155};\\\", \\\"{x:702,y:649,t:1526930359172};\\\", \\\"{x:701,y:648,t:1526930359188};\\\", \\\"{x:701,y:644,t:1526930359204};\\\", \\\"{x:701,y:640,t:1526930359222};\\\", \\\"{x:701,y:633,t:1526930359238};\\\", \\\"{x:703,y:626,t:1526930359255};\\\", \\\"{x:711,y:614,t:1526930359271};\\\", \\\"{x:719,y:604,t:1526930359287};\\\", \\\"{x:724,y:599,t:1526930359311};\\\", \\\"{x:724,y:598,t:1526930359352};\\\", \\\"{x:718,y:598,t:1526930359360};\\\", \\\"{x:694,y:607,t:1526930359376};\\\", \\\"{x:666,y:623,t:1526930359394};\\\", \\\"{x:633,y:642,t:1526930359411};\\\", \\\"{x:600,y:664,t:1526930359426};\\\", \\\"{x:574,y:677,t:1526930359443};\\\", \\\"{x:556,y:690,t:1526930359461};\\\", \\\"{x:545,y:700,t:1526930359477};\\\", \\\"{x:538,y:713,t:1526930359493};\\\", \\\"{x:533,y:718,t:1526930359511};\\\", \\\"{x:530,y:723,t:1526930359528};\\\", \\\"{x:524,y:730,t:1526930359544};\\\", \\\"{x:517,y:736,t:1526930359560};\\\", \\\"{x:512,y:739,t:1526930359577};\\\", \\\"{x:508,y:743,t:1526930359593};\\\", \\\"{x:505,y:746,t:1526930359610};\\\", \\\"{x:504,y:746,t:1526930359887};\\\", \\\"{x:503,y:746,t:1526930360009};\\\", \\\"{x:501,y:745,t:1526930360105};\\\", \\\"{x:492,y:741,t:1526930360113};\\\", \\\"{x:480,y:738,t:1526930360128};\\\", \\\"{x:391,y:725,t:1526930360145};\\\", \\\"{x:282,y:705,t:1526930360160};\\\", \\\"{x:167,y:678,t:1526930360177};\\\", \\\"{x:51,y:645,t:1526930360195};\\\", \\\"{x:0,y:612,t:1526930360211};\\\", \\\"{x:0,y:578,t:1526930360228};\\\", \\\"{x:0,y:555,t:1526930360245};\\\", \\\"{x:0,y:539,t:1526930360260};\\\", \\\"{x:0,y:531,t:1526930360277};\\\", \\\"{x:0,y:522,t:1526930360295};\\\", \\\"{x:0,y:508,t:1526930360311};\\\", \\\"{x:4,y:492,t:1526930360328};\\\", \\\"{x:22,y:460,t:1526930360345};\\\", \\\"{x:36,y:441,t:1526930360361};\\\", \\\"{x:51,y:423,t:1526930360377};\\\", \\\"{x:67,y:407,t:1526930360395};\\\", \\\"{x:73,y:398,t:1526930360412};\\\", \\\"{x:79,y:391,t:1526930360428};\\\", \\\"{x:81,y:388,t:1526930360445};\\\", \\\"{x:83,y:385,t:1526930360462};\\\", \\\"{x:85,y:383,t:1526930360477};\\\", \\\"{x:85,y:382,t:1526930360495};\\\", \\\"{x:86,y:380,t:1526930360512};\\\", \\\"{x:86,y:378,t:1526930361065};\\\", \\\"{x:86,y:375,t:1526930361078};\\\", \\\"{x:80,y:363,t:1526930361094};\\\", \\\"{x:71,y:347,t:1526930361111};\\\", \\\"{x:47,y:316,t:1526930361128};\\\", \\\"{x:29,y:299,t:1526930361144};\\\", \\\"{x:11,y:287,t:1526930361161};\\\", \\\"{x:0,y:275,t:1526930361179};\\\", \\\"{x:0,y:261,t:1526930361194};\\\", \\\"{x:0,y:251,t:1526930361211};\\\", \\\"{x:0,y:238,t:1526930361228};\\\", \\\"{x:0,y:228,t:1526930361245};\\\", \\\"{x:0,y:219,t:1526930361261};\\\" ] }, { \\\"rt\\\": 13486, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 724615, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -02 PM-03 PM-04 PM-05 PM-04 PM-01 PM-12 PM-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:0,y:197,t:1526930361454};\\\", \\\"{x:3,y:197,t:1526930363018};\\\", \\\"{x:31,y:204,t:1526930363030};\\\", \\\"{x:155,y:236,t:1526930363047};\\\", \\\"{x:347,y:281,t:1526930363064};\\\", \\\"{x:584,y:333,t:1526930363080};\\\", \\\"{x:980,y:434,t:1526930363098};\\\", \\\"{x:1222,y:498,t:1526930363114};\\\", \\\"{x:1409,y:565,t:1526930363131};\\\", \\\"{x:1533,y:620,t:1526930363147};\\\", \\\"{x:1620,y:668,t:1526930363163};\\\", \\\"{x:1653,y:697,t:1526930363179};\\\", \\\"{x:1667,y:713,t:1526930363196};\\\", \\\"{x:1669,y:722,t:1526930363214};\\\", \\\"{x:1669,y:729,t:1526930363230};\\\", \\\"{x:1669,y:735,t:1526930363247};\\\", \\\"{x:1668,y:743,t:1526930363264};\\\", \\\"{x:1661,y:752,t:1526930363279};\\\", \\\"{x:1639,y:782,t:1526930363296};\\\", \\\"{x:1621,y:807,t:1526930363314};\\\", \\\"{x:1604,y:830,t:1526930363331};\\\", \\\"{x:1583,y:852,t:1526930363347};\\\", \\\"{x:1565,y:870,t:1526930363364};\\\", \\\"{x:1547,y:886,t:1526930363379};\\\", \\\"{x:1531,y:892,t:1526930363397};\\\", \\\"{x:1514,y:899,t:1526930363414};\\\", \\\"{x:1486,y:904,t:1526930363430};\\\", \\\"{x:1453,y:904,t:1526930363447};\\\", \\\"{x:1416,y:904,t:1526930363464};\\\", \\\"{x:1372,y:900,t:1526930363481};\\\", \\\"{x:1354,y:897,t:1526930363497};\\\", \\\"{x:1346,y:895,t:1526930363514};\\\", \\\"{x:1342,y:895,t:1526930363531};\\\", \\\"{x:1338,y:895,t:1526930363547};\\\", \\\"{x:1333,y:894,t:1526930363564};\\\", \\\"{x:1330,y:894,t:1526930363581};\\\", \\\"{x:1328,y:894,t:1526930363597};\\\", \\\"{x:1328,y:893,t:1526930363626};\\\", \\\"{x:1332,y:893,t:1526930363682};\\\", \\\"{x:1342,y:893,t:1526930363698};\\\", \\\"{x:1364,y:893,t:1526930363714};\\\", \\\"{x:1388,y:895,t:1526930363732};\\\", \\\"{x:1412,y:898,t:1526930363747};\\\", \\\"{x:1429,y:904,t:1526930363764};\\\", \\\"{x:1442,y:908,t:1526930363781};\\\", \\\"{x:1449,y:910,t:1526930363798};\\\", \\\"{x:1455,y:910,t:1526930363815};\\\", \\\"{x:1459,y:913,t:1526930363831};\\\", \\\"{x:1463,y:914,t:1526930363847};\\\", \\\"{x:1463,y:915,t:1526930363864};\\\", \\\"{x:1464,y:918,t:1526930363881};\\\", \\\"{x:1464,y:920,t:1526930363897};\\\", \\\"{x:1464,y:925,t:1526930363914};\\\", \\\"{x:1464,y:932,t:1526930363931};\\\", \\\"{x:1464,y:939,t:1526930363947};\\\", \\\"{x:1464,y:948,t:1526930363964};\\\", \\\"{x:1464,y:957,t:1526930363981};\\\", \\\"{x:1464,y:963,t:1526930363999};\\\", \\\"{x:1464,y:967,t:1526930364014};\\\", \\\"{x:1464,y:972,t:1526930364032};\\\", \\\"{x:1464,y:977,t:1526930364048};\\\", \\\"{x:1467,y:981,t:1526930364064};\\\", \\\"{x:1472,y:986,t:1526930364082};\\\", \\\"{x:1478,y:990,t:1526930364097};\\\", \\\"{x:1485,y:993,t:1526930364114};\\\", \\\"{x:1496,y:995,t:1526930364132};\\\", \\\"{x:1510,y:999,t:1526930364148};\\\", \\\"{x:1523,y:1001,t:1526930364164};\\\", \\\"{x:1537,y:1001,t:1526930364182};\\\", \\\"{x:1545,y:1001,t:1526930364198};\\\", \\\"{x:1549,y:1001,t:1526930364214};\\\", \\\"{x:1551,y:1001,t:1526930364266};\\\", \\\"{x:1552,y:1001,t:1526930364306};\\\", \\\"{x:1552,y:1000,t:1526930364321};\\\", \\\"{x:1552,y:998,t:1526930364338};\\\", \\\"{x:1552,y:996,t:1526930364349};\\\", \\\"{x:1552,y:994,t:1526930364364};\\\", \\\"{x:1551,y:990,t:1526930364381};\\\", \\\"{x:1551,y:987,t:1526930364398};\\\", \\\"{x:1550,y:985,t:1526930364414};\\\", \\\"{x:1550,y:983,t:1526930364432};\\\", \\\"{x:1550,y:982,t:1526930364448};\\\", \\\"{x:1550,y:980,t:1526930364464};\\\", \\\"{x:1552,y:978,t:1526930364481};\\\", \\\"{x:1556,y:976,t:1526930364498};\\\", \\\"{x:1567,y:972,t:1526930364515};\\\", \\\"{x:1578,y:972,t:1526930364532};\\\", \\\"{x:1589,y:971,t:1526930364548};\\\", \\\"{x:1602,y:971,t:1526930364565};\\\", \\\"{x:1613,y:971,t:1526930364581};\\\", \\\"{x:1625,y:971,t:1526930364598};\\\", \\\"{x:1642,y:971,t:1526930364615};\\\", \\\"{x:1658,y:971,t:1526930364632};\\\", \\\"{x:1677,y:971,t:1526930364648};\\\", \\\"{x:1694,y:971,t:1526930364665};\\\", \\\"{x:1697,y:971,t:1526930364681};\\\", \\\"{x:1696,y:971,t:1526930364728};\\\", \\\"{x:1688,y:971,t:1526930364736};\\\", \\\"{x:1674,y:971,t:1526930364747};\\\", \\\"{x:1620,y:971,t:1526930364765};\\\", \\\"{x:1523,y:971,t:1526930364780};\\\", \\\"{x:1401,y:971,t:1526930364798};\\\", \\\"{x:1253,y:960,t:1526930364815};\\\", \\\"{x:1140,y:944,t:1526930364830};\\\", \\\"{x:1084,y:944,t:1526930364848};\\\", \\\"{x:1071,y:944,t:1526930364865};\\\", \\\"{x:1071,y:945,t:1526930364897};\\\", \\\"{x:1073,y:946,t:1526930364905};\\\", \\\"{x:1074,y:946,t:1526930364915};\\\", \\\"{x:1076,y:948,t:1526930364931};\\\", \\\"{x:1078,y:948,t:1526930364947};\\\", \\\"{x:1084,y:951,t:1526930364965};\\\", \\\"{x:1099,y:955,t:1526930364982};\\\", \\\"{x:1122,y:959,t:1526930364998};\\\", \\\"{x:1147,y:962,t:1526930365015};\\\", \\\"{x:1173,y:967,t:1526930365032};\\\", \\\"{x:1200,y:968,t:1526930365049};\\\", \\\"{x:1243,y:968,t:1526930365065};\\\", \\\"{x:1276,y:968,t:1526930365082};\\\", \\\"{x:1297,y:968,t:1526930365098};\\\", \\\"{x:1315,y:968,t:1526930365115};\\\", \\\"{x:1326,y:968,t:1526930365133};\\\", \\\"{x:1331,y:968,t:1526930365148};\\\", \\\"{x:1333,y:968,t:1526930365165};\\\", \\\"{x:1334,y:968,t:1526930365185};\\\", \\\"{x:1335,y:968,t:1526930365198};\\\", \\\"{x:1336,y:967,t:1526930365233};\\\", \\\"{x:1338,y:965,t:1526930365257};\\\", \\\"{x:1338,y:964,t:1526930365274};\\\", \\\"{x:1339,y:964,t:1526930365281};\\\", \\\"{x:1339,y:963,t:1526930365298};\\\", \\\"{x:1340,y:963,t:1526930365544};\\\", \\\"{x:1342,y:963,t:1526930365560};\\\", \\\"{x:1344,y:963,t:1526930365584};\\\", \\\"{x:1345,y:963,t:1526930365600};\\\", \\\"{x:1346,y:964,t:1526930365615};\\\", \\\"{x:1347,y:966,t:1526930365632};\\\", \\\"{x:1347,y:963,t:1526930365816};\\\", \\\"{x:1347,y:960,t:1526930365831};\\\", \\\"{x:1344,y:947,t:1526930365849};\\\", \\\"{x:1343,y:938,t:1526930365866};\\\", \\\"{x:1342,y:929,t:1526930365882};\\\", \\\"{x:1340,y:921,t:1526930365898};\\\", \\\"{x:1340,y:913,t:1526930365916};\\\", \\\"{x:1340,y:897,t:1526930365932};\\\", \\\"{x:1342,y:883,t:1526930365948};\\\", \\\"{x:1342,y:875,t:1526930365966};\\\", \\\"{x:1342,y:870,t:1526930365982};\\\", \\\"{x:1342,y:863,t:1526930365999};\\\", \\\"{x:1342,y:861,t:1526930366016};\\\", \\\"{x:1342,y:856,t:1526930366032};\\\", \\\"{x:1342,y:854,t:1526930366049};\\\", \\\"{x:1344,y:855,t:1526930366176};\\\", \\\"{x:1344,y:861,t:1526930366184};\\\", \\\"{x:1345,y:867,t:1526930366199};\\\", \\\"{x:1347,y:881,t:1526930366216};\\\", \\\"{x:1350,y:893,t:1526930366232};\\\", \\\"{x:1352,y:907,t:1526930366249};\\\", \\\"{x:1354,y:917,t:1526930366265};\\\", \\\"{x:1356,y:926,t:1526930366282};\\\", \\\"{x:1356,y:936,t:1526930366298};\\\", \\\"{x:1360,y:947,t:1526930366316};\\\", \\\"{x:1360,y:952,t:1526930366333};\\\", \\\"{x:1361,y:957,t:1526930366349};\\\", \\\"{x:1361,y:960,t:1526930366365};\\\", \\\"{x:1361,y:964,t:1526930366383};\\\", \\\"{x:1361,y:969,t:1526930366399};\\\", \\\"{x:1361,y:971,t:1526930366415};\\\", \\\"{x:1361,y:976,t:1526930366432};\\\", \\\"{x:1361,y:977,t:1526930366449};\\\", \\\"{x:1361,y:979,t:1526930366465};\\\", \\\"{x:1361,y:980,t:1526930366482};\\\", \\\"{x:1361,y:981,t:1526930366616};\\\", \\\"{x:1360,y:981,t:1526930366640};\\\", \\\"{x:1359,y:981,t:1526930366656};\\\", \\\"{x:1358,y:981,t:1526930366665};\\\", \\\"{x:1357,y:979,t:1526930366682};\\\", \\\"{x:1355,y:979,t:1526930366699};\\\", \\\"{x:1354,y:977,t:1526930366716};\\\", \\\"{x:1353,y:976,t:1526930366736};\\\", \\\"{x:1353,y:975,t:1526930366749};\\\", \\\"{x:1352,y:974,t:1526930366768};\\\", \\\"{x:1352,y:972,t:1526930366784};\\\", \\\"{x:1352,y:971,t:1526930366800};\\\", \\\"{x:1351,y:968,t:1526930366816};\\\", \\\"{x:1351,y:966,t:1526930366832};\\\", \\\"{x:1351,y:965,t:1526930366849};\\\", \\\"{x:1351,y:963,t:1526930366866};\\\", \\\"{x:1351,y:962,t:1526930366883};\\\", \\\"{x:1351,y:961,t:1526930366904};\\\", \\\"{x:1351,y:959,t:1526930366968};\\\", \\\"{x:1351,y:957,t:1526930366993};\\\", \\\"{x:1351,y:956,t:1526930367000};\\\", \\\"{x:1351,y:955,t:1526930367016};\\\", \\\"{x:1350,y:952,t:1526930367033};\\\", \\\"{x:1349,y:950,t:1526930367050};\\\", \\\"{x:1349,y:947,t:1526930367066};\\\", \\\"{x:1347,y:944,t:1526930367083};\\\", \\\"{x:1347,y:940,t:1526930367100};\\\", \\\"{x:1347,y:935,t:1526930367115};\\\", \\\"{x:1347,y:928,t:1526930367132};\\\", \\\"{x:1347,y:921,t:1526930367150};\\\", \\\"{x:1347,y:916,t:1526930367166};\\\", \\\"{x:1347,y:911,t:1526930367183};\\\", \\\"{x:1347,y:906,t:1526930367200};\\\", \\\"{x:1347,y:902,t:1526930367216};\\\", \\\"{x:1346,y:895,t:1526930367233};\\\", \\\"{x:1343,y:887,t:1526930367250};\\\", \\\"{x:1342,y:882,t:1526930367265};\\\", \\\"{x:1339,y:872,t:1526930367283};\\\", \\\"{x:1336,y:865,t:1526930367300};\\\", \\\"{x:1331,y:855,t:1526930367317};\\\", \\\"{x:1328,y:847,t:1526930367333};\\\", \\\"{x:1327,y:845,t:1526930367350};\\\", \\\"{x:1325,y:838,t:1526930367367};\\\", \\\"{x:1325,y:831,t:1526930367383};\\\", \\\"{x:1324,y:826,t:1526930367400};\\\", \\\"{x:1324,y:820,t:1526930367417};\\\", \\\"{x:1324,y:816,t:1526930367433};\\\", \\\"{x:1324,y:815,t:1526930367450};\\\", \\\"{x:1324,y:812,t:1526930367467};\\\", \\\"{x:1324,y:808,t:1526930367483};\\\", \\\"{x:1325,y:806,t:1526930367500};\\\", \\\"{x:1326,y:804,t:1526930367517};\\\", \\\"{x:1326,y:803,t:1526930367533};\\\", \\\"{x:1327,y:801,t:1526930367549};\\\", \\\"{x:1329,y:798,t:1526930367567};\\\", \\\"{x:1329,y:794,t:1526930367583};\\\", \\\"{x:1330,y:792,t:1526930367599};\\\", \\\"{x:1331,y:788,t:1526930367616};\\\", \\\"{x:1332,y:786,t:1526930367633};\\\", \\\"{x:1333,y:782,t:1526930367650};\\\", \\\"{x:1335,y:779,t:1526930367667};\\\", \\\"{x:1339,y:773,t:1526930367683};\\\", \\\"{x:1341,y:767,t:1526930367701};\\\", \\\"{x:1341,y:763,t:1526930367717};\\\", \\\"{x:1342,y:761,t:1526930367734};\\\", \\\"{x:1342,y:758,t:1526930367750};\\\", \\\"{x:1342,y:757,t:1526930367767};\\\", \\\"{x:1342,y:756,t:1526930367785};\\\", \\\"{x:1343,y:755,t:1526930368810};\\\", \\\"{x:1343,y:756,t:1526930368817};\\\", \\\"{x:1344,y:758,t:1526930368835};\\\", \\\"{x:1344,y:759,t:1526930368852};\\\", \\\"{x:1345,y:759,t:1526930368868};\\\", \\\"{x:1345,y:760,t:1526930368897};\\\", \\\"{x:1343,y:760,t:1526930371475};\\\", \\\"{x:1324,y:760,t:1526930371489};\\\", \\\"{x:1253,y:756,t:1526930371505};\\\", \\\"{x:1142,y:754,t:1526930371521};\\\", \\\"{x:1006,y:752,t:1526930371539};\\\", \\\"{x:820,y:745,t:1526930371555};\\\", \\\"{x:714,y:743,t:1526930371571};\\\", \\\"{x:633,y:743,t:1526930371588};\\\", \\\"{x:599,y:743,t:1526930371605};\\\", \\\"{x:583,y:738,t:1526930371622};\\\", \\\"{x:577,y:734,t:1526930371638};\\\", \\\"{x:573,y:729,t:1526930371656};\\\", \\\"{x:569,y:724,t:1526930371672};\\\", \\\"{x:564,y:717,t:1526930371688};\\\", \\\"{x:550,y:701,t:1526930371706};\\\", \\\"{x:514,y:682,t:1526930371722};\\\", \\\"{x:463,y:659,t:1526930371740};\\\", \\\"{x:393,y:629,t:1526930371755};\\\", \\\"{x:372,y:620,t:1526930371772};\\\", \\\"{x:366,y:617,t:1526930371784};\\\", \\\"{x:362,y:614,t:1526930371801};\\\", \\\"{x:360,y:612,t:1526930371819};\\\", \\\"{x:359,y:605,t:1526930371835};\\\", \\\"{x:354,y:596,t:1526930371852};\\\", \\\"{x:345,y:586,t:1526930371869};\\\", \\\"{x:332,y:575,t:1526930371889};\\\", \\\"{x:321,y:569,t:1526930371905};\\\", \\\"{x:307,y:565,t:1526930371921};\\\", \\\"{x:289,y:563,t:1526930371938};\\\", \\\"{x:277,y:560,t:1526930371955};\\\", \\\"{x:270,y:560,t:1526930371972};\\\", \\\"{x:259,y:560,t:1526930371988};\\\", \\\"{x:245,y:560,t:1526930372005};\\\", \\\"{x:227,y:560,t:1526930372021};\\\", \\\"{x:210,y:560,t:1526930372039};\\\", \\\"{x:196,y:560,t:1526930372055};\\\", \\\"{x:182,y:560,t:1526930372072};\\\", \\\"{x:172,y:560,t:1526930372088};\\\", \\\"{x:165,y:561,t:1526930372105};\\\", \\\"{x:157,y:565,t:1526930372122};\\\", \\\"{x:147,y:571,t:1526930372138};\\\", \\\"{x:145,y:574,t:1526930372156};\\\", \\\"{x:145,y:579,t:1526930372173};\\\", \\\"{x:148,y:583,t:1526930372190};\\\", \\\"{x:167,y:590,t:1526930372205};\\\", \\\"{x:204,y:595,t:1526930372223};\\\", \\\"{x:294,y:601,t:1526930372239};\\\", \\\"{x:405,y:601,t:1526930372255};\\\", \\\"{x:532,y:601,t:1526930372273};\\\", \\\"{x:660,y:601,t:1526930372288};\\\", \\\"{x:754,y:601,t:1526930372307};\\\", \\\"{x:826,y:595,t:1526930372323};\\\", \\\"{x:841,y:590,t:1526930372339};\\\", \\\"{x:847,y:587,t:1526930372356};\\\", \\\"{x:847,y:585,t:1526930372373};\\\", \\\"{x:847,y:584,t:1526930372388};\\\", \\\"{x:847,y:583,t:1526930372406};\\\", \\\"{x:847,y:581,t:1526930372423};\\\", \\\"{x:847,y:580,t:1526930372439};\\\", \\\"{x:847,y:577,t:1526930372456};\\\", \\\"{x:846,y:575,t:1526930372472};\\\", \\\"{x:844,y:571,t:1526930372490};\\\", \\\"{x:839,y:561,t:1526930372506};\\\", \\\"{x:838,y:553,t:1526930372523};\\\", \\\"{x:836,y:547,t:1526930372540};\\\", \\\"{x:836,y:541,t:1526930372555};\\\", \\\"{x:836,y:536,t:1526930372573};\\\", \\\"{x:837,y:531,t:1526930372589};\\\", \\\"{x:837,y:529,t:1526930372606};\\\", \\\"{x:837,y:527,t:1526930372623};\\\", \\\"{x:837,y:524,t:1526930372639};\\\", \\\"{x:837,y:523,t:1526930372656};\\\", \\\"{x:837,y:520,t:1526930372673};\\\", \\\"{x:837,y:518,t:1526930372690};\\\", \\\"{x:836,y:516,t:1526930372707};\\\", \\\"{x:836,y:515,t:1526930372730};\\\", \\\"{x:836,y:514,t:1526930372795};\\\", \\\"{x:836,y:513,t:1526930372827};\\\", \\\"{x:836,y:512,t:1526930372851};\\\", \\\"{x:836,y:511,t:1526930372875};\\\", \\\"{x:836,y:510,t:1526930373106};\\\", \\\"{x:816,y:510,t:1526930373123};\\\", \\\"{x:791,y:510,t:1526930373139};\\\", \\\"{x:757,y:510,t:1526930373157};\\\", \\\"{x:729,y:510,t:1526930373172};\\\", \\\"{x:706,y:510,t:1526930373191};\\\", \\\"{x:684,y:514,t:1526930373207};\\\", \\\"{x:655,y:517,t:1526930373222};\\\", \\\"{x:618,y:524,t:1526930373241};\\\", \\\"{x:574,y:528,t:1526930373257};\\\", \\\"{x:533,y:533,t:1526930373272};\\\", \\\"{x:500,y:535,t:1526930373290};\\\", \\\"{x:484,y:539,t:1526930373307};\\\", \\\"{x:483,y:539,t:1526930373323};\\\", \\\"{x:487,y:539,t:1526930373402};\\\", \\\"{x:497,y:535,t:1526930373410};\\\", \\\"{x:511,y:532,t:1526930373424};\\\", \\\"{x:538,y:529,t:1526930373440};\\\", \\\"{x:563,y:523,t:1526930373457};\\\", \\\"{x:585,y:518,t:1526930373473};\\\", \\\"{x:591,y:516,t:1526930373490};\\\", \\\"{x:590,y:516,t:1526930373522};\\\", \\\"{x:586,y:516,t:1526930373530};\\\", \\\"{x:577,y:516,t:1526930373540};\\\", \\\"{x:552,y:521,t:1526930373557};\\\", \\\"{x:499,y:528,t:1526930373574};\\\", \\\"{x:419,y:539,t:1526930373590};\\\", \\\"{x:325,y:549,t:1526930373607};\\\", \\\"{x:224,y:557,t:1526930373624};\\\", \\\"{x:145,y:558,t:1526930373640};\\\", \\\"{x:102,y:559,t:1526930373657};\\\", \\\"{x:87,y:560,t:1526930373674};\\\", \\\"{x:84,y:562,t:1526930373690};\\\", \\\"{x:85,y:562,t:1526930373788};\\\", \\\"{x:88,y:562,t:1526930373795};\\\", \\\"{x:91,y:560,t:1526930373807};\\\", \\\"{x:96,y:556,t:1526930373824};\\\", \\\"{x:104,y:553,t:1526930373842};\\\", \\\"{x:109,y:550,t:1526930373856};\\\", \\\"{x:116,y:546,t:1526930373873};\\\", \\\"{x:126,y:544,t:1526930373890};\\\", \\\"{x:133,y:544,t:1526930373906};\\\", \\\"{x:140,y:544,t:1526930373924};\\\", \\\"{x:146,y:544,t:1526930373941};\\\", \\\"{x:149,y:544,t:1526930373957};\\\", \\\"{x:150,y:544,t:1526930373974};\\\", \\\"{x:151,y:544,t:1526930374050};\\\", \\\"{x:152,y:544,t:1526930374091};\\\", \\\"{x:152,y:544,t:1526930374182};\\\", \\\"{x:152,y:543,t:1526930374226};\\\", \\\"{x:154,y:543,t:1526930374241};\\\", \\\"{x:169,y:547,t:1526930374257};\\\", \\\"{x:191,y:552,t:1526930374274};\\\", \\\"{x:233,y:562,t:1526930374292};\\\", \\\"{x:286,y:576,t:1526930374308};\\\", \\\"{x:350,y:595,t:1526930374324};\\\", \\\"{x:412,y:614,t:1526930374341};\\\", \\\"{x:455,y:629,t:1526930374358};\\\", \\\"{x:496,y:647,t:1526930374374};\\\", \\\"{x:523,y:661,t:1526930374391};\\\", \\\"{x:542,y:676,t:1526930374408};\\\", \\\"{x:556,y:689,t:1526930374423};\\\", \\\"{x:569,y:702,t:1526930374441};\\\", \\\"{x:579,y:714,t:1526930374457};\\\", \\\"{x:588,y:725,t:1526930374473};\\\", \\\"{x:592,y:738,t:1526930374491};\\\", \\\"{x:592,y:745,t:1526930374508};\\\", \\\"{x:592,y:751,t:1526930374524};\\\", \\\"{x:585,y:759,t:1526930374541};\\\", \\\"{x:576,y:762,t:1526930374558};\\\", \\\"{x:569,y:765,t:1526930374574};\\\", \\\"{x:558,y:766,t:1526930374591};\\\", \\\"{x:551,y:767,t:1526930374608};\\\", \\\"{x:543,y:767,t:1526930374624};\\\", \\\"{x:533,y:766,t:1526930374641};\\\", \\\"{x:525,y:765,t:1526930374658};\\\", \\\"{x:521,y:762,t:1526930374674};\\\", \\\"{x:515,y:758,t:1526930374691};\\\", \\\"{x:514,y:756,t:1526930374709};\\\", \\\"{x:513,y:752,t:1526930374726};\\\", \\\"{x:511,y:749,t:1526930374741};\\\", \\\"{x:511,y:748,t:1526930374758};\\\", \\\"{x:511,y:746,t:1526930374774};\\\", \\\"{x:511,y:745,t:1526930374791};\\\", \\\"{x:511,y:744,t:1526930375194};\\\", \\\"{x:508,y:744,t:1526930375233};\\\", \\\"{x:503,y:744,t:1526930375242};\\\", \\\"{x:495,y:744,t:1526930375257};\\\", \\\"{x:485,y:744,t:1526930375275};\\\", \\\"{x:477,y:744,t:1526930375291};\\\", \\\"{x:469,y:744,t:1526930375307};\\\", \\\"{x:462,y:744,t:1526930375325};\\\", \\\"{x:458,y:744,t:1526930375342};\\\", \\\"{x:455,y:742,t:1526930375358};\\\", \\\"{x:454,y:742,t:1526930375375};\\\", \\\"{x:453,y:741,t:1526930375392};\\\", \\\"{x:452,y:741,t:1526930375409};\\\", \\\"{x:451,y:740,t:1526930375426};\\\", \\\"{x:450,y:738,t:1526930375467};\\\", \\\"{x:450,y:737,t:1526930375482};\\\", \\\"{x:449,y:736,t:1526930375492};\\\", \\\"{x:449,y:735,t:1526930375509};\\\", \\\"{x:448,y:733,t:1526930375525};\\\", \\\"{x:448,y:732,t:1526930375542};\\\", \\\"{x:447,y:730,t:1526930375747};\\\", \\\"{x:447,y:729,t:1526930375786};\\\", \\\"{x:446,y:729,t:1526930375795};\\\", \\\"{x:446,y:728,t:1526930375876};\\\", \\\"{x:444,y:728,t:1526930375892};\\\", \\\"{x:444,y:727,t:1526930375946};\\\" ] }, { \\\"rt\\\": 14811, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 740642, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:449,y:727,t:1526930376315};\\\", \\\"{x:461,y:727,t:1526930376326};\\\", \\\"{x:493,y:729,t:1526930376342};\\\", \\\"{x:549,y:737,t:1526930376358};\\\", \\\"{x:613,y:745,t:1526930376376};\\\", \\\"{x:674,y:753,t:1526930376392};\\\", \\\"{x:717,y:761,t:1526930376408};\\\", \\\"{x:746,y:764,t:1526930376425};\\\", \\\"{x:751,y:765,t:1526930376442};\\\", \\\"{x:751,y:764,t:1526930376915};\\\", \\\"{x:751,y:762,t:1526930376926};\\\", \\\"{x:747,y:756,t:1526930376943};\\\", \\\"{x:744,y:749,t:1526930376960};\\\", \\\"{x:739,y:740,t:1526930376976};\\\", \\\"{x:733,y:728,t:1526930376993};\\\", \\\"{x:718,y:704,t:1526930377010};\\\", \\\"{x:713,y:697,t:1526930377026};\\\", \\\"{x:697,y:668,t:1526930377043};\\\", \\\"{x:690,y:651,t:1526930377060};\\\", \\\"{x:682,y:636,t:1526930377077};\\\", \\\"{x:674,y:620,t:1526930377094};\\\", \\\"{x:664,y:601,t:1526930377110};\\\", \\\"{x:653,y:583,t:1526930377126};\\\", \\\"{x:643,y:566,t:1526930377142};\\\", \\\"{x:632,y:553,t:1526930377160};\\\", \\\"{x:621,y:541,t:1526930377176};\\\", \\\"{x:612,y:529,t:1526930377192};\\\", \\\"{x:605,y:520,t:1526930377211};\\\", \\\"{x:602,y:516,t:1526930377227};\\\", \\\"{x:600,y:513,t:1526930377243};\\\", \\\"{x:599,y:512,t:1526930377260};\\\", \\\"{x:598,y:511,t:1526930377276};\\\", \\\"{x:598,y:509,t:1526930377293};\\\", \\\"{x:597,y:509,t:1526930377309};\\\", \\\"{x:594,y:506,t:1526930377326};\\\", \\\"{x:591,y:504,t:1526930377343};\\\", \\\"{x:590,y:503,t:1526930377360};\\\", \\\"{x:589,y:502,t:1526930377376};\\\", \\\"{x:589,y:501,t:1526930377426};\\\", \\\"{x:593,y:501,t:1526930379955};\\\", \\\"{x:623,y:509,t:1526930379963};\\\", \\\"{x:738,y:538,t:1526930379979};\\\", \\\"{x:898,y:575,t:1526930379995};\\\", \\\"{x:1079,y:621,t:1526930380012};\\\", \\\"{x:1260,y:659,t:1526930380028};\\\", \\\"{x:1419,y:685,t:1526930380045};\\\", \\\"{x:1519,y:703,t:1526930380062};\\\", \\\"{x:1570,y:710,t:1526930380079};\\\", \\\"{x:1579,y:711,t:1526930380095};\\\", \\\"{x:1579,y:712,t:1526930380187};\\\", \\\"{x:1578,y:712,t:1526930380243};\\\", \\\"{x:1571,y:714,t:1526930380251};\\\", \\\"{x:1562,y:714,t:1526930380262};\\\", \\\"{x:1536,y:714,t:1526930380279};\\\", \\\"{x:1492,y:714,t:1526930380296};\\\", \\\"{x:1433,y:715,t:1526930380313};\\\", \\\"{x:1380,y:715,t:1526930380330};\\\", \\\"{x:1345,y:718,t:1526930380346};\\\", \\\"{x:1329,y:721,t:1526930380362};\\\", \\\"{x:1327,y:720,t:1526930380507};\\\", \\\"{x:1327,y:718,t:1526930380514};\\\", \\\"{x:1327,y:716,t:1526930380529};\\\", \\\"{x:1327,y:713,t:1526930380546};\\\", \\\"{x:1327,y:711,t:1526930380562};\\\", \\\"{x:1327,y:709,t:1526930380580};\\\", \\\"{x:1327,y:707,t:1526930380597};\\\", \\\"{x:1329,y:707,t:1526930380627};\\\", \\\"{x:1329,y:706,t:1526930380635};\\\", \\\"{x:1330,y:706,t:1526930380651};\\\", \\\"{x:1331,y:706,t:1526930380663};\\\", \\\"{x:1333,y:705,t:1526930380679};\\\", \\\"{x:1334,y:705,t:1526930380697};\\\", \\\"{x:1335,y:705,t:1526930380713};\\\", \\\"{x:1336,y:705,t:1526930380729};\\\", \\\"{x:1338,y:704,t:1526930380746};\\\", \\\"{x:1339,y:704,t:1526930380762};\\\", \\\"{x:1341,y:704,t:1526930380780};\\\", \\\"{x:1342,y:704,t:1526930380797};\\\", \\\"{x:1343,y:703,t:1526930380812};\\\", \\\"{x:1344,y:703,t:1526930380830};\\\", \\\"{x:1344,y:702,t:1526930380852};\\\", \\\"{x:1345,y:701,t:1526930380869};\\\", \\\"{x:1346,y:700,t:1526930380907};\\\", \\\"{x:1347,y:700,t:1526930380931};\\\", \\\"{x:1347,y:699,t:1526930380946};\\\", \\\"{x:1348,y:699,t:1526930380963};\\\", \\\"{x:1348,y:698,t:1526930380987};\\\", \\\"{x:1349,y:697,t:1526930381010};\\\", \\\"{x:1349,y:696,t:1526930381050};\\\", \\\"{x:1350,y:695,t:1526930381194};\\\", \\\"{x:1351,y:695,t:1526930381395};\\\", \\\"{x:1352,y:695,t:1526930381427};\\\", \\\"{x:1352,y:696,t:1526930381475};\\\", \\\"{x:1352,y:697,t:1526930381498};\\\", \\\"{x:1352,y:698,t:1526930381522};\\\", \\\"{x:1352,y:699,t:1526930381530};\\\", \\\"{x:1353,y:700,t:1526930381557};\\\", \\\"{x:1353,y:701,t:1526930381611};\\\", \\\"{x:1353,y:702,t:1526930381627};\\\", \\\"{x:1353,y:703,t:1526930381755};\\\", \\\"{x:1353,y:704,t:1526930381779};\\\", \\\"{x:1351,y:704,t:1526930381828};\\\", \\\"{x:1350,y:704,t:1526930381899};\\\", \\\"{x:1349,y:704,t:1526930381932};\\\", \\\"{x:1348,y:704,t:1526930381947};\\\", \\\"{x:1347,y:704,t:1526930382012};\\\", \\\"{x:1345,y:703,t:1526930382026};\\\", \\\"{x:1345,y:702,t:1526930382059};\\\", \\\"{x:1345,y:701,t:1526930382076};\\\", \\\"{x:1345,y:700,t:1526930382099};\\\", \\\"{x:1345,y:699,t:1526930382114};\\\", \\\"{x:1344,y:698,t:1526930382130};\\\", \\\"{x:1344,y:697,t:1526930382187};\\\", \\\"{x:1344,y:696,t:1526930382267};\\\", \\\"{x:1345,y:697,t:1526930385467};\\\", \\\"{x:1347,y:698,t:1526930385483};\\\", \\\"{x:1348,y:699,t:1526930385500};\\\", \\\"{x:1349,y:701,t:1526930385554};\\\", \\\"{x:1350,y:701,t:1526930385567};\\\", \\\"{x:1350,y:702,t:1526930385604};\\\", \\\"{x:1351,y:702,t:1526930385627};\\\", \\\"{x:1351,y:704,t:1526930385635};\\\", \\\"{x:1351,y:705,t:1526930385651};\\\", \\\"{x:1351,y:708,t:1526930385666};\\\", \\\"{x:1351,y:711,t:1526930385683};\\\", \\\"{x:1351,y:715,t:1526930385700};\\\", \\\"{x:1350,y:720,t:1526930385717};\\\", \\\"{x:1350,y:726,t:1526930385734};\\\", \\\"{x:1350,y:728,t:1526930385750};\\\", \\\"{x:1350,y:730,t:1526930385766};\\\", \\\"{x:1350,y:732,t:1526930385784};\\\", \\\"{x:1350,y:733,t:1526930385799};\\\", \\\"{x:1350,y:735,t:1526930385817};\\\", \\\"{x:1350,y:738,t:1526930385834};\\\", \\\"{x:1350,y:740,t:1526930385850};\\\", \\\"{x:1350,y:744,t:1526930385867};\\\", \\\"{x:1351,y:746,t:1526930385885};\\\", \\\"{x:1351,y:748,t:1526930385907};\\\", \\\"{x:1351,y:749,t:1526930385916};\\\", \\\"{x:1351,y:750,t:1526930385934};\\\", \\\"{x:1351,y:752,t:1526930385949};\\\", \\\"{x:1351,y:753,t:1526930385973};\\\", \\\"{x:1351,y:754,t:1526930385983};\\\", \\\"{x:1351,y:755,t:1526930386000};\\\", \\\"{x:1351,y:756,t:1526930386018};\\\", \\\"{x:1351,y:757,t:1526930386042};\\\", \\\"{x:1351,y:758,t:1526930386082};\\\", \\\"{x:1351,y:759,t:1526930386138};\\\", \\\"{x:1351,y:760,t:1526930386194};\\\", \\\"{x:1351,y:761,t:1526930386315};\\\", \\\"{x:1350,y:761,t:1526930386354};\\\", \\\"{x:1349,y:761,t:1526930386435};\\\", \\\"{x:1348,y:761,t:1526930386451};\\\", \\\"{x:1347,y:761,t:1526930386547};\\\", \\\"{x:1345,y:761,t:1526930386555};\\\", \\\"{x:1344,y:761,t:1526930386611};\\\", \\\"{x:1343,y:760,t:1526930386667};\\\", \\\"{x:1342,y:760,t:1526930386708};\\\", \\\"{x:1341,y:758,t:1526930386755};\\\", \\\"{x:1340,y:758,t:1526930386795};\\\", \\\"{x:1339,y:757,t:1526930386851};\\\", \\\"{x:1338,y:755,t:1526930386891};\\\", \\\"{x:1338,y:754,t:1526930386979};\\\", \\\"{x:1337,y:754,t:1526930386986};\\\", \\\"{x:1337,y:753,t:1526930387003};\\\", \\\"{x:1336,y:752,t:1526930387027};\\\", \\\"{x:1335,y:752,t:1526930387338};\\\", \\\"{x:1334,y:754,t:1526930387351};\\\", \\\"{x:1328,y:760,t:1526930387368};\\\", \\\"{x:1316,y:766,t:1526930387385};\\\", \\\"{x:1296,y:772,t:1526930387401};\\\", \\\"{x:1272,y:776,t:1526930387417};\\\", \\\"{x:1218,y:779,t:1526930387434};\\\", \\\"{x:1179,y:779,t:1526930387450};\\\", \\\"{x:1137,y:779,t:1526930387468};\\\", \\\"{x:1098,y:779,t:1526930387485};\\\", \\\"{x:1044,y:779,t:1526930387501};\\\", \\\"{x:984,y:773,t:1526930387517};\\\", \\\"{x:916,y:761,t:1526930387535};\\\", \\\"{x:855,y:742,t:1526930387551};\\\", \\\"{x:818,y:731,t:1526930387567};\\\", \\\"{x:794,y:721,t:1526930387585};\\\", \\\"{x:780,y:711,t:1526930387602};\\\", \\\"{x:772,y:704,t:1526930387618};\\\", \\\"{x:766,y:692,t:1526930387635};\\\", \\\"{x:761,y:683,t:1526930387652};\\\", \\\"{x:758,y:673,t:1526930387668};\\\", \\\"{x:754,y:665,t:1526930387685};\\\", \\\"{x:749,y:655,t:1526930387702};\\\", \\\"{x:746,y:650,t:1526930387718};\\\", \\\"{x:741,y:641,t:1526930387735};\\\", \\\"{x:739,y:633,t:1526930387752};\\\", \\\"{x:731,y:619,t:1526930387769};\\\", \\\"{x:727,y:607,t:1526930387785};\\\", \\\"{x:720,y:592,t:1526930387802};\\\", \\\"{x:716,y:584,t:1526930387819};\\\", \\\"{x:716,y:580,t:1526930387835};\\\", \\\"{x:716,y:574,t:1526930387851};\\\", \\\"{x:717,y:570,t:1526930387868};\\\", \\\"{x:724,y:562,t:1526930387886};\\\", \\\"{x:738,y:554,t:1526930387902};\\\", \\\"{x:760,y:546,t:1526930387918};\\\", \\\"{x:784,y:539,t:1526930387935};\\\", \\\"{x:806,y:532,t:1526930387951};\\\", \\\"{x:831,y:524,t:1526930387969};\\\", \\\"{x:846,y:518,t:1526930387986};\\\", \\\"{x:852,y:515,t:1526930388002};\\\", \\\"{x:854,y:514,t:1526930388018};\\\", \\\"{x:854,y:513,t:1526930388035};\\\", \\\"{x:855,y:512,t:1526930388052};\\\", \\\"{x:855,y:509,t:1526930388068};\\\", \\\"{x:856,y:505,t:1526930388085};\\\", \\\"{x:856,y:501,t:1526930388101};\\\", \\\"{x:858,y:498,t:1526930388118};\\\", \\\"{x:858,y:496,t:1526930388135};\\\", \\\"{x:858,y:495,t:1526930388151};\\\", \\\"{x:858,y:494,t:1526930388323};\\\", \\\"{x:856,y:495,t:1526930388336};\\\", \\\"{x:852,y:496,t:1526930388353};\\\", \\\"{x:848,y:497,t:1526930388370};\\\", \\\"{x:845,y:498,t:1526930388386};\\\", \\\"{x:841,y:499,t:1526930388403};\\\", \\\"{x:840,y:499,t:1526930388475};\\\", \\\"{x:839,y:499,t:1526930388490};\\\", \\\"{x:838,y:499,t:1526930388555};\\\", \\\"{x:836,y:499,t:1526930389034};\\\", \\\"{x:832,y:499,t:1526930389053};\\\", \\\"{x:829,y:499,t:1526930389069};\\\", \\\"{x:828,y:499,t:1526930389086};\\\", \\\"{x:827,y:499,t:1526930389103};\\\", \\\"{x:826,y:499,t:1526930389119};\\\", \\\"{x:825,y:499,t:1526930389136};\\\", \\\"{x:823,y:499,t:1526930389152};\\\", \\\"{x:817,y:500,t:1526930389169};\\\", \\\"{x:804,y:503,t:1526930389185};\\\", \\\"{x:790,y:505,t:1526930389202};\\\", \\\"{x:770,y:509,t:1526930389219};\\\", \\\"{x:747,y:509,t:1526930389235};\\\", \\\"{x:724,y:509,t:1526930389252};\\\", \\\"{x:699,y:511,t:1526930389270};\\\", \\\"{x:672,y:515,t:1526930389285};\\\", \\\"{x:643,y:519,t:1526930389303};\\\", \\\"{x:604,y:523,t:1526930389319};\\\", \\\"{x:555,y:534,t:1526930389337};\\\", \\\"{x:514,y:538,t:1526930389353};\\\", \\\"{x:483,y:543,t:1526930389370};\\\", \\\"{x:451,y:544,t:1526930389385};\\\", \\\"{x:435,y:544,t:1526930389402};\\\", \\\"{x:416,y:544,t:1526930389420};\\\", \\\"{x:399,y:544,t:1526930389436};\\\", \\\"{x:380,y:544,t:1526930389453};\\\", \\\"{x:364,y:544,t:1526930389470};\\\", \\\"{x:355,y:544,t:1526930389486};\\\", \\\"{x:351,y:544,t:1526930389503};\\\", \\\"{x:350,y:544,t:1526930389520};\\\", \\\"{x:349,y:544,t:1526930389578};\\\", \\\"{x:348,y:544,t:1526930389586};\\\", \\\"{x:344,y:542,t:1526930389603};\\\", \\\"{x:336,y:538,t:1526930389619};\\\", \\\"{x:330,y:535,t:1526930389637};\\\", \\\"{x:319,y:533,t:1526930389654};\\\", \\\"{x:302,y:530,t:1526930389669};\\\", \\\"{x:284,y:530,t:1526930389686};\\\", \\\"{x:258,y:530,t:1526930389705};\\\", \\\"{x:239,y:530,t:1526930389720};\\\", \\\"{x:225,y:532,t:1526930389736};\\\", \\\"{x:217,y:535,t:1526930389752};\\\", \\\"{x:212,y:536,t:1526930389769};\\\", \\\"{x:209,y:538,t:1526930389787};\\\", \\\"{x:208,y:539,t:1526930389802};\\\", \\\"{x:205,y:541,t:1526930389820};\\\", \\\"{x:203,y:541,t:1526930389837};\\\", \\\"{x:201,y:541,t:1526930389852};\\\", \\\"{x:200,y:541,t:1526930389869};\\\", \\\"{x:198,y:541,t:1526930389887};\\\", \\\"{x:194,y:541,t:1526930389903};\\\", \\\"{x:188,y:541,t:1526930389920};\\\", \\\"{x:179,y:541,t:1526930389936};\\\", \\\"{x:169,y:541,t:1526930389953};\\\", \\\"{x:162,y:541,t:1526930389969};\\\", \\\"{x:166,y:544,t:1526930390290};\\\", \\\"{x:176,y:552,t:1526930390303};\\\", \\\"{x:215,y:575,t:1526930390321};\\\", \\\"{x:270,y:599,t:1526930390336};\\\", \\\"{x:315,y:621,t:1526930390354};\\\", \\\"{x:359,y:643,t:1526930390371};\\\", \\\"{x:374,y:653,t:1526930390387};\\\", \\\"{x:389,y:663,t:1526930390403};\\\", \\\"{x:403,y:674,t:1526930390420};\\\", \\\"{x:418,y:689,t:1526930390438};\\\", \\\"{x:437,y:702,t:1526930390454};\\\", \\\"{x:453,y:713,t:1526930390470};\\\", \\\"{x:466,y:723,t:1526930390487};\\\", \\\"{x:477,y:730,t:1526930390504};\\\", \\\"{x:484,y:735,t:1526930390521};\\\", \\\"{x:491,y:741,t:1526930390538};\\\", \\\"{x:496,y:744,t:1526930390554};\\\", \\\"{x:496,y:745,t:1526930390571};\\\", \\\"{x:496,y:744,t:1526930390754};\\\", \\\"{x:495,y:742,t:1526930390771};\\\", \\\"{x:495,y:740,t:1526930390788};\\\", \\\"{x:495,y:739,t:1526930390804};\\\", \\\"{x:495,y:738,t:1526930391466};\\\", \\\"{x:495,y:737,t:1526930391474};\\\", \\\"{x:495,y:735,t:1526930391488};\\\", \\\"{x:492,y:734,t:1526930391504};\\\", \\\"{x:490,y:732,t:1526930391522};\\\", \\\"{x:488,y:731,t:1526930391538};\\\", \\\"{x:486,y:730,t:1526930391555};\\\", \\\"{x:484,y:729,t:1526930391571};\\\", \\\"{x:483,y:728,t:1526930391588};\\\", \\\"{x:482,y:727,t:1526930391605};\\\", \\\"{x:481,y:727,t:1526930391650};\\\", \\\"{x:480,y:727,t:1526930391658};\\\", \\\"{x:479,y:727,t:1526930391674};\\\", \\\"{x:478,y:726,t:1526930391688};\\\", \\\"{x:476,y:726,t:1526930391704};\\\", \\\"{x:474,y:725,t:1526930391722};\\\", \\\"{x:469,y:724,t:1526930391737};\\\", \\\"{x:458,y:723,t:1526930391754};\\\", \\\"{x:447,y:723,t:1526930391772};\\\", \\\"{x:429,y:723,t:1526930391788};\\\", \\\"{x:405,y:723,t:1526930391804};\\\", \\\"{x:371,y:723,t:1526930391821};\\\", \\\"{x:329,y:723,t:1526930391839};\\\", \\\"{x:276,y:723,t:1526930391855};\\\", \\\"{x:229,y:723,t:1526930391872};\\\", \\\"{x:194,y:723,t:1526930391888};\\\", \\\"{x:175,y:726,t:1526930391905};\\\", \\\"{x:163,y:726,t:1526930391922};\\\", \\\"{x:153,y:728,t:1526930391938};\\\", \\\"{x:148,y:730,t:1526930391955};\\\", \\\"{x:145,y:730,t:1526930391972};\\\", \\\"{x:141,y:731,t:1526930392001};\\\" ] }, { \\\"rt\\\": 37183, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 779087, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-M -M -Z -Z -F -4-Z -Z -4-F -O -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:139,y:731,t:1526930392235};\\\", \\\"{x:138,y:731,t:1526930392260};\\\", \\\"{x:137,y:729,t:1526930392490};\\\", \\\"{x:137,y:728,t:1526930392554};\\\", \\\"{x:150,y:708,t:1526930392659};\\\", \\\"{x:169,y:699,t:1526930392674};\\\", \\\"{x:176,y:694,t:1526930392688};\\\", \\\"{x:221,y:669,t:1526930392708};\\\", \\\"{x:254,y:657,t:1526930392722};\\\", \\\"{x:295,y:639,t:1526930392739};\\\", \\\"{x:334,y:621,t:1526930392756};\\\", \\\"{x:373,y:606,t:1526930392772};\\\", \\\"{x:405,y:593,t:1526930392788};\\\", \\\"{x:425,y:585,t:1526930392806};\\\", \\\"{x:444,y:580,t:1526930392823};\\\", \\\"{x:455,y:576,t:1526930392839};\\\", \\\"{x:461,y:572,t:1526930392855};\\\", \\\"{x:462,y:572,t:1526930392872};\\\", \\\"{x:463,y:572,t:1526930392889};\\\", \\\"{x:463,y:571,t:1526930392906};\\\", \\\"{x:465,y:570,t:1526930392954};\\\", \\\"{x:466,y:569,t:1526930392962};\\\", \\\"{x:466,y:567,t:1526930392978};\\\", \\\"{x:467,y:566,t:1526930392989};\\\", \\\"{x:467,y:563,t:1526930393006};\\\", \\\"{x:469,y:562,t:1526930393024};\\\", \\\"{x:469,y:559,t:1526930393039};\\\", \\\"{x:470,y:557,t:1526930393056};\\\", \\\"{x:470,y:553,t:1526930393074};\\\", \\\"{x:474,y:545,t:1526930393089};\\\", \\\"{x:478,y:537,t:1526930393105};\\\", \\\"{x:481,y:529,t:1526930393122};\\\", \\\"{x:484,y:523,t:1526930393140};\\\", \\\"{x:488,y:517,t:1526930393156};\\\", \\\"{x:490,y:512,t:1526930393173};\\\", \\\"{x:492,y:508,t:1526930393190};\\\", \\\"{x:495,y:502,t:1526930393205};\\\", \\\"{x:496,y:499,t:1526930393223};\\\", \\\"{x:496,y:495,t:1526930393239};\\\", \\\"{x:498,y:492,t:1526930393256};\\\", \\\"{x:499,y:488,t:1526930393274};\\\", \\\"{x:499,y:485,t:1526930393290};\\\", \\\"{x:499,y:483,t:1526930393314};\\\", \\\"{x:500,y:483,t:1526930393322};\\\", \\\"{x:500,y:482,t:1526930393338};\\\", \\\"{x:500,y:480,t:1526930393362};\\\", \\\"{x:500,y:479,t:1526930393394};\\\", \\\"{x:500,y:477,t:1526930393418};\\\", \\\"{x:500,y:476,t:1526930393434};\\\", \\\"{x:500,y:474,t:1526930393459};\\\", \\\"{x:500,y:473,t:1526930393474};\\\", \\\"{x:500,y:471,t:1526930393498};\\\", \\\"{x:500,y:470,t:1526930393538};\\\", \\\"{x:500,y:468,t:1526930393563};\\\", \\\"{x:498,y:467,t:1526930393578};\\\", \\\"{x:498,y:466,t:1526930393589};\\\", \\\"{x:494,y:463,t:1526930393605};\\\", \\\"{x:489,y:460,t:1526930393622};\\\", \\\"{x:486,y:458,t:1526930393639};\\\", \\\"{x:485,y:457,t:1526930393655};\\\", \\\"{x:484,y:456,t:1526930393672};\\\", \\\"{x:483,y:455,t:1526930393706};\\\", \\\"{x:483,y:454,t:1526930393754};\\\", \\\"{x:487,y:454,t:1526930393947};\\\", \\\"{x:494,y:454,t:1526930393954};\\\", \\\"{x:516,y:455,t:1526930393971};\\\", \\\"{x:548,y:458,t:1526930393988};\\\", \\\"{x:586,y:458,t:1526930394005};\\\", \\\"{x:621,y:460,t:1526930394021};\\\", \\\"{x:657,y:460,t:1526930394038};\\\", \\\"{x:679,y:460,t:1526930394055};\\\", \\\"{x:695,y:460,t:1526930394071};\\\", \\\"{x:709,y:461,t:1526930394088};\\\", \\\"{x:722,y:461,t:1526930394105};\\\", \\\"{x:738,y:461,t:1526930394121};\\\", \\\"{x:775,y:461,t:1526930394138};\\\", \\\"{x:806,y:462,t:1526930394155};\\\", \\\"{x:863,y:465,t:1526930394171};\\\", \\\"{x:919,y:465,t:1526930394188};\\\", \\\"{x:981,y:467,t:1526930394205};\\\", \\\"{x:1065,y:469,t:1526930394221};\\\", \\\"{x:1158,y:476,t:1526930394238};\\\", \\\"{x:1275,y:480,t:1526930394254};\\\", \\\"{x:1396,y:490,t:1526930394271};\\\", \\\"{x:1517,y:501,t:1526930394289};\\\", \\\"{x:1617,y:517,t:1526930394305};\\\", \\\"{x:1708,y:528,t:1526930394321};\\\", \\\"{x:1778,y:551,t:1526930394338};\\\", \\\"{x:1870,y:588,t:1526930394354};\\\", \\\"{x:1918,y:610,t:1526930394371};\\\", \\\"{x:1919,y:625,t:1526930394387};\\\", \\\"{x:1919,y:643,t:1526930394403};\\\", \\\"{x:1919,y:658,t:1526930394420};\\\", \\\"{x:1919,y:669,t:1526930394437};\\\", \\\"{x:1919,y:675,t:1526930394454};\\\", \\\"{x:1919,y:680,t:1526930394470};\\\", \\\"{x:1919,y:688,t:1526930394487};\\\", \\\"{x:1919,y:692,t:1526930394503};\\\", \\\"{x:1915,y:700,t:1526930394520};\\\", \\\"{x:1901,y:709,t:1526930394538};\\\", \\\"{x:1877,y:719,t:1526930394552};\\\", \\\"{x:1823,y:731,t:1526930394573};\\\", \\\"{x:1794,y:734,t:1526930394591};\\\", \\\"{x:1766,y:738,t:1526930394606};\\\", \\\"{x:1743,y:742,t:1526930394623};\\\", \\\"{x:1722,y:745,t:1526930394640};\\\", \\\"{x:1706,y:747,t:1526930394657};\\\", \\\"{x:1687,y:750,t:1526930394673};\\\", \\\"{x:1671,y:754,t:1526930394691};\\\", \\\"{x:1659,y:754,t:1526930394707};\\\", \\\"{x:1636,y:758,t:1526930394724};\\\", \\\"{x:1610,y:761,t:1526930394740};\\\", \\\"{x:1583,y:762,t:1526930394757};\\\", \\\"{x:1543,y:764,t:1526930394774};\\\", \\\"{x:1497,y:765,t:1526930394791};\\\", \\\"{x:1453,y:770,t:1526930394807};\\\", \\\"{x:1413,y:778,t:1526930394824};\\\", \\\"{x:1383,y:791,t:1526930394841};\\\", \\\"{x:1345,y:812,t:1526930394858};\\\", \\\"{x:1324,y:827,t:1526930394874};\\\", \\\"{x:1302,y:843,t:1526930394891};\\\", \\\"{x:1294,y:850,t:1526930394907};\\\", \\\"{x:1289,y:854,t:1526930394925};\\\", \\\"{x:1287,y:856,t:1526930394941};\\\", \\\"{x:1287,y:857,t:1526930394958};\\\", \\\"{x:1286,y:858,t:1526930394974};\\\", \\\"{x:1286,y:859,t:1526930394992};\\\", \\\"{x:1286,y:862,t:1526930395008};\\\", \\\"{x:1291,y:868,t:1526930395024};\\\", \\\"{x:1304,y:877,t:1526930395041};\\\", \\\"{x:1339,y:897,t:1526930395059};\\\", \\\"{x:1371,y:916,t:1526930395075};\\\", \\\"{x:1395,y:929,t:1526930395091};\\\", \\\"{x:1421,y:945,t:1526930395108};\\\", \\\"{x:1436,y:954,t:1526930395124};\\\", \\\"{x:1444,y:959,t:1526930395141};\\\", \\\"{x:1448,y:964,t:1526930395159};\\\", \\\"{x:1450,y:966,t:1526930395174};\\\", \\\"{x:1450,y:967,t:1526930395211};\\\", \\\"{x:1450,y:968,t:1526930395226};\\\", \\\"{x:1450,y:969,t:1526930395241};\\\", \\\"{x:1450,y:971,t:1526930395259};\\\", \\\"{x:1447,y:971,t:1526930395274};\\\", \\\"{x:1443,y:971,t:1526930395292};\\\", \\\"{x:1435,y:971,t:1526930395308};\\\", \\\"{x:1423,y:971,t:1526930395324};\\\", \\\"{x:1411,y:967,t:1526930395342};\\\", \\\"{x:1396,y:960,t:1526930395358};\\\", \\\"{x:1388,y:953,t:1526930395375};\\\", \\\"{x:1382,y:946,t:1526930395391};\\\", \\\"{x:1382,y:929,t:1526930395409};\\\", \\\"{x:1382,y:910,t:1526930395425};\\\", \\\"{x:1387,y:890,t:1526930395441};\\\", \\\"{x:1391,y:863,t:1526930395458};\\\", \\\"{x:1395,y:848,t:1526930395474};\\\", \\\"{x:1399,y:836,t:1526930395492};\\\", \\\"{x:1404,y:826,t:1526930395508};\\\", \\\"{x:1410,y:816,t:1526930395525};\\\", \\\"{x:1416,y:804,t:1526930395541};\\\", \\\"{x:1419,y:795,t:1526930395558};\\\", \\\"{x:1422,y:788,t:1526930395575};\\\", \\\"{x:1422,y:785,t:1526930395592};\\\", \\\"{x:1422,y:782,t:1526930395609};\\\", \\\"{x:1422,y:779,t:1526930395626};\\\", \\\"{x:1423,y:777,t:1526930395642};\\\", \\\"{x:1421,y:776,t:1526930395723};\\\", \\\"{x:1413,y:776,t:1526930395730};\\\", \\\"{x:1406,y:776,t:1526930395741};\\\", \\\"{x:1385,y:781,t:1526930395758};\\\", \\\"{x:1355,y:789,t:1526930395775};\\\", \\\"{x:1331,y:797,t:1526930395793};\\\", \\\"{x:1312,y:802,t:1526930395809};\\\", \\\"{x:1293,y:810,t:1526930395825};\\\", \\\"{x:1270,y:820,t:1526930395842};\\\", \\\"{x:1257,y:825,t:1526930395859};\\\", \\\"{x:1241,y:831,t:1526930395875};\\\", \\\"{x:1221,y:835,t:1526930395892};\\\", \\\"{x:1209,y:839,t:1526930395908};\\\", \\\"{x:1200,y:843,t:1526930395925};\\\", \\\"{x:1193,y:846,t:1526930395942};\\\", \\\"{x:1187,y:849,t:1526930395958};\\\", \\\"{x:1186,y:850,t:1526930395975};\\\", \\\"{x:1185,y:850,t:1526930395992};\\\", \\\"{x:1185,y:851,t:1526930396075};\\\", \\\"{x:1197,y:851,t:1526930396092};\\\", \\\"{x:1220,y:851,t:1526930396107};\\\", \\\"{x:1249,y:851,t:1526930396125};\\\", \\\"{x:1287,y:851,t:1526930396141};\\\", \\\"{x:1321,y:851,t:1526930396159};\\\", \\\"{x:1349,y:850,t:1526930396174};\\\", \\\"{x:1373,y:850,t:1526930396192};\\\", \\\"{x:1391,y:849,t:1526930396208};\\\", \\\"{x:1407,y:849,t:1526930396224};\\\", \\\"{x:1441,y:849,t:1526930396242};\\\", \\\"{x:1472,y:848,t:1526930396259};\\\", \\\"{x:1504,y:848,t:1526930396274};\\\", \\\"{x:1533,y:848,t:1526930396292};\\\", \\\"{x:1560,y:848,t:1526930396308};\\\", \\\"{x:1578,y:848,t:1526930396325};\\\", \\\"{x:1590,y:848,t:1526930396341};\\\", \\\"{x:1595,y:848,t:1526930396358};\\\", \\\"{x:1597,y:848,t:1526930396375};\\\", \\\"{x:1600,y:848,t:1526930396391};\\\", \\\"{x:1606,y:846,t:1526930396409};\\\", \\\"{x:1616,y:845,t:1526930396425};\\\", \\\"{x:1638,y:843,t:1526930396443};\\\", \\\"{x:1655,y:840,t:1526930396458};\\\", \\\"{x:1665,y:838,t:1526930396475};\\\", \\\"{x:1674,y:836,t:1526930396492};\\\", \\\"{x:1680,y:836,t:1526930396509};\\\", \\\"{x:1683,y:836,t:1526930396525};\\\", \\\"{x:1684,y:835,t:1526930396542};\\\", \\\"{x:1688,y:835,t:1526930396559};\\\", \\\"{x:1691,y:835,t:1526930396576};\\\", \\\"{x:1697,y:834,t:1526930396592};\\\", \\\"{x:1701,y:833,t:1526930396609};\\\", \\\"{x:1707,y:833,t:1526930396626};\\\", \\\"{x:1710,y:833,t:1526930396641};\\\", \\\"{x:1714,y:833,t:1526930396659};\\\", \\\"{x:1716,y:833,t:1526930396676};\\\", \\\"{x:1718,y:833,t:1526930396691};\\\", \\\"{x:1720,y:833,t:1526930396708};\\\", \\\"{x:1723,y:833,t:1526930396726};\\\", \\\"{x:1725,y:833,t:1526930396746};\\\", \\\"{x:1726,y:833,t:1526930396819};\\\", \\\"{x:1725,y:833,t:1526930396843};\\\", \\\"{x:1706,y:834,t:1526930396860};\\\", \\\"{x:1675,y:839,t:1526930396876};\\\", \\\"{x:1624,y:841,t:1526930396893};\\\", \\\"{x:1569,y:844,t:1526930396910};\\\", \\\"{x:1527,y:844,t:1526930396926};\\\", \\\"{x:1500,y:845,t:1526930396943};\\\", \\\"{x:1483,y:847,t:1526930396959};\\\", \\\"{x:1474,y:852,t:1526930396976};\\\", \\\"{x:1469,y:855,t:1526930396993};\\\", \\\"{x:1466,y:858,t:1526930397009};\\\", \\\"{x:1453,y:864,t:1526930397026};\\\", \\\"{x:1437,y:870,t:1526930397043};\\\", \\\"{x:1420,y:875,t:1526930397059};\\\", \\\"{x:1404,y:879,t:1526930397076};\\\", \\\"{x:1391,y:884,t:1526930397093};\\\", \\\"{x:1383,y:890,t:1526930397109};\\\", \\\"{x:1378,y:893,t:1526930397129};\\\", \\\"{x:1374,y:896,t:1526930397143};\\\", \\\"{x:1368,y:899,t:1526930397159};\\\", \\\"{x:1359,y:902,t:1526930397175};\\\", \\\"{x:1348,y:902,t:1526930397193};\\\", \\\"{x:1337,y:902,t:1526930397209};\\\", \\\"{x:1323,y:902,t:1526930397226};\\\", \\\"{x:1316,y:898,t:1526930397243};\\\", \\\"{x:1308,y:893,t:1526930397259};\\\", \\\"{x:1303,y:885,t:1526930397275};\\\", \\\"{x:1296,y:873,t:1526930397293};\\\", \\\"{x:1290,y:854,t:1526930397308};\\\", \\\"{x:1282,y:834,t:1526930397326};\\\", \\\"{x:1279,y:816,t:1526930397343};\\\", \\\"{x:1273,y:795,t:1526930397359};\\\", \\\"{x:1271,y:777,t:1526930397376};\\\", \\\"{x:1271,y:757,t:1526930397393};\\\", \\\"{x:1271,y:737,t:1526930397409};\\\", \\\"{x:1281,y:709,t:1526930397426};\\\", \\\"{x:1289,y:692,t:1526930397443};\\\", \\\"{x:1299,y:676,t:1526930397459};\\\", \\\"{x:1309,y:663,t:1526930397475};\\\", \\\"{x:1324,y:649,t:1526930397493};\\\", \\\"{x:1339,y:638,t:1526930397510};\\\", \\\"{x:1360,y:626,t:1526930397526};\\\", \\\"{x:1388,y:611,t:1526930397542};\\\", \\\"{x:1412,y:603,t:1526930397560};\\\", \\\"{x:1435,y:595,t:1526930397576};\\\", \\\"{x:1455,y:591,t:1526930397593};\\\", \\\"{x:1479,y:581,t:1526930397610};\\\", \\\"{x:1497,y:576,t:1526930397626};\\\", \\\"{x:1512,y:572,t:1526930397643};\\\", \\\"{x:1529,y:567,t:1526930397660};\\\", \\\"{x:1539,y:564,t:1526930397676};\\\", \\\"{x:1546,y:562,t:1526930397693};\\\", \\\"{x:1551,y:561,t:1526930397710};\\\", \\\"{x:1555,y:561,t:1526930397726};\\\", \\\"{x:1561,y:561,t:1526930397743};\\\", \\\"{x:1565,y:561,t:1526930397760};\\\", \\\"{x:1573,y:561,t:1526930397777};\\\", \\\"{x:1578,y:561,t:1526930397794};\\\", \\\"{x:1586,y:563,t:1526930397811};\\\", \\\"{x:1595,y:570,t:1526930397827};\\\", \\\"{x:1607,y:580,t:1526930397843};\\\", \\\"{x:1621,y:598,t:1526930397861};\\\", \\\"{x:1633,y:616,t:1526930397877};\\\", \\\"{x:1643,y:636,t:1526930397893};\\\", \\\"{x:1652,y:656,t:1526930397910};\\\", \\\"{x:1656,y:674,t:1526930397927};\\\", \\\"{x:1663,y:691,t:1526930397943};\\\", \\\"{x:1667,y:701,t:1526930397960};\\\", \\\"{x:1669,y:707,t:1526930397978};\\\", \\\"{x:1670,y:712,t:1526930397993};\\\", \\\"{x:1670,y:714,t:1526930398010};\\\", \\\"{x:1670,y:715,t:1526930398027};\\\", \\\"{x:1670,y:716,t:1526930398083};\\\", \\\"{x:1667,y:716,t:1526930398093};\\\", \\\"{x:1662,y:716,t:1526930398110};\\\", \\\"{x:1655,y:716,t:1526930398127};\\\", \\\"{x:1650,y:716,t:1526930398143};\\\", \\\"{x:1646,y:716,t:1526930398160};\\\", \\\"{x:1645,y:716,t:1526930398178};\\\", \\\"{x:1643,y:716,t:1526930398193};\\\", \\\"{x:1641,y:715,t:1526930398211};\\\", \\\"{x:1639,y:714,t:1526930398226};\\\", \\\"{x:1636,y:713,t:1526930398244};\\\", \\\"{x:1634,y:711,t:1526930398260};\\\", \\\"{x:1633,y:710,t:1526930398277};\\\", \\\"{x:1632,y:710,t:1526930398293};\\\", \\\"{x:1631,y:709,t:1526930398310};\\\", \\\"{x:1630,y:708,t:1526930398327};\\\", \\\"{x:1628,y:707,t:1526930398343};\\\", \\\"{x:1627,y:706,t:1526930398360};\\\", \\\"{x:1626,y:705,t:1526930398377};\\\", \\\"{x:1625,y:705,t:1526930398394};\\\", \\\"{x:1623,y:704,t:1526930398410};\\\", \\\"{x:1622,y:703,t:1526930398427};\\\", \\\"{x:1620,y:702,t:1526930398450};\\\", \\\"{x:1619,y:702,t:1526930398835};\\\", \\\"{x:1618,y:702,t:1526930398971};\\\", \\\"{x:1616,y:702,t:1526930399011};\\\", \\\"{x:1615,y:702,t:1526930399044};\\\", \\\"{x:1613,y:702,t:1526930399138};\\\", \\\"{x:1612,y:702,t:1526930399532};\\\", \\\"{x:1611,y:702,t:1526930399554};\\\", \\\"{x:1610,y:702,t:1526930399627};\\\", \\\"{x:1609,y:702,t:1526930399645};\\\", \\\"{x:1608,y:702,t:1526930399674};\\\", \\\"{x:1607,y:702,t:1526930399691};\\\", \\\"{x:1606,y:702,t:1526930399699};\\\", \\\"{x:1605,y:703,t:1526930399730};\\\", \\\"{x:1604,y:703,t:1526930399762};\\\", \\\"{x:1603,y:703,t:1526930399779};\\\", \\\"{x:1602,y:703,t:1526930399867};\\\", \\\"{x:1602,y:702,t:1526930399931};\\\", \\\"{x:1602,y:701,t:1526930399946};\\\", \\\"{x:1602,y:700,t:1526930400019};\\\", \\\"{x:1602,y:699,t:1526930400051};\\\", \\\"{x:1603,y:699,t:1526930400147};\\\", \\\"{x:1605,y:699,t:1526930400170};\\\", \\\"{x:1606,y:699,t:1526930400194};\\\", \\\"{x:1608,y:698,t:1526930400213};\\\", \\\"{x:1609,y:698,t:1526930400229};\\\", \\\"{x:1610,y:698,t:1526930400245};\\\", \\\"{x:1612,y:698,t:1526930400262};\\\", \\\"{x:1613,y:697,t:1526930400291};\\\", \\\"{x:1612,y:697,t:1526930406634};\\\", \\\"{x:1558,y:699,t:1526930406650};\\\", \\\"{x:1455,y:699,t:1526930406667};\\\", \\\"{x:1347,y:699,t:1526930406684};\\\", \\\"{x:1239,y:699,t:1526930406701};\\\", \\\"{x:1158,y:699,t:1526930406718};\\\", \\\"{x:1105,y:699,t:1526930406733};\\\", \\\"{x:1063,y:699,t:1526930406751};\\\", \\\"{x:1021,y:699,t:1526930406768};\\\", \\\"{x:961,y:693,t:1526930406783};\\\", \\\"{x:898,y:680,t:1526930406801};\\\", \\\"{x:838,y:666,t:1526930406818};\\\", \\\"{x:793,y:652,t:1526930406833};\\\", \\\"{x:759,y:636,t:1526930406850};\\\", \\\"{x:749,y:627,t:1526930406868};\\\", \\\"{x:740,y:621,t:1526930406883};\\\", \\\"{x:735,y:616,t:1526930406899};\\\", \\\"{x:731,y:612,t:1526930406914};\\\", \\\"{x:728,y:606,t:1526930406931};\\\", \\\"{x:728,y:603,t:1526930406947};\\\", \\\"{x:729,y:599,t:1526930406964};\\\", \\\"{x:733,y:589,t:1526930406982};\\\", \\\"{x:738,y:581,t:1526930407000};\\\", \\\"{x:746,y:570,t:1526930407017};\\\", \\\"{x:757,y:559,t:1526930407034};\\\", \\\"{x:776,y:540,t:1526930407050};\\\", \\\"{x:788,y:530,t:1526930407067};\\\", \\\"{x:799,y:522,t:1526930407084};\\\", \\\"{x:810,y:515,t:1526930407100};\\\", \\\"{x:815,y:511,t:1526930407117};\\\", \\\"{x:817,y:510,t:1526930407133};\\\", \\\"{x:818,y:508,t:1526930407150};\\\", \\\"{x:818,y:507,t:1526930407167};\\\", \\\"{x:819,y:506,t:1526930407183};\\\", \\\"{x:819,y:505,t:1526930407200};\\\", \\\"{x:820,y:504,t:1526930407217};\\\", \\\"{x:821,y:503,t:1526930407234};\\\", \\\"{x:821,y:502,t:1526930407258};\\\", \\\"{x:821,y:501,t:1526930407274};\\\", \\\"{x:822,y:501,t:1526930407284};\\\", \\\"{x:823,y:500,t:1526930407301};\\\", \\\"{x:824,y:498,t:1526930407317};\\\", \\\"{x:825,y:498,t:1526930407338};\\\", \\\"{x:826,y:498,t:1526930407387};\\\", \\\"{x:827,y:498,t:1526930407425};\\\", \\\"{x:829,y:499,t:1526930407657};\\\", \\\"{x:831,y:500,t:1526930407667};\\\", \\\"{x:839,y:507,t:1526930407684};\\\", \\\"{x:867,y:519,t:1526930407701};\\\", \\\"{x:926,y:537,t:1526930407718};\\\", \\\"{x:1014,y:554,t:1526930407734};\\\", \\\"{x:1100,y:566,t:1526930407751};\\\", \\\"{x:1186,y:579,t:1526930407767};\\\", \\\"{x:1263,y:588,t:1526930407784};\\\", \\\"{x:1316,y:597,t:1526930407802};\\\", \\\"{x:1325,y:598,t:1526930407817};\\\", \\\"{x:1338,y:603,t:1526930407834};\\\", \\\"{x:1341,y:606,t:1526930407852};\\\", \\\"{x:1344,y:609,t:1526930407868};\\\", \\\"{x:1345,y:612,t:1526930407885};\\\", \\\"{x:1349,y:618,t:1526930407902};\\\", \\\"{x:1357,y:625,t:1526930407918};\\\", \\\"{x:1367,y:634,t:1526930407934};\\\", \\\"{x:1379,y:644,t:1526930407952};\\\", \\\"{x:1397,y:654,t:1526930407968};\\\", \\\"{x:1419,y:668,t:1526930407984};\\\", \\\"{x:1448,y:686,t:1526930408002};\\\", \\\"{x:1466,y:694,t:1526930408018};\\\", \\\"{x:1477,y:698,t:1526930408034};\\\", \\\"{x:1486,y:702,t:1526930408052};\\\", \\\"{x:1502,y:708,t:1526930408069};\\\", \\\"{x:1531,y:715,t:1526930408084};\\\", \\\"{x:1571,y:723,t:1526930408102};\\\", \\\"{x:1602,y:729,t:1526930408118};\\\", \\\"{x:1629,y:734,t:1526930408135};\\\", \\\"{x:1645,y:737,t:1526930408152};\\\", \\\"{x:1649,y:738,t:1526930408169};\\\", \\\"{x:1649,y:737,t:1526930408290};\\\", \\\"{x:1648,y:735,t:1526930408302};\\\", \\\"{x:1646,y:731,t:1526930408319};\\\", \\\"{x:1643,y:729,t:1526930408335};\\\", \\\"{x:1641,y:726,t:1526930408351};\\\", \\\"{x:1638,y:723,t:1526930408369};\\\", \\\"{x:1635,y:719,t:1526930408385};\\\", \\\"{x:1633,y:715,t:1526930408403};\\\", \\\"{x:1631,y:714,t:1526930408419};\\\", \\\"{x:1628,y:711,t:1526930408436};\\\", \\\"{x:1625,y:709,t:1526930408452};\\\", \\\"{x:1622,y:708,t:1526930408468};\\\", \\\"{x:1618,y:705,t:1526930408486};\\\", \\\"{x:1612,y:702,t:1526930408502};\\\", \\\"{x:1609,y:700,t:1526930408519};\\\", \\\"{x:1607,y:700,t:1526930408535};\\\", \\\"{x:1606,y:700,t:1526930408551};\\\", \\\"{x:1603,y:698,t:1526930408569};\\\", \\\"{x:1602,y:697,t:1526930408594};\\\", \\\"{x:1602,y:696,t:1526930408907};\\\", \\\"{x:1603,y:696,t:1526930408919};\\\", \\\"{x:1604,y:696,t:1526930408936};\\\", \\\"{x:1605,y:696,t:1526930408952};\\\", \\\"{x:1607,y:696,t:1526930408968};\\\", \\\"{x:1608,y:696,t:1526930408986};\\\", \\\"{x:1609,y:696,t:1526930409067};\\\", \\\"{x:1610,y:696,t:1526930409086};\\\", \\\"{x:1611,y:696,t:1526930409103};\\\", \\\"{x:1612,y:696,t:1526930409119};\\\", \\\"{x:1614,y:695,t:1526930409135};\\\", \\\"{x:1615,y:694,t:1526930409153};\\\", \\\"{x:1619,y:693,t:1526930409168};\\\", \\\"{x:1620,y:692,t:1526930409186};\\\", \\\"{x:1613,y:691,t:1526930417186};\\\", \\\"{x:1587,y:691,t:1526930417194};\\\", \\\"{x:1559,y:691,t:1526930417209};\\\", \\\"{x:1439,y:691,t:1526930417227};\\\", \\\"{x:1331,y:691,t:1526930417242};\\\", \\\"{x:1234,y:691,t:1526930417259};\\\", \\\"{x:1143,y:691,t:1526930417276};\\\", \\\"{x:1059,y:691,t:1526930417292};\\\", \\\"{x:968,y:691,t:1526930417309};\\\", \\\"{x:879,y:691,t:1526930417326};\\\", \\\"{x:776,y:689,t:1526930417342};\\\", \\\"{x:657,y:689,t:1526930417359};\\\", \\\"{x:549,y:689,t:1526930417376};\\\", \\\"{x:449,y:689,t:1526930417392};\\\", \\\"{x:377,y:682,t:1526930417409};\\\", \\\"{x:331,y:674,t:1526930417426};\\\", \\\"{x:329,y:672,t:1526930417442};\\\", \\\"{x:329,y:671,t:1526930417459};\\\", \\\"{x:329,y:665,t:1526930417477};\\\", \\\"{x:329,y:657,t:1526930417492};\\\", \\\"{x:326,y:647,t:1526930417508};\\\", \\\"{x:325,y:639,t:1526930417526};\\\", \\\"{x:325,y:629,t:1526930417542};\\\", \\\"{x:326,y:618,t:1526930417558};\\\", \\\"{x:335,y:605,t:1526930417575};\\\", \\\"{x:348,y:597,t:1526930417592};\\\", \\\"{x:382,y:587,t:1526930417609};\\\", \\\"{x:476,y:572,t:1526930417625};\\\", \\\"{x:559,y:561,t:1526930417643};\\\", \\\"{x:643,y:550,t:1526930417659};\\\", \\\"{x:708,y:544,t:1526930417676};\\\", \\\"{x:748,y:543,t:1526930417693};\\\", \\\"{x:770,y:542,t:1526930417708};\\\", \\\"{x:778,y:541,t:1526930417726};\\\", \\\"{x:779,y:541,t:1526930417742};\\\", \\\"{x:780,y:542,t:1526930417818};\\\", \\\"{x:780,y:545,t:1526930417825};\\\", \\\"{x:775,y:552,t:1526930417842};\\\", \\\"{x:762,y:558,t:1526930417860};\\\", \\\"{x:744,y:567,t:1526930417876};\\\", \\\"{x:729,y:570,t:1526930417892};\\\", \\\"{x:713,y:573,t:1526930417909};\\\", \\\"{x:698,y:573,t:1526930417925};\\\", \\\"{x:681,y:573,t:1526930417942};\\\", \\\"{x:665,y:573,t:1526930417958};\\\", \\\"{x:650,y:572,t:1526930417975};\\\", \\\"{x:633,y:570,t:1526930417992};\\\", \\\"{x:619,y:568,t:1526930418009};\\\", \\\"{x:609,y:566,t:1526930418025};\\\", \\\"{x:602,y:566,t:1526930418042};\\\", \\\"{x:601,y:566,t:1526930418058};\\\", \\\"{x:600,y:566,t:1526930418075};\\\", \\\"{x:599,y:566,t:1526930418379};\\\", \\\"{x:606,y:566,t:1526930418804};\\\", \\\"{x:621,y:568,t:1526930418809};\\\", \\\"{x:681,y:575,t:1526930418827};\\\", \\\"{x:776,y:591,t:1526930418843};\\\", \\\"{x:878,y:603,t:1526930418860};\\\", \\\"{x:984,y:616,t:1526930418877};\\\", \\\"{x:1070,y:630,t:1526930418894};\\\", \\\"{x:1140,y:640,t:1526930418910};\\\", \\\"{x:1199,y:648,t:1526930418927};\\\", \\\"{x:1241,y:654,t:1526930418944};\\\", \\\"{x:1267,y:661,t:1526930418959};\\\", \\\"{x:1292,y:668,t:1526930418977};\\\", \\\"{x:1316,y:677,t:1526930418993};\\\", \\\"{x:1332,y:685,t:1526930419010};\\\", \\\"{x:1348,y:692,t:1526930419027};\\\", \\\"{x:1360,y:697,t:1526930419044};\\\", \\\"{x:1367,y:700,t:1526930419060};\\\", \\\"{x:1370,y:702,t:1526930419077};\\\", \\\"{x:1371,y:702,t:1526930419094};\\\", \\\"{x:1371,y:703,t:1526930419110};\\\", \\\"{x:1375,y:707,t:1526930419127};\\\", \\\"{x:1383,y:713,t:1526930419143};\\\", \\\"{x:1398,y:720,t:1526930419160};\\\", \\\"{x:1411,y:725,t:1526930419177};\\\", \\\"{x:1432,y:735,t:1526930419194};\\\", \\\"{x:1438,y:736,t:1526930419210};\\\", \\\"{x:1441,y:738,t:1526930419227};\\\", \\\"{x:1443,y:738,t:1526930419244};\\\", \\\"{x:1443,y:739,t:1526930419260};\\\", \\\"{x:1444,y:740,t:1526930419277};\\\", \\\"{x:1445,y:740,t:1526930419294};\\\", \\\"{x:1446,y:741,t:1526930419310};\\\", \\\"{x:1447,y:742,t:1526930419327};\\\", \\\"{x:1449,y:744,t:1526930419344};\\\", \\\"{x:1451,y:746,t:1526930419360};\\\", \\\"{x:1456,y:749,t:1526930419377};\\\", \\\"{x:1465,y:753,t:1526930419394};\\\", \\\"{x:1473,y:758,t:1526930419410};\\\", \\\"{x:1480,y:761,t:1526930419427};\\\", \\\"{x:1484,y:763,t:1526930419444};\\\", \\\"{x:1485,y:764,t:1526930419461};\\\", \\\"{x:1489,y:764,t:1526930419635};\\\", \\\"{x:1492,y:765,t:1526930419644};\\\", \\\"{x:1497,y:765,t:1526930419662};\\\", \\\"{x:1500,y:765,t:1526930419677};\\\", \\\"{x:1502,y:765,t:1526930419694};\\\", \\\"{x:1503,y:765,t:1526930419770};\\\", \\\"{x:1504,y:764,t:1526930419843};\\\", \\\"{x:1504,y:763,t:1526930419867};\\\", \\\"{x:1504,y:762,t:1526930419891};\\\", \\\"{x:1504,y:761,t:1526930419906};\\\", \\\"{x:1504,y:760,t:1526930419922};\\\", \\\"{x:1504,y:759,t:1526930419930};\\\", \\\"{x:1504,y:758,t:1526930419962};\\\", \\\"{x:1504,y:757,t:1526930419986};\\\", \\\"{x:1504,y:756,t:1526930420026};\\\", \\\"{x:1506,y:756,t:1526930420411};\\\", \\\"{x:1509,y:756,t:1526930420428};\\\", \\\"{x:1512,y:756,t:1526930420446};\\\", \\\"{x:1516,y:756,t:1526930420461};\\\", \\\"{x:1520,y:756,t:1526930420478};\\\", \\\"{x:1526,y:756,t:1526930420496};\\\", \\\"{x:1540,y:757,t:1526930420511};\\\", \\\"{x:1563,y:761,t:1526930420528};\\\", \\\"{x:1588,y:764,t:1526930420545};\\\", \\\"{x:1611,y:766,t:1526930420561};\\\", \\\"{x:1635,y:768,t:1526930420579};\\\", \\\"{x:1641,y:769,t:1526930420595};\\\", \\\"{x:1645,y:769,t:1526930420611};\\\", \\\"{x:1648,y:771,t:1526930420628};\\\", \\\"{x:1650,y:771,t:1526930420645};\\\", \\\"{x:1655,y:771,t:1526930420661};\\\", \\\"{x:1662,y:772,t:1526930420678};\\\", \\\"{x:1670,y:773,t:1526930420695};\\\", \\\"{x:1677,y:775,t:1526930420712};\\\", \\\"{x:1678,y:775,t:1526930420811};\\\", \\\"{x:1671,y:768,t:1526930420828};\\\", \\\"{x:1657,y:759,t:1526930420845};\\\", \\\"{x:1642,y:746,t:1526930420862};\\\", \\\"{x:1631,y:739,t:1526930420879};\\\", \\\"{x:1622,y:731,t:1526930420895};\\\", \\\"{x:1615,y:726,t:1526930420911};\\\", \\\"{x:1612,y:723,t:1526930420928};\\\", \\\"{x:1609,y:718,t:1526930420945};\\\", \\\"{x:1607,y:714,t:1526930420962};\\\", \\\"{x:1605,y:711,t:1526930420979};\\\", \\\"{x:1604,y:710,t:1526930420995};\\\", \\\"{x:1603,y:708,t:1526930421012};\\\", \\\"{x:1602,y:705,t:1526930421029};\\\", \\\"{x:1602,y:704,t:1526930421050};\\\", \\\"{x:1602,y:703,t:1526930421063};\\\", \\\"{x:1601,y:701,t:1526930421079};\\\", \\\"{x:1601,y:699,t:1526930421114};\\\", \\\"{x:1601,y:698,t:1526930421128};\\\", \\\"{x:1601,y:697,t:1526930421146};\\\", \\\"{x:1601,y:694,t:1526930421161};\\\", \\\"{x:1601,y:692,t:1526930421178};\\\", \\\"{x:1601,y:691,t:1526930421195};\\\", \\\"{x:1601,y:689,t:1526930421212};\\\", \\\"{x:1601,y:688,t:1526930421228};\\\", \\\"{x:1601,y:686,t:1526930421245};\\\", \\\"{x:1601,y:685,t:1526930421265};\\\", \\\"{x:1601,y:684,t:1526930421278};\\\", \\\"{x:1601,y:683,t:1526930421297};\\\", \\\"{x:1601,y:682,t:1526930421346};\\\", \\\"{x:1602,y:682,t:1526930421930};\\\", \\\"{x:1603,y:682,t:1526930422410};\\\", \\\"{x:1604,y:682,t:1526930422441};\\\", \\\"{x:1605,y:682,t:1526930422675};\\\", \\\"{x:1605,y:683,t:1526930422731};\\\", \\\"{x:1606,y:683,t:1526930422755};\\\", \\\"{x:1606,y:685,t:1526930422826};\\\", \\\"{x:1606,y:686,t:1526930422922};\\\", \\\"{x:1605,y:687,t:1526930423618};\\\", \\\"{x:1599,y:687,t:1526930423630};\\\", \\\"{x:1583,y:682,t:1526930423647};\\\", \\\"{x:1567,y:677,t:1526930423663};\\\", \\\"{x:1553,y:672,t:1526930423681};\\\", \\\"{x:1540,y:668,t:1526930423697};\\\", \\\"{x:1533,y:664,t:1526930423713};\\\", \\\"{x:1523,y:654,t:1526930423730};\\\", \\\"{x:1514,y:645,t:1526930423747};\\\", \\\"{x:1505,y:637,t:1526930423763};\\\", \\\"{x:1494,y:626,t:1526930423780};\\\", \\\"{x:1485,y:620,t:1526930423797};\\\", \\\"{x:1474,y:611,t:1526930423814};\\\", \\\"{x:1463,y:604,t:1526930423830};\\\", \\\"{x:1451,y:594,t:1526930423847};\\\", \\\"{x:1445,y:590,t:1526930423863};\\\", \\\"{x:1441,y:587,t:1526930423881};\\\", \\\"{x:1438,y:584,t:1526930423897};\\\", \\\"{x:1437,y:583,t:1526930423914};\\\", \\\"{x:1435,y:581,t:1526930423930};\\\", \\\"{x:1435,y:580,t:1526930423948};\\\", \\\"{x:1434,y:578,t:1526930423964};\\\", \\\"{x:1434,y:577,t:1526930423981};\\\", \\\"{x:1434,y:575,t:1526930423997};\\\", \\\"{x:1433,y:574,t:1526930424017};\\\", \\\"{x:1435,y:574,t:1526930424122};\\\", \\\"{x:1439,y:574,t:1526930424130};\\\", \\\"{x:1447,y:578,t:1526930424147};\\\", \\\"{x:1459,y:586,t:1526930424164};\\\", \\\"{x:1478,y:596,t:1526930424180};\\\", \\\"{x:1495,y:605,t:1526930424197};\\\", \\\"{x:1508,y:612,t:1526930424214};\\\", \\\"{x:1514,y:617,t:1526930424230};\\\", \\\"{x:1516,y:618,t:1526930424247};\\\", \\\"{x:1515,y:618,t:1526930424281};\\\", \\\"{x:1510,y:618,t:1526930424297};\\\", \\\"{x:1483,y:618,t:1526930424313};\\\", \\\"{x:1459,y:613,t:1526930424330};\\\", \\\"{x:1440,y:608,t:1526930424347};\\\", \\\"{x:1424,y:598,t:1526930424364};\\\", \\\"{x:1416,y:590,t:1526930424380};\\\", \\\"{x:1413,y:585,t:1526930424398};\\\", \\\"{x:1411,y:581,t:1526930424414};\\\", \\\"{x:1409,y:577,t:1526930424430};\\\", \\\"{x:1408,y:574,t:1526930424448};\\\", \\\"{x:1407,y:572,t:1526930424464};\\\", \\\"{x:1407,y:571,t:1526930424481};\\\", \\\"{x:1406,y:570,t:1526930424498};\\\", \\\"{x:1405,y:568,t:1526930424514};\\\", \\\"{x:1404,y:568,t:1526930424530};\\\", \\\"{x:1404,y:567,t:1526930424554};\\\", \\\"{x:1404,y:566,t:1526930424810};\\\", \\\"{x:1405,y:566,t:1526930424899};\\\", \\\"{x:1406,y:566,t:1526930424962};\\\", \\\"{x:1407,y:566,t:1526930424986};\\\", \\\"{x:1408,y:566,t:1526930425003};\\\", \\\"{x:1409,y:566,t:1526930425018};\\\", \\\"{x:1410,y:566,t:1526930425032};\\\", \\\"{x:1413,y:566,t:1526930425048};\\\", \\\"{x:1417,y:566,t:1526930425064};\\\", \\\"{x:1422,y:566,t:1526930425083};\\\", \\\"{x:1435,y:566,t:1526930425098};\\\", \\\"{x:1443,y:566,t:1526930425114};\\\", \\\"{x:1450,y:566,t:1526930425132};\\\", \\\"{x:1458,y:568,t:1526930425148};\\\", \\\"{x:1465,y:568,t:1526930425164};\\\", \\\"{x:1469,y:568,t:1526930425182};\\\", \\\"{x:1472,y:568,t:1526930425198};\\\", \\\"{x:1473,y:568,t:1526930425214};\\\", \\\"{x:1473,y:567,t:1526930425378};\\\", \\\"{x:1473,y:566,t:1526930425410};\\\", \\\"{x:1473,y:565,t:1526930425418};\\\", \\\"{x:1473,y:563,t:1526930425458};\\\", \\\"{x:1474,y:563,t:1526930426018};\\\", \\\"{x:1478,y:563,t:1526930426031};\\\", \\\"{x:1495,y:563,t:1526930426048};\\\", \\\"{x:1530,y:563,t:1526930426066};\\\", \\\"{x:1552,y:563,t:1526930426082};\\\", \\\"{x:1572,y:562,t:1526930426099};\\\", \\\"{x:1584,y:562,t:1526930426116};\\\", \\\"{x:1588,y:562,t:1526930426132};\\\", \\\"{x:1590,y:561,t:1526930426148};\\\", \\\"{x:1591,y:561,t:1526930426177};\\\", \\\"{x:1592,y:561,t:1526930426185};\\\", \\\"{x:1594,y:561,t:1526930426197};\\\", \\\"{x:1601,y:561,t:1526930426215};\\\", \\\"{x:1610,y:561,t:1526930426231};\\\", \\\"{x:1614,y:561,t:1526930426247};\\\", \\\"{x:1616,y:561,t:1526930426265};\\\", \\\"{x:1611,y:561,t:1526930428234};\\\", \\\"{x:1577,y:561,t:1526930428250};\\\", \\\"{x:1519,y:561,t:1526930428267};\\\", \\\"{x:1438,y:561,t:1526930428284};\\\", \\\"{x:1341,y:561,t:1526930428300};\\\", \\\"{x:1250,y:561,t:1526930428316};\\\", \\\"{x:1169,y:561,t:1526930428334};\\\", \\\"{x:1113,y:561,t:1526930428350};\\\", \\\"{x:1067,y:563,t:1526930428367};\\\", \\\"{x:1025,y:569,t:1526930428384};\\\", \\\"{x:983,y:574,t:1526930428401};\\\", \\\"{x:944,y:580,t:1526930428417};\\\", \\\"{x:866,y:594,t:1526930428434};\\\", \\\"{x:828,y:606,t:1526930428450};\\\", \\\"{x:781,y:627,t:1526930428484};\\\", \\\"{x:762,y:638,t:1526930428501};\\\", \\\"{x:738,y:654,t:1526930428518};\\\", \\\"{x:707,y:673,t:1526930428534};\\\", \\\"{x:659,y:700,t:1526930428551};\\\", \\\"{x:603,y:737,t:1526930428567};\\\", \\\"{x:548,y:771,t:1526930428584};\\\", \\\"{x:459,y:830,t:1526930428601};\\\", \\\"{x:422,y:850,t:1526930428617};\\\", \\\"{x:399,y:858,t:1526930428634};\\\", \\\"{x:384,y:861,t:1526930428651};\\\", \\\"{x:377,y:861,t:1526930428667};\\\", \\\"{x:373,y:861,t:1526930428683};\\\", \\\"{x:365,y:860,t:1526930428700};\\\", \\\"{x:357,y:855,t:1526930428717};\\\", \\\"{x:346,y:846,t:1526930428734};\\\", \\\"{x:338,y:837,t:1526930428751};\\\", \\\"{x:335,y:828,t:1526930428767};\\\", \\\"{x:334,y:820,t:1526930428784};\\\", \\\"{x:334,y:809,t:1526930428802};\\\", \\\"{x:341,y:801,t:1526930428817};\\\", \\\"{x:354,y:792,t:1526930428833};\\\", \\\"{x:371,y:786,t:1526930428850};\\\", \\\"{x:391,y:779,t:1526930428868};\\\", \\\"{x:412,y:774,t:1526930428884};\\\", \\\"{x:435,y:769,t:1526930428900};\\\", \\\"{x:452,y:765,t:1526930428917};\\\", \\\"{x:465,y:761,t:1526930428934};\\\", \\\"{x:474,y:758,t:1526930428950};\\\", \\\"{x:484,y:754,t:1526930428968};\\\", \\\"{x:488,y:751,t:1526930428983};\\\", \\\"{x:495,y:748,t:1526930429001};\\\", \\\"{x:496,y:748,t:1526930429018};\\\", \\\"{x:498,y:746,t:1526930429035};\\\", \\\"{x:498,y:745,t:1526930429057};\\\", \\\"{x:499,y:742,t:1526930429089};\\\", \\\"{x:499,y:741,t:1526930429105};\\\", \\\"{x:499,y:739,t:1526930429122};\\\", \\\"{x:499,y:738,t:1526930429146};\\\", \\\"{x:499,y:737,t:1526930429162};\\\", \\\"{x:499,y:736,t:1526930429593};\\\", \\\"{x:499,y:735,t:1526930429601};\\\", \\\"{x:521,y:741,t:1526930429618};\\\", \\\"{x:571,y:755,t:1526930429635};\\\", \\\"{x:657,y:766,t:1526930429652};\\\", \\\"{x:759,y:780,t:1526930429668};\\\", \\\"{x:862,y:796,t:1526930429685};\\\", \\\"{x:945,y:805,t:1526930429702};\\\", \\\"{x:1003,y:812,t:1526930429718};\\\", \\\"{x:1042,y:812,t:1526930429735};\\\", \\\"{x:1063,y:812,t:1526930429752};\\\", \\\"{x:1074,y:812,t:1526930429768};\\\", \\\"{x:1079,y:812,t:1526930429785};\\\", \\\"{x:1080,y:812,t:1526930429802};\\\", \\\"{x:1081,y:812,t:1526930429898};\\\", \\\"{x:1081,y:811,t:1526930429954};\\\", \\\"{x:1081,y:810,t:1526930430010};\\\", \\\"{x:1081,y:809,t:1526930430194};\\\", \\\"{x:1081,y:808,t:1526930430242};\\\", \\\"{x:1081,y:807,t:1526930430290};\\\", \\\"{x:1081,y:806,t:1526930430352};\\\", \\\"{x:1081,y:805,t:1526930430376};\\\", \\\"{x:1081,y:804,t:1526930430471};\\\" ] }, { \\\"rt\\\": 34078, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 814442, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -03 PM-O -04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1080,y:803,t:1526930431385};\\\", \\\"{x:1053,y:803,t:1526930431401};\\\", \\\"{x:997,y:803,t:1526930431418};\\\", \\\"{x:913,y:801,t:1526930431434};\\\", \\\"{x:813,y:801,t:1526930431451};\\\", \\\"{x:712,y:797,t:1526930431467};\\\", \\\"{x:621,y:797,t:1526930431484};\\\", \\\"{x:540,y:797,t:1526930431501};\\\", \\\"{x:478,y:798,t:1526930431518};\\\", \\\"{x:434,y:798,t:1526930431534};\\\", \\\"{x:396,y:798,t:1526930431552};\\\", \\\"{x:386,y:797,t:1526930431568};\\\", \\\"{x:386,y:796,t:1526930431632};\\\", \\\"{x:385,y:795,t:1526930431639};\\\", \\\"{x:384,y:793,t:1526930431650};\\\", \\\"{x:383,y:785,t:1526930431668};\\\", \\\"{x:382,y:777,t:1526930431685};\\\", \\\"{x:382,y:768,t:1526930431701};\\\", \\\"{x:383,y:759,t:1526930431718};\\\", \\\"{x:400,y:741,t:1526930431734};\\\", \\\"{x:426,y:730,t:1526930431751};\\\", \\\"{x:458,y:717,t:1526930431768};\\\", \\\"{x:496,y:704,t:1526930431785};\\\", \\\"{x:544,y:695,t:1526930431801};\\\", \\\"{x:599,y:689,t:1526930431818};\\\", \\\"{x:647,y:682,t:1526930431835};\\\", \\\"{x:701,y:679,t:1526930431851};\\\", \\\"{x:764,y:672,t:1526930431868};\\\", \\\"{x:829,y:671,t:1526930431885};\\\", \\\"{x:903,y:665,t:1526930431901};\\\", \\\"{x:975,y:657,t:1526930431918};\\\", \\\"{x:1048,y:655,t:1526930431935};\\\", \\\"{x:1071,y:655,t:1526930431952};\\\", \\\"{x:1090,y:655,t:1526930431968};\\\", \\\"{x:1107,y:655,t:1526930431985};\\\", \\\"{x:1122,y:655,t:1526930432002};\\\", \\\"{x:1138,y:655,t:1526930432019};\\\", \\\"{x:1160,y:658,t:1526930432036};\\\", \\\"{x:1186,y:663,t:1526930432051};\\\", \\\"{x:1215,y:669,t:1526930432068};\\\", \\\"{x:1244,y:675,t:1526930432085};\\\", \\\"{x:1271,y:681,t:1526930432102};\\\", \\\"{x:1298,y:686,t:1526930432118};\\\", \\\"{x:1332,y:697,t:1526930432136};\\\", \\\"{x:1356,y:703,t:1526930432152};\\\", \\\"{x:1381,y:710,t:1526930432169};\\\", \\\"{x:1402,y:716,t:1526930432186};\\\", \\\"{x:1427,y:723,t:1526930432203};\\\", \\\"{x:1449,y:727,t:1526930432218};\\\", \\\"{x:1473,y:734,t:1526930432235};\\\", \\\"{x:1499,y:743,t:1526930432252};\\\", \\\"{x:1522,y:750,t:1526930432269};\\\", \\\"{x:1545,y:757,t:1526930432286};\\\", \\\"{x:1569,y:766,t:1526930432303};\\\", \\\"{x:1588,y:772,t:1526930432319};\\\", \\\"{x:1607,y:781,t:1526930432335};\\\", \\\"{x:1623,y:789,t:1526930432352};\\\", \\\"{x:1633,y:796,t:1526930432369};\\\", \\\"{x:1645,y:803,t:1526930432386};\\\", \\\"{x:1659,y:812,t:1526930432402};\\\", \\\"{x:1671,y:823,t:1526930432418};\\\", \\\"{x:1683,y:833,t:1526930432438};\\\", \\\"{x:1698,y:844,t:1526930432452};\\\", \\\"{x:1708,y:853,t:1526930432468};\\\", \\\"{x:1715,y:861,t:1526930432485};\\\", \\\"{x:1721,y:867,t:1526930432502};\\\", \\\"{x:1724,y:871,t:1526930432518};\\\", \\\"{x:1727,y:880,t:1526930432535};\\\", \\\"{x:1728,y:886,t:1526930432552};\\\", \\\"{x:1731,y:896,t:1526930432568};\\\", \\\"{x:1732,y:909,t:1526930432585};\\\", \\\"{x:1732,y:924,t:1526930432602};\\\", \\\"{x:1732,y:940,t:1526930432619};\\\", \\\"{x:1726,y:956,t:1526930432635};\\\", \\\"{x:1718,y:970,t:1526930432652};\\\", \\\"{x:1706,y:982,t:1526930432669};\\\", \\\"{x:1693,y:990,t:1526930432685};\\\", \\\"{x:1680,y:995,t:1526930432702};\\\", \\\"{x:1660,y:999,t:1526930432719};\\\", \\\"{x:1646,y:1000,t:1526930432735};\\\", \\\"{x:1629,y:1000,t:1526930432753};\\\", \\\"{x:1615,y:1000,t:1526930432770};\\\", \\\"{x:1604,y:1000,t:1526930432786};\\\", \\\"{x:1596,y:1000,t:1526930432803};\\\", \\\"{x:1588,y:1000,t:1526930432820};\\\", \\\"{x:1579,y:998,t:1526930432835};\\\", \\\"{x:1574,y:997,t:1526930432852};\\\", \\\"{x:1571,y:994,t:1526930432870};\\\", \\\"{x:1571,y:993,t:1526930432885};\\\", \\\"{x:1569,y:991,t:1526930432902};\\\", \\\"{x:1569,y:989,t:1526930432920};\\\", \\\"{x:1568,y:985,t:1526930432935};\\\", \\\"{x:1568,y:983,t:1526930432953};\\\", \\\"{x:1567,y:981,t:1526930432969};\\\", \\\"{x:1567,y:979,t:1526930432992};\\\", \\\"{x:1567,y:978,t:1526930433016};\\\", \\\"{x:1567,y:976,t:1526930433056};\\\", \\\"{x:1567,y:975,t:1526930433095};\\\", \\\"{x:1567,y:973,t:1526930433112};\\\", \\\"{x:1566,y:971,t:1526930433120};\\\", \\\"{x:1565,y:971,t:1526930433136};\\\", \\\"{x:1563,y:969,t:1526930433152};\\\", \\\"{x:1562,y:967,t:1526930433170};\\\", \\\"{x:1560,y:966,t:1526930433187};\\\", \\\"{x:1559,y:965,t:1526930433202};\\\", \\\"{x:1558,y:965,t:1526930433220};\\\", \\\"{x:1557,y:964,t:1526930433240};\\\", \\\"{x:1555,y:963,t:1526930433272};\\\", \\\"{x:1555,y:962,t:1526930433296};\\\", \\\"{x:1554,y:962,t:1526930433312};\\\", \\\"{x:1553,y:961,t:1526930433327};\\\", \\\"{x:1552,y:960,t:1526930433376};\\\", \\\"{x:1552,y:959,t:1526930433392};\\\", \\\"{x:1551,y:959,t:1526930433440};\\\", \\\"{x:1550,y:959,t:1526930433480};\\\", \\\"{x:1549,y:958,t:1526930433488};\\\", \\\"{x:1548,y:958,t:1526930433559};\\\", \\\"{x:1547,y:958,t:1526930433575};\\\", \\\"{x:1546,y:958,t:1526930433647};\\\", \\\"{x:1545,y:958,t:1526930433792};\\\", \\\"{x:1544,y:958,t:1526930433848};\\\", \\\"{x:1544,y:959,t:1526930433856};\\\", \\\"{x:1544,y:960,t:1526930433870};\\\", \\\"{x:1544,y:961,t:1526930433896};\\\", \\\"{x:1544,y:962,t:1526930433928};\\\", \\\"{x:1544,y:963,t:1526930433952};\\\", \\\"{x:1545,y:964,t:1526930434016};\\\", \\\"{x:1544,y:962,t:1526930434216};\\\", \\\"{x:1541,y:958,t:1526930434224};\\\", \\\"{x:1537,y:951,t:1526930434237};\\\", \\\"{x:1533,y:945,t:1526930434254};\\\", \\\"{x:1529,y:937,t:1526930434270};\\\", \\\"{x:1527,y:930,t:1526930434286};\\\", \\\"{x:1520,y:915,t:1526930434303};\\\", \\\"{x:1516,y:908,t:1526930434320};\\\", \\\"{x:1515,y:903,t:1526930434337};\\\", \\\"{x:1513,y:899,t:1526930434354};\\\", \\\"{x:1511,y:894,t:1526930434370};\\\", \\\"{x:1510,y:889,t:1526930434386};\\\", \\\"{x:1510,y:886,t:1526930434403};\\\", \\\"{x:1510,y:882,t:1526930434420};\\\", \\\"{x:1510,y:877,t:1526930434436};\\\", \\\"{x:1510,y:872,t:1526930434453};\\\", \\\"{x:1510,y:867,t:1526930434470};\\\", \\\"{x:1510,y:862,t:1526930434486};\\\", \\\"{x:1513,y:856,t:1526930434503};\\\", \\\"{x:1517,y:851,t:1526930434520};\\\", \\\"{x:1520,y:849,t:1526930434537};\\\", \\\"{x:1524,y:845,t:1526930434553};\\\", \\\"{x:1527,y:843,t:1526930434570};\\\", \\\"{x:1530,y:840,t:1526930434588};\\\", \\\"{x:1531,y:840,t:1526930434603};\\\", \\\"{x:1533,y:839,t:1526930434621};\\\", \\\"{x:1534,y:838,t:1526930434638};\\\", \\\"{x:1535,y:837,t:1526930434664};\\\", \\\"{x:1537,y:836,t:1526930434688};\\\", \\\"{x:1538,y:836,t:1526930434712};\\\", \\\"{x:1539,y:836,t:1526930434727};\\\", \\\"{x:1541,y:836,t:1526930434743};\\\", \\\"{x:1543,y:836,t:1526930434759};\\\", \\\"{x:1544,y:836,t:1526930434784};\\\", \\\"{x:1545,y:836,t:1526930434816};\\\", \\\"{x:1546,y:836,t:1526930434832};\\\", \\\"{x:1547,y:836,t:1526930434840};\\\", \\\"{x:1548,y:836,t:1526930434904};\\\", \\\"{x:1549,y:836,t:1526930434921};\\\", \\\"{x:1550,y:836,t:1526930434944};\\\", \\\"{x:1550,y:837,t:1526930434976};\\\", \\\"{x:1550,y:838,t:1526930434992};\\\", \\\"{x:1550,y:839,t:1526930435008};\\\", \\\"{x:1550,y:842,t:1526930435048};\\\", \\\"{x:1551,y:843,t:1526930435088};\\\", \\\"{x:1551,y:844,t:1526930435111};\\\", \\\"{x:1551,y:845,t:1526930435152};\\\", \\\"{x:1551,y:847,t:1526930435184};\\\", \\\"{x:1552,y:847,t:1526930435288};\\\", \\\"{x:1552,y:846,t:1526930435656};\\\", \\\"{x:1552,y:845,t:1526930435816};\\\", \\\"{x:1552,y:844,t:1526930435823};\\\", \\\"{x:1552,y:843,t:1526930435840};\\\", \\\"{x:1552,y:841,t:1526930435855};\\\", \\\"{x:1552,y:840,t:1526930435872};\\\", \\\"{x:1552,y:838,t:1526930435945};\\\", \\\"{x:1552,y:837,t:1526930438457};\\\", \\\"{x:1550,y:834,t:1526930438474};\\\", \\\"{x:1550,y:833,t:1526930438504};\\\", \\\"{x:1549,y:833,t:1526930438512};\\\", \\\"{x:1549,y:832,t:1526930438524};\\\", \\\"{x:1549,y:830,t:1526930438552};\\\", \\\"{x:1548,y:830,t:1526930438585};\\\", \\\"{x:1548,y:829,t:1526930438607};\\\", \\\"{x:1548,y:830,t:1526930439280};\\\", \\\"{x:1548,y:831,t:1526930439304};\\\", \\\"{x:1548,y:832,t:1526930439328};\\\", \\\"{x:1548,y:831,t:1526930443360};\\\", \\\"{x:1547,y:830,t:1526930443383};\\\", \\\"{x:1547,y:829,t:1526930443400};\\\", \\\"{x:1546,y:828,t:1526930443416};\\\", \\\"{x:1546,y:827,t:1526930443505};\\\", \\\"{x:1546,y:825,t:1526930444056};\\\", \\\"{x:1546,y:822,t:1526930444063};\\\", \\\"{x:1546,y:820,t:1526930444078};\\\", \\\"{x:1545,y:815,t:1526930444094};\\\", \\\"{x:1543,y:808,t:1526930444111};\\\", \\\"{x:1543,y:802,t:1526930444127};\\\", \\\"{x:1541,y:798,t:1526930444144};\\\", \\\"{x:1541,y:796,t:1526930444161};\\\", \\\"{x:1540,y:793,t:1526930444178};\\\", \\\"{x:1539,y:791,t:1526930444195};\\\", \\\"{x:1539,y:787,t:1526930444211};\\\", \\\"{x:1539,y:784,t:1526930444228};\\\", \\\"{x:1539,y:781,t:1526930444244};\\\", \\\"{x:1539,y:778,t:1526930444261};\\\", \\\"{x:1539,y:775,t:1526930444278};\\\", \\\"{x:1539,y:772,t:1526930444294};\\\", \\\"{x:1539,y:769,t:1526930444311};\\\", \\\"{x:1539,y:766,t:1526930444327};\\\", \\\"{x:1539,y:765,t:1526930444344};\\\", \\\"{x:1539,y:764,t:1526930444361};\\\", \\\"{x:1539,y:763,t:1526930444378};\\\", \\\"{x:1539,y:762,t:1526930444394};\\\", \\\"{x:1539,y:761,t:1526930444415};\\\", \\\"{x:1540,y:760,t:1526930444439};\\\", \\\"{x:1542,y:760,t:1526930444480};\\\", \\\"{x:1542,y:759,t:1526930445992};\\\", \\\"{x:1535,y:759,t:1526930445999};\\\", \\\"{x:1524,y:761,t:1526930446012};\\\", \\\"{x:1502,y:765,t:1526930446029};\\\", \\\"{x:1476,y:769,t:1526930446047};\\\", \\\"{x:1452,y:770,t:1526930446062};\\\", \\\"{x:1433,y:772,t:1526930446080};\\\", \\\"{x:1429,y:774,t:1526930446095};\\\", \\\"{x:1428,y:774,t:1526930446168};\\\", \\\"{x:1427,y:774,t:1526930446184};\\\", \\\"{x:1426,y:774,t:1526930446197};\\\", \\\"{x:1424,y:774,t:1526930446213};\\\", \\\"{x:1422,y:774,t:1526930446229};\\\", \\\"{x:1421,y:774,t:1526930446246};\\\", \\\"{x:1420,y:774,t:1526930446262};\\\", \\\"{x:1419,y:774,t:1526930446279};\\\", \\\"{x:1417,y:773,t:1526930446295};\\\", \\\"{x:1416,y:772,t:1526930446328};\\\", \\\"{x:1415,y:770,t:1526930446368};\\\", \\\"{x:1415,y:769,t:1526930446399};\\\", \\\"{x:1414,y:768,t:1526930446413};\\\", \\\"{x:1414,y:767,t:1526930446447};\\\", \\\"{x:1414,y:766,t:1526930446472};\\\", \\\"{x:1414,y:765,t:1526930446480};\\\", \\\"{x:1413,y:765,t:1526930446496};\\\", \\\"{x:1413,y:764,t:1526930446536};\\\", \\\"{x:1413,y:763,t:1526930446560};\\\", \\\"{x:1412,y:762,t:1526930446568};\\\", \\\"{x:1415,y:763,t:1526930446760};\\\", \\\"{x:1421,y:764,t:1526930446768};\\\", \\\"{x:1427,y:766,t:1526930446779};\\\", \\\"{x:1441,y:768,t:1526930446796};\\\", \\\"{x:1455,y:771,t:1526930446813};\\\", \\\"{x:1465,y:771,t:1526930446830};\\\", \\\"{x:1471,y:771,t:1526930446846};\\\", \\\"{x:1473,y:771,t:1526930446863};\\\", \\\"{x:1475,y:771,t:1526930446896};\\\", \\\"{x:1476,y:771,t:1526930446913};\\\", \\\"{x:1476,y:770,t:1526930446930};\\\", \\\"{x:1478,y:769,t:1526930446946};\\\", \\\"{x:1478,y:768,t:1526930446963};\\\", \\\"{x:1479,y:768,t:1526930446980};\\\", \\\"{x:1480,y:766,t:1526930446996};\\\", \\\"{x:1480,y:765,t:1526930447023};\\\", \\\"{x:1481,y:765,t:1526930447032};\\\", \\\"{x:1481,y:763,t:1526930447072};\\\", \\\"{x:1481,y:762,t:1526930447096};\\\", \\\"{x:1481,y:760,t:1526930447208};\\\", \\\"{x:1482,y:760,t:1526930447408};\\\", \\\"{x:1483,y:760,t:1526930447440};\\\", \\\"{x:1485,y:760,t:1526930447447};\\\", \\\"{x:1486,y:761,t:1526930447462};\\\", \\\"{x:1488,y:763,t:1526930447479};\\\", \\\"{x:1489,y:764,t:1526930447496};\\\", \\\"{x:1493,y:766,t:1526930447512};\\\", \\\"{x:1497,y:768,t:1526930447529};\\\", \\\"{x:1499,y:768,t:1526930447546};\\\", \\\"{x:1500,y:768,t:1526930447562};\\\", \\\"{x:1502,y:769,t:1526930447579};\\\", \\\"{x:1505,y:769,t:1526930447597};\\\", \\\"{x:1508,y:769,t:1526930447613};\\\", \\\"{x:1512,y:769,t:1526930447630};\\\", \\\"{x:1520,y:770,t:1526930447647};\\\", \\\"{x:1525,y:770,t:1526930447663};\\\", \\\"{x:1528,y:770,t:1526930447680};\\\", \\\"{x:1529,y:770,t:1526930447697};\\\", \\\"{x:1531,y:770,t:1526930447714};\\\", \\\"{x:1533,y:770,t:1526930447735};\\\", \\\"{x:1534,y:770,t:1526930447784};\\\", \\\"{x:1536,y:770,t:1526930447800};\\\", \\\"{x:1537,y:770,t:1526930447824};\\\", \\\"{x:1538,y:770,t:1526930447855};\\\", \\\"{x:1539,y:770,t:1526930447863};\\\", \\\"{x:1540,y:769,t:1526930447880};\\\", \\\"{x:1540,y:768,t:1526930447903};\\\", \\\"{x:1541,y:767,t:1526930447927};\\\", \\\"{x:1541,y:766,t:1526930447992};\\\", \\\"{x:1542,y:766,t:1526930448024};\\\", \\\"{x:1542,y:765,t:1526930448032};\\\", \\\"{x:1543,y:764,t:1526930448047};\\\", \\\"{x:1544,y:763,t:1526930448079};\\\", \\\"{x:1545,y:763,t:1526930448103};\\\", \\\"{x:1546,y:762,t:1526930448119};\\\", \\\"{x:1546,y:761,t:1526930448130};\\\", \\\"{x:1547,y:761,t:1526930448146};\\\", \\\"{x:1547,y:760,t:1526930448163};\\\", \\\"{x:1548,y:760,t:1526930448180};\\\", \\\"{x:1549,y:759,t:1526930448196};\\\", \\\"{x:1549,y:758,t:1526930448215};\\\", \\\"{x:1545,y:758,t:1526930449896};\\\", \\\"{x:1514,y:758,t:1526930449904};\\\", \\\"{x:1469,y:756,t:1526930449916};\\\", \\\"{x:1331,y:737,t:1526930449933};\\\", \\\"{x:1173,y:715,t:1526930449948};\\\", \\\"{x:998,y:688,t:1526930449965};\\\", \\\"{x:827,y:661,t:1526930449982};\\\", \\\"{x:686,y:644,t:1526930449998};\\\", \\\"{x:515,y:618,t:1526930450017};\\\", \\\"{x:443,y:607,t:1526930450032};\\\", \\\"{x:417,y:604,t:1526930450047};\\\", \\\"{x:402,y:601,t:1526930450065};\\\", \\\"{x:401,y:601,t:1526930450083};\\\", \\\"{x:401,y:600,t:1526930450118};\\\", \\\"{x:401,y:598,t:1526930450134};\\\", \\\"{x:401,y:595,t:1526930450150};\\\", \\\"{x:410,y:581,t:1526930450167};\\\", \\\"{x:420,y:571,t:1526930450183};\\\", \\\"{x:428,y:562,t:1526930450200};\\\", \\\"{x:429,y:559,t:1526930450216};\\\", \\\"{x:429,y:555,t:1526930450233};\\\", \\\"{x:429,y:553,t:1526930450249};\\\", \\\"{x:426,y:551,t:1526930450265};\\\", \\\"{x:421,y:546,t:1526930450283};\\\", \\\"{x:410,y:539,t:1526930450300};\\\", \\\"{x:394,y:531,t:1526930450316};\\\", \\\"{x:372,y:525,t:1526930450333};\\\", \\\"{x:354,y:521,t:1526930450350};\\\", \\\"{x:329,y:520,t:1526930450367};\\\", \\\"{x:310,y:520,t:1526930450382};\\\", \\\"{x:291,y:520,t:1526930450400};\\\", \\\"{x:265,y:520,t:1526930450417};\\\", \\\"{x:234,y:524,t:1526930450433};\\\", \\\"{x:205,y:528,t:1526930450451};\\\", \\\"{x:180,y:530,t:1526930450467};\\\", \\\"{x:156,y:535,t:1526930450482};\\\", \\\"{x:136,y:536,t:1526930450500};\\\", \\\"{x:124,y:536,t:1526930450515};\\\", \\\"{x:115,y:536,t:1526930450533};\\\", \\\"{x:111,y:536,t:1526930450550};\\\", \\\"{x:113,y:536,t:1526930450702};\\\", \\\"{x:115,y:536,t:1526930450717};\\\", \\\"{x:122,y:536,t:1526930450733};\\\", \\\"{x:126,y:536,t:1526930450749};\\\", \\\"{x:136,y:536,t:1526930450766};\\\", \\\"{x:139,y:536,t:1526930450783};\\\", \\\"{x:141,y:536,t:1526930450800};\\\", \\\"{x:143,y:536,t:1526930450816};\\\", \\\"{x:144,y:536,t:1526930450839};\\\", \\\"{x:146,y:536,t:1526930450849};\\\", \\\"{x:147,y:536,t:1526930450867};\\\", \\\"{x:150,y:536,t:1526930450885};\\\", \\\"{x:153,y:535,t:1526930450899};\\\", \\\"{x:154,y:535,t:1526930450917};\\\", \\\"{x:156,y:535,t:1526930450933};\\\", \\\"{x:157,y:535,t:1526930450968};\\\", \\\"{x:157,y:534,t:1526930450983};\\\", \\\"{x:159,y:534,t:1526930451335};\\\", \\\"{x:161,y:534,t:1526930451350};\\\", \\\"{x:168,y:531,t:1526930451367};\\\", \\\"{x:174,y:530,t:1526930451384};\\\", \\\"{x:183,y:530,t:1526930451401};\\\", \\\"{x:194,y:530,t:1526930451418};\\\", \\\"{x:207,y:530,t:1526930451433};\\\", \\\"{x:225,y:530,t:1526930451451};\\\", \\\"{x:247,y:530,t:1526930451466};\\\", \\\"{x:266,y:530,t:1526930451484};\\\", \\\"{x:284,y:530,t:1526930451501};\\\", \\\"{x:303,y:526,t:1526930451518};\\\", \\\"{x:321,y:525,t:1526930451534};\\\", \\\"{x:347,y:525,t:1526930451551};\\\", \\\"{x:362,y:525,t:1526930451566};\\\", \\\"{x:376,y:525,t:1526930451584};\\\", \\\"{x:389,y:525,t:1526930451600};\\\", \\\"{x:404,y:525,t:1526930451617};\\\", \\\"{x:421,y:525,t:1526930451634};\\\", \\\"{x:443,y:525,t:1526930451651};\\\", \\\"{x:470,y:525,t:1526930451667};\\\", \\\"{x:504,y:525,t:1526930451684};\\\", \\\"{x:548,y:525,t:1526930451700};\\\", \\\"{x:599,y:525,t:1526930451717};\\\", \\\"{x:659,y:529,t:1526930451734};\\\", \\\"{x:805,y:551,t:1526930451752};\\\", \\\"{x:930,y:569,t:1526930451769};\\\", \\\"{x:1054,y:582,t:1526930451784};\\\", \\\"{x:1179,y:600,t:1526930451801};\\\", \\\"{x:1288,y:621,t:1526930451817};\\\", \\\"{x:1388,y:638,t:1526930451834};\\\", \\\"{x:1461,y:653,t:1526930451851};\\\", \\\"{x:1516,y:672,t:1526930451868};\\\", \\\"{x:1549,y:681,t:1526930451884};\\\", \\\"{x:1566,y:688,t:1526930451901};\\\", \\\"{x:1578,y:692,t:1526930451918};\\\", \\\"{x:1583,y:692,t:1526930451934};\\\", \\\"{x:1584,y:694,t:1526930451951};\\\", \\\"{x:1585,y:694,t:1526930451975};\\\", \\\"{x:1585,y:695,t:1526930451992};\\\", \\\"{x:1587,y:697,t:1526930452008};\\\", \\\"{x:1589,y:698,t:1526930452023};\\\", \\\"{x:1589,y:699,t:1526930452034};\\\", \\\"{x:1589,y:703,t:1526930452051};\\\", \\\"{x:1589,y:706,t:1526930452068};\\\", \\\"{x:1588,y:712,t:1526930452084};\\\", \\\"{x:1580,y:717,t:1526930452101};\\\", \\\"{x:1560,y:723,t:1526930452118};\\\", \\\"{x:1525,y:729,t:1526930452135};\\\", \\\"{x:1506,y:733,t:1526930452151};\\\", \\\"{x:1493,y:734,t:1526930452168};\\\", \\\"{x:1488,y:735,t:1526930452186};\\\", \\\"{x:1487,y:735,t:1526930452272};\\\", \\\"{x:1486,y:734,t:1526930452285};\\\", \\\"{x:1486,y:732,t:1526930452301};\\\", \\\"{x:1487,y:730,t:1526930452318};\\\", \\\"{x:1492,y:726,t:1526930452335};\\\", \\\"{x:1498,y:723,t:1526930452351};\\\", \\\"{x:1506,y:722,t:1526930452368};\\\", \\\"{x:1514,y:722,t:1526930452385};\\\", \\\"{x:1525,y:722,t:1526930452401};\\\", \\\"{x:1536,y:722,t:1526930452419};\\\", \\\"{x:1547,y:724,t:1526930452435};\\\", \\\"{x:1555,y:729,t:1526930452451};\\\", \\\"{x:1562,y:734,t:1526930452469};\\\", \\\"{x:1570,y:739,t:1526930452485};\\\", \\\"{x:1578,y:751,t:1526930452502};\\\", \\\"{x:1589,y:767,t:1526930452518};\\\", \\\"{x:1612,y:808,t:1526930452536};\\\", \\\"{x:1623,y:831,t:1526930452551};\\\", \\\"{x:1631,y:851,t:1526930452569};\\\", \\\"{x:1637,y:867,t:1526930452585};\\\", \\\"{x:1639,y:880,t:1526930452601};\\\", \\\"{x:1639,y:889,t:1526930452619};\\\", \\\"{x:1639,y:897,t:1526930452635};\\\", \\\"{x:1639,y:904,t:1526930452651};\\\", \\\"{x:1636,y:913,t:1526930452668};\\\", \\\"{x:1633,y:922,t:1526930452685};\\\", \\\"{x:1632,y:931,t:1526930452702};\\\", \\\"{x:1629,y:938,t:1526930452718};\\\", \\\"{x:1623,y:951,t:1526930452736};\\\", \\\"{x:1622,y:958,t:1526930452752};\\\", \\\"{x:1618,y:967,t:1526930452768};\\\", \\\"{x:1614,y:975,t:1526930452786};\\\", \\\"{x:1610,y:983,t:1526930452803};\\\", \\\"{x:1607,y:988,t:1526930452818};\\\", \\\"{x:1603,y:993,t:1526930452835};\\\", \\\"{x:1602,y:994,t:1526930452852};\\\", \\\"{x:1598,y:996,t:1526930452869};\\\", \\\"{x:1594,y:998,t:1526930452886};\\\", \\\"{x:1590,y:999,t:1526930452902};\\\", \\\"{x:1583,y:1001,t:1526930452918};\\\", \\\"{x:1571,y:1002,t:1526930452935};\\\", \\\"{x:1567,y:1002,t:1526930452952};\\\", \\\"{x:1564,y:1001,t:1526930452969};\\\", \\\"{x:1561,y:999,t:1526930452986};\\\", \\\"{x:1559,y:995,t:1526930453002};\\\", \\\"{x:1555,y:992,t:1526930453019};\\\", \\\"{x:1552,y:988,t:1526930453035};\\\", \\\"{x:1551,y:984,t:1526930453052};\\\", \\\"{x:1549,y:981,t:1526930453069};\\\", \\\"{x:1548,y:977,t:1526930453085};\\\", \\\"{x:1547,y:972,t:1526930453103};\\\", \\\"{x:1546,y:971,t:1526930453118};\\\", \\\"{x:1545,y:965,t:1526930453135};\\\", \\\"{x:1545,y:961,t:1526930453153};\\\", \\\"{x:1544,y:957,t:1526930453168};\\\", \\\"{x:1541,y:952,t:1526930453185};\\\", \\\"{x:1538,y:949,t:1526930453203};\\\", \\\"{x:1536,y:945,t:1526930453218};\\\", \\\"{x:1534,y:941,t:1526930453235};\\\", \\\"{x:1533,y:939,t:1526930453253};\\\", \\\"{x:1532,y:933,t:1526930453269};\\\", \\\"{x:1530,y:927,t:1526930453285};\\\", \\\"{x:1529,y:921,t:1526930453303};\\\", \\\"{x:1528,y:912,t:1526930453319};\\\", \\\"{x:1528,y:906,t:1526930453335};\\\", \\\"{x:1526,y:898,t:1526930453353};\\\", \\\"{x:1525,y:890,t:1526930453369};\\\", \\\"{x:1525,y:883,t:1526930453385};\\\", \\\"{x:1524,y:875,t:1526930453403};\\\", \\\"{x:1524,y:869,t:1526930453419};\\\", \\\"{x:1524,y:863,t:1526930453436};\\\", \\\"{x:1524,y:858,t:1526930453453};\\\", \\\"{x:1524,y:854,t:1526930453469};\\\", \\\"{x:1524,y:848,t:1526930453485};\\\", \\\"{x:1524,y:844,t:1526930453502};\\\", \\\"{x:1524,y:836,t:1526930453519};\\\", \\\"{x:1524,y:829,t:1526930453536};\\\", \\\"{x:1524,y:824,t:1526930453552};\\\", \\\"{x:1524,y:818,t:1526930453570};\\\", \\\"{x:1524,y:814,t:1526930453585};\\\", \\\"{x:1524,y:812,t:1526930453603};\\\", \\\"{x:1524,y:811,t:1526930453620};\\\", \\\"{x:1524,y:810,t:1526930453712};\\\", \\\"{x:1526,y:810,t:1526930453735};\\\", \\\"{x:1529,y:819,t:1526930453753};\\\", \\\"{x:1532,y:831,t:1526930453769};\\\", \\\"{x:1535,y:848,t:1526930453787};\\\", \\\"{x:1536,y:862,t:1526930453802};\\\", \\\"{x:1540,y:879,t:1526930453819};\\\", \\\"{x:1542,y:897,t:1526930453837};\\\", \\\"{x:1542,y:908,t:1526930453852};\\\", \\\"{x:1542,y:919,t:1526930453869};\\\", \\\"{x:1542,y:929,t:1526930453887};\\\", \\\"{x:1542,y:937,t:1526930453902};\\\", \\\"{x:1542,y:948,t:1526930453919};\\\", \\\"{x:1542,y:952,t:1526930453936};\\\", \\\"{x:1542,y:956,t:1526930453953};\\\", \\\"{x:1542,y:961,t:1526930453969};\\\", \\\"{x:1542,y:963,t:1526930453986};\\\", \\\"{x:1542,y:964,t:1526930454014};\\\", \\\"{x:1541,y:963,t:1526930454127};\\\", \\\"{x:1541,y:961,t:1526930454135};\\\", \\\"{x:1538,y:954,t:1526930454151};\\\", \\\"{x:1537,y:948,t:1526930454169};\\\", \\\"{x:1535,y:941,t:1526930454186};\\\", \\\"{x:1535,y:936,t:1526930454202};\\\", \\\"{x:1533,y:932,t:1526930454218};\\\", \\\"{x:1533,y:927,t:1526930454236};\\\", \\\"{x:1533,y:921,t:1526930454252};\\\", \\\"{x:1532,y:919,t:1526930454269};\\\", \\\"{x:1532,y:915,t:1526930454286};\\\", \\\"{x:1532,y:911,t:1526930454302};\\\", \\\"{x:1532,y:904,t:1526930454319};\\\", \\\"{x:1532,y:898,t:1526930454336};\\\", \\\"{x:1532,y:892,t:1526930454352};\\\", \\\"{x:1532,y:887,t:1526930454369};\\\", \\\"{x:1532,y:880,t:1526930454386};\\\", \\\"{x:1532,y:874,t:1526930454403};\\\", \\\"{x:1532,y:870,t:1526930454419};\\\", \\\"{x:1533,y:864,t:1526930454437};\\\", \\\"{x:1534,y:857,t:1526930454452};\\\", \\\"{x:1537,y:853,t:1526930454470};\\\", \\\"{x:1539,y:847,t:1526930454487};\\\", \\\"{x:1540,y:843,t:1526930454504};\\\", \\\"{x:1541,y:842,t:1526930454519};\\\", \\\"{x:1542,y:838,t:1526930454537};\\\", \\\"{x:1542,y:837,t:1526930454575};\\\", \\\"{x:1542,y:836,t:1526930454615};\\\", \\\"{x:1542,y:835,t:1526930454624};\\\", \\\"{x:1544,y:834,t:1526930454655};\\\", \\\"{x:1544,y:833,t:1526930454669};\\\", \\\"{x:1545,y:832,t:1526930454696};\\\", \\\"{x:1546,y:832,t:1526930454808};\\\", \\\"{x:1547,y:832,t:1526930454823};\\\", \\\"{x:1547,y:831,t:1526930454837};\\\", \\\"{x:1548,y:827,t:1526930454854};\\\", \\\"{x:1550,y:822,t:1526930454869};\\\", \\\"{x:1553,y:813,t:1526930454886};\\\", \\\"{x:1556,y:795,t:1526930454903};\\\", \\\"{x:1556,y:786,t:1526930454920};\\\", \\\"{x:1556,y:781,t:1526930454936};\\\", \\\"{x:1555,y:772,t:1526930454953};\\\", \\\"{x:1554,y:763,t:1526930454970};\\\", \\\"{x:1554,y:755,t:1526930454986};\\\", \\\"{x:1554,y:749,t:1526930455003};\\\", \\\"{x:1554,y:743,t:1526930455020};\\\", \\\"{x:1554,y:737,t:1526930455036};\\\", \\\"{x:1554,y:733,t:1526930455053};\\\", \\\"{x:1554,y:729,t:1526930455069};\\\", \\\"{x:1554,y:726,t:1526930455087};\\\", \\\"{x:1555,y:722,t:1526930455104};\\\", \\\"{x:1555,y:719,t:1526930455120};\\\", \\\"{x:1555,y:718,t:1526930455137};\\\", \\\"{x:1555,y:716,t:1526930455154};\\\", \\\"{x:1555,y:715,t:1526930455170};\\\", \\\"{x:1555,y:713,t:1526930455186};\\\", \\\"{x:1555,y:712,t:1526930455204};\\\", \\\"{x:1555,y:710,t:1526930455220};\\\", \\\"{x:1555,y:709,t:1526930455237};\\\", \\\"{x:1555,y:708,t:1526930455253};\\\", \\\"{x:1554,y:707,t:1526930455270};\\\", \\\"{x:1554,y:706,t:1526930455295};\\\", \\\"{x:1553,y:706,t:1526930455304};\\\", \\\"{x:1553,y:705,t:1526930455321};\\\", \\\"{x:1552,y:704,t:1526930455351};\\\", \\\"{x:1552,y:703,t:1526930455504};\\\", \\\"{x:1551,y:703,t:1526930455527};\\\", \\\"{x:1550,y:701,t:1526930455568};\\\", \\\"{x:1550,y:700,t:1526930455632};\\\", \\\"{x:1550,y:698,t:1526930455672};\\\", \\\"{x:1550,y:697,t:1526930455720};\\\", \\\"{x:1549,y:696,t:1526930455744};\\\", \\\"{x:1549,y:695,t:1526930455754};\\\", \\\"{x:1549,y:694,t:1526930455807};\\\", \\\"{x:1548,y:692,t:1526930455856};\\\", \\\"{x:1547,y:692,t:1526930455952};\\\", \\\"{x:1546,y:691,t:1526930455984};\\\", \\\"{x:1545,y:691,t:1526930460360};\\\", \\\"{x:1544,y:691,t:1526930460374};\\\", \\\"{x:1543,y:689,t:1526930460389};\\\", \\\"{x:1543,y:687,t:1526930460406};\\\", \\\"{x:1540,y:682,t:1526930460423};\\\", \\\"{x:1539,y:676,t:1526930460440};\\\", \\\"{x:1539,y:673,t:1526930460456};\\\", \\\"{x:1538,y:668,t:1526930460473};\\\", \\\"{x:1536,y:662,t:1526930460489};\\\", \\\"{x:1535,y:656,t:1526930460506};\\\", \\\"{x:1534,y:646,t:1526930460523};\\\", \\\"{x:1532,y:640,t:1526930460540};\\\", \\\"{x:1530,y:632,t:1526930460557};\\\", \\\"{x:1530,y:628,t:1526930460573};\\\", \\\"{x:1530,y:624,t:1526930460589};\\\", \\\"{x:1529,y:620,t:1526930460606};\\\", \\\"{x:1529,y:613,t:1526930460623};\\\", \\\"{x:1529,y:607,t:1526930460639};\\\", \\\"{x:1529,y:602,t:1526930460656};\\\", \\\"{x:1529,y:598,t:1526930460674};\\\", \\\"{x:1529,y:594,t:1526930460690};\\\", \\\"{x:1529,y:590,t:1526930460706};\\\", \\\"{x:1529,y:588,t:1526930460723};\\\", \\\"{x:1529,y:587,t:1526930460741};\\\", \\\"{x:1529,y:585,t:1526930460756};\\\", \\\"{x:1529,y:583,t:1526930460774};\\\", \\\"{x:1531,y:580,t:1526930460790};\\\", \\\"{x:1533,y:577,t:1526930460807};\\\", \\\"{x:1536,y:572,t:1526930460823};\\\", \\\"{x:1538,y:570,t:1526930460841};\\\", \\\"{x:1540,y:568,t:1526930460856};\\\", \\\"{x:1541,y:566,t:1526930460873};\\\", \\\"{x:1542,y:566,t:1526930460891};\\\", \\\"{x:1542,y:565,t:1526930460911};\\\", \\\"{x:1542,y:564,t:1526930460935};\\\", \\\"{x:1543,y:564,t:1526930460959};\\\", \\\"{x:1544,y:564,t:1526930461032};\\\", \\\"{x:1545,y:564,t:1526930461040};\\\", \\\"{x:1547,y:563,t:1526930461624};\\\", \\\"{x:1548,y:562,t:1526930462256};\\\", \\\"{x:1548,y:563,t:1526930463119};\\\", \\\"{x:1548,y:564,t:1526930463128};\\\", \\\"{x:1548,y:565,t:1526930463152};\\\", \\\"{x:1548,y:566,t:1526930463159};\\\", \\\"{x:1548,y:567,t:1526930463183};\\\", \\\"{x:1548,y:568,t:1526930463232};\\\", \\\"{x:1547,y:569,t:1526930463242};\\\", \\\"{x:1547,y:570,t:1526930463264};\\\", \\\"{x:1547,y:571,t:1526930463295};\\\", \\\"{x:1547,y:572,t:1526930463309};\\\", \\\"{x:1547,y:573,t:1526930463324};\\\", \\\"{x:1547,y:574,t:1526930463342};\\\", \\\"{x:1547,y:575,t:1526930463359};\\\", \\\"{x:1547,y:576,t:1526930463375};\\\", \\\"{x:1547,y:577,t:1526930463391};\\\", \\\"{x:1547,y:578,t:1526930463415};\\\", \\\"{x:1547,y:579,t:1526930463431};\\\", \\\"{x:1547,y:580,t:1526930463464};\\\", \\\"{x:1547,y:581,t:1526930463474};\\\", \\\"{x:1547,y:582,t:1526930463492};\\\", \\\"{x:1547,y:583,t:1526930463519};\\\", \\\"{x:1547,y:584,t:1526930463528};\\\", \\\"{x:1547,y:585,t:1526930463543};\\\", \\\"{x:1547,y:586,t:1526930463559};\\\", \\\"{x:1547,y:588,t:1526930463574};\\\", \\\"{x:1547,y:590,t:1526930463591};\\\", \\\"{x:1547,y:594,t:1526930463608};\\\", \\\"{x:1547,y:597,t:1526930463624};\\\", \\\"{x:1547,y:602,t:1526930463641};\\\", \\\"{x:1547,y:607,t:1526930463658};\\\", \\\"{x:1549,y:613,t:1526930463675};\\\", \\\"{x:1550,y:621,t:1526930463691};\\\", \\\"{x:1552,y:627,t:1526930463708};\\\", \\\"{x:1553,y:633,t:1526930463725};\\\", \\\"{x:1553,y:638,t:1526930463741};\\\", \\\"{x:1553,y:644,t:1526930463758};\\\", \\\"{x:1553,y:650,t:1526930463775};\\\", \\\"{x:1552,y:657,t:1526930463791};\\\", \\\"{x:1543,y:662,t:1526930463808};\\\", \\\"{x:1520,y:669,t:1526930463825};\\\", \\\"{x:1480,y:677,t:1526930463841};\\\", \\\"{x:1407,y:689,t:1526930463858};\\\", \\\"{x:1320,y:693,t:1526930463876};\\\", \\\"{x:1226,y:703,t:1526930463891};\\\", \\\"{x:1137,y:714,t:1526930463908};\\\", \\\"{x:1048,y:727,t:1526930463925};\\\", \\\"{x:987,y:737,t:1526930463942};\\\", \\\"{x:899,y:749,t:1526930463959};\\\", \\\"{x:865,y:755,t:1526930463974};\\\", \\\"{x:837,y:766,t:1526930463992};\\\", \\\"{x:799,y:777,t:1526930464009};\\\", \\\"{x:750,y:790,t:1526930464025};\\\", \\\"{x:686,y:807,t:1526930464042};\\\", \\\"{x:621,y:830,t:1526930464059};\\\", \\\"{x:561,y:842,t:1526930464075};\\\", \\\"{x:504,y:855,t:1526930464092};\\\", \\\"{x:473,y:860,t:1526930464108};\\\", \\\"{x:449,y:860,t:1526930464125};\\\", \\\"{x:438,y:860,t:1526930464141};\\\", \\\"{x:431,y:859,t:1526930464158};\\\", \\\"{x:428,y:854,t:1526930464175};\\\", \\\"{x:425,y:846,t:1526930464192};\\\", \\\"{x:424,y:837,t:1526930464208};\\\", \\\"{x:420,y:827,t:1526930464226};\\\", \\\"{x:420,y:820,t:1526930464242};\\\", \\\"{x:420,y:810,t:1526930464259};\\\", \\\"{x:421,y:804,t:1526930464276};\\\", \\\"{x:426,y:794,t:1526930464293};\\\", \\\"{x:430,y:787,t:1526930464309};\\\", \\\"{x:434,y:782,t:1526930464325};\\\", \\\"{x:441,y:774,t:1526930464342};\\\", \\\"{x:450,y:769,t:1526930464359};\\\", \\\"{x:459,y:764,t:1526930464375};\\\", \\\"{x:467,y:758,t:1526930464393};\\\", \\\"{x:472,y:755,t:1526930464409};\\\", \\\"{x:475,y:752,t:1526930464427};\\\", \\\"{x:478,y:748,t:1526930464443};\\\", \\\"{x:481,y:744,t:1526930464458};\\\", \\\"{x:482,y:740,t:1526930464475};\\\", \\\"{x:486,y:733,t:1526930464494};\\\", \\\"{x:489,y:729,t:1526930464511};\\\", \\\"{x:492,y:725,t:1526930464528};\\\", \\\"{x:493,y:724,t:1526930464544};\\\", \\\"{x:494,y:723,t:1526930464719};\\\", \\\"{x:494,y:723,t:1526930464788};\\\", \\\"{x:494,y:725,t:1526930465047};\\\", \\\"{x:494,y:726,t:1526930465062};\\\", \\\"{x:495,y:728,t:1526930465079};\\\", \\\"{x:495,y:730,t:1526930465095};\\\", \\\"{x:495,y:732,t:1526930465111};\\\", \\\"{x:495,y:736,t:1526930465128};\\\", \\\"{x:495,y:740,t:1526930465145};\\\", \\\"{x:495,y:745,t:1526930465161};\\\", \\\"{x:495,y:751,t:1526930465178};\\\", \\\"{x:494,y:761,t:1526930465194};\\\", \\\"{x:483,y:778,t:1526930465211};\\\", \\\"{x:468,y:793,t:1526930465228};\\\", \\\"{x:444,y:808,t:1526930465244};\\\", \\\"{x:415,y:824,t:1526930465261};\\\", \\\"{x:379,y:838,t:1526930465278};\\\", \\\"{x:355,y:851,t:1526930465295};\\\", \\\"{x:320,y:866,t:1526930465311};\\\", \\\"{x:284,y:881,t:1526930465328};\\\", \\\"{x:259,y:893,t:1526930465345};\\\", \\\"{x:240,y:904,t:1526930465361};\\\", \\\"{x:226,y:913,t:1526930465378};\\\", \\\"{x:218,y:922,t:1526930465395};\\\", \\\"{x:215,y:930,t:1526930465411};\\\", \\\"{x:215,y:935,t:1526930465428};\\\", \\\"{x:215,y:940,t:1526930465445};\\\", \\\"{x:218,y:946,t:1526930465462};\\\", \\\"{x:236,y:951,t:1526930465478};\\\", \\\"{x:264,y:956,t:1526930465495};\\\", \\\"{x:298,y:960,t:1526930465511};\\\", \\\"{x:380,y:974,t:1526930465528};\\\", \\\"{x:465,y:986,t:1526930465546};\\\", \\\"{x:560,y:1001,t:1526930465561};\\\", \\\"{x:643,y:1010,t:1526930465579};\\\", \\\"{x:713,y:1021,t:1526930465596};\\\", \\\"{x:758,y:1022,t:1526930465611};\\\", \\\"{x:788,y:1022,t:1526930465628};\\\", \\\"{x:806,y:1026,t:1526930465645};\\\", \\\"{x:820,y:1026,t:1526930465662};\\\", \\\"{x:822,y:1026,t:1526930465678};\\\", \\\"{x:823,y:1026,t:1526930465695};\\\", \\\"{x:824,y:1026,t:1526930465847};\\\" ] }, { \\\"rt\\\": 70705, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 886410, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-02 PM-X -X -O -X -X -E -C -X -X -02 PM-G -02 PM-02 PM-02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:826,y:1024,t:1526930466035};\\\", \\\"{x:825,y:1023,t:1526930466062};\\\", \\\"{x:806,y:1023,t:1526930466079};\\\", \\\"{x:760,y:1023,t:1526930466095};\\\", \\\"{x:621,y:1021,t:1526930466126};\\\", \\\"{x:455,y:1007,t:1526930466145};\\\", \\\"{x:366,y:1007,t:1526930466162};\\\", \\\"{x:327,y:1003,t:1526930466179};\\\", \\\"{x:316,y:1003,t:1526930466195};\\\", \\\"{x:317,y:1002,t:1526930466246};\\\", \\\"{x:322,y:999,t:1526930466262};\\\", \\\"{x:326,y:997,t:1526930466279};\\\", \\\"{x:332,y:992,t:1526930466296};\\\", \\\"{x:340,y:985,t:1526930466313};\\\", \\\"{x:350,y:978,t:1526930466329};\\\", \\\"{x:357,y:972,t:1526930466345};\\\", \\\"{x:361,y:966,t:1526930466362};\\\", \\\"{x:382,y:909,t:1526930466455};\\\", \\\"{x:384,y:905,t:1526930466465};\\\", \\\"{x:386,y:899,t:1526930466479};\\\", \\\"{x:386,y:895,t:1526930466495};\\\", \\\"{x:387,y:893,t:1526930466512};\\\", \\\"{x:387,y:891,t:1526930466529};\\\", \\\"{x:387,y:889,t:1526930466546};\\\", \\\"{x:387,y:886,t:1526930466563};\\\", \\\"{x:387,y:884,t:1526930466579};\\\", \\\"{x:387,y:880,t:1526930466596};\\\", \\\"{x:388,y:876,t:1526930466612};\\\", \\\"{x:390,y:873,t:1526930466629};\\\", \\\"{x:392,y:869,t:1526930466646};\\\", \\\"{x:393,y:869,t:1526930466662};\\\", \\\"{x:394,y:868,t:1526930466679};\\\", \\\"{x:395,y:868,t:1526930466696};\\\", \\\"{x:396,y:867,t:1526930466790};\\\", \\\"{x:396,y:866,t:1526930466799};\\\", \\\"{x:394,y:867,t:1526930467032};\\\", \\\"{x:383,y:872,t:1526930467047};\\\", \\\"{x:365,y:873,t:1526930467064};\\\", \\\"{x:351,y:873,t:1526930467080};\\\", \\\"{x:339,y:873,t:1526930467097};\\\", \\\"{x:326,y:873,t:1526930467114};\\\", \\\"{x:321,y:873,t:1526930467130};\\\", \\\"{x:318,y:872,t:1526930467146};\\\", \\\"{x:314,y:870,t:1526930467164};\\\", \\\"{x:307,y:867,t:1526930467180};\\\", \\\"{x:302,y:865,t:1526930467197};\\\", \\\"{x:294,y:862,t:1526930467214};\\\", \\\"{x:287,y:858,t:1526930467230};\\\", \\\"{x:277,y:855,t:1526930467247};\\\", \\\"{x:274,y:854,t:1526930467263};\\\", \\\"{x:273,y:854,t:1526930467280};\\\", \\\"{x:272,y:853,t:1526930467296};\\\", \\\"{x:271,y:852,t:1526930467335};\\\", \\\"{x:270,y:852,t:1526930467347};\\\", \\\"{x:269,y:851,t:1526930467400};\\\", \\\"{x:268,y:850,t:1526930467615};\\\", \\\"{x:267,y:849,t:1526930467647};\\\", \\\"{x:265,y:849,t:1526930467687};\\\", \\\"{x:264,y:848,t:1526930467711};\\\", \\\"{x:263,y:848,t:1526930467791};\\\", \\\"{x:262,y:847,t:1526930468000};\\\", \\\"{x:263,y:847,t:1526930468071};\\\", \\\"{x:264,y:846,t:1526930468081};\\\", \\\"{x:265,y:846,t:1526930468098};\\\", \\\"{x:266,y:845,t:1526930468191};\\\", \\\"{x:267,y:845,t:1526930468206};\\\", \\\"{x:268,y:845,t:1526930468215};\\\", \\\"{x:269,y:845,t:1526930468231};\\\", \\\"{x:270,y:845,t:1526930468255};\\\", \\\"{x:270,y:844,t:1526930468295};\\\", \\\"{x:271,y:844,t:1526930468311};\\\", \\\"{x:272,y:844,t:1526930468335};\\\", \\\"{x:274,y:842,t:1526930468348};\\\", \\\"{x:277,y:842,t:1526930468367};\\\", \\\"{x:278,y:842,t:1526930468381};\\\", \\\"{x:281,y:841,t:1526930468398};\\\", \\\"{x:284,y:840,t:1526930468414};\\\", \\\"{x:289,y:838,t:1526930468431};\\\", \\\"{x:293,y:838,t:1526930468447};\\\", \\\"{x:297,y:837,t:1526930468465};\\\", \\\"{x:300,y:837,t:1526930468480};\\\", \\\"{x:303,y:837,t:1526930468498};\\\", \\\"{x:307,y:837,t:1526930468515};\\\", \\\"{x:309,y:837,t:1526930468531};\\\", \\\"{x:312,y:837,t:1526930468548};\\\", \\\"{x:316,y:837,t:1526930468564};\\\", \\\"{x:319,y:837,t:1526930468580};\\\", \\\"{x:323,y:837,t:1526930468597};\\\", \\\"{x:328,y:837,t:1526930468614};\\\", \\\"{x:331,y:837,t:1526930468631};\\\", \\\"{x:333,y:837,t:1526930468648};\\\", \\\"{x:334,y:837,t:1526930468665};\\\", \\\"{x:335,y:837,t:1526930468681};\\\", \\\"{x:336,y:836,t:1526930468735};\\\", \\\"{x:337,y:836,t:1526930468800};\\\", \\\"{x:337,y:835,t:1526930469735};\\\", \\\"{x:338,y:834,t:1526930469749};\\\", \\\"{x:340,y:833,t:1526930469765};\\\", \\\"{x:341,y:832,t:1526930469782};\\\", \\\"{x:344,y:830,t:1526930469799};\\\", \\\"{x:345,y:829,t:1526930469815};\\\", \\\"{x:346,y:828,t:1526930469831};\\\", \\\"{x:348,y:828,t:1526930469848};\\\", \\\"{x:350,y:826,t:1526930469865};\\\", \\\"{x:352,y:826,t:1526930469882};\\\", \\\"{x:354,y:824,t:1526930469898};\\\", \\\"{x:356,y:823,t:1526930469916};\\\", \\\"{x:357,y:822,t:1526930469932};\\\", \\\"{x:361,y:821,t:1526930469948};\\\", \\\"{x:364,y:819,t:1526930469966};\\\", \\\"{x:370,y:815,t:1526930469982};\\\", \\\"{x:378,y:811,t:1526930469999};\\\", \\\"{x:383,y:809,t:1526930470015};\\\", \\\"{x:388,y:806,t:1526930470032};\\\", \\\"{x:392,y:804,t:1526930470049};\\\", \\\"{x:394,y:802,t:1526930470065};\\\", \\\"{x:400,y:800,t:1526930470082};\\\", \\\"{x:402,y:799,t:1526930470099};\\\", \\\"{x:407,y:797,t:1526930470115};\\\", \\\"{x:409,y:795,t:1526930470132};\\\", \\\"{x:413,y:795,t:1526930470148};\\\", \\\"{x:416,y:792,t:1526930470166};\\\", \\\"{x:420,y:792,t:1526930470181};\\\", \\\"{x:425,y:790,t:1526930470198};\\\", \\\"{x:426,y:790,t:1526930470216};\\\", \\\"{x:427,y:790,t:1526930470231};\\\", \\\"{x:428,y:789,t:1526930470248};\\\", \\\"{x:430,y:789,t:1526930470295};\\\", \\\"{x:431,y:789,t:1526930470327};\\\", \\\"{x:432,y:789,t:1526930470335};\\\", \\\"{x:433,y:788,t:1526930470349};\\\", \\\"{x:434,y:788,t:1526930470366};\\\", \\\"{x:438,y:786,t:1526930470391};\\\", \\\"{x:442,y:786,t:1526930470400};\\\", \\\"{x:458,y:783,t:1526930470415};\\\", \\\"{x:480,y:781,t:1526930470432};\\\", \\\"{x:506,y:780,t:1526930470449};\\\", \\\"{x:542,y:780,t:1526930470466};\\\", \\\"{x:599,y:778,t:1526930470483};\\\", \\\"{x:657,y:786,t:1526930470498};\\\", \\\"{x:755,y:801,t:1526930470516};\\\", \\\"{x:849,y:813,t:1526930470533};\\\", \\\"{x:963,y:829,t:1526930470550};\\\", \\\"{x:1087,y:844,t:1526930470566};\\\", \\\"{x:1263,y:870,t:1526930470583};\\\", \\\"{x:1363,y:884,t:1526930470600};\\\", \\\"{x:1457,y:909,t:1526930470616};\\\", \\\"{x:1527,y:931,t:1526930470633};\\\", \\\"{x:1585,y:947,t:1526930470648};\\\", \\\"{x:1639,y:965,t:1526930470666};\\\", \\\"{x:1676,y:978,t:1526930470682};\\\", \\\"{x:1709,y:993,t:1526930470699};\\\", \\\"{x:1728,y:1001,t:1526930470715};\\\", \\\"{x:1741,y:1006,t:1526930470732};\\\", \\\"{x:1744,y:1008,t:1526930470748};\\\", \\\"{x:1745,y:1008,t:1526930470782};\\\", \\\"{x:1745,y:1009,t:1526930470799};\\\", \\\"{x:1725,y:1011,t:1526930470815};\\\", \\\"{x:1686,y:1011,t:1526930470833};\\\", \\\"{x:1617,y:1011,t:1526930470849};\\\", \\\"{x:1528,y:1011,t:1526930470866};\\\", \\\"{x:1472,y:1011,t:1526930470883};\\\", \\\"{x:1435,y:1011,t:1526930470899};\\\", \\\"{x:1418,y:1011,t:1526930470916};\\\", \\\"{x:1415,y:1011,t:1526930470933};\\\", \\\"{x:1414,y:1010,t:1526930470966};\\\", \\\"{x:1413,y:1009,t:1526930470983};\\\", \\\"{x:1412,y:1007,t:1526930471000};\\\", \\\"{x:1411,y:1005,t:1526930471017};\\\", \\\"{x:1411,y:1004,t:1526930471033};\\\", \\\"{x:1411,y:1001,t:1526930471050};\\\", \\\"{x:1413,y:999,t:1526930471066};\\\", \\\"{x:1418,y:997,t:1526930471083};\\\", \\\"{x:1424,y:996,t:1526930471100};\\\", \\\"{x:1434,y:993,t:1526930471116};\\\", \\\"{x:1443,y:991,t:1526930471133};\\\", \\\"{x:1451,y:988,t:1526930471150};\\\", \\\"{x:1455,y:985,t:1526930471166};\\\", \\\"{x:1460,y:982,t:1526930471183};\\\", \\\"{x:1460,y:981,t:1526930471199};\\\", \\\"{x:1461,y:981,t:1526930471216};\\\", \\\"{x:1463,y:980,t:1526930471232};\\\", \\\"{x:1464,y:978,t:1526930471249};\\\", \\\"{x:1465,y:978,t:1526930471266};\\\", \\\"{x:1465,y:977,t:1526930471319};\\\", \\\"{x:1466,y:976,t:1526930471342};\\\", \\\"{x:1466,y:975,t:1526930471359};\\\", \\\"{x:1467,y:974,t:1526930471366};\\\", \\\"{x:1468,y:974,t:1526930471383};\\\", \\\"{x:1469,y:972,t:1526930471400};\\\", \\\"{x:1470,y:970,t:1526930471417};\\\", \\\"{x:1471,y:969,t:1526930471433};\\\", \\\"{x:1472,y:968,t:1526930471450};\\\", \\\"{x:1473,y:968,t:1526930471467};\\\", \\\"{x:1474,y:968,t:1526930471483};\\\", \\\"{x:1477,y:966,t:1526930471500};\\\", \\\"{x:1478,y:965,t:1526930471517};\\\", \\\"{x:1479,y:965,t:1526930471533};\\\", \\\"{x:1481,y:965,t:1526930471550};\\\", \\\"{x:1482,y:965,t:1526930471567};\\\", \\\"{x:1483,y:964,t:1526930471583};\\\", \\\"{x:1484,y:964,t:1526930471615};\\\", \\\"{x:1484,y:963,t:1526930471623};\\\", \\\"{x:1485,y:963,t:1526930471648};\\\", \\\"{x:1486,y:962,t:1526930471824};\\\", \\\"{x:1486,y:961,t:1526930471839};\\\", \\\"{x:1485,y:959,t:1526930471851};\\\", \\\"{x:1481,y:954,t:1526930471867};\\\", \\\"{x:1479,y:950,t:1526930471884};\\\", \\\"{x:1478,y:948,t:1526930471901};\\\", \\\"{x:1477,y:944,t:1526930471917};\\\", \\\"{x:1476,y:942,t:1526930471934};\\\", \\\"{x:1474,y:938,t:1526930471951};\\\", \\\"{x:1472,y:933,t:1526930471967};\\\", \\\"{x:1471,y:930,t:1526930471984};\\\", \\\"{x:1471,y:926,t:1526930472001};\\\", \\\"{x:1471,y:921,t:1526930472017};\\\", \\\"{x:1471,y:919,t:1526930472034};\\\", \\\"{x:1471,y:915,t:1526930472050};\\\", \\\"{x:1471,y:914,t:1526930472067};\\\", \\\"{x:1471,y:911,t:1526930472084};\\\", \\\"{x:1470,y:909,t:1526930472101};\\\", \\\"{x:1469,y:906,t:1526930472118};\\\", \\\"{x:1469,y:902,t:1526930472134};\\\", \\\"{x:1469,y:899,t:1526930472151};\\\", \\\"{x:1469,y:895,t:1526930472167};\\\", \\\"{x:1470,y:892,t:1526930472184};\\\", \\\"{x:1470,y:890,t:1526930472201};\\\", \\\"{x:1470,y:888,t:1526930472217};\\\", \\\"{x:1470,y:886,t:1526930472234};\\\", \\\"{x:1470,y:885,t:1526930472251};\\\", \\\"{x:1470,y:883,t:1526930472268};\\\", \\\"{x:1470,y:882,t:1526930472285};\\\", \\\"{x:1470,y:881,t:1526930472301};\\\", \\\"{x:1470,y:880,t:1526930472318};\\\", \\\"{x:1470,y:878,t:1526930472335};\\\", \\\"{x:1470,y:877,t:1526930472351};\\\", \\\"{x:1470,y:875,t:1526930472367};\\\", \\\"{x:1470,y:874,t:1526930472384};\\\", \\\"{x:1470,y:871,t:1526930472401};\\\", \\\"{x:1470,y:869,t:1526930472417};\\\", \\\"{x:1470,y:867,t:1526930472434};\\\", \\\"{x:1470,y:864,t:1526930472452};\\\", \\\"{x:1470,y:859,t:1526930472467};\\\", \\\"{x:1470,y:856,t:1526930472484};\\\", \\\"{x:1470,y:854,t:1526930472501};\\\", \\\"{x:1470,y:852,t:1526930472518};\\\", \\\"{x:1470,y:851,t:1526930472534};\\\", \\\"{x:1470,y:849,t:1526930472552};\\\", \\\"{x:1471,y:848,t:1526930472567};\\\", \\\"{x:1471,y:847,t:1526930472584};\\\", \\\"{x:1471,y:846,t:1526930472601};\\\", \\\"{x:1473,y:845,t:1526930472618};\\\", \\\"{x:1476,y:842,t:1526930472634};\\\", \\\"{x:1479,y:838,t:1526930472651};\\\", \\\"{x:1482,y:835,t:1526930472669};\\\", \\\"{x:1484,y:834,t:1526930472684};\\\", \\\"{x:1486,y:832,t:1526930472700};\\\", \\\"{x:1486,y:831,t:1526930473576};\\\", \\\"{x:1486,y:830,t:1526930473585};\\\", \\\"{x:1485,y:830,t:1526930473607};\\\", \\\"{x:1484,y:829,t:1526930473623};\\\", \\\"{x:1483,y:829,t:1526930473679};\\\", \\\"{x:1482,y:829,t:1526930478855};\\\", \\\"{x:1481,y:828,t:1526930484816};\\\", \\\"{x:1480,y:826,t:1526930484826};\\\", \\\"{x:1479,y:821,t:1526930484845};\\\", \\\"{x:1479,y:815,t:1526930484860};\\\", \\\"{x:1478,y:812,t:1526930484876};\\\", \\\"{x:1476,y:808,t:1526930484894};\\\", \\\"{x:1476,y:806,t:1526930484909};\\\", \\\"{x:1475,y:803,t:1526930484927};\\\", \\\"{x:1474,y:801,t:1526930484944};\\\", \\\"{x:1474,y:799,t:1526930484959};\\\", \\\"{x:1474,y:795,t:1526930484977};\\\", \\\"{x:1473,y:793,t:1526930484994};\\\", \\\"{x:1473,y:790,t:1526930485009};\\\", \\\"{x:1473,y:788,t:1526930485026};\\\", \\\"{x:1473,y:786,t:1526930485043};\\\", \\\"{x:1473,y:785,t:1526930485059};\\\", \\\"{x:1473,y:784,t:1526930485079};\\\", \\\"{x:1473,y:783,t:1526930485094};\\\", \\\"{x:1473,y:782,t:1526930485111};\\\", \\\"{x:1473,y:780,t:1526930485127};\\\", \\\"{x:1473,y:779,t:1526930485143};\\\", \\\"{x:1473,y:778,t:1526930485175};\\\", \\\"{x:1473,y:777,t:1526930485183};\\\", \\\"{x:1472,y:777,t:1526930485193};\\\", \\\"{x:1472,y:776,t:1526930485211};\\\", \\\"{x:1472,y:775,t:1526930485227};\\\", \\\"{x:1471,y:774,t:1526930485243};\\\", \\\"{x:1470,y:774,t:1526930485261};\\\", \\\"{x:1467,y:774,t:1526930485277};\\\", \\\"{x:1465,y:774,t:1526930485294};\\\", \\\"{x:1459,y:774,t:1526930485310};\\\", \\\"{x:1456,y:772,t:1526930485327};\\\", \\\"{x:1452,y:772,t:1526930485344};\\\", \\\"{x:1446,y:772,t:1526930485361};\\\", \\\"{x:1439,y:772,t:1526930485377};\\\", \\\"{x:1433,y:772,t:1526930485394};\\\", \\\"{x:1429,y:772,t:1526930485411};\\\", \\\"{x:1426,y:772,t:1526930485426};\\\", \\\"{x:1425,y:772,t:1526930485447};\\\", \\\"{x:1424,y:771,t:1526930485503};\\\", \\\"{x:1423,y:771,t:1526930485511};\\\", \\\"{x:1422,y:770,t:1526930485526};\\\", \\\"{x:1420,y:769,t:1526930485544};\\\", \\\"{x:1419,y:768,t:1526930485561};\\\", \\\"{x:1417,y:767,t:1526930485578};\\\", \\\"{x:1415,y:765,t:1526930485594};\\\", \\\"{x:1415,y:764,t:1526930485610};\\\", \\\"{x:1414,y:763,t:1526930485628};\\\", \\\"{x:1413,y:763,t:1526930485643};\\\", \\\"{x:1412,y:761,t:1526930485661};\\\", \\\"{x:1412,y:759,t:1526930485679};\\\", \\\"{x:1412,y:758,t:1526930485888};\\\", \\\"{x:1413,y:758,t:1526930485903};\\\", \\\"{x:1415,y:759,t:1526930485911};\\\", \\\"{x:1416,y:760,t:1526930485927};\\\", \\\"{x:1419,y:760,t:1526930485944};\\\", \\\"{x:1423,y:762,t:1526930485960};\\\", \\\"{x:1427,y:763,t:1526930485977};\\\", \\\"{x:1433,y:764,t:1526930485994};\\\", \\\"{x:1439,y:764,t:1526930486010};\\\", \\\"{x:1447,y:764,t:1526930486027};\\\", \\\"{x:1455,y:764,t:1526930486045};\\\", \\\"{x:1461,y:764,t:1526930486060};\\\", \\\"{x:1466,y:764,t:1526930486077};\\\", \\\"{x:1469,y:764,t:1526930486095};\\\", \\\"{x:1470,y:764,t:1526930486126};\\\", \\\"{x:1472,y:764,t:1526930486175};\\\", \\\"{x:1473,y:764,t:1526930486230};\\\", \\\"{x:1474,y:764,t:1526930486246};\\\", \\\"{x:1476,y:764,t:1526930486260};\\\", \\\"{x:1479,y:762,t:1526930486277};\\\", \\\"{x:1483,y:760,t:1526930486294};\\\", \\\"{x:1485,y:760,t:1526930486310};\\\", \\\"{x:1486,y:760,t:1526930486328};\\\", \\\"{x:1487,y:759,t:1526930486344};\\\", \\\"{x:1488,y:759,t:1526930486366};\\\", \\\"{x:1488,y:758,t:1526930486576};\\\", \\\"{x:1487,y:758,t:1526930486607};\\\", \\\"{x:1486,y:758,t:1526930486648};\\\", \\\"{x:1484,y:758,t:1526930486687};\\\", \\\"{x:1483,y:759,t:1526930486727};\\\", \\\"{x:1481,y:759,t:1526930486792};\\\", \\\"{x:1481,y:760,t:1526930486807};\\\", \\\"{x:1480,y:760,t:1526930486821};\\\", \\\"{x:1479,y:761,t:1526930486846};\\\", \\\"{x:1478,y:762,t:1526930486861};\\\", \\\"{x:1478,y:763,t:1526930487040};\\\", \\\"{x:1479,y:765,t:1526930487055};\\\", \\\"{x:1481,y:766,t:1526930487062};\\\", \\\"{x:1488,y:766,t:1526930487078};\\\", \\\"{x:1495,y:767,t:1526930487095};\\\", \\\"{x:1499,y:767,t:1526930487112};\\\", \\\"{x:1503,y:767,t:1526930487129};\\\", \\\"{x:1506,y:767,t:1526930487145};\\\", \\\"{x:1508,y:767,t:1526930487162};\\\", \\\"{x:1511,y:767,t:1526930487179};\\\", \\\"{x:1517,y:767,t:1526930487194};\\\", \\\"{x:1522,y:767,t:1526930487213};\\\", \\\"{x:1529,y:767,t:1526930487228};\\\", \\\"{x:1536,y:767,t:1526930487245};\\\", \\\"{x:1540,y:766,t:1526930487262};\\\", \\\"{x:1542,y:765,t:1526930487278};\\\", \\\"{x:1543,y:765,t:1526930487463};\\\", \\\"{x:1544,y:765,t:1526930487503};\\\", \\\"{x:1545,y:765,t:1526930487560};\\\", \\\"{x:1547,y:764,t:1526930487599};\\\", \\\"{x:1548,y:764,t:1526930487647};\\\", \\\"{x:1550,y:764,t:1526930487663};\\\", \\\"{x:1551,y:764,t:1526930487678};\\\", \\\"{x:1552,y:763,t:1526930487751};\\\", \\\"{x:1553,y:763,t:1526930487887};\\\", \\\"{x:1553,y:762,t:1526930487896};\\\", \\\"{x:1554,y:762,t:1526930488360};\\\", \\\"{x:1554,y:760,t:1526930488479};\\\", \\\"{x:1554,y:759,t:1526930488503};\\\", \\\"{x:1553,y:758,t:1526930488623};\\\", \\\"{x:1551,y:758,t:1526930489303};\\\", \\\"{x:1551,y:757,t:1526930489319};\\\", \\\"{x:1550,y:757,t:1526930490997};\\\", \\\"{x:1549,y:757,t:1526930493740};\\\", \\\"{x:1548,y:757,t:1526930493748};\\\", \\\"{x:1547,y:758,t:1526930493820};\\\", \\\"{x:1546,y:759,t:1526930493908};\\\", \\\"{x:1546,y:760,t:1526930497125};\\\", \\\"{x:1545,y:763,t:1526930497134};\\\", \\\"{x:1541,y:768,t:1526930497150};\\\", \\\"{x:1537,y:773,t:1526930497167};\\\", \\\"{x:1532,y:781,t:1526930497183};\\\", \\\"{x:1530,y:786,t:1526930497199};\\\", \\\"{x:1527,y:791,t:1526930497216};\\\", \\\"{x:1523,y:795,t:1526930497234};\\\", \\\"{x:1522,y:797,t:1526930497249};\\\", \\\"{x:1520,y:801,t:1526930497266};\\\", \\\"{x:1519,y:802,t:1526930497283};\\\", \\\"{x:1519,y:805,t:1526930497299};\\\", \\\"{x:1517,y:808,t:1526930497317};\\\", \\\"{x:1517,y:809,t:1526930497334};\\\", \\\"{x:1514,y:813,t:1526930497350};\\\", \\\"{x:1512,y:815,t:1526930497367};\\\", \\\"{x:1508,y:820,t:1526930497383};\\\", \\\"{x:1504,y:824,t:1526930497400};\\\", \\\"{x:1498,y:828,t:1526930497416};\\\", \\\"{x:1493,y:831,t:1526930497433};\\\", \\\"{x:1489,y:833,t:1526930497450};\\\", \\\"{x:1483,y:836,t:1526930497466};\\\", \\\"{x:1481,y:838,t:1526930497483};\\\", \\\"{x:1479,y:839,t:1526930497500};\\\", \\\"{x:1477,y:839,t:1526930497517};\\\", \\\"{x:1476,y:839,t:1526930497534};\\\", \\\"{x:1474,y:840,t:1526930497556};\\\", \\\"{x:1473,y:840,t:1526930497572};\\\", \\\"{x:1472,y:840,t:1526930497597};\\\", \\\"{x:1471,y:840,t:1526930497605};\\\", \\\"{x:1470,y:840,t:1526930497619};\\\", \\\"{x:1468,y:839,t:1526930497699};\\\", \\\"{x:1467,y:838,t:1526930497723};\\\", \\\"{x:1467,y:836,t:1526930497747};\\\", \\\"{x:1466,y:835,t:1526930497764};\\\", \\\"{x:1466,y:834,t:1526930497788};\\\", \\\"{x:1466,y:833,t:1526930497800};\\\", \\\"{x:1466,y:832,t:1526930497828};\\\", \\\"{x:1465,y:832,t:1526930497835};\\\", \\\"{x:1465,y:831,t:1526930497924};\\\", \\\"{x:1465,y:830,t:1526930497940};\\\", \\\"{x:1465,y:829,t:1526930497956};\\\", \\\"{x:1465,y:828,t:1526930497967};\\\", \\\"{x:1466,y:826,t:1526930498005};\\\", \\\"{x:1467,y:825,t:1526930498028};\\\", \\\"{x:1468,y:825,t:1526930498053};\\\", \\\"{x:1469,y:824,t:1526930498068};\\\", \\\"{x:1470,y:823,t:1526930498084};\\\", \\\"{x:1472,y:823,t:1526930498108};\\\", \\\"{x:1473,y:823,t:1526930498131};\\\", \\\"{x:1475,y:823,t:1526930498155};\\\", \\\"{x:1476,y:823,t:1526930498171};\\\", \\\"{x:1478,y:823,t:1526930498195};\\\", \\\"{x:1479,y:823,t:1526930498219};\\\", \\\"{x:1481,y:823,t:1526930498364};\\\", \\\"{x:1481,y:824,t:1526930500468};\\\", \\\"{x:1481,y:827,t:1526930500486};\\\", \\\"{x:1477,y:834,t:1526930500503};\\\", \\\"{x:1472,y:840,t:1526930500519};\\\", \\\"{x:1468,y:848,t:1526930500536};\\\", \\\"{x:1465,y:853,t:1526930500553};\\\", \\\"{x:1463,y:858,t:1526930500569};\\\", \\\"{x:1461,y:863,t:1526930500586};\\\", \\\"{x:1459,y:867,t:1526930500603};\\\", \\\"{x:1458,y:872,t:1526930500619};\\\", \\\"{x:1453,y:887,t:1526930500636};\\\", \\\"{x:1451,y:898,t:1526930500652};\\\", \\\"{x:1448,y:906,t:1526930500669};\\\", \\\"{x:1448,y:912,t:1526930500685};\\\", \\\"{x:1448,y:915,t:1526930500703};\\\", \\\"{x:1448,y:918,t:1526930500719};\\\", \\\"{x:1448,y:919,t:1526930500736};\\\", \\\"{x:1448,y:920,t:1526930500753};\\\", \\\"{x:1448,y:921,t:1526930500805};\\\", \\\"{x:1448,y:923,t:1526930500836};\\\", \\\"{x:1451,y:925,t:1526930500853};\\\", \\\"{x:1455,y:927,t:1526930500870};\\\", \\\"{x:1458,y:929,t:1526930500886};\\\", \\\"{x:1460,y:931,t:1526930500902};\\\", \\\"{x:1462,y:933,t:1526930500920};\\\", \\\"{x:1465,y:936,t:1526930500936};\\\", \\\"{x:1470,y:939,t:1526930500953};\\\", \\\"{x:1477,y:944,t:1526930500969};\\\", \\\"{x:1484,y:949,t:1526930500986};\\\", \\\"{x:1491,y:954,t:1526930501002};\\\", \\\"{x:1497,y:960,t:1526930501020};\\\", \\\"{x:1499,y:963,t:1526930501036};\\\", \\\"{x:1499,y:964,t:1526930501052};\\\", \\\"{x:1500,y:966,t:1526930501070};\\\", \\\"{x:1500,y:967,t:1526930501086};\\\", \\\"{x:1500,y:966,t:1526930501204};\\\", \\\"{x:1497,y:957,t:1526930501220};\\\", \\\"{x:1492,y:944,t:1526930501236};\\\", \\\"{x:1489,y:933,t:1526930501252};\\\", \\\"{x:1487,y:922,t:1526930501269};\\\", \\\"{x:1482,y:907,t:1526930501286};\\\", \\\"{x:1478,y:893,t:1526930501302};\\\", \\\"{x:1474,y:879,t:1526930501319};\\\", \\\"{x:1469,y:868,t:1526930501336};\\\", \\\"{x:1469,y:858,t:1526930501352};\\\", \\\"{x:1468,y:846,t:1526930501369};\\\", \\\"{x:1468,y:836,t:1526930501386};\\\", \\\"{x:1468,y:829,t:1526930501402};\\\", \\\"{x:1465,y:818,t:1526930501419};\\\", \\\"{x:1464,y:813,t:1526930501436};\\\", \\\"{x:1463,y:809,t:1526930501452};\\\", \\\"{x:1463,y:805,t:1526930501469};\\\", \\\"{x:1462,y:801,t:1526930501486};\\\", \\\"{x:1462,y:800,t:1526930501503};\\\", \\\"{x:1462,y:797,t:1526930501519};\\\", \\\"{x:1462,y:796,t:1526930501536};\\\", \\\"{x:1462,y:795,t:1526930501552};\\\", \\\"{x:1462,y:793,t:1526930501636};\\\", \\\"{x:1464,y:793,t:1526930501684};\\\", \\\"{x:1466,y:793,t:1526930501700};\\\", \\\"{x:1466,y:794,t:1526930501708};\\\", \\\"{x:1467,y:794,t:1526930501719};\\\", \\\"{x:1469,y:796,t:1526930501737};\\\", \\\"{x:1469,y:798,t:1526930501752};\\\", \\\"{x:1470,y:801,t:1526930501770};\\\", \\\"{x:1471,y:803,t:1526930501787};\\\", \\\"{x:1471,y:808,t:1526930501804};\\\", \\\"{x:1472,y:810,t:1526930501820};\\\", \\\"{x:1472,y:812,t:1526930501837};\\\", \\\"{x:1473,y:813,t:1526930501854};\\\", \\\"{x:1473,y:814,t:1526930501870};\\\", \\\"{x:1473,y:815,t:1526930501887};\\\", \\\"{x:1474,y:817,t:1526930501904};\\\", \\\"{x:1474,y:818,t:1526930501924};\\\", \\\"{x:1474,y:819,t:1526930501937};\\\", \\\"{x:1474,y:820,t:1526930501954};\\\", \\\"{x:1474,y:821,t:1526930502021};\\\", \\\"{x:1475,y:822,t:1526930502037};\\\", \\\"{x:1475,y:823,t:1526930502053};\\\", \\\"{x:1475,y:824,t:1526930502076};\\\", \\\"{x:1475,y:823,t:1526930502340};\\\", \\\"{x:1475,y:820,t:1526930502354};\\\", \\\"{x:1474,y:816,t:1526930502371};\\\", \\\"{x:1474,y:810,t:1526930502387};\\\", \\\"{x:1472,y:802,t:1526930502404};\\\", \\\"{x:1472,y:797,t:1526930502420};\\\", \\\"{x:1472,y:792,t:1526930502437};\\\", \\\"{x:1472,y:784,t:1526930502453};\\\", \\\"{x:1472,y:778,t:1526930502471};\\\", \\\"{x:1472,y:770,t:1526930502487};\\\", \\\"{x:1474,y:764,t:1526930502504};\\\", \\\"{x:1474,y:758,t:1526930502521};\\\", \\\"{x:1474,y:755,t:1526930502536};\\\", \\\"{x:1475,y:750,t:1526930502554};\\\", \\\"{x:1475,y:747,t:1526930502571};\\\", \\\"{x:1475,y:744,t:1526930502587};\\\", \\\"{x:1475,y:740,t:1526930502604};\\\", \\\"{x:1476,y:737,t:1526930502620};\\\", \\\"{x:1476,y:734,t:1526930502637};\\\", \\\"{x:1477,y:730,t:1526930502654};\\\", \\\"{x:1477,y:729,t:1526930502670};\\\", \\\"{x:1479,y:725,t:1526930502688};\\\", \\\"{x:1479,y:721,t:1526930502704};\\\", \\\"{x:1481,y:717,t:1526930502721};\\\", \\\"{x:1482,y:715,t:1526930502738};\\\", \\\"{x:1485,y:711,t:1526930502754};\\\", \\\"{x:1485,y:709,t:1526930502771};\\\", \\\"{x:1485,y:708,t:1526930502788};\\\", \\\"{x:1485,y:707,t:1526930502804};\\\", \\\"{x:1485,y:706,t:1526930502828};\\\", \\\"{x:1485,y:705,t:1526930502852};\\\", \\\"{x:1485,y:704,t:1526930502876};\\\", \\\"{x:1485,y:703,t:1526930502893};\\\", \\\"{x:1485,y:702,t:1526930502908};\\\", \\\"{x:1485,y:701,t:1526930502957};\\\", \\\"{x:1485,y:699,t:1526930503301};\\\", \\\"{x:1484,y:698,t:1526930503540};\\\", \\\"{x:1483,y:696,t:1526930503565};\\\", \\\"{x:1482,y:696,t:1526930504068};\\\", \\\"{x:1478,y:696,t:1526930504076};\\\", \\\"{x:1469,y:696,t:1526930504089};\\\", \\\"{x:1440,y:699,t:1526930504105};\\\", \\\"{x:1394,y:702,t:1526930504122};\\\", \\\"{x:1327,y:702,t:1526930504139};\\\", \\\"{x:1237,y:697,t:1526930504155};\\\", \\\"{x:1065,y:683,t:1526930504172};\\\", \\\"{x:946,y:669,t:1526930504188};\\\", \\\"{x:842,y:661,t:1526930504205};\\\", \\\"{x:754,y:653,t:1526930504222};\\\", \\\"{x:685,y:643,t:1526930504240};\\\", \\\"{x:644,y:638,t:1526930504254};\\\", \\\"{x:622,y:634,t:1526930504272};\\\", \\\"{x:609,y:631,t:1526930504290};\\\", \\\"{x:603,y:628,t:1526930504307};\\\", \\\"{x:601,y:626,t:1526930504323};\\\", \\\"{x:598,y:625,t:1526930504340};\\\", \\\"{x:596,y:624,t:1526930504357};\\\", \\\"{x:595,y:623,t:1526930504374};\\\", \\\"{x:593,y:622,t:1526930504403};\\\", \\\"{x:593,y:621,t:1526930504427};\\\", \\\"{x:592,y:621,t:1526930504440};\\\", \\\"{x:592,y:619,t:1526930504457};\\\", \\\"{x:594,y:615,t:1526930504473};\\\", \\\"{x:599,y:610,t:1526930504491};\\\", \\\"{x:615,y:603,t:1526930504508};\\\", \\\"{x:629,y:598,t:1526930504525};\\\", \\\"{x:637,y:595,t:1526930504540};\\\", \\\"{x:644,y:590,t:1526930504558};\\\", \\\"{x:648,y:586,t:1526930504574};\\\", \\\"{x:651,y:584,t:1526930504590};\\\", \\\"{x:651,y:583,t:1526930504608};\\\", \\\"{x:651,y:582,t:1526930504635};\\\", \\\"{x:652,y:580,t:1526930504643};\\\", \\\"{x:653,y:579,t:1526930504658};\\\", \\\"{x:655,y:577,t:1526930504674};\\\", \\\"{x:662,y:572,t:1526930504693};\\\", \\\"{x:677,y:561,t:1526930504709};\\\", \\\"{x:703,y:552,t:1526930504724};\\\", \\\"{x:730,y:546,t:1526930504741};\\\", \\\"{x:759,y:544,t:1526930504757};\\\", \\\"{x:781,y:540,t:1526930504774};\\\", \\\"{x:796,y:538,t:1526930504792};\\\", \\\"{x:809,y:536,t:1526930504807};\\\", \\\"{x:815,y:535,t:1526930504824};\\\", \\\"{x:818,y:534,t:1526930504840};\\\", \\\"{x:820,y:534,t:1526930504972};\\\", \\\"{x:821,y:532,t:1526930504980};\\\", \\\"{x:822,y:532,t:1526930505004};\\\", \\\"{x:822,y:530,t:1526930505013};\\\", \\\"{x:823,y:529,t:1526930505035};\\\", \\\"{x:824,y:528,t:1526930505044};\\\", \\\"{x:824,y:527,t:1526930505076};\\\", \\\"{x:825,y:526,t:1526930505091};\\\", \\\"{x:825,y:525,t:1526930505107};\\\", \\\"{x:825,y:524,t:1526930505125};\\\", \\\"{x:826,y:522,t:1526930505142};\\\", \\\"{x:827,y:522,t:1526930505157};\\\", \\\"{x:828,y:521,t:1526930505174};\\\", \\\"{x:829,y:521,t:1526930505195};\\\", \\\"{x:833,y:521,t:1526930505555};\\\", \\\"{x:844,y:521,t:1526930505564};\\\", \\\"{x:852,y:521,t:1526930505575};\\\", \\\"{x:881,y:521,t:1526930505592};\\\", \\\"{x:927,y:521,t:1526930505609};\\\", \\\"{x:1001,y:516,t:1526930505624};\\\", \\\"{x:1060,y:516,t:1526930505642};\\\", \\\"{x:1118,y:516,t:1526930505658};\\\", \\\"{x:1151,y:516,t:1526930505674};\\\", \\\"{x:1181,y:516,t:1526930505691};\\\", \\\"{x:1191,y:516,t:1526930505708};\\\", \\\"{x:1198,y:516,t:1526930505725};\\\", \\\"{x:1207,y:516,t:1526930505741};\\\", \\\"{x:1220,y:516,t:1526930505758};\\\", \\\"{x:1235,y:518,t:1526930505774};\\\", \\\"{x:1251,y:521,t:1526930505791};\\\", \\\"{x:1267,y:523,t:1526930505808};\\\", \\\"{x:1281,y:526,t:1526930505824};\\\", \\\"{x:1293,y:528,t:1526930505841};\\\", \\\"{x:1303,y:529,t:1526930505858};\\\", \\\"{x:1314,y:531,t:1526930505875};\\\", \\\"{x:1328,y:533,t:1526930505891};\\\", \\\"{x:1334,y:535,t:1526930505909};\\\", \\\"{x:1340,y:536,t:1526930505925};\\\", \\\"{x:1345,y:540,t:1526930505942};\\\", \\\"{x:1348,y:543,t:1526930505958};\\\", \\\"{x:1355,y:548,t:1526930505974};\\\", \\\"{x:1363,y:553,t:1526930505992};\\\", \\\"{x:1372,y:560,t:1526930506009};\\\", \\\"{x:1379,y:567,t:1526930506024};\\\", \\\"{x:1385,y:572,t:1526930506042};\\\", \\\"{x:1395,y:579,t:1526930506058};\\\", \\\"{x:1400,y:583,t:1526930506074};\\\", \\\"{x:1405,y:587,t:1526930506092};\\\", \\\"{x:1411,y:590,t:1526930506108};\\\", \\\"{x:1417,y:591,t:1526930506125};\\\", \\\"{x:1419,y:592,t:1526930506141};\\\", \\\"{x:1421,y:593,t:1526930506158};\\\", \\\"{x:1422,y:593,t:1526930506174};\\\", \\\"{x:1424,y:593,t:1526930506192};\\\", \\\"{x:1425,y:593,t:1526930506208};\\\", \\\"{x:1427,y:593,t:1526930506225};\\\", \\\"{x:1430,y:593,t:1526930506241};\\\", \\\"{x:1431,y:592,t:1526930506258};\\\", \\\"{x:1431,y:591,t:1526930506274};\\\", \\\"{x:1431,y:585,t:1526930506291};\\\", \\\"{x:1431,y:582,t:1526930506308};\\\", \\\"{x:1431,y:580,t:1526930506324};\\\", \\\"{x:1430,y:577,t:1526930506342};\\\", \\\"{x:1428,y:575,t:1526930506358};\\\", \\\"{x:1426,y:573,t:1526930506375};\\\", \\\"{x:1425,y:572,t:1526930506395};\\\", \\\"{x:1424,y:572,t:1526930506420};\\\", \\\"{x:1423,y:572,t:1526930506444};\\\", \\\"{x:1422,y:571,t:1526930506459};\\\", \\\"{x:1420,y:570,t:1526930506474};\\\", \\\"{x:1415,y:569,t:1526930506492};\\\", \\\"{x:1410,y:569,t:1526930506509};\\\", \\\"{x:1399,y:567,t:1526930506525};\\\", \\\"{x:1388,y:567,t:1526930506542};\\\", \\\"{x:1371,y:567,t:1526930506559};\\\", \\\"{x:1347,y:567,t:1526930506576};\\\", \\\"{x:1325,y:567,t:1526930506592};\\\", \\\"{x:1309,y:567,t:1526930506609};\\\", \\\"{x:1295,y:564,t:1526930506625};\\\", \\\"{x:1289,y:563,t:1526930506642};\\\", \\\"{x:1287,y:563,t:1526930506659};\\\", \\\"{x:1285,y:562,t:1526930506674};\\\", \\\"{x:1283,y:562,t:1526930506748};\\\", \\\"{x:1288,y:563,t:1526930507006};\\\", \\\"{x:1299,y:564,t:1526930507012};\\\", \\\"{x:1310,y:565,t:1526930507026};\\\", \\\"{x:1334,y:570,t:1526930507042};\\\", \\\"{x:1353,y:572,t:1526930507060};\\\", \\\"{x:1370,y:575,t:1526930507076};\\\", \\\"{x:1373,y:575,t:1526930507092};\\\", \\\"{x:1374,y:575,t:1526930507109};\\\", \\\"{x:1376,y:576,t:1526930507127};\\\", \\\"{x:1381,y:578,t:1526930507142};\\\", \\\"{x:1389,y:582,t:1526930507159};\\\", \\\"{x:1401,y:590,t:1526930507176};\\\", \\\"{x:1414,y:599,t:1526930507192};\\\", \\\"{x:1432,y:611,t:1526930507209};\\\", \\\"{x:1445,y:624,t:1526930507226};\\\", \\\"{x:1457,y:642,t:1526930507242};\\\", \\\"{x:1468,y:662,t:1526930507258};\\\", \\\"{x:1484,y:698,t:1526930507276};\\\", \\\"{x:1497,y:727,t:1526930507292};\\\", \\\"{x:1508,y:766,t:1526930507309};\\\", \\\"{x:1520,y:794,t:1526930507326};\\\", \\\"{x:1526,y:819,t:1526930507342};\\\", \\\"{x:1532,y:841,t:1526930507358};\\\", \\\"{x:1537,y:856,t:1526930507376};\\\", \\\"{x:1539,y:864,t:1526930507392};\\\", \\\"{x:1542,y:869,t:1526930507409};\\\", \\\"{x:1542,y:873,t:1526930507426};\\\", \\\"{x:1542,y:876,t:1526930507442};\\\", \\\"{x:1543,y:878,t:1526930507459};\\\", \\\"{x:1543,y:879,t:1526930507477};\\\", \\\"{x:1544,y:880,t:1526930507524};\\\", \\\"{x:1542,y:878,t:1526930507564};\\\", \\\"{x:1538,y:874,t:1526930507576};\\\", \\\"{x:1529,y:867,t:1526930507592};\\\", \\\"{x:1517,y:858,t:1526930507609};\\\", \\\"{x:1511,y:854,t:1526930507627};\\\", \\\"{x:1505,y:853,t:1526930507642};\\\", \\\"{x:1504,y:853,t:1526930507659};\\\", \\\"{x:1502,y:852,t:1526930507676};\\\", \\\"{x:1500,y:851,t:1526930507692};\\\", \\\"{x:1498,y:851,t:1526930507709};\\\", \\\"{x:1495,y:850,t:1526930507726};\\\", \\\"{x:1493,y:850,t:1526930507743};\\\", \\\"{x:1492,y:849,t:1526930507759};\\\", \\\"{x:1491,y:848,t:1526930507776};\\\", \\\"{x:1490,y:848,t:1526930507792};\\\", \\\"{x:1489,y:847,t:1526930507808};\\\", \\\"{x:1487,y:845,t:1526930507825};\\\", \\\"{x:1484,y:843,t:1526930507841};\\\", \\\"{x:1482,y:841,t:1526930507858};\\\", \\\"{x:1481,y:838,t:1526930507875};\\\", \\\"{x:1480,y:837,t:1526930507892};\\\", \\\"{x:1479,y:836,t:1526930507908};\\\", \\\"{x:1478,y:835,t:1526930507926};\\\", \\\"{x:1477,y:833,t:1526930507955};\\\", \\\"{x:1476,y:833,t:1526930507980};\\\", \\\"{x:1476,y:832,t:1526930508012};\\\", \\\"{x:1476,y:831,t:1526930508076};\\\", \\\"{x:1476,y:830,t:1526930508099};\\\", \\\"{x:1475,y:829,t:1526930508182};\\\", \\\"{x:1474,y:828,t:1526930508676};\\\", \\\"{x:1474,y:827,t:1526930509363};\\\", \\\"{x:1474,y:826,t:1526930509573};\\\", \\\"{x:1474,y:827,t:1526930509908};\\\", \\\"{x:1474,y:828,t:1526930509916};\\\", \\\"{x:1474,y:829,t:1526930509956};\\\", \\\"{x:1474,y:830,t:1526930510013};\\\", \\\"{x:1472,y:830,t:1526930510140};\\\", \\\"{x:1468,y:830,t:1526930510148};\\\", \\\"{x:1465,y:830,t:1526930510160};\\\", \\\"{x:1459,y:827,t:1526930510177};\\\", \\\"{x:1457,y:827,t:1526930510193};\\\", \\\"{x:1455,y:826,t:1526930510210};\\\", \\\"{x:1454,y:825,t:1526930510227};\\\", \\\"{x:1453,y:825,t:1526930510243};\\\", \\\"{x:1453,y:828,t:1526930510365};\\\", \\\"{x:1455,y:833,t:1526930510377};\\\", \\\"{x:1459,y:843,t:1526930510394};\\\", \\\"{x:1463,y:858,t:1526930510410};\\\", \\\"{x:1467,y:872,t:1526930510427};\\\", \\\"{x:1469,y:881,t:1526930510443};\\\", \\\"{x:1474,y:897,t:1526930510460};\\\", \\\"{x:1476,y:905,t:1526930510477};\\\", \\\"{x:1479,y:914,t:1526930510493};\\\", \\\"{x:1482,y:924,t:1526930510511};\\\", \\\"{x:1484,y:938,t:1526930510527};\\\", \\\"{x:1489,y:950,t:1526930510543};\\\", \\\"{x:1495,y:964,t:1526930510561};\\\", \\\"{x:1497,y:970,t:1526930510577};\\\", \\\"{x:1497,y:971,t:1526930510593};\\\", \\\"{x:1497,y:972,t:1526930510716};\\\", \\\"{x:1495,y:972,t:1526930510727};\\\", \\\"{x:1490,y:971,t:1526930510743};\\\", \\\"{x:1486,y:971,t:1526930510760};\\\", \\\"{x:1484,y:969,t:1526930510777};\\\", \\\"{x:1480,y:967,t:1526930510793};\\\", \\\"{x:1479,y:966,t:1526930510810};\\\", \\\"{x:1479,y:964,t:1526930510827};\\\", \\\"{x:1476,y:962,t:1526930510844};\\\", \\\"{x:1475,y:960,t:1526930510860};\\\", \\\"{x:1474,y:959,t:1526930510878};\\\", \\\"{x:1474,y:957,t:1526930510894};\\\", \\\"{x:1474,y:955,t:1526930510910};\\\", \\\"{x:1473,y:954,t:1526930510927};\\\", \\\"{x:1473,y:953,t:1526930510948};\\\", \\\"{x:1473,y:952,t:1526930510960};\\\", \\\"{x:1473,y:951,t:1526930510977};\\\", \\\"{x:1473,y:948,t:1526930510993};\\\", \\\"{x:1472,y:945,t:1526930511010};\\\", \\\"{x:1472,y:942,t:1526930511027};\\\", \\\"{x:1472,y:940,t:1526930511043};\\\", \\\"{x:1472,y:935,t:1526930511060};\\\", \\\"{x:1472,y:932,t:1526930511077};\\\", \\\"{x:1472,y:929,t:1526930511094};\\\", \\\"{x:1472,y:922,t:1526930511110};\\\", \\\"{x:1472,y:916,t:1526930511127};\\\", \\\"{x:1472,y:912,t:1526930511143};\\\", \\\"{x:1472,y:907,t:1526930511161};\\\", \\\"{x:1472,y:902,t:1526930511177};\\\", \\\"{x:1472,y:897,t:1526930511193};\\\", \\\"{x:1472,y:891,t:1526930511210};\\\", \\\"{x:1472,y:885,t:1526930511227};\\\", \\\"{x:1472,y:879,t:1526930511243};\\\", \\\"{x:1472,y:871,t:1526930511260};\\\", \\\"{x:1472,y:865,t:1526930511276};\\\", \\\"{x:1472,y:860,t:1526930511293};\\\", \\\"{x:1472,y:855,t:1526930511310};\\\", \\\"{x:1472,y:851,t:1526930511327};\\\", \\\"{x:1471,y:846,t:1526930511344};\\\", \\\"{x:1470,y:841,t:1526930511360};\\\", \\\"{x:1470,y:840,t:1526930511376};\\\", \\\"{x:1470,y:838,t:1526930511392};\\\", \\\"{x:1469,y:838,t:1526930511410};\\\", \\\"{x:1469,y:837,t:1526930511452};\\\", \\\"{x:1469,y:835,t:1526930511476};\\\", \\\"{x:1469,y:834,t:1526930511494};\\\", \\\"{x:1470,y:833,t:1526930511510};\\\", \\\"{x:1471,y:831,t:1526930511526};\\\", \\\"{x:1472,y:830,t:1526930511544};\\\", \\\"{x:1473,y:829,t:1526930511620};\\\", \\\"{x:1474,y:828,t:1526930511660};\\\", \\\"{x:1474,y:826,t:1526930511684};\\\", \\\"{x:1475,y:824,t:1526930511694};\\\", \\\"{x:1475,y:821,t:1526930511710};\\\", \\\"{x:1475,y:815,t:1526930511727};\\\", \\\"{x:1475,y:810,t:1526930511744};\\\", \\\"{x:1475,y:806,t:1526930511760};\\\", \\\"{x:1475,y:795,t:1526930511777};\\\", \\\"{x:1475,y:789,t:1526930511794};\\\", \\\"{x:1475,y:781,t:1526930511811};\\\", \\\"{x:1475,y:771,t:1526930511828};\\\", \\\"{x:1474,y:761,t:1526930511844};\\\", \\\"{x:1474,y:755,t:1526930511860};\\\", \\\"{x:1472,y:750,t:1526930511877};\\\", \\\"{x:1471,y:745,t:1526930511894};\\\", \\\"{x:1471,y:744,t:1526930511911};\\\", \\\"{x:1471,y:741,t:1526930511928};\\\", \\\"{x:1471,y:739,t:1526930511944};\\\", \\\"{x:1471,y:738,t:1526930511961};\\\", \\\"{x:1471,y:736,t:1526930511977};\\\", \\\"{x:1471,y:735,t:1526930511994};\\\", \\\"{x:1470,y:733,t:1526930512010};\\\", \\\"{x:1470,y:731,t:1526930512027};\\\", \\\"{x:1470,y:727,t:1526930512044};\\\", \\\"{x:1470,y:722,t:1526930512061};\\\", \\\"{x:1470,y:719,t:1526930512077};\\\", \\\"{x:1470,y:715,t:1526930512094};\\\", \\\"{x:1470,y:710,t:1526930512110};\\\", \\\"{x:1470,y:707,t:1526930512127};\\\", \\\"{x:1470,y:703,t:1526930512145};\\\", \\\"{x:1470,y:699,t:1526930512160};\\\", \\\"{x:1470,y:697,t:1526930512178};\\\", \\\"{x:1470,y:692,t:1526930512194};\\\", \\\"{x:1470,y:687,t:1526930512210};\\\", \\\"{x:1471,y:684,t:1526930512228};\\\", \\\"{x:1473,y:675,t:1526930512244};\\\", \\\"{x:1474,y:670,t:1526930512260};\\\", \\\"{x:1474,y:666,t:1526930512277};\\\", \\\"{x:1475,y:661,t:1526930512294};\\\", \\\"{x:1476,y:655,t:1526930512310};\\\", \\\"{x:1477,y:648,t:1526930512327};\\\", \\\"{x:1479,y:641,t:1526930512345};\\\", \\\"{x:1480,y:636,t:1526930512360};\\\", \\\"{x:1482,y:632,t:1526930512377};\\\", \\\"{x:1484,y:628,t:1526930512394};\\\", \\\"{x:1485,y:626,t:1526930512410};\\\", \\\"{x:1485,y:625,t:1526930512427};\\\", \\\"{x:1485,y:623,t:1526930512972};\\\", \\\"{x:1485,y:622,t:1526930512980};\\\", \\\"{x:1485,y:619,t:1526930512995};\\\", \\\"{x:1483,y:615,t:1526930513012};\\\", \\\"{x:1480,y:608,t:1526930513027};\\\", \\\"{x:1476,y:599,t:1526930513044};\\\", \\\"{x:1475,y:596,t:1526930513062};\\\", \\\"{x:1474,y:591,t:1526930513077};\\\", \\\"{x:1474,y:588,t:1526930513094};\\\", \\\"{x:1472,y:587,t:1526930513111};\\\", \\\"{x:1472,y:585,t:1526930513127};\\\", \\\"{x:1472,y:582,t:1526930513145};\\\", \\\"{x:1472,y:581,t:1526930513161};\\\", \\\"{x:1472,y:577,t:1526930513178};\\\", \\\"{x:1472,y:574,t:1526930513194};\\\", \\\"{x:1472,y:572,t:1526930513211};\\\", \\\"{x:1472,y:571,t:1526930513227};\\\", \\\"{x:1472,y:570,t:1526930514004};\\\", \\\"{x:1472,y:569,t:1526930514012};\\\", \\\"{x:1472,y:568,t:1526930514029};\\\", \\\"{x:1472,y:566,t:1526930514044};\\\", \\\"{x:1473,y:565,t:1526930514061};\\\", \\\"{x:1474,y:562,t:1526930514078};\\\", \\\"{x:1475,y:561,t:1526930514100};\\\", \\\"{x:1476,y:561,t:1526930514132};\\\", \\\"{x:1475,y:561,t:1526930514860};\\\", \\\"{x:1472,y:561,t:1526930515485};\\\", \\\"{x:1461,y:561,t:1526930515495};\\\", \\\"{x:1414,y:559,t:1526930515512};\\\", \\\"{x:1321,y:553,t:1526930515529};\\\", \\\"{x:1197,y:541,t:1526930515545};\\\", \\\"{x:1058,y:530,t:1526930515562};\\\", \\\"{x:920,y:520,t:1526930515580};\\\", \\\"{x:816,y:512,t:1526930515595};\\\", \\\"{x:745,y:505,t:1526930515611};\\\", \\\"{x:679,y:501,t:1526930515630};\\\", \\\"{x:663,y:501,t:1526930515645};\\\", \\\"{x:659,y:501,t:1526930515661};\\\", \\\"{x:658,y:501,t:1526930515731};\\\", \\\"{x:655,y:501,t:1526930515739};\\\", \\\"{x:652,y:501,t:1526930515749};\\\", \\\"{x:649,y:501,t:1526930515765};\\\", \\\"{x:645,y:501,t:1526930515783};\\\", \\\"{x:642,y:501,t:1526930515800};\\\", \\\"{x:638,y:501,t:1526930515816};\\\", \\\"{x:634,y:501,t:1526930515832};\\\", \\\"{x:629,y:502,t:1526930515850};\\\", \\\"{x:623,y:502,t:1526930515867};\\\", \\\"{x:618,y:502,t:1526930515882};\\\", \\\"{x:613,y:502,t:1526930515899};\\\", \\\"{x:611,y:502,t:1526930515917};\\\", \\\"{x:609,y:502,t:1526930515940};\\\", \\\"{x:608,y:502,t:1526930515956};\\\", \\\"{x:608,y:503,t:1526930515972};\\\", \\\"{x:606,y:503,t:1526930516003};\\\", \\\"{x:606,y:504,t:1526930516036};\\\", \\\"{x:605,y:504,t:1526930516107};\\\", \\\"{x:605,y:505,t:1526930516117};\\\", \\\"{x:605,y:506,t:1526930516138};\\\", \\\"{x:605,y:507,t:1526930516150};\\\", \\\"{x:605,y:508,t:1526930516166};\\\", \\\"{x:606,y:510,t:1526930516187};\\\", \\\"{x:607,y:510,t:1526930516499};\\\", \\\"{x:614,y:510,t:1526930516507};\\\", \\\"{x:622,y:510,t:1526930516517};\\\", \\\"{x:648,y:510,t:1526930516534};\\\", \\\"{x:700,y:510,t:1526930516550};\\\", \\\"{x:764,y:510,t:1526930516567};\\\", \\\"{x:844,y:510,t:1526930516584};\\\", \\\"{x:911,y:510,t:1526930516602};\\\", \\\"{x:981,y:510,t:1526930516617};\\\", \\\"{x:1034,y:510,t:1526930516634};\\\", \\\"{x:1095,y:510,t:1526930516650};\\\", \\\"{x:1181,y:510,t:1526930516667};\\\", \\\"{x:1240,y:510,t:1526930516684};\\\", \\\"{x:1293,y:510,t:1526930516700};\\\", \\\"{x:1343,y:516,t:1526930516717};\\\", \\\"{x:1385,y:521,t:1526930516734};\\\", \\\"{x:1416,y:525,t:1526930516750};\\\", \\\"{x:1439,y:528,t:1526930516767};\\\", \\\"{x:1457,y:533,t:1526930516784};\\\", \\\"{x:1474,y:536,t:1526930516800};\\\", \\\"{x:1484,y:539,t:1526930516817};\\\", \\\"{x:1496,y:543,t:1526930516834};\\\", \\\"{x:1514,y:550,t:1526930516851};\\\", \\\"{x:1522,y:554,t:1526930516867};\\\", \\\"{x:1529,y:559,t:1526930516884};\\\", \\\"{x:1536,y:563,t:1526930516901};\\\", \\\"{x:1540,y:567,t:1526930516917};\\\", \\\"{x:1542,y:570,t:1526930516934};\\\", \\\"{x:1546,y:575,t:1526930516951};\\\", \\\"{x:1548,y:581,t:1526930516967};\\\", \\\"{x:1550,y:587,t:1526930516984};\\\", \\\"{x:1552,y:594,t:1526930517002};\\\", \\\"{x:1553,y:599,t:1526930517017};\\\", \\\"{x:1554,y:606,t:1526930517035};\\\", \\\"{x:1554,y:615,t:1526930517051};\\\", \\\"{x:1554,y:620,t:1526930517067};\\\", \\\"{x:1551,y:626,t:1526930517084};\\\", \\\"{x:1547,y:632,t:1526930517100};\\\", \\\"{x:1543,y:636,t:1526930517116};\\\", \\\"{x:1541,y:638,t:1526930517134};\\\", \\\"{x:1537,y:640,t:1526930517151};\\\", \\\"{x:1536,y:641,t:1526930517167};\\\", \\\"{x:1534,y:641,t:1526930517184};\\\", \\\"{x:1533,y:641,t:1526930517200};\\\", \\\"{x:1532,y:641,t:1526930517217};\\\", \\\"{x:1531,y:641,t:1526930517234};\\\", \\\"{x:1527,y:641,t:1526930517251};\\\", \\\"{x:1524,y:640,t:1526930517268};\\\", \\\"{x:1521,y:639,t:1526930517284};\\\", \\\"{x:1520,y:639,t:1526930517302};\\\", \\\"{x:1518,y:637,t:1526930517319};\\\", \\\"{x:1516,y:636,t:1526930517334};\\\", \\\"{x:1514,y:633,t:1526930517351};\\\", \\\"{x:1511,y:632,t:1526930517367};\\\", \\\"{x:1509,y:630,t:1526930517383};\\\", \\\"{x:1506,y:627,t:1526930517401};\\\", \\\"{x:1505,y:627,t:1526930517418};\\\", \\\"{x:1502,y:624,t:1526930517434};\\\", \\\"{x:1499,y:617,t:1526930517450};\\\", \\\"{x:1498,y:614,t:1526930517467};\\\", \\\"{x:1496,y:611,t:1526930517483};\\\", \\\"{x:1496,y:608,t:1526930517501};\\\", \\\"{x:1495,y:605,t:1526930517518};\\\", \\\"{x:1495,y:601,t:1526930517534};\\\", \\\"{x:1494,y:597,t:1526930517551};\\\", \\\"{x:1493,y:593,t:1526930517568};\\\", \\\"{x:1492,y:592,t:1526930517584};\\\", \\\"{x:1492,y:591,t:1526930517601};\\\", \\\"{x:1492,y:590,t:1526930517618};\\\", \\\"{x:1492,y:588,t:1526930517634};\\\", \\\"{x:1491,y:587,t:1526930517651};\\\", \\\"{x:1490,y:585,t:1526930517668};\\\", \\\"{x:1489,y:583,t:1526930517684};\\\", \\\"{x:1489,y:581,t:1526930517702};\\\", \\\"{x:1488,y:579,t:1526930517718};\\\", \\\"{x:1488,y:577,t:1526930517735};\\\", \\\"{x:1487,y:575,t:1526930517751};\\\", \\\"{x:1487,y:574,t:1526930517768};\\\", \\\"{x:1486,y:571,t:1526930517785};\\\", \\\"{x:1485,y:570,t:1526930517801};\\\", \\\"{x:1485,y:568,t:1526930517819};\\\", \\\"{x:1485,y:565,t:1526930517836};\\\", \\\"{x:1485,y:563,t:1526930517860};\\\", \\\"{x:1485,y:562,t:1526930517876};\\\", \\\"{x:1485,y:560,t:1526930517908};\\\", \\\"{x:1484,y:560,t:1526930518012};\\\", \\\"{x:1484,y:562,t:1526930518109};\\\", \\\"{x:1483,y:564,t:1526930518118};\\\", \\\"{x:1483,y:566,t:1526930518136};\\\", \\\"{x:1483,y:570,t:1526930518152};\\\", \\\"{x:1483,y:573,t:1526930518169};\\\", \\\"{x:1483,y:576,t:1526930518185};\\\", \\\"{x:1483,y:579,t:1526930518202};\\\", \\\"{x:1483,y:582,t:1526930518218};\\\", \\\"{x:1483,y:587,t:1526930518236};\\\", \\\"{x:1483,y:590,t:1526930518252};\\\", \\\"{x:1483,y:592,t:1526930518269};\\\", \\\"{x:1483,y:596,t:1526930518286};\\\", \\\"{x:1483,y:598,t:1526930518303};\\\", \\\"{x:1483,y:602,t:1526930518319};\\\", \\\"{x:1483,y:604,t:1526930518335};\\\", \\\"{x:1483,y:606,t:1526930518353};\\\", \\\"{x:1483,y:609,t:1526930518368};\\\", \\\"{x:1483,y:612,t:1526930518386};\\\", \\\"{x:1483,y:615,t:1526930518402};\\\", \\\"{x:1483,y:617,t:1526930518418};\\\", \\\"{x:1483,y:623,t:1526930518435};\\\", \\\"{x:1483,y:628,t:1526930518452};\\\", \\\"{x:1483,y:633,t:1526930518468};\\\", \\\"{x:1483,y:637,t:1526930518485};\\\", \\\"{x:1483,y:642,t:1526930518502};\\\", \\\"{x:1483,y:646,t:1526930518519};\\\", \\\"{x:1483,y:651,t:1526930518536};\\\", \\\"{x:1483,y:655,t:1526930518552};\\\", \\\"{x:1483,y:660,t:1526930518568};\\\", \\\"{x:1483,y:667,t:1526930518586};\\\", \\\"{x:1483,y:673,t:1526930518602};\\\", \\\"{x:1483,y:678,t:1526930518618};\\\", \\\"{x:1483,y:683,t:1526930518636};\\\", \\\"{x:1483,y:687,t:1526930518652};\\\", \\\"{x:1484,y:693,t:1526930518669};\\\", \\\"{x:1485,y:699,t:1526930518686};\\\", \\\"{x:1485,y:704,t:1526930518703};\\\", \\\"{x:1487,y:711,t:1526930518719};\\\", \\\"{x:1488,y:717,t:1526930518735};\\\", \\\"{x:1488,y:722,t:1526930518752};\\\", \\\"{x:1489,y:729,t:1526930518769};\\\", \\\"{x:1491,y:736,t:1526930518785};\\\", \\\"{x:1492,y:743,t:1526930518802};\\\", \\\"{x:1496,y:762,t:1526930518820};\\\", \\\"{x:1499,y:775,t:1526930518836};\\\", \\\"{x:1502,y:787,t:1526930518852};\\\", \\\"{x:1504,y:798,t:1526930518870};\\\", \\\"{x:1507,y:811,t:1526930518886};\\\", \\\"{x:1507,y:827,t:1526930518903};\\\", \\\"{x:1507,y:842,t:1526930518919};\\\", \\\"{x:1507,y:857,t:1526930518935};\\\", \\\"{x:1508,y:871,t:1526930518952};\\\", \\\"{x:1508,y:883,t:1526930518970};\\\", \\\"{x:1509,y:896,t:1526930518986};\\\", \\\"{x:1509,y:907,t:1526930519003};\\\", \\\"{x:1510,y:915,t:1526930519019};\\\", \\\"{x:1510,y:919,t:1526930519036};\\\", \\\"{x:1510,y:926,t:1526930519052};\\\", \\\"{x:1510,y:934,t:1526930519069};\\\", \\\"{x:1510,y:946,t:1526930519084};\\\", \\\"{x:1510,y:954,t:1526930519102};\\\", \\\"{x:1510,y:961,t:1526930519118};\\\", \\\"{x:1511,y:966,t:1526930519135};\\\", \\\"{x:1511,y:969,t:1526930519152};\\\", \\\"{x:1512,y:973,t:1526930519169};\\\", \\\"{x:1512,y:976,t:1526930519185};\\\", \\\"{x:1512,y:979,t:1526930519202};\\\", \\\"{x:1512,y:983,t:1526930519219};\\\", \\\"{x:1512,y:986,t:1526930519235};\\\", \\\"{x:1512,y:989,t:1526930519252};\\\", \\\"{x:1512,y:986,t:1526930519380};\\\", \\\"{x:1512,y:983,t:1526930519388};\\\", \\\"{x:1512,y:982,t:1526930519403};\\\", \\\"{x:1511,y:977,t:1526930519419};\\\", \\\"{x:1509,y:972,t:1526930519436};\\\", \\\"{x:1508,y:969,t:1526930519453};\\\", \\\"{x:1508,y:968,t:1526930519469};\\\", \\\"{x:1508,y:966,t:1526930519486};\\\", \\\"{x:1508,y:965,t:1526930519503};\\\", \\\"{x:1508,y:963,t:1526930519524};\\\", \\\"{x:1508,y:962,t:1526930519536};\\\", \\\"{x:1507,y:960,t:1526930519552};\\\", \\\"{x:1507,y:958,t:1526930519569};\\\", \\\"{x:1507,y:957,t:1526930519587};\\\", \\\"{x:1507,y:956,t:1526930519602};\\\", \\\"{x:1507,y:955,t:1526930519820};\\\", \\\"{x:1507,y:954,t:1526930519843};\\\", \\\"{x:1507,y:953,t:1526930519853};\\\", \\\"{x:1507,y:948,t:1526930519869};\\\", \\\"{x:1507,y:943,t:1526930519887};\\\", \\\"{x:1507,y:940,t:1526930519903};\\\", \\\"{x:1507,y:935,t:1526930519920};\\\", \\\"{x:1506,y:932,t:1526930519937};\\\", \\\"{x:1504,y:928,t:1526930519953};\\\", \\\"{x:1503,y:927,t:1526930519969};\\\", \\\"{x:1503,y:924,t:1526930519987};\\\", \\\"{x:1502,y:922,t:1526930520012};\\\", \\\"{x:1501,y:922,t:1526930520019};\\\", \\\"{x:1501,y:921,t:1526930520037};\\\", \\\"{x:1500,y:920,t:1526930520054};\\\", \\\"{x:1500,y:922,t:1526930520237};\\\", \\\"{x:1500,y:928,t:1526930520254};\\\", \\\"{x:1500,y:934,t:1526930520270};\\\", \\\"{x:1500,y:939,t:1526930520286};\\\", \\\"{x:1500,y:944,t:1526930520303};\\\", \\\"{x:1500,y:947,t:1526930520319};\\\", \\\"{x:1499,y:950,t:1526930520337};\\\", \\\"{x:1498,y:952,t:1526930520353};\\\", \\\"{x:1498,y:953,t:1526930520370};\\\", \\\"{x:1497,y:955,t:1526930520386};\\\", \\\"{x:1495,y:957,t:1526930520403};\\\", \\\"{x:1493,y:959,t:1526930520420};\\\", \\\"{x:1492,y:961,t:1526930520443};\\\", \\\"{x:1490,y:961,t:1526930520460};\\\", \\\"{x:1488,y:961,t:1526930520476};\\\", \\\"{x:1487,y:962,t:1526930520487};\\\", \\\"{x:1483,y:963,t:1526930520504};\\\", \\\"{x:1481,y:963,t:1526930520520};\\\", \\\"{x:1480,y:964,t:1526930520537};\\\", \\\"{x:1479,y:964,t:1526930520556};\\\", \\\"{x:1478,y:964,t:1526930520570};\\\", \\\"{x:1478,y:965,t:1526930520587};\\\", \\\"{x:1477,y:965,t:1526930520603};\\\", \\\"{x:1476,y:965,t:1526930520620};\\\", \\\"{x:1476,y:964,t:1526930520868};\\\", \\\"{x:1477,y:963,t:1526930520908};\\\", \\\"{x:1477,y:962,t:1526930520940};\\\", \\\"{x:1477,y:961,t:1526930520989};\\\", \\\"{x:1478,y:961,t:1526930521004};\\\", \\\"{x:1478,y:960,t:1526930521027};\\\", \\\"{x:1478,y:959,t:1526930521044};\\\", \\\"{x:1478,y:958,t:1526930521076};\\\", \\\"{x:1478,y:957,t:1526930521108};\\\", \\\"{x:1478,y:956,t:1526930521120};\\\", \\\"{x:1478,y:955,t:1526930521138};\\\", \\\"{x:1478,y:954,t:1526930521153};\\\", \\\"{x:1478,y:953,t:1526930521171};\\\", \\\"{x:1478,y:952,t:1526930521187};\\\", \\\"{x:1478,y:951,t:1526930521212};\\\", \\\"{x:1478,y:950,t:1526930521251};\\\", \\\"{x:1480,y:950,t:1526930521371};\\\", \\\"{x:1481,y:950,t:1526930521403};\\\", \\\"{x:1483,y:950,t:1526930521421};\\\", \\\"{x:1485,y:950,t:1526930521437};\\\", \\\"{x:1488,y:951,t:1526930521453};\\\", \\\"{x:1492,y:952,t:1526930521470};\\\", \\\"{x:1495,y:954,t:1526930521487};\\\", \\\"{x:1498,y:957,t:1526930521504};\\\", \\\"{x:1500,y:958,t:1526930521521};\\\", \\\"{x:1502,y:959,t:1526930521537};\\\", \\\"{x:1503,y:960,t:1526930521555};\\\", \\\"{x:1504,y:961,t:1526930521596};\\\", \\\"{x:1505,y:961,t:1526930521628};\\\", \\\"{x:1505,y:962,t:1526930521638};\\\", \\\"{x:1507,y:963,t:1526930521654};\\\", \\\"{x:1508,y:963,t:1526930521676};\\\", \\\"{x:1508,y:964,t:1526930521708};\\\", \\\"{x:1510,y:964,t:1526930521756};\\\", \\\"{x:1511,y:965,t:1526930521789};\\\", \\\"{x:1511,y:966,t:1526930521820};\\\", \\\"{x:1513,y:966,t:1526930521851};\\\", \\\"{x:1514,y:967,t:1526930521867};\\\", \\\"{x:1515,y:967,t:1526930521884};\\\", \\\"{x:1516,y:968,t:1526930521892};\\\", \\\"{x:1517,y:969,t:1526930521972};\\\", \\\"{x:1516,y:970,t:1526930522028};\\\", \\\"{x:1514,y:970,t:1526930522038};\\\", \\\"{x:1512,y:970,t:1526930522055};\\\", \\\"{x:1508,y:970,t:1526930522072};\\\", \\\"{x:1504,y:970,t:1526930522087};\\\", \\\"{x:1499,y:970,t:1526930522105};\\\", \\\"{x:1495,y:970,t:1526930522122};\\\", \\\"{x:1492,y:970,t:1526930522138};\\\", \\\"{x:1490,y:970,t:1526930522154};\\\", \\\"{x:1489,y:969,t:1526930522171};\\\", \\\"{x:1487,y:969,t:1526930522203};\\\", \\\"{x:1487,y:968,t:1526930522222};\\\", \\\"{x:1485,y:968,t:1526930522420};\\\", \\\"{x:1484,y:968,t:1526930522444};\\\", \\\"{x:1483,y:968,t:1526930522459};\\\", \\\"{x:1482,y:967,t:1526930522471};\\\", \\\"{x:1481,y:967,t:1526930522489};\\\", \\\"{x:1480,y:966,t:1526930522505};\\\", \\\"{x:1479,y:965,t:1526930522557};\\\", \\\"{x:1478,y:965,t:1526930522595};\\\", \\\"{x:1477,y:965,t:1526930522604};\\\", \\\"{x:1477,y:964,t:1526930522709};\\\", \\\"{x:1477,y:963,t:1526930522724};\\\", \\\"{x:1477,y:962,t:1526930522813};\\\", \\\"{x:1477,y:960,t:1526930522892};\\\", \\\"{x:1476,y:960,t:1526930522924};\\\", \\\"{x:1476,y:959,t:1526930523364};\\\", \\\"{x:1476,y:958,t:1526930523388};\\\", \\\"{x:1476,y:957,t:1526930523406};\\\", \\\"{x:1475,y:956,t:1526930523428};\\\", \\\"{x:1474,y:956,t:1526930523724};\\\", \\\"{x:1474,y:957,t:1526930523739};\\\", \\\"{x:1474,y:958,t:1526930523756};\\\", \\\"{x:1474,y:962,t:1526930523772};\\\", \\\"{x:1474,y:963,t:1526930523797};\\\", \\\"{x:1474,y:964,t:1526930523805};\\\", \\\"{x:1474,y:965,t:1526930523826};\\\", \\\"{x:1474,y:966,t:1526930523899};\\\", \\\"{x:1474,y:967,t:1526930523915};\\\", \\\"{x:1474,y:968,t:1526930523939};\\\", \\\"{x:1474,y:969,t:1526930524012};\\\", \\\"{x:1474,y:970,t:1526930524036};\\\", \\\"{x:1474,y:969,t:1526930524492};\\\", \\\"{x:1474,y:968,t:1526930524540};\\\", \\\"{x:1474,y:967,t:1526930524564};\\\", \\\"{x:1474,y:968,t:1526930524812};\\\", \\\"{x:1474,y:969,t:1526930524828};\\\", \\\"{x:1474,y:968,t:1526930524989};\\\", \\\"{x:1475,y:963,t:1526930525007};\\\", \\\"{x:1475,y:959,t:1526930525023};\\\", \\\"{x:1477,y:955,t:1526930525039};\\\", \\\"{x:1477,y:951,t:1526930525057};\\\", \\\"{x:1477,y:946,t:1526930525074};\\\", \\\"{x:1477,y:939,t:1526930525090};\\\", \\\"{x:1477,y:933,t:1526930525107};\\\", \\\"{x:1476,y:923,t:1526930525123};\\\", \\\"{x:1474,y:916,t:1526930525139};\\\", \\\"{x:1473,y:911,t:1526930525156};\\\", \\\"{x:1473,y:908,t:1526930525174};\\\", \\\"{x:1473,y:905,t:1526930525190};\\\", \\\"{x:1473,y:902,t:1526930525207};\\\", \\\"{x:1473,y:899,t:1526930525224};\\\", \\\"{x:1473,y:895,t:1526930525239};\\\", \\\"{x:1472,y:892,t:1526930525256};\\\", \\\"{x:1472,y:891,t:1526930525274};\\\", \\\"{x:1472,y:889,t:1526930525290};\\\", \\\"{x:1472,y:888,t:1526930525306};\\\", \\\"{x:1473,y:888,t:1526930525556};\\\", \\\"{x:1473,y:890,t:1526930525563};\\\", \\\"{x:1474,y:891,t:1526930525573};\\\", \\\"{x:1474,y:894,t:1526930525589};\\\", \\\"{x:1474,y:896,t:1526930525606};\\\", \\\"{x:1474,y:901,t:1526930525623};\\\", \\\"{x:1476,y:904,t:1526930525640};\\\", \\\"{x:1476,y:908,t:1526930525657};\\\", \\\"{x:1476,y:911,t:1526930525674};\\\", \\\"{x:1477,y:915,t:1526930525690};\\\", \\\"{x:1478,y:919,t:1526930525707};\\\", \\\"{x:1478,y:926,t:1526930525724};\\\", \\\"{x:1478,y:928,t:1526930525741};\\\", \\\"{x:1478,y:930,t:1526930525757};\\\", \\\"{x:1478,y:935,t:1526930525774};\\\", \\\"{x:1478,y:940,t:1526930525791};\\\", \\\"{x:1478,y:943,t:1526930525806};\\\", \\\"{x:1478,y:947,t:1526930525823};\\\", \\\"{x:1478,y:950,t:1526930525840};\\\", \\\"{x:1477,y:955,t:1526930525856};\\\", \\\"{x:1477,y:957,t:1526930525873};\\\", \\\"{x:1477,y:958,t:1526930525890};\\\", \\\"{x:1476,y:960,t:1526930525906};\\\", \\\"{x:1476,y:961,t:1526930525923};\\\", \\\"{x:1476,y:959,t:1526930526076};\\\", \\\"{x:1476,y:956,t:1526930526091};\\\", \\\"{x:1476,y:947,t:1526930526107};\\\", \\\"{x:1476,y:942,t:1526930526124};\\\", \\\"{x:1476,y:939,t:1526930526140};\\\", \\\"{x:1476,y:936,t:1526930526157};\\\", \\\"{x:1476,y:933,t:1526930526173};\\\", \\\"{x:1476,y:928,t:1526930526190};\\\", \\\"{x:1476,y:924,t:1526930526207};\\\", \\\"{x:1476,y:920,t:1526930526223};\\\", \\\"{x:1476,y:916,t:1526930526240};\\\", \\\"{x:1476,y:913,t:1526930526257};\\\", \\\"{x:1476,y:911,t:1526930526273};\\\", \\\"{x:1477,y:910,t:1526930526290};\\\", \\\"{x:1477,y:908,t:1526930526339};\\\", \\\"{x:1477,y:907,t:1526930526428};\\\", \\\"{x:1477,y:905,t:1526930526460};\\\", \\\"{x:1477,y:904,t:1526930526500};\\\", \\\"{x:1477,y:902,t:1526930526540};\\\", \\\"{x:1475,y:904,t:1526930526820};\\\", \\\"{x:1473,y:906,t:1526930526827};\\\", \\\"{x:1470,y:908,t:1526930526841};\\\", \\\"{x:1468,y:910,t:1526930526858};\\\", \\\"{x:1464,y:910,t:1526930526875};\\\", \\\"{x:1461,y:912,t:1526930526891};\\\", \\\"{x:1454,y:912,t:1526930526907};\\\", \\\"{x:1451,y:912,t:1526930526924};\\\", \\\"{x:1447,y:912,t:1526930526941};\\\", \\\"{x:1445,y:912,t:1526930526958};\\\", \\\"{x:1443,y:912,t:1526930526975};\\\", \\\"{x:1441,y:912,t:1526930527004};\\\", \\\"{x:1440,y:912,t:1526930527028};\\\", \\\"{x:1439,y:911,t:1526930527041};\\\", \\\"{x:1437,y:909,t:1526930527057};\\\", \\\"{x:1434,y:908,t:1526930527075};\\\", \\\"{x:1433,y:908,t:1526930527140};\\\", \\\"{x:1433,y:907,t:1526930527156};\\\", \\\"{x:1432,y:906,t:1526930527172};\\\", \\\"{x:1431,y:906,t:1526930527188};\\\", \\\"{x:1430,y:905,t:1526930527196};\\\", \\\"{x:1429,y:904,t:1526930527227};\\\", \\\"{x:1428,y:903,t:1526930527242};\\\", \\\"{x:1427,y:902,t:1526930527258};\\\", \\\"{x:1425,y:900,t:1526930527300};\\\", \\\"{x:1424,y:900,t:1526930527324};\\\", \\\"{x:1424,y:899,t:1526930527341};\\\", \\\"{x:1422,y:899,t:1526930527363};\\\", \\\"{x:1420,y:896,t:1526930527636};\\\", \\\"{x:1418,y:894,t:1526930527652};\\\", \\\"{x:1418,y:892,t:1526930527668};\\\", \\\"{x:1417,y:892,t:1526930527675};\\\", \\\"{x:1416,y:891,t:1526930527692};\\\", \\\"{x:1415,y:889,t:1526930527708};\\\", \\\"{x:1415,y:888,t:1526930527725};\\\", \\\"{x:1415,y:887,t:1526930527755};\\\", \\\"{x:1418,y:887,t:1526930527884};\\\", \\\"{x:1423,y:890,t:1526930527892};\\\", \\\"{x:1431,y:894,t:1526930527909};\\\", \\\"{x:1442,y:901,t:1526930527924};\\\", \\\"{x:1450,y:908,t:1526930527942};\\\", \\\"{x:1462,y:916,t:1526930527958};\\\", \\\"{x:1468,y:922,t:1526930527975};\\\", \\\"{x:1476,y:930,t:1526930527992};\\\", \\\"{x:1479,y:933,t:1526930528009};\\\", \\\"{x:1484,y:940,t:1526930528025};\\\", \\\"{x:1485,y:947,t:1526930528042};\\\", \\\"{x:1488,y:954,t:1526930528059};\\\", \\\"{x:1489,y:959,t:1526930528075};\\\", \\\"{x:1489,y:966,t:1526930528091};\\\", \\\"{x:1489,y:970,t:1526930528109};\\\", \\\"{x:1489,y:974,t:1526930528125};\\\", \\\"{x:1489,y:978,t:1526930528142};\\\", \\\"{x:1489,y:980,t:1526930528158};\\\", \\\"{x:1489,y:981,t:1526930528176};\\\", \\\"{x:1489,y:982,t:1526930528191};\\\", \\\"{x:1489,y:983,t:1526930528220};\\\", \\\"{x:1489,y:982,t:1526930528348};\\\", \\\"{x:1489,y:980,t:1526930528363};\\\", \\\"{x:1489,y:977,t:1526930528376};\\\", \\\"{x:1489,y:974,t:1526930528391};\\\", \\\"{x:1489,y:969,t:1526930528409};\\\", \\\"{x:1489,y:967,t:1526930528426};\\\", \\\"{x:1489,y:965,t:1526930528442};\\\", \\\"{x:1488,y:960,t:1526930528459};\\\", \\\"{x:1488,y:957,t:1526930528476};\\\", \\\"{x:1488,y:955,t:1526930528491};\\\", \\\"{x:1488,y:953,t:1526930528509};\\\", \\\"{x:1488,y:952,t:1526930528525};\\\", \\\"{x:1488,y:949,t:1526930528542};\\\", \\\"{x:1488,y:946,t:1526930528559};\\\", \\\"{x:1488,y:943,t:1526930528576};\\\", \\\"{x:1488,y:940,t:1526930528592};\\\", \\\"{x:1488,y:937,t:1526930528609};\\\", \\\"{x:1488,y:935,t:1526930528626};\\\", \\\"{x:1488,y:932,t:1526930528642};\\\", \\\"{x:1488,y:927,t:1526930528659};\\\", \\\"{x:1485,y:919,t:1526930528676};\\\", \\\"{x:1484,y:913,t:1526930528693};\\\", \\\"{x:1480,y:905,t:1526930528709};\\\", \\\"{x:1478,y:895,t:1526930528726};\\\", \\\"{x:1471,y:880,t:1526930528743};\\\", \\\"{x:1468,y:869,t:1526930528759};\\\", \\\"{x:1462,y:855,t:1526930528776};\\\", \\\"{x:1459,y:842,t:1526930528793};\\\", \\\"{x:1459,y:833,t:1526930528809};\\\", \\\"{x:1458,y:828,t:1526930528826};\\\", \\\"{x:1458,y:822,t:1526930528842};\\\", \\\"{x:1458,y:817,t:1526930528859};\\\", \\\"{x:1458,y:812,t:1526930528875};\\\", \\\"{x:1458,y:809,t:1526930528893};\\\", \\\"{x:1460,y:805,t:1526930528909};\\\", \\\"{x:1460,y:802,t:1526930528926};\\\", \\\"{x:1462,y:798,t:1526930528942};\\\", \\\"{x:1463,y:794,t:1526930528959};\\\", \\\"{x:1465,y:791,t:1526930528976};\\\", \\\"{x:1467,y:788,t:1526930528993};\\\", \\\"{x:1469,y:785,t:1526930529009};\\\", \\\"{x:1471,y:783,t:1526930529026};\\\", \\\"{x:1473,y:780,t:1526930529043};\\\", \\\"{x:1474,y:779,t:1526930529059};\\\", \\\"{x:1475,y:778,t:1526930529076};\\\", \\\"{x:1477,y:776,t:1526930529093};\\\", \\\"{x:1478,y:774,t:1526930529109};\\\", \\\"{x:1481,y:771,t:1526930529126};\\\", \\\"{x:1483,y:768,t:1526930529143};\\\", \\\"{x:1484,y:767,t:1526930529158};\\\", \\\"{x:1485,y:766,t:1526930529176};\\\", \\\"{x:1486,y:764,t:1526930529193};\\\", \\\"{x:1486,y:763,t:1526930529340};\\\", \\\"{x:1487,y:761,t:1526930529356};\\\", \\\"{x:1487,y:760,t:1526930529404};\\\", \\\"{x:1487,y:759,t:1526930529411};\\\", \\\"{x:1486,y:758,t:1526930529460};\\\", \\\"{x:1485,y:758,t:1526930529580};\\\", \\\"{x:1484,y:758,t:1526930529604};\\\", \\\"{x:1483,y:758,t:1526930529627};\\\", \\\"{x:1482,y:758,t:1526930529642};\\\", \\\"{x:1481,y:758,t:1526930529659};\\\", \\\"{x:1480,y:758,t:1526930529676};\\\", \\\"{x:1478,y:759,t:1526930529706};\\\", \\\"{x:1477,y:759,t:1526930529747};\\\", \\\"{x:1475,y:759,t:1526930529778};\\\", \\\"{x:1474,y:759,t:1526930529876};\\\", \\\"{x:1474,y:760,t:1526930529947};\\\", \\\"{x:1473,y:761,t:1526930530468};\\\", \\\"{x:1473,y:762,t:1526930530572};\\\", \\\"{x:1473,y:761,t:1526930531628};\\\", \\\"{x:1473,y:760,t:1526930531692};\\\", \\\"{x:1473,y:759,t:1526930531707};\\\", \\\"{x:1473,y:758,t:1526930531844};\\\", \\\"{x:1474,y:758,t:1526930532092};\\\", \\\"{x:1476,y:758,t:1526930532124};\\\", \\\"{x:1477,y:758,t:1526930532139};\\\", \\\"{x:1478,y:758,t:1526930532147};\\\", \\\"{x:1479,y:758,t:1526930532187};\\\", \\\"{x:1480,y:758,t:1526930532260};\\\", \\\"{x:1481,y:758,t:1526930532556};\\\", \\\"{x:1481,y:756,t:1526930532564};\\\", \\\"{x:1480,y:755,t:1526930532580};\\\", \\\"{x:1480,y:752,t:1526930532596};\\\", \\\"{x:1480,y:750,t:1526930532611};\\\", \\\"{x:1480,y:749,t:1526930532628};\\\", \\\"{x:1480,y:748,t:1526930532645};\\\", \\\"{x:1480,y:745,t:1526930532662};\\\", \\\"{x:1480,y:744,t:1526930532678};\\\", \\\"{x:1480,y:742,t:1526930532695};\\\", \\\"{x:1480,y:739,t:1526930532712};\\\", \\\"{x:1480,y:737,t:1526930532728};\\\", \\\"{x:1480,y:734,t:1526930532745};\\\", \\\"{x:1480,y:733,t:1526930532762};\\\", \\\"{x:1480,y:730,t:1526930532778};\\\", \\\"{x:1480,y:728,t:1526930532795};\\\", \\\"{x:1480,y:726,t:1526930532812};\\\", \\\"{x:1480,y:723,t:1526930532829};\\\", \\\"{x:1480,y:721,t:1526930532845};\\\", \\\"{x:1480,y:720,t:1526930532868};\\\", \\\"{x:1480,y:718,t:1526930532884};\\\", \\\"{x:1480,y:717,t:1526930532907};\\\", \\\"{x:1480,y:715,t:1526930532948};\\\", \\\"{x:1480,y:714,t:1526930532971};\\\", \\\"{x:1480,y:713,t:1526930532979};\\\", \\\"{x:1480,y:712,t:1526930532995};\\\", \\\"{x:1480,y:711,t:1526930533012};\\\", \\\"{x:1480,y:709,t:1526930533043};\\\", \\\"{x:1479,y:708,t:1526930533068};\\\", \\\"{x:1479,y:707,t:1526930533132};\\\", \\\"{x:1479,y:706,t:1526930533164};\\\", \\\"{x:1478,y:704,t:1526930533244};\\\", \\\"{x:1478,y:703,t:1526930533308};\\\", \\\"{x:1478,y:702,t:1526930533323};\\\", \\\"{x:1478,y:701,t:1526930533355};\\\", \\\"{x:1478,y:700,t:1526930533387};\\\", \\\"{x:1478,y:699,t:1526930533764};\\\", \\\"{x:1478,y:698,t:1526930534036};\\\", \\\"{x:1478,y:697,t:1526930534132};\\\", \\\"{x:1478,y:696,t:1526930534164};\\\", \\\"{x:1476,y:695,t:1526930535818};\\\", \\\"{x:1468,y:696,t:1526930535829};\\\", \\\"{x:1439,y:712,t:1526930535846};\\\", \\\"{x:1389,y:736,t:1526930535864};\\\", \\\"{x:1329,y:757,t:1526930535879};\\\", \\\"{x:1269,y:770,t:1526930535897};\\\", \\\"{x:1220,y:782,t:1526930535913};\\\", \\\"{x:1181,y:787,t:1526930535930};\\\", \\\"{x:1125,y:792,t:1526930535947};\\\", \\\"{x:1081,y:796,t:1526930535963};\\\", \\\"{x:1027,y:804,t:1526930535980};\\\", \\\"{x:968,y:816,t:1526930535997};\\\", \\\"{x:888,y:825,t:1526930536014};\\\", \\\"{x:814,y:839,t:1526930536030};\\\", \\\"{x:731,y:848,t:1526930536046};\\\", \\\"{x:658,y:852,t:1526930536063};\\\", \\\"{x:597,y:852,t:1526930536080};\\\", \\\"{x:542,y:848,t:1526930536096};\\\", \\\"{x:506,y:833,t:1526930536114};\\\", \\\"{x:466,y:813,t:1526930536130};\\\", \\\"{x:450,y:802,t:1526930536146};\\\", \\\"{x:442,y:793,t:1526930536163};\\\", \\\"{x:436,y:783,t:1526930536181};\\\", \\\"{x:432,y:774,t:1526930536198};\\\", \\\"{x:425,y:767,t:1526930536214};\\\", \\\"{x:422,y:763,t:1526930536231};\\\", \\\"{x:420,y:759,t:1526930536246};\\\", \\\"{x:418,y:755,t:1526930536264};\\\", \\\"{x:416,y:751,t:1526930536281};\\\", \\\"{x:414,y:745,t:1526930536296};\\\", \\\"{x:413,y:743,t:1526930536314};\\\", \\\"{x:413,y:742,t:1526930536330};\\\", \\\"{x:413,y:741,t:1526930536371};\\\", \\\"{x:413,y:740,t:1526930536395};\\\", \\\"{x:417,y:740,t:1526930536403};\\\", \\\"{x:423,y:740,t:1526930536413};\\\", \\\"{x:439,y:740,t:1526930536431};\\\", \\\"{x:456,y:745,t:1526930536447};\\\", \\\"{x:473,y:750,t:1526930536464};\\\", \\\"{x:487,y:753,t:1526930536480};\\\", \\\"{x:495,y:755,t:1526930536498};\\\", \\\"{x:502,y:758,t:1526930536514};\\\", \\\"{x:503,y:758,t:1526930536539};\\\", \\\"{x:504,y:758,t:1526930536760};\\\", \\\"{x:504,y:757,t:1526930536890};\\\", \\\"{x:504,y:756,t:1526930536939};\\\", \\\"{x:504,y:755,t:1526930536955};\\\", \\\"{x:504,y:754,t:1526930536971};\\\", \\\"{x:504,y:755,t:1526930537284};\\\", \\\"{x:499,y:763,t:1526930537299};\\\", \\\"{x:491,y:772,t:1526930537316};\\\", \\\"{x:480,y:783,t:1526930537334};\\\", \\\"{x:461,y:799,t:1526930537350};\\\", \\\"{x:431,y:820,t:1526930537367};\\\", \\\"{x:381,y:853,t:1526930537384};\\\", \\\"{x:326,y:899,t:1526930537401};\\\", \\\"{x:267,y:946,t:1526930537417};\\\", \\\"{x:192,y:996,t:1526930537433};\\\", \\\"{x:114,y:1060,t:1526930537451};\\\", \\\"{x:102,y:1069,t:1526930537467};\\\", \\\"{x:80,y:1097,t:1526930537483};\\\", \\\"{x:76,y:1107,t:1526930537501};\\\", \\\"{x:75,y:1110,t:1526930537517};\\\", \\\"{x:74,y:1111,t:1526930537534};\\\", \\\"{x:74,y:1112,t:1526930537551};\\\", \\\"{x:74,y:1113,t:1526930537579};\\\" ] }, { \\\"rt\\\": 25359, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 913338, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"By looking at the X axis of the graph\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8510, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 922854, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 18207, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 942086, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 4612, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 947789, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"X9PTQ\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"X9PTQ\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 389, dom: 982, initialDom: 1120",
  "javascriptErrors": []
}