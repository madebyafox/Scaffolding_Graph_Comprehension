var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a94eed4c51171bb693b092705a28964a",
  "created": "2018-05-15T14:13:39.9818234-07:00",
  "lastActivity": "2018-05-15T14:16:19.8259014-07:00",
  "pageViews": [
    {
      "id": "051540744b6ddfdaffa25e9269c5af7230d768f0",
      "startTime": "2018-05-15T14:13:40.0619014-07:00",
      "endTime": "2018-05-15T14:16:19.8259014-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 159764,
      "engagementTime": 122961,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 159764,
  "engagementTime": 122961,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=XX1TE",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2fb0ec5c8f4b477bffd82a1eaceea5a3",
  "gdpr": false
}