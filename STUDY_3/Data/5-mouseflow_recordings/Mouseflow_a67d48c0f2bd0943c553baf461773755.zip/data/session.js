var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a67d48c0f2bd0943c553baf461773755",
  "created": "2018-05-24T12:06:15.2101894-07:00",
  "lastActivity": "2018-05-24T12:07:12.5948299-07:00",
  "pageViews": [
    {
      "id": "05241544f8145887b6a0838a66c8d43040d074eb",
      "startTime": "2018-05-24T12:06:15.3288299-07:00",
      "endTime": "2018-05-24T12:07:12.5948299-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 57266,
      "engagementTime": 42400,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 57266,
  "engagementTime": 42400,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XKNWZ",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "dde52d4ae42e8e82a96bef854f91b020",
  "gdpr": false
}