var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "09ee37423b41d0c7675ff710e70369f0",
  "created": "2018-05-25T10:08:22.0344406-07:00",
  "lastActivity": "2018-05-25T10:08:37.1691744-07:00",
  "pageViews": [
    {
      "id": "0525227699f6006cc4ce54cfd935d69dba7817c0",
      "startTime": "2018-05-25T10:08:22.1750718-07:00",
      "endTime": "2018-05-25T10:08:37.1691744-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 15095,
      "engagementTime": 15095,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15095,
  "engagementTime": 15095,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=W8QKU",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "828af0a2bf5acdcc2cbf0caae7838a10",
  "gdpr": false
}