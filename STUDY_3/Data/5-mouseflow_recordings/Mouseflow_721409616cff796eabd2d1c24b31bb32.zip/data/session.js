var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "721409616cff796eabd2d1c24b31bb32",
  "created": "2018-05-18T11:21:26.4963264-07:00",
  "lastActivity": "2018-05-18T11:22:09.8923264-07:00",
  "pageViews": [
    {
      "id": "05182772ed09a924a8663fca7f3dfcce8a98dccb",
      "startTime": "2018-05-18T11:21:26.4963264-07:00",
      "endTime": "2018-05-18T11:22:09.8923264-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 43396,
      "engagementTime": 16992,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 43396,
  "engagementTime": 16992,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OY8PV",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1db166ce71f6b1341fa32118907ae3eb",
  "gdpr": false
}