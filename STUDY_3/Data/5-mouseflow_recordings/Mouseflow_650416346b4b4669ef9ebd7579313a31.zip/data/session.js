var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "650416346b4b4669ef9ebd7579313a31",
  "created": "2018-06-04T12:23:42.6866172-07:00",
  "lastActivity": "2018-06-04T12:24:23.6966172-07:00",
  "pageViews": [
    {
      "id": "0604422696ed493c7a863dd4a67a3aa27589d2fc",
      "startTime": "2018-06-04T12:23:42.6866172-07:00",
      "endTime": "2018-06-04T12:24:23.6966172-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 41010,
      "engagementTime": 40860,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 41010,
  "engagementTime": 40860,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=74OF5",
    "CONDITION=311\n311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "418ed531fcca3831a6d241df2d6f660d",
  "gdpr": false
}