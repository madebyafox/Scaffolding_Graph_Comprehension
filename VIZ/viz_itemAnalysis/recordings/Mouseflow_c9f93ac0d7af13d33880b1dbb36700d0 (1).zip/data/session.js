var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c9f93ac0d7af13d33880b1dbb36700d0",
  "created": "2017-11-30T10:10:28.0144684-08:00",
  "lastActivity": "2017-11-30T10:11:03.9484684-08:00",
  "pageViews": [
    {
      "id": "113027787b79927da9bb45cd1967c31adc66e5b1",
      "startTime": "2017-11-30T10:10:28.0144684-08:00",
      "endTime": "2017-11-30T10:11:03.9484684-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 35934,
      "engagementTime": 27284,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 35934,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PO9J4",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "fcb1af646e79744bc550bdb55b43e312",
  "gdpr": false
}